-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2018 at 06:46 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `c5z13x`
--
CREATE DATABASE IF NOT EXISTS `c5z13x` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `c5z13x`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_category`
--

CREATE TABLE `admin_category` (
  `cid` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `description` varchar(254) NOT NULL,
  `sortorder` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_category`
--

INSERT INTO `admin_category` (`cid`, `name`, `description`, `sortorder`) VALUES
(1, 'System', 'Core modules at the heart of operation of the site.', 0),
(2, 'Layout', 'Layout modules for controlling the site\'s look and feel.', 0),
(3, 'Users', 'Modules for controlling user membership, access rights and profiles.', 0),
(4, 'Content', 'Modules for providing content to your users.', 0),
(5, 'CityPilot', 'CityPilot system', 0),
(6, 'Security', 'Modules for managing the site\'s security.', 0),
(7, 'New modules', 'Newly-installed or uncategorized modules.', 6);

-- --------------------------------------------------------

--
-- Table structure for table `admin_module`
--

CREATE TABLE `admin_module` (
  `amid` int(11) NOT NULL,
  `mid` int(11) NOT NULL DEFAULT '0',
  `cid` int(11) NOT NULL DEFAULT '0',
  `sortorder` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_module`
--

INSERT INTO `admin_module` (`amid`, `mid`, `cid`, `sortorder`) VALUES
(1, 1, 1, 5),
(2, 12, 1, 5),
(3, 13, 2, 2),
(4, 2, 1, 5),
(5, 9, 3, 3),
(6, 6, 3, 3),
(7, 3, 2, 2),
(8, 14, 3, 3),
(9, 11, 6, 1),
(10, 4, 4, 5),
(11, 16, 4, 5),
(12, 7, 1, 5),
(13, 5, 1, 4),
(14, 10, 4, 5),
(15, 17, 5, 0),
(16, 19, 5, 1),
(17, 21, 7, 5),
(18, 22, 5, 14),
(19, 23, 5, 14),
(20, 24, 5, 14),
(21, 26, 7, 5),
(22, 27, 5, 7),
(23, 28, 5, 14),
(24, 29, 5, 9),
(25, 32, 5, 14),
(26, 33, 5, 14),
(27, 34, 5, 14),
(28, 18, 5, 14),
(29, 36, 5, 14),
(30, 15, 4, 5),
(31, 37, 4, 5),
(32, 38, 5, 14),
(33, 39, 7, 2),
(34, 40, 7, 3),
(35, 41, 5, 14),
(36, 42, 7, 4),
(37, 43, 7, 5),
(38, 44, 7, 6),
(39, 45, 7, 7),
(40, 46, 7, 8),
(41, 47, 7, 9),
(42, 48, 7, 10),
(43, 49, 7, 11),
(44, 50, 7, 12);

-- --------------------------------------------------------

--
-- Table structure for table `block_placements`
--

CREATE TABLE `block_placements` (
  `pid` int(11) NOT NULL DEFAULT '0',
  `bid` int(11) NOT NULL DEFAULT '0',
  `sortorder` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `block_placements`
--

INSERT INTO `block_placements` (`pid`, `bid`, `sortorder`) VALUES
(1, 1, 0),
(9, 41, 4),
(7, 5, 0),
(2, 4, 6),
(12, 24, 9),
(9, 15, 3),
(10, 17, 0),
(9, 3, 2),
(12, 22, 8),
(9, 36, 1),
(12, 50, 7),
(11, 23, 0),
(12, 46, 6),
(13, 25, 0),
(19, 26, 0),
(15, 27, 0),
(21, 28, 0),
(20, 29, 0),
(1, 30, 0),
(23, 31, 0),
(24, 32, 0),
(25, 33, 0),
(26, 34, 0),
(53, 74, 0),
(12, 45, 5),
(27, 40, 0),
(28, 43, 0),
(29, 44, 0),
(12, 38, 4),
(12, 35, 3),
(30, 47, 0),
(31, 49, 0),
(12, 20, 2),
(32, 51, 0),
(32, 52, 0),
(12, 55, 1),
(66, 80, 0),
(12, 54, 0),
(34, 57, 0),
(27, 58, 0),
(35, 59, 0),
(36, 61, 1),
(36, 60, 0),
(39, 63, 0),
(38, 64, 0),
(42, 65, 0),
(45, 66, 0),
(46, 67, 0),
(47, 68, 0),
(48, 69, 0),
(34, 14, 0),
(49, 56, 0),
(44, 70, 0),
(50, 71, 0),
(51, 72, 0),
(52, 73, 0),
(54, 48, 0),
(71, 110, 0),
(56, 77, 0),
(55, 109, 0),
(58, 79, 0),
(61, 82, 0),
(63, 84, 0),
(64, 85, 0),
(65, 76, 0),
(67, 86, 0),
(68, 87, 0),
(69, 88, 0),
(71, 90, 0),
(74, 92, 0),
(75, 93, 0),
(80, 101, 0),
(61, 102, 0),
(77, 107, 0),
(79, 108, 0),
(69, 111, 0),
(83, 112, 0),
(84, 113, 0),
(40, 114, 0),
(85, 115, 0);

-- --------------------------------------------------------

--
-- Table structure for table `block_positions`
--

CREATE TABLE `block_positions` (
  `pid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `block_positions`
--

INSERT INTO `block_positions` (`pid`, `name`, `description`) VALUES
(1, 'left', 'Left blocks'),
(2, 'right', 'Right blocks'),
(3, 'center', 'Center blocks'),
(4, 'search', 'Search block'),
(5, 'header', 'Header block'),
(6, 'footer', 'Footer block'),
(7, 'topnav', 'Top navigation block'),
(8, 'bottomnav', 'Bottom navigation block'),
(9, 'center-home', 'center home position'),
(10, 'newslist-top', 'top news'),
(11, 'top-menu', 'top menu'),
(12, 'right-home', ''),
(13, 'bot-menu', ''),
(14, 'bot-content', ''),
(15, 'newslist-bot', 'news in the bottom section'),
(16, 'bot-address1', ''),
(17, 'bot-address2', ''),
(18, 'bot-address3', ''),
(19, 'bot-logo', 'log in the bottom section'),
(20, 'bot-copyright', ''),
(21, 'top-logo', ''),
(22, 'login-front', 'login block for acta-it theme'),
(23, 'login-top-actait', 'login for acta it'),
(24, 'ZSELEX-shop-service', 'shop service menu'),
(25, 'ZSELEX-minisite-products', 'displaying shop products in miniwebsite'),
(26, 'ZSELEX-minishop-products', 'displaying shop products in minishop'),
(27, 'gallery', 'diaply shop image gallery'),
(28, 'language-block', 'language selector block'),
(29, 'very-top-menu', ''),
(30, 'shop-articles', 'display shop articles'),
(31, 'googlemapzselex', ''),
(32, 'minisite-right', 'right block display in minisite page'),
(33, 'minisite-left', ''),
(34, 'selectionbox', ''),
(35, 'zmap-center', ''),
(36, 'zmap-right', ''),
(37, 'verytop-left', 'CityPilot'),
(38, 'verytop-right', 'CityPilot'),
(39, 'top-left', 'CityPilot'),
(40, 'top-center', 'CityPilot'),
(41, 'top-right', 'CityPilot'),
(42, 'bot1-left', 'CityPilot'),
(43, 'bot1-center', 'CityPilot'),
(44, 'bot1-right', 'CityPilot'),
(45, 'bot2-01', 'CityPilot'),
(46, 'bot2-02', 'CityPilot'),
(47, 'bot2-03', 'CityPilot'),
(48, 'bot2-04', 'CityPilot'),
(49, 'upcomming-events', ''),
(50, 'specialdeals', ''),
(51, 'citypilotheader', ''),
(52, 'citypilotfooter', ''),
(53, 'shopaddress', ''),
(54, 'minisite-googlemap', ''),
(55, 'minisitemenu', ''),
(56, 'newshops', 'newshops'),
(57, 'lowertopmenu', ''),
(58, 'yourservices', 'ZSELEX simple innerview'),
(61, 'backendmsg-right', 'ZSELEX Backend Message Right'),
(63, 'backendguide-right', 'ZSELEX Backend Guide Right'),
(64, 'backendstats-right', 'ZSELEX backend stats block right'),
(65, 'minisite-event', ''),
(66, 'ministe-images', ''),
(67, 'minisite-banner', ''),
(68, 'minisite-announcement', ''),
(69, 'employees', ''),
(71, 'backendmenu', 'ZSELEX backend menu'),
(74, 'shopadmin-settings', 'ZSELEX shopsettings link to backend'),
(75, 'shopadmin-events', 'ZSELEX eventssettings link to backend'),
(76, 'shopadmin-products', 'ZSELEX products settings link to backend'),
(77, 'shopsummary-menu', 'ZSELEX backend \"My Page\"'),
(78, 'shopsites-menu', 'ZSELEX backend \"My Sites\"'),
(79, 'shopservices-menu', 'ZSELEX backend \"My Services\"'),
(80, 'exclusive_events', ''),
(81, 'zvelo-left', ''),
(82, 'zvelo-right', ''),
(83, 'page-index', ''),
(84, 'sociallinks', 'sociallinks'),
(85, 'follow-us', 'Follow us block for Responsive Theme');

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE `blocks` (
  `bid` int(11) NOT NULL,
  `bkey` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `content` longtext NOT NULL,
  `url` longtext NOT NULL,
  `mid` int(11) NOT NULL DEFAULT '0',
  `filter` longtext NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `collapsable` int(11) NOT NULL DEFAULT '1',
  `defaultstate` int(11) NOT NULL DEFAULT '1',
  `refresh` int(11) NOT NULL DEFAULT '0',
  `last_update` datetime NOT NULL,
  `language` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`bid`, `bkey`, `title`, `description`, `content`, `url`, `mid`, `filter`, `active`, `collapsable`, `defaultstate`, `refresh`, `last_update`, `language`) VALUES
(1, 'Extmenu', 'Main menu', 'Main menu', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:24:\"blocks_block_extmenu.tpl\";s:11:\"blocktitles\";a:1:{s:2:\"en\";s:9:\"Main menu\";}s:5:\"links\";a:1:{s:2:\"en\";a:7:{i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:4:\"Home\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:19:\"Go to the home page\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:14:\"Administration\";s:3:\"url\";s:24:\"{Admin:admin:adminpanel}\";s:5:\"title\";s:29:\"Go to the site administration\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:10:\"My Account\";s:3:\"url\";s:7:\"{Users}\";s:5:\"title\";s:24:\"Go to your account panel\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:7:\"Log out\";s:3:\"url\";s:19:\"{Users:user:logout}\";s:5:\"title\";s:20:\"Log out of this site\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:4;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:11:\"Site search\";s:3:\"url\";s:8:\"{Search}\";s:5:\"title\";s:16:\"Search this site\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:5;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:19:\"Shop Administration\";s:3:\"url\";s:23:\"{Zselex:admin:viewshop}\";s:5:\"title\";s:19:\"shop administration\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:6;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:4:\"Cart\";s:3:\"url\";s:18:\"{Zselex:user:cart}\";s:5:\"title\";s:4:\"Cart\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";N;}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2012-02-13 12:54:04', ''),
(2, 'Search', 'Search box', 'Search block', 'a:2:{s:16:\"displaySearchBtn\";i:1;s:6:\"active\";a:6:{s:5:\"Users\";i:1;s:4:\"News\";i:1;s:3:\"FAQ\";i:1;s:7:\"Content\";i:1;s:4:\"Clip\";i:1;s:5:\"Zvelo\";i:1;}}', '', 10, 's:7:\"s:0:\"\";\";', 1, 1, 1, 3600, '2014-08-07 08:38:56', ''),
(3, 'Html', 'This site is powered by Zikula!', 'HTML block', '<p><a href=\"http://zikula.org/\">Zikula</a> is a content management system (CMS) and application framework. It is secure and stable, and is a good choice for sites with a large volume of traffic.</p><p>With Zikula:</p><ul><li>you can customise all aspects of the site\'s appearance through themes, with support for CSS style sheets, JavaScript, Flash and all other modern web development technologies;</li><li>you can mark content as being suitable for either a single language or for all languages, and can control all aspects of localisation and internationalisation of your site;</li><li>you can be sure that your pages will display properly in all browsers, thanks to Zikula\'s full compliance with W3C HTML standards;</li><li>you get a standard application-programming interface (API) that lets you easily augment your site\'s functionality through modules, blocks and other extensions;</li><li>you can get help and support from the Zikula community of webmasters and developers at <a href=\"http://www.zikula.org\">zikula.org</a>.</li></ul><p>Enjoy using Zikula!</p><p><strong>The Zikula team</strong></p><p><em>Note: Zikula is Free Open Source Software (FOSS) licensed under the GNU General Public License.</em></p>', '', 3, 'a:0:{}', 0, 0, 1, 3600, '2013-04-26 16:23:23', ''),
(4, 'Login', 'User log-in', 'Login block', '', '', 14, 'a:0:{}', 1, 1, 1, 3600, '2012-02-13 12:54:04', ''),
(5, 'Extmenu', 'topnavblock', 'Theme navigation', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:31:\"blocks_block_extmenu_topnav.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"en\";s:14:\"Top navigation\";s:2:\"da\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"en\";a:2:{i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:4:\"Home\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:26:\"Go to the site\'s home page\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:10:\"My Account\";s:3:\"url\";s:7:\"{Users}\";s:5:\"title\";s:24:\"Go to your account panel\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}s:2:\"da\";a:2:{i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:4:\"Home\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:26:\"Go to the site\'s home page\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:10:\"My Account\";s:3:\"url\";s:7:\"{Users}\";s:5:\"title\";s:24:\"Go to your account panel\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-04-18 12:25:48', ''),
(14, 'Selection', 'selection box', '', 'a:6:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:4:\"shop\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:7:\"orderby\";s:0:\"\";s:11:\"displayinfo\";s:2:\"no\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-05-29 15:00:34', ''),
(15, 'Centerblockproducts', 'Product Display', '', '', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2012-03-05 17:53:49', 'en'),
(36, 'Shopdisplay', 'Shops Listing', '', 'a:3:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:1:\"5\";s:7:\"orderby\";s:6:\"random\";}', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2012-10-31 13:24:17', ''),
(17, 'Frontpagedisplay', 'KeepRunning News', '', 'a:28:{s:4:\"show\";i:1;s:8:\"category\";a:1:{s:4:\"Main\";a:9:{i:0;s:2:\"33\";i:1;s:2:\"34\";i:2;s:2:\"35\";i:3;s:2:\"36\";i:4;s:2:\"37\";i:5;s:2:\"38\";i:6;s:2:\"39\";i:7;s:2:\"40\";i:8;s:2:\"41\";}}s:5:\"limit\";i:3;s:6:\"status\";i:0;s:5:\"order\";i:3;s:9:\"dayslimit\";i:0;s:14:\"maxtitlelength\";i:0;s:12:\"titlewraptxt\";s:3:\"...\";s:15:\"showemptyresult\";b:0;s:13:\"blocktemplate\";s:0:\"\";s:11:\"rowtemplate\";s:0:\"\";s:9:\"dispuname\";b:0;s:8:\"dispdate\";b:1;s:10:\"dateformat\";s:2:\"%x\";s:9:\"dispreads\";b:0;s:12:\"dispcomments\";b:0;s:13:\"dispsplitchar\";s:2:\", \";s:12:\"disphometext\";b:1;s:17:\"maxhometextlength\";i:0;s:15:\"hometextwraptxt\";s:3:\"...\";s:12:\"dispnewimage\";b:0;s:13:\"newimagelimit\";i:3;s:11:\"newimageset\";s:16:\"icons/extrasmall\";s:11:\"newimagesrc\";s:13:\"favorites.png\";s:9:\"scrolling\";i:1;s:11:\"scrollstyle\";s:327:\"%DIVID% {\r\nwidth:inherit;\r\noverflow:hidden;\r\nposition:relative;\r\npadding:2px;\r\nborder:0px solid black;\r\nbackground:transparent;\r\n/* IE: Height + 2*padding + 2*border */\r\nheight:54px;\r\nvoice-family: \"\\\"}\\\"\";\r\nvoice-family:inherit;\r\n/* regular height */\r\nheight:50px;\r\n}\r\n/* Opera browser */\r\nhtml>body %DIVID% {\r\nheight:50px;\r\n}\";s:11:\"scrolldelay\";i:3000;s:12:\"scrollmspeed\";i:2;}', '', 22, 'a:0:{}', 0, 0, 1, 3600, '2012-10-31 13:19:34', ''),
(20, 'Advertisedisplay', 'Advertisement', 'LOW AD BLOCK', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:1:\"2\";s:6:\"adtype\";s:1:\"2\";s:7:\"orderby\";s:6:\"random\";}', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2012-10-31 13:19:32', ''),
(35, 'Shopad', 'Shop Ads', 'display shop ads', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:1:\"4\";s:6:\"adtype\";s:1:\"2\";s:7:\"orderby\";s:6:\"random\";}', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2012-10-31 13:24:27', ''),
(22, 'Ishopproducts', 'ISHOP Products', '', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:1:\"2\";s:6:\"shopId\";s:2:\"26\";s:7:\"orderby\";s:6:\"random\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:20:25', ''),
(23, 'Menu', 'Top Menu', '', 'a:5:{s:14:\"displaymodules\";i:0;s:5:\"style\";i:1;s:10:\"stylesheet\";s:0:\"\";s:8:\"template\";s:4:\"menu\";s:7:\"content\";s:64:\"{homepage}|About|LINESPLIT{Users}|Contact|LINESPLIT{Search}|FAQ|\";}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-05-29 08:52:30', ''),
(24, 'Zencartproducts', 'Testing', '', 'a:10:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:4:\"shop\";s:4:\"test\";s:6:\"amount\";s:1:\"2\";s:6:\"domain\";s:19:\"demo.keeprunning.dk\";s:4:\"host\";s:19:\"demo.keeprunning.dk\";s:8:\"database\";s:10:\"c6demokeep\";s:8:\"username\";s:10:\"c6demokeep\";s:8:\"password\";s:8:\"th140651\";s:11:\"tableprefix\";s:4:\"zen_\";s:7:\"orderby\";s:6:\"random\";}', '', 3, 'a:0:{}', 0, 0, 1, 3600, '2013-05-28 10:00:07', ''),
(25, 'Extmenu', 'Bottom Menu', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:24:\"blocks_block_extmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"en\";s:0:\"\";s:2:\"da\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"en\";a:2:{i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:8:\"Site Map\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:3:\"Faq\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}s:2:\"da\";a:2:{i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:8:\"Site Map\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:3:\"Faq\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:19:51', ''),
(26, 'Html', 'Bottom Logo', '', 'KeepRunning', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:20:57', ''),
(27, 'Frontpagedisplay', 'KeepRunning News Bottom', '', 'a:28:{s:4:\"show\";i:1;s:8:\"category\";a:1:{s:4:\"Main\";a:9:{i:0;s:2:\"33\";i:1;s:2:\"34\";i:2;s:2:\"35\";i:3;s:2:\"36\";i:4;s:2:\"37\";i:5;s:2:\"38\";i:6;s:2:\"39\";i:7;s:2:\"40\";i:8;s:2:\"41\";}}s:5:\"limit\";i:3;s:6:\"status\";i:0;s:5:\"order\";i:0;s:9:\"dayslimit\";i:0;s:14:\"maxtitlelength\";i:0;s:12:\"titlewraptxt\";s:3:\"...\";s:15:\"showemptyresult\";b:0;s:13:\"blocktemplate\";s:0:\"\";s:11:\"rowtemplate\";s:0:\"\";s:9:\"dispuname\";b:0;s:8:\"dispdate\";b:1;s:10:\"dateformat\";s:2:\"%x\";s:9:\"dispreads\";b:0;s:12:\"dispcomments\";b:0;s:13:\"dispsplitchar\";s:2:\", \";s:12:\"disphometext\";b:1;s:17:\"maxhometextlength\";i:0;s:15:\"hometextwraptxt\";s:3:\"...\";s:12:\"dispnewimage\";b:0;s:13:\"newimagelimit\";i:3;s:11:\"newimageset\";s:16:\"icons/extrasmall\";s:11:\"newimagesrc\";s:13:\"favorites.png\";s:9:\"scrolling\";i:1;s:11:\"scrollstyle\";s:327:\"%DIVID% {\r\nwidth:inherit;\r\noverflow:hidden;\r\nposition:relative;\r\npadding:2px;\r\nborder:0px solid black;\r\nbackground:transparent;\r\n/* IE: Height + 2*padding + 2*border */\r\nheight:54px;\r\nvoice-family: \"\\\"}\\\"\";\r\nvoice-family:inherit;\r\n/* regular height */\r\nheight:50px;\r\n}\r\n/* Opera browser */\r\nhtml>body %DIVID% {\r\nheight:50px;\r\n}\";s:11:\"scrolldelay\";i:3000;s:12:\"scrollmspeed\";i:2;}', '', 22, 'a:0:{}', 0, 0, 1, 3600, '2012-10-31 13:21:02', ''),
(28, 'Html', 'Top Logo', '', 'Keep Running', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:21:13', ''),
(29, 'Html', 'Bottom Copyright', '', '&copy;2012  KeepRunning ', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:21:22', ''),
(30, 'Online', 'Who Is Online', '', '', '', 14, 'a:0:{}', 0, 0, 1, 3600, '2012-08-06 09:14:19', 'en'),
(31, 'Login', 'Login Front Acta-It', '', '', '', 14, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:24:47', ''),
(32, 'Servicemenu', 'Service Menu', '', 'a:0:{}', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2012-10-31 13:24:43', ''),
(33, 'Miniwebsiteproducts', 'Products MiniSite', '', 'a:5:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:1:\"4\";s:7:\"orderby\";s:6:\"random\";s:11:\"displayinfo\";s:3:\"yes\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:12:\"title danish\";s:11:\"infomessage\";s:23:\"test info in danish....\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:13:\"title english\";s:11:\"infomessage\";s:25:\"test info in english.....\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-06-28 14:47:48', ''),
(34, 'Minishopproducts', 'Products in your mini shop', '', 'a:5:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:2:\"50\";s:7:\"orderby\";s:6:\"random\";s:11:\"displayinfo\";s:3:\"yes\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:12:\"title danish\";s:11:\"infomessage\";s:35:\"danish information testing.........\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:13:\"title english\";s:11:\"infomessage\";s:36:\"english information testing.........\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 17:03:46', ''),
(80, 'Minisiteimages', 'Images', '', 'a:6:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:7:\"shop_id\";s:0:\"\";s:7:\"orderby\";s:0:\"\";s:11:\"displayinfo\";s:2:\"no\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-09-26 19:19:56', ''),
(38, 'Dealoftheday', 'Deal Of The Day', '', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:6:\"shopId\";s:0:\"\";s:7:\"orderby\";s:0:\"\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:24:08', ''),
(40, 'Gallery', 'Gallery', '', 'a:6:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:6:\"shopId\";s:0:\"\";s:7:\"orderby\";s:0:\"\";s:11:\"displayinfo\";s:3:\"yes\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:15:\"title in danish\";s:11:\"infomessage\";s:36:\"testtt test.....  info..............\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:16:\"title in english\";s:11:\"infomessage\";s:45:\"testingggggggggggggggggggggg english.........\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:17:21', ''),
(41, 'Centerblocknews', 'New Center', '', 'a:28:{s:4:\"show\";i:1;s:8:\"category\";a:1:{s:4:\"Main\";a:9:{i:0;s:2:\"33\";i:1;s:2:\"34\";i:2;s:2:\"35\";i:3;s:2:\"36\";i:4;s:2:\"37\";i:5;s:2:\"38\";i:6;s:2:\"39\";i:7;s:2:\"40\";i:8;s:2:\"41\";}}s:5:\"limit\";i:3;s:6:\"status\";i:0;s:5:\"order\";i:3;s:9:\"dayslimit\";i:0;s:14:\"maxtitlelength\";i:0;s:12:\"titlewraptxt\";s:3:\"...\";s:15:\"showemptyresult\";b:0;s:13:\"blocktemplate\";s:0:\"\";s:11:\"rowtemplate\";s:0:\"\";s:9:\"dispuname\";b:0;s:8:\"dispdate\";b:1;s:10:\"dateformat\";s:2:\"%x\";s:9:\"dispreads\";b:0;s:12:\"dispcomments\";b:0;s:13:\"dispsplitchar\";s:2:\", \";s:12:\"disphometext\";b:1;s:17:\"maxhometextlength\";i:0;s:15:\"hometextwraptxt\";s:3:\"...\";s:12:\"dispnewimage\";b:0;s:13:\"newimagelimit\";i:3;s:11:\"newimageset\";s:16:\"icons/extrasmall\";s:11:\"newimagesrc\";s:13:\"favorites.png\";s:9:\"scrolling\";i:1;s:11:\"scrollstyle\";s:327:\"%DIVID% {\r\nwidth:inherit;\r\noverflow:hidden;\r\nposition:relative;\r\npadding:2px;\r\nborder:0px solid black;\r\nbackground:transparent;\r\n/* IE: Height + 2*padding + 2*border */\r\nheight:54px;\r\nvoice-family: \"\\\"}\\\"\";\r\nvoice-family:inherit;\r\n/* regular height */\r\nheight:50px;\r\n}\r\n/* Opera browser */\r\nhtml>body %DIVID% {\r\nheight:50px;\r\n}\";s:11:\"scrolldelay\";i:3000;s:12:\"scrollmspeed\";i:2;}', '', 22, 'a:0:{}', 0, 0, 1, 3600, '2012-10-31 13:23:43', ''),
(43, 'Lang', 'Language block on top', '', 'a:3:{s:6:\"format\";s:1:\"1\";s:15:\"fulltranslation\";s:1:\"2\";s:9:\"languages\";a:2:{i:0;a:3:{s:4:\"code\";s:2:\"da\";s:4:\"name\";s:6:\"Danish\";s:4:\"flag\";s:24:\"images/flags/flag-da.png\";}i:1;a:3:{s:4:\"code\";s:2:\"en\";s:4:\"name\";s:7:\"English\";s:4:\"flag\";s:24:\"images/flags/flag-en.png\";}}}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:23:25', ''),
(44, 'Extmenu', 'very top menu', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:24:\"blocks_block_extmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"en\";s:0:\"\";s:2:\"da\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"en\";a:4:{i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"test1\";s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"test2\";s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"test3\";s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"test4\";s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}s:2:\"da\";a:4:{i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"test1\";s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"test2\";s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"test3\";s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"test4\";s:3:\"url\";s:0:\"\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 0, 0, 1, 3600, '2012-10-31 13:23:15', ''),
(45, 'Lang', 'Language', '', 'a:3:{s:6:\"format\";s:1:\"1\";s:15:\"fulltranslation\";s:1:\"1\";s:9:\"languages\";a:2:{i:0;a:3:{s:4:\"code\";s:2:\"da\";s:4:\"name\";s:6:\"Danish\";s:4:\"flag\";s:24:\"images/flags/flag-da.png\";}i:1;a:3:{s:4:\"code\";s:2:\"en\";s:4:\"name\";s:7:\"English\";s:4:\"flag\";s:24:\"images/flags/flag-en.png\";}}}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2012-10-31 13:18:34', ''),
(46, 'Zencartproducts', 'KeepRunning Shop', 'testttt', 'a:10:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:4:\"shop\";s:12:\"keeprunning \";s:6:\"amount\";s:1:\"2\";s:6:\"domain\";s:19:\"shop.keeprunning.dk\";s:4:\"host\";s:19:\"shop.keeprunning.dk\";s:8:\"database\";s:10:\"c6shopkeep\";s:8:\"username\";s:10:\"c6shopkeep\";s:8:\"password\";s:8:\"th140651\";s:11:\"tableprefix\";s:4:\"zen_\";s:7:\"orderby\";s:6:\"random\";}', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2013-02-25 09:33:20', 'en'),
(47, 'Shoparticles', 'Shop Articles', '', 'a:28:{s:4:\"show\";i:1;s:8:\"category\";N;s:5:\"limit\";i:3;s:6:\"status\";i:0;s:5:\"order\";i:0;s:9:\"dayslimit\";i:0;s:14:\"maxtitlelength\";i:0;s:12:\"titlewraptxt\";s:3:\"...\";s:15:\"showemptyresult\";b:0;s:13:\"blocktemplate\";s:0:\"\";s:11:\"rowtemplate\";s:0:\"\";s:9:\"dispuname\";b:0;s:8:\"dispdate\";b:1;s:10:\"dateformat\";s:2:\"%x\";s:9:\"dispreads\";b:0;s:12:\"dispcomments\";b:0;s:13:\"dispsplitchar\";s:2:\", \";s:12:\"disphometext\";b:1;s:17:\"maxhometextlength\";i:0;s:15:\"hometextwraptxt\";s:3:\"...\";s:12:\"dispnewimage\";b:0;s:13:\"newimagelimit\";i:3;s:11:\"newimageset\";s:16:\"icons/extrasmall\";s:11:\"newimagesrc\";s:13:\"favorites.png\";s:9:\"scrolling\";i:1;s:11:\"scrollstyle\";s:327:\"%DIVID% {\r\nwidth:inherit;\r\noverflow:hidden;\r\nposition:relative;\r\npadding:2px;\r\nborder:0px solid black;\r\nbackground:transparent;\r\n/* IE: Height + 2*padding + 2*border */\r\nheight:54px;\r\nvoice-family: \"\\\"}\\\"\";\r\nvoice-family:inherit;\r\n/* regular height */\r\nheight:50px;\r\n}\r\n/* Opera browser */\r\nhtml>body %DIVID% {\r\nheight:50px;\r\n}\";s:11:\"scrolldelay\";i:3000;s:12:\"scrollmspeed\";i:2;}', '', 22, 'a:0:{}', 1, 0, 1, 3600, '2012-11-12 13:57:36', ''),
(48, 'Googlemap', 'Minisite Google Map', '', 'a:5:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:11:\"displayinfo\";s:3:\"yes\";s:6:\"height\";s:0:\"\";s:5:\"width\";s:0:\"\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-11-11 12:25:10', ''),
(49, 'Googlemapzselex', 'Google Map Zselex', '', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:10:\"centerfunc\";s:0:\"\";s:11:\"displayinfo\";s:0:\"\";s:9:\"blockinfo\";s:0:\"\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2012-11-28 19:39:38', 'en'),
(50, 'Ishopproducts', 'Ishop 2', 'sdfsdf', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:6:\"amount\";s:1:\"2\";s:6:\"shopId\";s:2:\"32\";s:7:\"orderby\";s:6:\"random\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-01-04 10:33:32', 'en'),
(51, 'Extservicemenu', 'Services', 'service menu', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:31:\"blocks_block_extservicemenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:2:{i:0;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:18:\"Advertise Products\";s:3:\"url\";s:28:\"{Zselex:admin:viewadvertise}\";s:5:\"title\";s:18:\"Advertise Products\";s:6:\"active\";s:1:\"1\";}i:1;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:16:\"Minisite Gallery\";s:3:\"url\";s:36:\"{Zselex:admin:viewshopgalleryimages}\";s:5:\"title\";s:16:\"Minisite Gallery\";s:6:\"active\";s:1:\"1\";}}s:2:\"en\";a:2:{i:0;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:18:\"Advertise Products\";s:3:\"url\";s:28:\"{Zselex:admin:viewadvertise}\";s:5:\"title\";s:18:\"Advertise Products\";s:6:\"active\";s:1:\"1\";}i:1;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:16:\"Minisite Gallery\";s:3:\"url\";s:36:\"{Zselex:admin:viewshopgalleryimages}\";s:5:\"title\";s:16:\"Minisite Gallery\";s:6:\"active\";s:1:\"1\";}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 0, 0, 1, 3600, '2013-01-25 08:17:02', 'en'),
(52, 'Extmenu', 'Shop Administration', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:24:\"blocks_block_extmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:1:{i:0;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:19:\"Shop Administration\";s:3:\"url\";s:23:\"{Zselex:admin:viewshop}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}}s:2:\"en\";a:1:{i:0;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:19:\"Shop Administration\";s:3:\"url\";s:23:\"{Zselex:admin:viewshop}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 0, 0, 1, 3600, '2013-01-25 13:10:35', 'en'),
(76, 'Minisiteevent', 'Events', 'minisite events', 'a:2:{s:11:\"displayinfo\";s:2:\"no\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-09-26 19:17:51', ''),
(54, 'Minisiteeventselection', ' Events', '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:10:\"eventlimit\";s:1:\"2\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2013-02-22 15:17:31', 'en'),
(55, 'Eventcalender', 'Event Calendar', '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:10:\"eventlimit\";s:0:\"\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2013-02-21 18:02:46', 'en'),
(56, 'Upcommingevents', 'Upcomming Events', '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:19:\"upcommingeventlimit\";s:2:\"10\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-06-04 13:42:31', ''),
(57, 'Selection', 'Selection For Events', '', 'a:6:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:4:\"shop\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:7:\"orderby\";s:0:\"\";s:11:\"displayinfo\";s:2:\"no\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 0, 0, 1, 3600, '2013-02-25 18:45:50', 'en'),
(58, 'Pdfimagedisplay', 'PDF', 'test', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:5:\"limit\";s:0:\"\";s:11:\"displayinfo\";s:3:\"yes\";s:9:\"blockinfo\";a:2:{s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-03-20 08:17:44', 'en'),
(59, 'Map', 'Map', '', 'a:1:{s:26:\"showAdminHelloWorldinBlock\";s:0:\"\";}', '', 26, 'a:0:{}', 1, 0, 1, 3600, '2013-03-05 09:49:49', 'en'),
(60, 'Projects', 'Projects', '', 'a:1:{s:26:\"showAdminHelloWorldinBlock\";s:0:\"\";}', '', 26, 'a:0:{}', 1, 0, 1, 3600, '2013-03-05 09:50:23', 'en'),
(61, 'Roads', 'Roads', '', 'a:1:{s:26:\"showAdminHelloWorldinBlock\";s:0:\"\";}', '', 26, 'a:0:{}', 1, 0, 1, 3600, '2013-03-05 09:50:51', 'en'),
(63, 'Html', 'Top Logo', '', '<a href=\"index.php\"><img src=\"/themes/CityPilot/images/Logo.png\" class=\"logo\" /></a>', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-05-30 08:55:09', ''),
(64, 'Extmenu', 'Very Top Menu', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:24:\"blocks_block_extmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:7:{i:6;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:8:\"Forsiden\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:12:\"Om CityPilot\";s:3:\"url\";s:26:\"news/display/om-citypilot/\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:10:\"Kontakt os\";s:3:\"url\";s:24:\"news/display/kontakt-os/\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:16:\"Spørgsmål/Svar\";s:3:\"url\";s:5:\"{FAQ}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:9:\"Min konto\";s:3:\"url\";s:7:\"{Users}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:4;a:7:{s:5:\"image\";s:34:\"images/icons/extrasmall/locked.png\";s:4:\"name\";s:5:\"Login\";s:3:\"url\";s:7:\"{users}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:5;a:7:{s:5:\"image\";s:34:\"images/icons/extrasmall/locked.png\";s:4:\"name\";s:6:\"Log ud\";s:3:\"url\";s:19:\"{Users:user:logout}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}s:2:\"en\";a:7:{i:6;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:4:\"Home\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:0;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:15:\"About CityPilot\";s:3:\"url\";s:26:\"news/display/om-citypilot/\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:10:\"Contact us\";s:3:\"url\";s:24:\"news/display/kontakt-os/\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:3:\"FAQ\";s:3:\"url\";s:5:\"{FAQ}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:7:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:10:\"My Account\";s:3:\"url\";s:7:\"{Users}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:4;a:7:{s:5:\"image\";s:34:\"images/icons/extrasmall/locked.png\";s:4:\"name\";s:5:\"Login\";s:3:\"url\";s:7:\"{users}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:5;a:7:{s:5:\"image\";s:34:\"images/icons/extrasmall/locked.png\";s:4:\"name\";s:6:\"Logout\";s:3:\"url\";s:19:\"{Users:user:logout}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2015-12-17 22:42:07', ''),
(65, 'Html', 'Bot Logo', '', '<img src=\"/themes/CityPilot/images/FooterLogo.png\" />', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-05-29 11:50:53', ''),
(66, 'Extmenu', 'RETUR OG BETALING', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:24:\"blocks_block_extmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:3:{i:0;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:10:\"Returvarer\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}i:1;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:15:\"Leveringspriser\";s:3:\"url\";s:11:\"{standard1}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}i:2;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:12:\"Leveringstid\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}}s:2:\"en\";a:3:{i:0;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:3:\"RMA\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}i:1;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:15:\"Delivery prices\";s:3:\"url\";s:11:\"{standard1}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}i:2;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:13:\"Delivery time\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-05-29 11:54:34', ''),
(67, 'Extmenu', 'BETINGELSER OG VILKÅR', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:24:\"blocks_block_extmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:3:{i:0;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:18:\"Handelsbetingelser\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}i:1;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:18:\"Behandling af data\";s:3:\"url\";s:11:\"{standard1}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}i:2;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:15:\"Sikker betaling\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}}s:2:\"en\";a:3:{i:0;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:14:\"Terms of trade\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}i:1;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:7:\"Privacy\";s:3:\"url\";s:11:\"{standard1}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}i:2;a:5:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:14:\"Secure payment\";s:3:\"url\";s:10:\"{homepage}\";s:5:\"title\";s:0:\"\";s:6:\"active\";s:1:\"1\";}}}s:12:\"blockversion\";i:1;}', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-05-29 11:57:35', ''),
(68, 'Html', 'TILMELD DIG VORES NYHEDSBREV', '', '<div class=\"Newletter\">\r\n	<form id=\"email_form\" action=\"http://mailinglist.citypilot.dk/lists/\" method=\"GET\" target=\"_blank\">\r\n	<input size=\"27\" name=\"email\"   maxlength=\"50\"  value=\"DIN EMAILADRESSE\" onblur=\"if(this.value==\'\') this.value=\'DIN EMAILADRESSE\';\" onfocus=\"if(this.value==\'DIN EMAILADRESSE\') this.value=\'\';\" type=\"text\"  autocomplete=off >\r\n	<input type=\"hidden\" name=\"p\" value=\"subscribe\" />\r\n	<input type=\"hidden\" name=\"id\" value=\"1\" />\r\n	<input type=\"button\" value=\"OK\" onclick=\"document.forms[\'email_form\'].submit();\" />\r\n	</form>\r\n</div>\r\n<div class=\"NewletterBot\">\r\n	Når du tilmelder dig vores nyhedsbrev får du automatisk tilsendt relevant information om CityPilot.\r\n</div>\r\n', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2014-04-10 18:46:09', ''),
(69, 'Html', 'FØLG OS', '', '<ul class=\"socialIcons\">\r\n	<li><a href=\"https://www.facebook.com/CityPilot\" id=\"fb\" target=\"_blank\"></a></li>\r\n	<li><a href=\"https://twitter.com/citypilotdk\" id=\"tw\" target=\"_blank\"></a></li>\r\n	<li><a href=\"#\" id=\"Pinterest\"></a></li>\r\n	<li><a href=\"#\" id=\"GPluse\"></a></li>\r\n	<li class=\"Zero\"><a href=\"#\" id=\"Share\"></a></li>\r\n</ul>', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2014-04-10 15:26:12', ''),
(70, 'Html', 'Kreditkort', '', '                <ul class=\"Payments\">\r\n                    <li><img src=\"/themes/CityPilot/images/Electron.png\" /></li>\r\n                    <li><img src=\"/themes/CityPilot/images/Master.png\" /></li>\r\n                    <li><img src=\"/themes/CityPilot/images/DK.png\" /></li>\r\n                    <li><img src=\"/themes/CityPilot/images/Visa.png\" /></li>\r\n                </ul>', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-06-03 12:04:33', ''),
(71, 'Specialdeals', 'Special tilbud lige nu', '', 'a:3:{s:9:\"sd_amount\";s:1:\"4\";s:9:\"sd_adtype\";s:1:\"1\";s:10:\"sd_orderby\";s:6:\"random\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-09-10 09:15:57', ''),
(72, 'Citypilotheader', 'CityPilot Header', 'Pilot Header', 'a:0:{}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-06-27 10:01:20', ''),
(73, 'Citypilotfooter', 'CityPilot Footer', 'CityPilot Footer', 'a:0:{}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-08-23 23:23:21', ''),
(74, 'Shopaddress', 'Shop Address', '', '', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-06-28 14:56:49', ''),
(110, 'Minisitemenu', 'New Backendmenu', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:52:\"blocks/minisitemenu/blocks_block_minisiteextmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:3:{i:0;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:8:\"Min Side\";s:3:\"url\";s:26:\"{ZSELEX:admin:shopsummary}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:8:\"Mit Site\";s:3:\"url\";s:18:\"{ZSELEX:user:site}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:13:\"Mine Services\";s:3:\"url\";s:27:\"{ZSELEX:admin:shopservices}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}s:2:\"en\";a:3:{i:0;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:7:\"My Page\";s:3:\"url\";s:26:\"{ZSELEX:admin:shopsummary}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:7:\"My Site\";s:3:\"url\";s:18:\"{ZSELEX:user:site}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:11:\"My Services\";s:3:\"url\";s:27:\"{ZSELEX:admin:shopservices}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}}s:12:\"blockversion\";i:1;}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2014-09-04 16:10:13', ''),
(77, 'Newshops', 'New Shops', '', 'a:3:{s:4:\"shop\";s:1:\"0\";s:6:\"amount\";s:2:\"20\";s:7:\"orderby\";s:6:\"random\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2014-12-12 17:02:42', ''),
(109, 'Minisitemenu', 'Minisite Zselex Menu', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:52:\"blocks/minisitemenu/blocks_block_minisiteextmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:5:{i:0;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:7:\"Forside\";s:3:\"url\";s:18:\"{ZSELEX:user:site}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:9:\"Produkter\";s:3:\"url\";s:18:\"{Zselex:user:shop}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:4;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"Pages\";s:3:\"url\";s:18:\"{ZTEXT:user:pages}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:7:\"Find os\";s:3:\"url\";s:20:\"{Zselex:user:findus}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:17:\"CityPilot Backend\";s:3:\"url\";s:26:\"{ZSELEX:admin:shopsummary}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}s:2:\"en\";a:5:{i:0;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:4:\"Home\";s:3:\"url\";s:18:\"{ZSELEX:user:site}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:8:\"Products\";s:3:\"url\";s:18:\"{Zselex:user:shop}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:4;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:5:\"Pages\";s:3:\"url\";s:18:\"{ZTEXT:user:pages}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:7:\"Find os\";s:3:\"url\";s:20:\"{Zselex:user:findus}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:17:\"CityPilot Backend\";s:3:\"url\";s:26:\"{ZSELEX:admin:shopsummary}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}}s:12:\"blockversion\";i:1;}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2015-04-15 09:10:40', ''),
(79, 'Yourservices', 'Your Services', '', 'a:0:{}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-08-14 14:06:37', ''),
(82, 'Html', 'CityPilotMessage', 'Messages from CityPilot', '<h4 class=\"Mail\">Message from City Pilot</h4>\r\n<p class=\"admin_right_p\">\r\nVi har opdateres shopsystemet med 4 nye services.<br />\r\nPrøve dem i en demoperiode og se om det er noget for dig<br />\r\n<a href=\"/content/view/preview/1/pid/2\">Læs mere her>></a>\r\n</p>', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-09-27 01:37:19', '');
INSERT INTO `blocks` (`bid`, `bkey`, `title`, `description`, `content`, `url`, `mid`, `filter`, `active`, `collapsable`, `defaultstate`, `refresh`, `last_update`, `language`) VALUES
(84, 'Html', 'BackendGuide', 'Guide for Backend', '<h4 class=\"Guide\">HJÆLP (hvad nu?)</h4>\r\n<!-- -->\r\n<div class=\"admin_right_p\" id=\"hideguidebuttons\" style=\"text-align:right; cursor:pointer; display:none;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hidegb()\" title=\"Skjuler guides\">Skjul guides</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showguidebuttons\" style=\"text-align:right; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"showgb()\" title=\"Viser guides\">Vis guides</div>\r\n\r\n<div id=\"guidediv\" style=\"display:none;\">\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-1\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(1,true)\" title=\"Vis mere...\"><b>1</b>: Mine Services</div>\r\n<div class=\"admin_right_p\" id=\"showblock-1\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(1,true)\" title=\"Skjul tekst\"><b>1: Mine Services</b></div><br />\r\nTryk enten på den store knap \"Mine Services\" eller linket i det mørkegrå bånd i toppen.<br />\r\nDu har her mulighed for at tilkøbe services og kan se de services du allerede har.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=shopservices&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a><br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(1,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-2\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(2,true)\" title=\"Vis mere...\"><b>2</b>: Vælg Pakke</div>\r\n<div class=\"admin_right_p\" id=\"showblock-2\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(2,true)\" title=\"Skjul tekst\"><b>2: Vælg Pakke</b></div><br />\r\nInden systemet kan anvendes skal man vælge de services man ønsker at arbejde med.<br />\r\nMan kan altid opgradere til en større pakke eller tilkøbe flere services.<br />\r\nTryk på \"Mere om...\" linket i hver pakke for at se hvilke services de indeholder.<br />\r\nHvis du bare vil prøve vælder du blot den pakke du vil prøve. Det er gratis.<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(2,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-3\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(3,true)\" title=\"Vis mere...\"><b>3</b>: Mit Site</div>\r\n<div class=\"admin_right_p\" id=\"showblock-3\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(3,true)\" title=\"Skjul tekst\"><b>3: Mit Site</b></div><br />\r\nTryk enten på den store knap \"Mit Site\" fra Min Side eller linket i det mørkegrå bånd i toppen.<br />\r\nDu bliver ledt til din egen forside.<br />\r\nHer ses links til de forskellige sektioner du kan redigere på dit site (Se pkt. 4).<br />\r\nDet er kun når du er logget ind i systemet de er synlige og kun for dig.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=user&func=site&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a><br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(3,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-4\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(4,true)\" title=\"Vis mere...\"><b>4</b>: Rediger Mit Site</div>\r\n<div class=\"admin_right_p\" id=\"showblock-4\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(4,true)\" title=\"Skjul tekst\"><b>4: Rediger Mit Site</b></div><br />\r\n<b>a. Generelt indhold</b><br />\r\nHer kan du ændre ting som f.eks. butikkens navn og åbningstider.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=shopsettings&shop_id=\'+getParmFromURI(\'shop_id\')+\'#aTop\'\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<b>b. Adresse</b><br />\r\nHer kan du ændre adresseinformationer for din butik.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=shopsettings&shop_id=\'+getParmFromURI(\'shop_id\')+\'#aAddress\'\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<b>c. Billeder</b><br />\r\nHer kan du uploade billeder til din forside. Antal afhænger af de services du har købt. Har du brug for flere kan du altid tilkøbe lige så mange du har brug for.<br />\r\nDet er meget nemt at uploade billeder.<br />\r\nDu skal blot åbne mappen med dine billeder i dit favoritprogram til at håndtere filer med (Windows: Stifinder) og trække billedet eller billederne over på \"pladen\" her.<br />\r\nUpload og tilretning af billederne sker helt automatisk.<br />\r\nNår billederne er uploadet kan du redigere diverse informationer ved at trykke på billedet.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=shopsettings&shop_id=\'+getParmFromURI(\'shop_id\')+\'#aImages\'\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<b>d. Banner</b><br />\r\nHer kan du uploade et banner, som vises i toppen af dit site.<br />\r\nDet bedste resultat får du med et billede i størrelsen 2048x320 pixel.<br />\r\nDu kan tilføje et billede som banner lige så let som med billeder (se pkt. 4.c).<br />\r\nNår bannerbilledet er uploadet kan du evt. skrive en information oven i banneret ved at trykke på billedet og udfylde felterne.<br />\r\nDu kan også angive i hvilket tidsrum beskedden skal vises, så du ikke behøver at huske på at fjerne beskedden igen.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=shopsettings&shop_id=\'+getParmFromURI(\'shop_id\')+\'#aBanner\'\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<b>e. Events</b><br />\r\nHer kan du oprette events. En event har ingen begrænsning forstået på den måde at det er noget du gerne vil fortælle om i en bestemt tidsperiode til dem der besøger dit site.<br />\r\nDu kan tilføje et billede til din event lige så let som med billeder (se pkt. 4.c).<br />\r\nDu skal blot åbne mappen med dine billeder i dit favoritprogram til at håndtere filer med (Windows: Stifinder) og trække eventbilledet eller eventbillederne over på \"pladen\" her.<br />\r\nUpload og tilretning af eventbillederne sker helt automatisk.<br />\r\nNår billedet er uploadet kan du redigere diverse informationer omkring eventen ved at trykke på billedet.<br />\r\nHer kan man bl.a. redigere det tidsrum eventen skal vises for de besøgende (aktiveringstidspunkt), tidsrum for selve eventen (Start og slut dato og tid) og informationer om selve eventen.<br />\r\nMan behøver ikke anvende et billede, men det gør eventen mere synlig. Tryk da blot på \"pladen\" og skriv dine informationer.<br />\r\nEvents vises automatisk for de besøgende i hele systemet. Du skal ikke gøre noget særligt i den forbindelse.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=events&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<b>f. Produkter (pakkeafhængig)</b><br />\r\nHer kan du uploade billeder af dine produkter du gerne vil gøre ekstra opmærksom på i din butik.<br />\r\nVi stiller også en komplet webshop til rådighed med denne service, så dine besøgende kan handle med dig direkte i din egen webshop.<br />\r\nProduktbilleder uploades lige så let som billeder (se pkt. 4.c).<br />\r\nDu skal blot åbne mappen med dine billeder i dit favoritprogram til at håndtere filer med (Windows: Stifinder) og trække produktbilledet eller produktbillederne over på \"pladen\" her.<br />\r\nUpload og tilretning af produktbillederne sker helt automatisk.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=products&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(4,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-5\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(5,true)\" title=\"Vis mere...\"><b>5</b>: Min Side</div>\r\n<div class=\"admin_right_p\" id=\"showblock-5\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(5,true)\" title=\"Skjul tekst\"><b>5: Min Side</b></div><br />\r\n<b>a. Skift Kodeord</b><br />\r\nHer kan du skifte dit kodeord ifm. dit login til systemet.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=users&type=user&func=changePassword&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<b>b. Skift Sprog</b><br />\r\nHer kan du skifte det anvendte sprog ifm. din færden på dit site. Det gælder ikke de besøgende og har ikke nogte med oversættelse af dit site til et andet sprog at gøre. Det er din oplevelse når du logger ind i systemet.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=users&type=user&func=changeLang&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<b>c. Skift Email</b><br />\r\nHer kan du ændre den emailadresse vi anvender når vi kontakter dig. F.eks. hvis du har glemt dit kodeord og du skal have det nulstillet, men også service meddelelser vil blive udsendt via denne emailadresse.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=users&type=user&func=changeEmail&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<b>d. Annoncer (pakkeafhængig)</b><br />\r\nHvis du har valgt en pakke med produkter (shop) kan du annoncere dine produkter i systemet.<br />\r\nDu kan oprette annoncer til visning på de forskellige niveauer i systemet (Land, Region eller By) samt vælge placering (A, B eller C).<br />\r\nAlt efter dine valg vil det \"koste\" dig et antal af dine tilgængelige annoncer. Du kan se disse informationer inden du opretter selve annoncen.<br />\r\nDu kan også til hver en tid slette og oprette en eller flere nye annoncer.<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=productAd&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a><br />\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(5,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<!--\r\n<div class=\"admin_right_p\" id=\"showbutton-6\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(6,true)\" title=\"Vis mere...\"><b>3</b>: Minisite Gallery</div>\r\n<div class=\"admin_right_p\" id=\"showblock-6\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(6,true)\" title=\"Skjul tekst\"><b>3: Minisite Gallery</b></div><br />\r\nDu trykker på Minisite Gallery i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=viewshopgalleryimages&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(6,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-7\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(7,true)\" title=\"Vis mere...\"><b>4</b>: Minisite Events</div>\r\n<div class=\"admin_right_p\" id=\"showblock-7\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(7,true)\" title=\"Skjul tekst\"><b>4: Minisite Events</b></div><br />\r\nDu trykker på Minisite Events i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=events&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(7,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-8\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(8,true)\" title=\"Vis mere...\"><b>5</b>: Minisite Banner</div>\r\n<div class=\"admin_right_p\" id=\"showblock-8\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(8,true)\" title=\"Skjul tekst\"><b>5: Minisite Banner</b></div><br />\r\nDu trykker på Minisite Banner i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=viewminishopbanner&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(8,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-9\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(9,true)\" title=\"Vis mere...\"><b>6</b>: Minisite Announcement</div>\r\n<div class=\"admin_right_p\" id=\"showblock-9\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(9,true)\" title=\"Skjul tekst\"><b>6: Minisite Announcement</b></div><br />\r\nDu trykker på Minisite Announcement i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=announcement&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(9,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-10\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(10,true)\" title=\"Vis mere...\"><b>7</b>: Minishop</div>\r\n<div class=\"admin_right_p\" id=\"showblock-10\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(10,true)\" title=\"Skjul tekst\"><b>7: Minishop</b></div><br />\r\nDu trykker på Minishop i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=shopconfig&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(10,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-11\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(11,true)\" title=\"Vis mere...\"><b>8</b>: Products</div>\r\n<div class=\"admin_right_p\" id=\"showblock-11\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(11,true)\" title=\"Skjul tekst\"><b>8: Products</b></div><br />\r\nDu trykker på Products i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=viewproducts&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(11,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-12\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(12,true)\" title=\"Vis mere...\"><b>9</b>: Advertise</div>\r\n<div class=\"admin_right_p\" id=\"showblock-12\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(12,true)\" title=\"Skjul tekst\"><b>9: Advertise</b></div><br />\r\nDu trykker på Advertise i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=viewadvertise&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(12,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-13\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(13,true)\" title=\"Vis mere...\"><b>10</b>: PDF</div>\r\n<div class=\"admin_right_p\" id=\"showblock-13\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(13,true)\" title=\"Skjul tekst\"><b>10: PDF</b></div><br />\r\nDu trykker på PDF i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=viewshoppdf&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(13,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-14\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(14,true)\" title=\"Vis mere...\"><b>11</b>: Articles</div>\r\n<div class=\"admin_right_p\" id=\"showblock-14\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(14,true)\" title=\"Skjul tekst\"><b>11: Articles</b></div><br />\r\nDu trykker på Articles i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=viewshoppdf&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(14,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-15\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(15,true)\" title=\"Vis mere...\"><b>12</b>: Article AD</div>\r\n<div class=\"admin_right_p\" id=\"showblock-15\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(15,true)\" title=\"Skjul tekst\"><b>12: Article AD</b></div><br />\r\nDu trykker på Article AD i listen til venstre og derefter på \"Rediger service\" linket.<br />\r\nDu kan også bare trykke på linket herunder...<br />\r\n<a href=\"#\" onclick=\"location.href=\'index.php?module=zselex&type=admin&func=viewarticleads&shop_id=\'+getParmFromURI(\'shop_id\')\">Gå direkte til funktionen>></a>\r\n<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(15,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n\r\n<div class=\"admin_right_p\" id=\"showbutton-16\" style=\"text-align:left; cursor:pointer; display:block;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"shows(16,true)\" title=\"Vis mere...\"><b>D</b>: Menuer...</div>\r\n<div class=\"admin_right_p\" id=\"showblock-16\" style=\"text-align:left; display:none;\"><div style=\"cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"hides(16,true)\" title=\"Skjul tekst\"><b>D: Menuer...</b></div><br />\r\n...<br />\r\n<div style=\"text-align:right; cursor:pointer;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"removes(16,true)\" title=\"Fjern guide. Kan hentes igen senere!\">Fjern</div>\r\n</div>\r\n-->\r\n\r\n<!-- -->\r\n<div class=\"admin_right_p\" id=\"restorebutton\" style=\"text-align:right; cursor:pointer; display:none;\" onmouseover=\"this.style.color=\'#e1531e\';\" onmouseout=\"this.style.color=\'black\';\" onClick=\"restoreAlls()\"  title=\"Henter alle guides frem igen.\">Genskab alle guides </div>\r\n\r\n</div>\r\n\r\n<script>\r\nvar maxguides = 20;\r\n\r\nfunction getCookie(c_name) {\r\n    var c_value = document.cookie;\r\n    var c_start = c_value.indexOf(\" \" + c_name + \"=\");\r\n    if (c_start == -1)\r\n    {\r\n        c_start = c_value.indexOf(c_name + \"=\");\r\n    }\r\n    if (c_start == -1)\r\n    {\r\n        //c_value = null;\r\n        c_value = \'\';\r\n    }\r\n    else\r\n    {\r\n        c_start = c_value.indexOf(\"=\", c_start) + 1;\r\n        var c_end = c_value.indexOf(\";\", c_start);\r\n        if (c_end == -1)\r\n        {\r\n            c_end = c_value.length;\r\n        }\r\n        c_value = unescape(c_value.substring(c_start,c_end));\r\n    }\r\n    return c_value;\r\n}\r\n\r\nfunction setCookie(name,value,days) {\r\n    if (days) {\r\n        var date = new Date();\r\n        date.setTime(date.getTime()+(days*24*60*60*1000));\r\n        var expires = \"; expires=\"+date.toGMTString();\r\n    }\r\n    else var expires = \"\";\r\n    document.cookie = name+\"=\"+value+expires+\"; path=/\";\r\n}\r\n\r\nfunction hides(n,check) {\r\n	if (!document.getElementById(\'showbutton-\'+n)) { return false; }\r\n	document.getElementById(\'showblock-\'+n).style.display=\'none\';\r\n	document.getElementById(\'showbutton-\'+n).style.display=\'block\';\r\n	setCookie(\'showsCookie-\'+n , \'\', -1);\r\n	setCookie(\'removesCookie-\'+n, \'\', -1);\r\n	if (check) { checkRestoreButton(); }\r\n}\r\n\r\nfunction shows(n,check) {\r\n	if (!document.getElementById(\'showbutton-\'+n)) { return false; }\r\n	document.getElementById(\'showbutton-\'+n).style.display=\'none\';\r\n	document.getElementById(\'showblock-\'+n).style.display=\'block\';\r\n	setCookie(\'showsCookie-\'+n, true, \'1\');\r\n	setCookie(\'removesCookie-\'+n, \'\', -1);\r\n	if (check) { checkRestoreButton(); }\r\n}\r\n\r\nfunction removes(n,check) {\r\n	if (!document.getElementById(\'showbutton-\'+n)) { return false; }\r\n	document.getElementById(\'showblock-\'+n).style.display=\'none\';\r\n	document.getElementById(\'showbutton-\'+n).style.display=\'none\';\r\n	setCookie(\'showsCookie-\'+n , \'\', -1);\r\n	setCookie(\'removesCookie-\'+n, true, \'1\');\r\n	if (check) { checkRestoreButton(); }\r\n}\r\n\r\nfunction restoresButton(show) {\r\n	if (show) {\r\n		document.getElementById(\'restorebutton\').style.display=\'block\';\r\n	} else {\r\n		document.getElementById(\'restorebutton\').style.display=\'none\';\r\n	}\r\n}\r\n\r\nfunction restoreAlls() {\r\n    for(var i=1; i<=maxguides; i++) {\r\n		hides(i,true);\r\n	}\r\n}\r\n\r\nfunction checkRestoreButton() {\r\n	restoresButton(false);\r\n    for (var i=1; i<=maxguides; i++) {\r\n		var removes_cookie = getCookie(\'removesCookie-\'+i);\r\n		if (removes_cookie) {\r\n			restoresButton(true);\r\n		}\r\n	}\r\n}\r\n\r\nfunction hidegb() {\r\n	document.getElementById(\'hideguidebuttons\').style.display=\'none\';\r\n	document.getElementById(\'showguidebuttons\').style.display=\'block\';\r\n	document.getElementById(\'guidediv\').style.display=\'none\';\r\n	setCookie(\'hideguidesCookie\', true, \'1\');\r\n}\r\n\r\nfunction showgb() {\r\n	document.getElementById(\'hideguidebuttons\').style.display=\'block\';\r\n	document.getElementById(\'showguidebuttons\').style.display=\'none\';\r\n	document.getElementById(\'guidediv\').style.display=\'block\';\r\n	setCookie(\'hideguidesCookie\' , \'\', -1);\r\n}\r\n\r\nfunction onloadShows() {\r\n	var hideguides_cookie = getCookie(\'hideguidesCookie\');\r\n	if (hideguides_cookie) {\r\n		hidegb();\r\n	} else {\r\n		showgb();\r\n	}\r\n	\r\n    for (var i=1; i<=maxguides; i++) {\r\n		var removes_cookie = getCookie(\'removesCookie-\'+i);\r\n		if (removes_cookie) {\r\n			removes(i,false);\r\n		} else {\r\n			var shows_cookie = getCookie(\'showsCookie-\'+i);\r\n			if (shows_cookie) {\r\n				shows(i,false);\r\n			} else {	\r\n				hides(i,false);\r\n			}\r\n		}\r\n	}\r\n	checkRestoreButton();\r\n}\r\n\r\nfunction getParmFromURI(parm) {\r\n	var searchString = window.location.search.substring(1);\r\n	if (!searchString) {\r\n		var hash = window.location.hash;\r\n		searchString = hash.slice(hash.indexOf(\'?\') + 1);\r\n	}\r\n	var params = searchString.split(\"&\");\r\n	for (var i=0; i<params.length; i++) {\r\n		var val = params[i].split(\"=\");\r\n		if (val[0] == parm) {\r\n			return val[1];\r\n		}\r\n	}\r\n	return null;\r\n}\r\n\r\n//window.onload = function(){ setTimeout( function(){ onloadShows(); }, 1000); };\r\nwindow.onload = function(){ onloadShows(); };\r\n</script>\r\n', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-12-14 09:59:35', ''),
(85, 'Html', 'BackendStats', 'Stats in backend', '<h4 class=\"Graph\">Statistik</h4>\r\n<p class=\"admin_right_p\">\r\nI have had:<br />\r\n<span class=\"orange_text\">184</span> new visitors lately <span class=\"orange_text\">1250</span> visitors in total <br /><br />\r\n<span class=\"orange_text\">3</span> rated your page <span class=\"orange_text\">16</span> has laid a comment<br /><br />\r\nI\'ve sold:<br /><span class=\"orange_text\">19</span> Products in July\r\n<span class=\"orange_text\">201</span> products in total\r\n</p>\r\n', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-09-26 00:59:28', ''),
(86, 'Banner', 'Banner', '', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:4:\"shop\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:7:\"orderby\";s:0:\"\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-09-27 17:58:41', ''),
(87, 'Announcement', 'Announcement', '', 'a:4:{s:22:\"showAdminZSELEXinBlock\";s:0:\"\";s:4:\"shop\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:7:\"orderby\";s:0:\"\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-09-27 17:59:23', ''),
(88, 'Employees', 'Employees', '', 'a:3:{s:4:\"shop\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:7:\"orderby\";s:0:\"\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2013-10-02 11:16:48', ''),
(90, 'Menutree', 'BackendMenu', '', 'a:13:{s:16:\"menutree_content\";a:13:{i:10;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:10:\"My Account\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";N;s:6:\"parent\";i:0;}s:2:\"da\";a:9:{s:2:\"id\";s:2:\"10\";s:4:\"name\";s:10:\"My Account\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";N;s:6:\"parent\";i:0;}}i:11;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:2:\"11\";s:4:\"name\";s:15:\"Change password\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:1;s:6:\"parent\";s:2:\"10\";}s:2:\"da\";a:9:{s:2:\"id\";s:2:\"11\";s:4:\"name\";s:15:\"Change password\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:1;s:6:\"parent\";s:2:\"10\";}}i:12;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:2:\"12\";s:4:\"name\";s:15:\"Change language\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:2;s:6:\"parent\";s:2:\"10\";}s:2:\"da\";a:9:{s:2:\"id\";s:2:\"12\";s:4:\"name\";s:15:\"Change language\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:2;s:6:\"parent\";s:2:\"10\";}}i:13;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:2:\"13\";s:4:\"name\";s:14:\"Email settings\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:3;s:6:\"parent\";s:2:\"10\";}s:2:\"da\";a:9:{s:2:\"id\";s:2:\"13\";s:4:\"name\";s:14:\"Email settings\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:3;s:6:\"parent\";s:2:\"10\";}}i:1;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:17:\"Services/Purchase\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:4;s:6:\"parent\";i:0;}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"1\";s:4:\"name\";s:17:\"Services/Purchase\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:4;s:6:\"parent\";i:0;}}i:3;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:7:\"Bundles\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:5;s:6:\"parent\";s:1:\"1\";}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"3\";s:4:\"name\";s:7:\"Bundles\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:5;s:6:\"parent\";s:1:\"1\";}}i:4;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"4\";s:4:\"name\";s:8:\"Purchase\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:6;s:6:\"parent\";s:1:\"1\";}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"4\";s:4:\"name\";s:8:\"Purchase\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:6;s:6:\"parent\";s:1:\"1\";}}i:5;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"5\";s:4:\"name\";s:13:\"Edit Services\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:7;s:6:\"parent\";s:1:\"1\";}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"5\";s:4:\"name\";s:13:\"Edit Services\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:7;s:6:\"parent\";s:1:\"1\";}}i:2;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"2\";s:4:\"name\";s:11:\"Minisite(s)\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:8;s:6:\"parent\";i:0;}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"2\";s:4:\"name\";s:11:\"Minisite(s)\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:8;s:6:\"parent\";i:0;}}i:6;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"6\";s:4:\"name\";s:9:\"Frontpage\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:9;s:6:\"parent\";s:1:\"2\";}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"6\";s:4:\"name\";s:9:\"Frontpage\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:9;s:6:\"parent\";s:1:\"2\";}}i:7;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"7\";s:4:\"name\";s:8:\"Products\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:10;s:6:\"parent\";s:1:\"2\";}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"7\";s:4:\"name\";s:8:\"Products\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:10;s:6:\"parent\";s:1:\"2\";}}i:8;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"8\";s:4:\"name\";s:7:\"Find Us\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:11;s:6:\"parent\";s:1:\"2\";}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"8\";s:4:\"name\";s:7:\"Find Us\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:11;s:6:\"parent\";s:1:\"2\";}}i:9;a:2:{s:2:\"en\";a:9:{s:2:\"id\";s:1:\"9\";s:4:\"name\";s:6:\"Events\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:1;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"en\";s:6:\"lineno\";i:12;s:6:\"parent\";s:1:\"2\";}s:2:\"da\";a:9:{s:2:\"id\";s:1:\"9\";s:4:\"name\";s:6:\"Events\";s:5:\"title\";N;s:9:\"className\";s:0:\"\";s:5:\"state\";b:0;s:4:\"href\";s:0:\"\";s:4:\"lang\";s:2:\"da\";s:6:\"lineno\";i:12;s:6:\"parent\";s:1:\"2\";}}}s:12:\"menutree_tpl\";s:42:\"menutree/blocks_block_menutree_default.tpl\";s:19:\"menutree_stylesheet\";s:0:\"\";s:15:\"menutree_titles\";a:2:{s:2:\"en\";s:0:\"\";s:2:\"da\";s:0:\"\";}s:18:\"menutree_linkclass\";b:0;s:17:\"menutree_maxdepth\";i:0;s:18:\"menutree_editlinks\";b:0;s:21:\"menutree_stripbaseurl\";b:1;s:20:\"menutree_titlesperms\";s:11:\"ACCESS_EDIT\";s:21:\"menutree_displayperms\";s:11:\"ACCESS_EDIT\";s:22:\"menutree_settingsperms\";s:11:\"ACCESS_EDIT\";s:12:\"oldlanguages\";a:2:{i:0;s:2:\"en\";i:1;s:2:\"da\";}s:17:\"olddefaultanguage\";s:2:\"en\";}', '', 3, 'a:0:{}', 0, 0, 1, 3600, '2013-11-05 16:45:09', ''),
(92, 'Html', 'Shopsettings', '', '<style>\r\nh4 {display:none;}\r\n</style>\r\n<a href=\"\"><img src=\"modules/ZSELEX/images/F2B_EDIT_button.png\" width=\"220px\"/ title=\"Rediger Forsiden\"></a>\r\n<br /><br />\r\n', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-11-05 06:53:30', ''),
(93, 'Html', 'Eventsettings', '', '<style>\r\nh4 {display:none;}\r\n</style>\r\n<a href=\"\"><img src=\"modules/ZSELEX/images/F2B_EDIT_button.png\" width=\"220px\"/ title=\"Rediger Events\"></a>\r\n<br />', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2013-11-05 06:54:49', ''),
(101, 'ExclusiveEvents', 'Exclusive Events', '', 'a:3:{s:4:\"shop\";s:0:\"\";s:6:\"amount\";s:0:\"\";s:7:\"orderby\";s:0:\"\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2014-01-03 14:01:49', ''),
(102, 'Membersonline', 'Online users', '', 'a:1:{s:9:\"lengthmax\";i:30;}', '', 18, 'a:0:{}', 1, 0, 1, 3600, '2014-01-14 11:09:58', ''),
(107, 'Minisitemenu', 'My Page', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:52:\"blocks/minisitemenu/blocks_block_minisiteextmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:4:{i:0;a:8:{s:5:\"image\";s:36:\"themes/CityPilot/images/password.png\";s:4:\"name\";s:13:\"Skift Kodeord\";s:3:\"url\";s:27:\"{Users:user:changePassword}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:8:{s:5:\"image\";s:36:\"themes/CityPilot/images/language.png\";s:4:\"name\";s:11:\"Skift Sprog\";s:3:\"url\";s:23:\"{Users:user:changeLang}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:8:{s:5:\"image\";s:37:\"themes/CityPilot/images/SmallMail.png\";s:4:\"name\";s:11:\"Skift Email\";s:3:\"url\";s:24:\"{Users:user:changeEmail}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:8:\"Annoncer\";s:3:\"url\";s:24:\"{ZSELEX:admin:productAd}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}s:2:\"en\";a:4:{i:0;a:8:{s:5:\"image\";s:36:\"themes/CityPilot/images/password.png\";s:4:\"name\";s:15:\"Change Password\";s:3:\"url\";s:27:\"{Users:user:changePassword}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:8:{s:5:\"image\";s:36:\"themes/CityPilot/images/language.png\";s:4:\"name\";s:15:\"Change Language\";s:3:\"url\";s:23:\"{Users:user:changeLang}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:2;a:8:{s:5:\"image\";s:37:\"themes/CityPilot/images/SmallMail.png\";s:4:\"name\";s:12:\"Change Email\";s:3:\"url\";s:24:\"{Users:user:changeEmail}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:3;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:9:\"Advertise\";s:3:\"url\";s:24:\"{ZSELEX:admin:productAd}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}}s:12:\"blockversion\";i:1;}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2014-09-04 15:31:01', ''),
(108, 'Minisitemenu', 'My Services', '', 'a:6:{s:14:\"displaymodules\";i:0;s:10:\"stylesheet\";s:11:\"extmenu.css\";s:8:\"template\";s:52:\"blocks/minisitemenu/blocks_block_minisiteextmenu.tpl\";s:11:\"blocktitles\";a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}s:5:\"links\";a:2:{s:2:\"da\";a:2:{i:0;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:16:\"Rediger Services\";s:3:\"url\";s:27:\"{ZSELEX:admin:editservices}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:9:\"Avanceret\";s:3:\"url\";s:28:\"{ZSELEX:admin:shopinnerview}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}s:2:\"en\";a:2:{i:0;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:13:\"Edit Services\";s:3:\"url\";s:27:\"{ZSELEX:admin:editservices}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}i:1;a:8:{s:5:\"image\";s:0:\"\";s:4:\"name\";s:8:\"Advanced\";s:3:\"url\";s:28:\"{ZSELEX:admin:shopinnerview}\";s:5:\"title\";s:0:\"\";s:8:\"services\";s:0:\"\";s:6:\"active\";s:1:\"1\";s:8:\"parentid\";N;s:11:\"haschildren\";b:0;}}}s:12:\"blockversion\";i:1;}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2014-09-04 15:58:38', ''),
(111, 'Products', 'ZBlock Test block', '', 'a:6:{s:9:\"shop_name\";s:13:\"New Shop Test\";s:8:\"site_url\";s:43:\"http://citypilot.dk/site/keeprunning-aarhus\";s:13:\"product_limit\";s:1:\"2\";s:10:\"categories\";s:0:\"\";s:13:\"manufacturers\";s:0:\"\";i:50;a:2:{s:10:\"categories\";s:0:\"\";s:13:\"manufacturers\";s:0:\"\";}}', '', 47, 'a:0:{}', 0, 0, 1, 3600, '2015-03-06 23:31:12', ''),
(112, 'Pageindex', 'Page Index', '', '', '', 48, 'a:0:{}', 1, 0, 1, 3600, '2015-04-15 09:08:43', ''),
(113, 'Sociallinks', 'Social Links', '', 'a:2:{s:11:\"displayinfo\";s:0:\"\";s:9:\"blockinfo\";s:0:\"\";}', '', 23, 'a:0:{}', 1, 0, 1, 3600, '2015-06-17 21:34:06', ''),
(114, 'Html', 'Top Center', '', '<b>I dag servicerer vi sitet fra kl. 12.00 til ca. kl. 14.00</b><br>\r\nVi beklager de gener dette måtte medføre.<br>\r\nVenlig hilsen<br>\r\nDit CityPilot Team', '', 3, 'a:0:{}', 0, 0, 1, 3600, '2015-08-17 19:10:23', ''),
(115, 'Html', 'Follow us', 'Follow us (CityPilot Responsive)', '  <ul>\r\n                    <li><a href=\"#\"><i class=\"fa fa-facebook-square\"></i></a></li>\r\n                    <li><a href=\"#\"><i class=\"fa fa-twitter-square\"></i></a></li>\r\n                    <li><a href=\"#\"><i class=\"fa fa-pinterest-square\"></i></a></li>\r\n                    <li><a href=\"#\"><i class=\"fa fa-google-plus-square\"></i></a></li>\r\n                    <li><a href=\"#\"><i class=\"fa fa-share-alt-square\"></i></a></li>\r\n                </ul>', '', 3, 'a:0:{}', 1, 0, 1, 3600, '2016-09-18 20:45:16', '');

-- --------------------------------------------------------

--
-- Table structure for table `categories_category`
--

CREATE TABLE `categories_category` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '1',
  `is_locked` tinyint(4) NOT NULL DEFAULT '0',
  `is_leaf` tinyint(4) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `sort_value` int(11) NOT NULL DEFAULT '2147483647',
  `display_name` longtext NOT NULL,
  `display_desc` longtext NOT NULL,
  `path` longtext NOT NULL,
  `ipath` varchar(255) NOT NULL,
  `status` varchar(1) NOT NULL DEFAULT 'A',
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories_category`
--

INSERT INTO `categories_category` (`id`, `parent_id`, `is_locked`, `is_leaf`, `name`, `value`, `sort_value`, `display_name`, `display_desc`, `path`, `ipath`, `status`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 0, 1, 0, '__SYSTEM__', '', 1, 'b:0;', 'b:0;', '/__SYSTEM__', '/1', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(2, 1, 0, 0, 'Modules', '', 2, 'a:1:{s:2:\"en\";s:7:\"Modules\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules', '/1/2', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(3, 1, 0, 0, 'General', '', 3, 'a:1:{s:2:\"en\";s:7:\"General\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General', '/1/3', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(4, 3, 0, 0, 'YesNo', '', 4, 'a:1:{s:2:\"en\";s:6:\"Yes/No\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/YesNo', '/1/3/4', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(5, 4, 0, 1, '1 - Yes', 'Y', 5, 'b:0;', 'b:0;', '/__SYSTEM__/General/YesNo/1 - Yes', '/1/3/4/5', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(6, 4, 0, 1, '2 - No', 'N', 6, 'b:0;', 'b:0;', '/__SYSTEM__/General/YesNo/2 - No', '/1/3/4/6', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(10, 3, 0, 0, 'Publication Status (extended)', '', 10, 'a:1:{s:2:\"en\";s:29:\"Publication status (extended)\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Extended', '/1/3/10', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(11, 10, 0, 1, 'Pending', 'P', 11, 'a:1:{s:2:\"en\";s:7:\"Pending\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Extended/Pending', '/1/3/10/11', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(12, 10, 0, 1, 'Checked', 'C', 12, 'a:1:{s:2:\"en\";s:7:\"Checked\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Extended/Checked', '/1/3/10/12', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(13, 10, 0, 1, 'Approved', 'A', 13, 'a:1:{s:2:\"en\";s:8:\"Approved\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Extended/Approved', '/1/3/10/13', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(14, 10, 0, 1, 'On-line', 'O', 14, 'a:1:{s:2:\"en\";s:7:\"On-line\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Extended/Online', '/1/3/10/14', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(15, 10, 0, 1, 'Rejected', 'R', 15, 'a:1:{s:2:\"en\";s:8:\"Rejected\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Extended/Rejected', '/1/3/10/15', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(16, 3, 0, 0, 'Gender', '', 16, 'a:1:{s:2:\"en\";s:6:\"Gender\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Gender', '/1/3/16', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(17, 16, 0, 1, 'Male', 'M', 17, 'a:1:{s:2:\"en\";s:4:\"Male\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Gender/Male', '/1/3/16/17', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(18, 16, 0, 1, 'Female', 'F', 18, 'a:1:{s:2:\"en\";s:6:\"Female\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Gender/Female', '/1/3/16/18', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(19, 3, 0, 0, 'Title', '', 19, 'a:1:{s:2:\"en\";s:5:\"Title\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Title', '/1/3/19', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(20, 19, 0, 1, 'Mr', 'Mr', 20, 'a:1:{s:2:\"en\";s:3:\"Mr.\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Title/Mr', '/1/3/19/20', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(21, 19, 0, 1, 'Mrs', 'Mrs', 21, 'a:1:{s:2:\"en\";s:4:\"Mrs.\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Title/Mrs', '/1/3/19/21', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(22, 19, 0, 1, 'Ms', 'Ms', 22, 'a:1:{s:2:\"en\";s:3:\"Ms.\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Title/Ms', '/1/3/19/22', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(23, 19, 0, 1, 'Miss', 'Miss', 23, 'a:1:{s:2:\"en\";s:4:\"Miss\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Title/Miss', '/1/3/19/23', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(24, 19, 0, 1, 'Dr', 'Dr', 24, 'a:1:{s:2:\"en\";s:3:\"Dr.\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Title/Dr', '/1/3/19/24', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(25, 3, 0, 0, 'ActiveStatus', '', 25, 'a:1:{s:2:\"en\";s:15:\"Activity status\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/ActiveStatus', '/1/3/25', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(26, 25, 0, 1, 'Active', 'A', 26, 'a:1:{s:2:\"en\";s:6:\"Active\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/ActiveStatus/Active', '/1/3/25/26', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(27, 25, 0, 1, 'Inactive', 'I', 27, 'a:1:{s:2:\"en\";s:8:\"Inactive\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/ActiveStatus/Inactive', '/1/3/25/27', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(28, 3, 0, 0, 'Publication status (basic)', '', 28, 'a:1:{s:2:\"en\";s:26:\"Publication status (basic)\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Basic', '/1/3/28', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(29, 28, 0, 1, 'Pending', 'P', 29, 'a:1:{s:2:\"en\";s:7:\"Pending\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Basic/Pending', '/1/3/28/29', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(30, 28, 0, 1, 'Approved', 'A', 30, 'a:1:{s:2:\"en\";s:8:\"Approved\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/General/Publication Status Basic/Approved', '/1/3/28/30', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(31, 1, 0, 0, 'Users', '', 31, 'a:1:{s:2:\"en\";s:5:\"Users\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Users', '/1/31', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(32, 2, 0, 0, 'Global', '', 32, 'a:1:{s:2:\"en\";s:6:\"Global\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global', '/1/2/32', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(33, 32, 0, 1, 'Blogging', '', 33, 'a:1:{s:2:\"en\";s:8:\"Blogging\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/Blogging', '/1/2/32/33', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(34, 32, 0, 1, 'Music and audio', '', 34, 'a:1:{s:2:\"en\";s:15:\"Music and audio\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/MusicAndAudio', '/1/2/32/34', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(35, 32, 0, 1, 'Art and photography', '', 35, 'a:1:{s:2:\"en\";s:19:\"Art and photography\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/ArtAndPhotography', '/1/2/32/35', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(36, 32, 0, 1, 'Writing and thinking', '', 36, 'a:1:{s:2:\"en\";s:20:\"Writing and thinking\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/WritingAndThinking', '/1/2/32/36', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(37, 32, 0, 1, 'Communications and media', '', 37, 'a:1:{s:2:\"en\";s:24:\"Communications and media\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/CommunicationsAndMedia', '/1/2/32/37', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(38, 32, 0, 1, 'Travel and culture', '', 38, 'a:1:{s:2:\"en\";s:18:\"Travel and culture\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/TravelAndCulture', '/1/2/32/38', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(39, 32, 0, 1, 'Science and technology', '', 39, 'a:1:{s:2:\"en\";s:22:\"Science and technology\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/ScienceAndTechnology', '/1/2/32/39', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(40, 32, 0, 1, 'Sport and activities', '', 40, 'a:1:{s:2:\"en\";s:20:\"Sport and activities\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/SportAndActivities', '/1/2/32/40', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(41, 32, 0, 1, 'Business and work', '', 41, 'a:1:{s:2:\"en\";s:17:\"Business and work\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/BusinessAndWork', '/1/2/32/41', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(10000, 2, 0, 0, 'News', '', 2147483647, 'a:1:{s:2:\"en\";s:14:\"News publisher\";}', 'a:1:{s:2:\"en\";s:147:\"Provides the ability to publish and manage news articles contributed by site users, with support for news categories and various associated blocks.\";}', '/__SYSTEM__/Modules/News', '/1/2/10000', 'A', 'A', '2012-02-13 16:22:33', 3, '2012-02-13 16:22:33', 3),
(10001, 32, 0, 1, '', '', 2147483647, 'a:1:{s:2:\"en\";s:0:\"\";}', 'a:1:{s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/Global/', '/1/2/32/10001', 'I', 'A', '2012-06-12 10:09:21', 3, '2012-06-12 10:09:21', 3),
(10002, 10000, 0, 1, 'Sportswear', '', 2147483647, 'a:2:{s:2:\"da\";s:10:\"Sportswear\";s:2:\"en\";s:10:\"Sportswear\";}', 'a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/News/Sportswear', '/1/2/10000/10002', 'A', 'A', '2012-12-28 14:11:47', 2, '2012-12-28 14:11:47', 2),
(10003, 10000, 0, 1, 'Clothes', '', 2147483647, 'a:2:{s:2:\"da\";s:7:\"Clothes\";s:2:\"en\";s:7:\"Clothes\";}', 'a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/News/Clothes', '/1/2/10000/10003', 'A', 'A', '2012-12-28 14:12:18', 2, '2012-12-28 14:12:18', 2),
(10004, 10000, 0, 1, 'Restaurant', '', 2147483647, 'a:2:{s:2:\"da\";s:10:\"Restaurant\";s:2:\"en\";s:10:\"Restaurant\";}', 'a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/News/Restaurant', '/1/2/10000/10004', 'A', 'A', '2012-12-28 14:12:45', 2, '2012-12-28 14:12:45', 2),
(10005, 10000, 0, 1, 'Travel', '', 2147483647, 'a:2:{s:2:\"da\";s:6:\"Travel\";s:2:\"en\";s:6:\"Travel\";}', 'a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/News/Travel', '/1/2/10000/10005', 'A', 'A', '2012-12-28 14:13:05', 2, '2012-12-28 14:13:05', 2),
(10006, 1, 0, 1, 'Food', '', 2147483647, 'a:2:{s:2:\"da\";s:4:\"Food\";s:2:\"en\";s:4:\"Food\";}', 'a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Food', '/1/10006', 'A', 'A', '2012-12-28 14:13:42', 2, '2012-12-28 14:13:42', 2),
(10007, 2, 0, 0, 'FAQ', '', 2147483647, 'a:1:{s:2:\"en\";s:3:\"FAQ\";}', 'a:1:{s:2:\"en\";s:26:\"Frequently Asked Questions\";}', '/__SYSTEM__/Modules/FAQ', '/1/2/10007', 'A', 'A', '2013-08-28 18:13:38', 2, '2013-08-28 18:13:38', 2),
(10008, 10000, 0, 1, 'Siteinfo', '', 2147483647, 'a:2:{s:2:\"da\";s:8:\"Siteinfo\";s:2:\"en\";s:8:\"Siteinfo\";}', 'a:2:{s:2:\"da\";s:0:\"\";s:2:\"en\";s:0:\"\";}', '/__SYSTEM__/Modules/News/Siteinfo', '/1/2/10000/10008', 'A', 'A', '2013-09-05 12:31:53', 2, '2013-09-05 12:31:53', 2),
(10009, 2, 0, 0, 'Clip', '', 2147483647, 'a:1:{s:2:\"en\";s:4:\"Clip\";}', 'a:1:{s:2:\"en\";s:18:\"Clip root category\";}', '/__SYSTEM__/Modules/Clip', '/1/2/10009', 'A', 'A', '2013-09-10 15:25:42', 2, '2013-09-10 15:25:42', 2),
(10010, 10009, 0, 0, 'Topics', '', 2147483647, 'a:1:{s:2:\"en\";s:6:\"Topics\";}', 'a:1:{s:2:\"en\";s:32:\"Clip topics for its publications\";}', '/__SYSTEM__/Modules/Clip/Topics', '/1/2/10009/10010', 'A', 'A', '2013-09-10 15:25:42', 2, '2013-09-10 15:25:42', 2),
(10011, 10010, 0, 1, 'Zikula', '', 2147483647, 'a:1:{s:2:\"en\";s:6:\"Zikula\";}', 'a:1:{s:2:\"en\";s:27:\"Zikula related publications\";}', '/__SYSTEM__/Modules/Clip/Topics/Zikula', '/1/2/10009/10010/10011', 'A', 'A', '2013-09-10 15:25:42', 2, '2013-09-10 15:25:42', 2),
(10012, 10010, 0, 1, 'FreeSoftware', '', 2147483647, 'a:1:{s:2:\"en\";s:13:\"Free Software\";}', 'a:1:{s:2:\"en\";s:34:\"Free software related publications\";}', '/__SYSTEM__/Modules/Clip/Topics/FreeSoftware', '/1/2/10009/10010/10012', 'A', 'A', '2013-09-10 15:25:42', 2, '2013-09-10 15:25:42', 2),
(10013, 10010, 0, 1, 'Community', '', 2147483647, 'a:1:{s:2:\"en\";s:9:\"Community\";}', 'a:1:{s:2:\"en\";s:30:\"Community related publications\";}', '/__SYSTEM__/Modules/Clip/Topics/Community', '/1/2/10009/10010/10013', 'A', 'A', '2013-09-10 15:25:42', 2, '2013-09-10 15:25:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories_mapmeta`
--

CREATE TABLE `categories_mapmeta` (
  `id` int(11) NOT NULL,
  `meta_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL DEFAULT '0',
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories_mapobj`
--

CREATE TABLE `categories_mapobj` (
  `id` int(11) NOT NULL,
  `modname` varchar(60) NOT NULL,
  `tablename` varchar(60) NOT NULL,
  `obj_id` int(11) NOT NULL DEFAULT '0',
  `obj_idcolumn` varchar(60) NOT NULL DEFAULT 'id',
  `reg_id` int(11) NOT NULL DEFAULT '0',
  `reg_property` varchar(60) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories_mapobj`
--

INSERT INTO `categories_mapobj` (`id`, `modname`, `tablename`, `obj_id`, `obj_idcolumn`, `reg_id`, `reg_property`, `category_id`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(38, 'News', 'news', 2, 'sid', 2, 'Main', 36, 'A', '2012-10-16 09:28:09', 3, '2012-10-16 09:28:09', 3),
(3, 'News', 'news', 3, 'sid', 2, 'Main', 35, 'A', '2012-05-23 10:09:49', 3, '2012-05-23 10:09:49', 3),
(4, 'News', 'news', 4, 'sid', 2, 'Main', 38, 'A', '2012-05-23 10:12:32', 3, '2012-05-23 10:12:32', 3),
(7, 'News', 'news', 5, 'sid', 2, 'Main', 37, 'A', '2012-07-12 15:12:39', 3, '2012-07-12 15:12:39', 3),
(8, 'News', 'news', 6, 'sid', 2, 'Main', 41, 'A', '2012-07-12 18:23:19', 3, '2012-07-12 18:23:19', 3),
(9, 'News', 'news', 7, 'sid', 2, 'Main', 37, 'A', '2012-07-14 19:24:14', 3, '2012-07-14 19:24:14', 3),
(19, 'News', 'news', 8, 'sid', 2, 'Main', 33, 'A', '2012-08-02 11:29:29', 5, '2012-08-02 11:29:29', 5),
(11, 'News', 'news', 9, 'sid', 2, 'Main', 35, 'A', '2012-07-20 11:16:59', 3, '2012-07-20 11:16:59', 3),
(12, 'News', 'news', 10, 'sid', 2, 'Main', 35, 'A', '2012-07-20 11:21:10', 5, '2012-07-20 11:21:10', 5),
(27, 'News', 'news', 22, 'sid', 2, 'Main', 36, 'A', '2012-08-06 12:16:31', 3, '2012-08-06 12:16:31', 3),
(26, 'News', 'news', 21, 'sid', 2, 'Main', 37, 'A', '2012-08-06 12:11:53', 5, '2012-08-06 12:11:53', 5),
(16, 'News', 'news', 14, 'sid', 2, 'Main', 39, 'A', '2012-08-01 13:32:11', 5, '2012-08-01 13:32:11', 5),
(17, 'News', 'news', 15, 'sid', 2, 'Main', 33, 'A', '2012-08-01 13:35:39', 3, '2012-08-01 13:35:39', 3),
(20, 'News', 'news', 16, 'sid', 2, 'Main', 34, 'A', '2012-08-02 14:36:56', 5, '2012-08-02 14:36:56', 5),
(22, 'News', 'news', 17, 'sid', 2, 'Main', 38, 'A', '2012-08-03 13:42:42', 5, '2012-08-03 13:42:42', 5),
(48, 'News', 'news', 18, 'sid', 2, 'Main', 41, 'A', '2012-10-17 16:47:09', 3, '2012-10-17 16:47:09', 3),
(28, 'News', 'news', 23, 'sid', 2, 'Main', 33, 'A', '2012-08-06 12:32:23', 3, '2012-08-06 12:32:23', 3),
(32, 'News', 'news', 24, 'sid', 2, 'Main', 36, 'A', '2012-08-07 09:14:26', 5, '2012-08-07 09:14:26', 5),
(31, 'News', 'news', 25, 'sid', 2, 'Main', 41, 'A', '2012-08-07 09:13:39', 5, '2012-08-07 09:13:39', 5),
(33, 'News', 'news', 19, 'sid', 2, 'Main', 33, 'A', '2012-08-07 09:14:46', 5, '2012-08-07 09:14:46', 5),
(34, 'News', 'news', 26, 'sid', 2, 'Main', 36, 'A', '2012-08-21 18:08:34', 3, '2012-08-21 18:08:34', 3),
(49, 'News', 'news', 31, 'sid', 2, '', 10002, 'A', '2013-02-18 09:58:15', 3, '2013-02-18 09:58:15', 3),
(50, 'News', 'news', 32, 'sid', 2, '', 10002, 'A', '2013-02-18 10:01:38', 3, '2013-02-18 10:01:38', 3),
(51, 'News', 'news', 33, 'sid', 2, '', 10003, 'A', '2013-02-18 10:25:05', 2, '2013-02-18 10:25:05', 2),
(52, 'News', 'news', 34, 'sid', 2, '', 10004, 'A', '2013-02-18 13:15:28', 3, '2013-02-18 13:15:28', 3),
(63, 'News', 'news', 36, 'sid', 2, '', 10008, 'A', '2013-09-05 20:00:25', 2, '2013-09-05 20:00:25', 2),
(64, 'News', 'news', 37, 'sid', 2, '', 10008, 'A', '2013-09-05 20:03:56', 2, '2013-09-05 20:03:56', 2),
(65, 'News', 'news', 38, 'sid', 2, '', 10008, 'A', '2013-09-27 00:56:08', 2, '2013-09-27 00:56:08', 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories_registry`
--

CREATE TABLE `categories_registry` (
  `id` int(11) NOT NULL,
  `modname` varchar(60) NOT NULL,
  `tablename` varchar(60) NOT NULL,
  `property` varchar(60) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories_registry`
--

INSERT INTO `categories_registry` (`id`, `modname`, `tablename`, `property`, `category_id`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(2, 'News', 'news', 'Main', 10000, 'A', '2012-02-16 09:12:53', 3, '2012-12-28 14:14:01', 2),
(3, 'FAQ', 'faqanswer', 'Main', 32, 'A', '2013-08-28 18:13:38', 2, '2013-08-28 18:13:38', 2),
(4, 'Content', 'content_page', 'primary', 32, 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:21:56', 2),
(5, 'Clip', 'clip_pubtypes', 'Global', 32, 'A', '2013-09-10 15:25:42', 2, '2013-09-10 15:25:42', 2),
(6, 'Clip', 'clip_pubtypes', 'Topics', 10010, 'A', '2013-09-10 15:25:43', 2, '2013-09-10 15:25:43', 2);

-- --------------------------------------------------------

--
-- Table structure for table `clip_grouptypes`
--

CREATE TABLE `clip_grouptypes` (
  `gid` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `sortorder` text NOT NULL,
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `level` smallint(6) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clip_grouptypes`
--

INSERT INTO `clip_grouptypes` (`gid`, `name`, `description`, `sortorder`, `lft`, `rgt`, `level`) VALUES
(1, 's:8:\"__ROOT__\";', 'a:0:{}', 'a:0:{}', 1, 4, 0),
(2, 'a:1:{s:2:\"en\";s:8:\"Contents\";}', 'a:1:{s:2:\"en\";s:34:\"Publication contents of this site.\";}', 'a:0:{}', 2, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `clip_pubdata1`
--

CREATE TABLE `clip_pubdata1` (
  `pid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `urltitle` varchar(255) NOT NULL,
  `author` int(11) NOT NULL,
  `hits` bigint(20) DEFAULT '0',
  `language` varchar(10) DEFAULT NULL,
  `revision` int(11) NOT NULL DEFAULT '1',
  `online` tinyint(1) DEFAULT '0',
  `intrash` tinyint(1) DEFAULT '0',
  `visible` tinyint(1) DEFAULT '1',
  `locked` tinyint(1) DEFAULT '0',
  `publishdate` datetime DEFAULT NULL,
  `expiredate` datetime DEFAULT NULL,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0',
  `field1` varchar(255) DEFAULT NULL,
  `field2` text,
  `field3` text,
  `field4` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clip_pubdata1`
--

INSERT INTO `clip_pubdata1` (`pid`, `id`, `urltitle`, `author`, `hits`, `language`, `revision`, `online`, `intrash`, `visible`, `locked`, `publishdate`, `expiredate`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `field1`, `field2`, `field3`, `field4`) VALUES
(1, 1, 'hello-world', 2, 21, '', 3, 1, 0, 1, 0, '2011-01-01 00:00:00', NULL, 'A', '2013-09-10 15:25:45', 2, '2013-09-10 15:25:45', 2, 'Hello world!', '<p> This is an example of a Blog post, edit or delete it, and start to publish!\n</p>\n<p>You will find that with your customization of the autogenerated templates, Clip will be able to fulfil your expectatives. Enjoy\n</p>\n<p>(this is pre-release content, to be enriched with users’ feedback)\n</p>', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `clip_pubdata2`
--

CREATE TABLE `clip_pubdata2` (
  `pid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `urltitle` varchar(255) NOT NULL,
  `author` int(11) NOT NULL,
  `hits` bigint(20) DEFAULT '0',
  `language` varchar(10) DEFAULT NULL,
  `revision` int(11) NOT NULL DEFAULT '1',
  `online` tinyint(1) DEFAULT '0',
  `intrash` tinyint(1) DEFAULT '0',
  `visible` tinyint(1) DEFAULT '1',
  `locked` tinyint(1) DEFAULT '0',
  `publishdate` datetime DEFAULT NULL,
  `expiredate` datetime DEFAULT NULL,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0',
  `field5` varchar(255) DEFAULT NULL,
  `field6` int(11) DEFAULT NULL,
  `field7` text,
  `field8` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clip_pubdata2`
--

INSERT INTO `clip_pubdata2` (`pid`, `id`, `urltitle`, `author`, `hits`, `language`, `revision`, `online`, `intrash`, `visible`, `locked`, `publishdate`, `expiredate`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `field5`, `field6`, `field7`, `field8`) VALUES
(1, 1, 'about-clip-static-pages', 2, 17, '', 3, 1, 0, 1, 0, '2011-01-01 00:00:00', NULL, 'A', '2013-09-10 15:25:47', 2, '2013-09-10 15:25:47', 2, 'About Clip Static Pages', 0, '<p>As you may know, Clip can handle multiple purpose applications through its publication types. This default Pages publication type shows how it can be useful to manage the static pages of your site.\n</p>\n<p>The default fields defined are as follows:\n</p>\n<ul>\n  <li>a title (string),</li>\n  <li>the page\'s content (text),</li>\n  <li>a category (list),</li>\n  <li>and even a config option (checkbox)</li>\n</ul>\n<p>The default templates are examples of how you can structure your publication type to fit your needs, in this case, a three step navigation: initially showing a list with the available categories (list.tpl), to present a list with the available pages inside one of them (list_category.tpl), and finally display the page (display.tpl).\n</p>\n<p> The list_category.tpl template has some logic on it to resolve the title depending on the filter used.\n  <br />\n</p>\n<p>The edit form is also customized to look pretty like the one of the Pages module.\n</p>\n<p>Hope that his example be useful to you.\n  <br /> Enjoy the possibilities!\n</p>\n<p>(this is pre-release content, to be enriched with users’ feedback)\n</p>', 1),
(2, 2, 'about-us', 2, 3, '', 0, 1, 0, 1, 0, '2011-01-01 00:00:00', NULL, 'A', '2013-09-10 15:25:47', 2, '2013-09-10 15:25:47', 2, 'About Us', 0, '<p>This is a temptative About Us page for your site.</p>\n\n<p>You can enrich it easily with the help of Scribite and its WYSIWYG editors. By default, the content (a text field) have enabled the use of Scribite on its config, but it requires the module installed on the site to work.</p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `clip_pubdata3`
--

CREATE TABLE `clip_pubdata3` (
  `pid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `urltitle` varchar(255) NOT NULL,
  `author` int(11) NOT NULL,
  `hits` bigint(20) DEFAULT '0',
  `language` varchar(10) DEFAULT NULL,
  `revision` int(11) NOT NULL DEFAULT '1',
  `online` tinyint(1) DEFAULT '0',
  `intrash` tinyint(1) DEFAULT '0',
  `visible` tinyint(1) DEFAULT '1',
  `locked` tinyint(1) DEFAULT '0',
  `publishdate` datetime DEFAULT NULL,
  `expiredate` datetime DEFAULT NULL,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0',
  `field9` varchar(255) DEFAULT NULL,
  `field10` text,
  `field11` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clip_pubdata3`
--

INSERT INTO `clip_pubdata3` (`pid`, `id`, `urltitle`, `author`, `hits`, `language`, `revision`, `online`, `intrash`, `visible`, `locked`, `publishdate`, `expiredate`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `field9`, `field10`, `field11`) VALUES
(1, 1, 'test-headline', 2, 2, '', 1, 1, 0, 1, 0, '2013-09-10 15:51:37', NULL, 'A', '2013-09-10 15:51:37', 2, '2013-09-10 15:51:37', 2, 'Test headline', 'Test teaser', 'Test text'),
(2, 2, 'test-headlinf', 2, 1, '', 1, 1, 0, 1, 0, '2013-09-10 15:59:39', NULL, 'A', '2013-09-10 15:59:39', 2, '2013-09-10 15:59:39', 2, 'Test headline', 'Test Teaser', 'Test Text');

-- --------------------------------------------------------

--
-- Table structure for table `clip_pubfields`
--

CREATE TABLE `clip_pubfields` (
  `id` int(11) NOT NULL,
  `tid` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `plugin` varchar(50) NOT NULL DEFAULT '',
  `config` text,
  `fielddbtype` varchar(50) NOT NULL DEFAULT '',
  `fieldmaxlength` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `is_title` tinyint(1) NOT NULL DEFAULT '0',
  `is_mandatory` tinyint(1) NOT NULL DEFAULT '0',
  `is_searchable` tinyint(1) NOT NULL DEFAULT '0',
  `is_filterable` tinyint(1) NOT NULL DEFAULT '0',
  `is_pageable` tinyint(1) NOT NULL DEFAULT '0',
  `is_counter` tinyint(1) NOT NULL DEFAULT '0',
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clip_pubfields`
--

INSERT INTO `clip_pubfields` (`id`, `tid`, `name`, `title`, `description`, `plugin`, `config`, `fielddbtype`, `fieldmaxlength`, `weight`, `is_title`, `is_mandatory`, `is_searchable`, `is_filterable`, `is_pageable`, `is_counter`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 1, 'title', 'Title', 'Enter title here', 'String', '', 'C(255)', NULL, 1, 1, 1, 1, 1, 0, 0, 'A', '2013-09-10 15:25:43', 2, '2013-09-10 15:25:43', 2),
(2, 1, 'content', 'Content', '', 'Text', '1', 'C(65535)', NULL, 2, 0, 0, 1, 0, 0, 0, 'A', '2013-09-10 15:25:43', 2, '2013-09-10 15:25:43', 2),
(3, 1, 'summary', 'Summary', 'Optional hand-crafted summary of your content that can be used in your templates.', 'Text', '0', 'C(65535)', NULL, 3, 0, 0, 0, 0, 0, 0, 'A', '2013-09-10 15:25:43', 2, '2013-09-10 15:25:43', 2),
(4, 1, 'category', 'Category', '', 'List', ',1,0', 'I4', NULL, 4, 0, 0, 0, 1, 0, 0, 'A', '2013-09-10 15:25:43', 2, '2013-09-10 15:25:43', 2),
(5, 2, 'title', 'Title', '', 'String', '', 'C(255)', NULL, 1, 1, 1, 1, 1, 0, 0, 'A', '2013-09-10 15:25:45', 2, '2013-09-10 15:25:45', 2),
(6, 2, 'category', 'Category', '', 'List', ',1,0', 'I4', NULL, 2, 0, 0, 0, 1, 0, 0, 'A', '2013-09-10 15:25:45', 2, '2013-09-10 15:25:45', 2),
(7, 2, 'content', 'Content', '', 'Text', '1', 'C(65535)', NULL, 3, 0, 0, 1, 0, 0, 0, 'A', '2013-09-10 15:25:45', 2, '2013-09-10 15:25:45', 2),
(8, 2, 'displayinfo', 'Display page information', '', 'Checkbox', '', 'L', NULL, 4, 0, 0, 0, 0, 0, 0, 'A', '2013-09-10 15:25:45', 2, '2013-09-10 15:25:45', 2),
(9, 3, 'HeadLine', 'Headline', '', 'String', '', 'C(255)', 255, 1, 1, 1, 1, 1, 0, 0, 'A', '2013-09-10 15:46:19', 2, '2013-09-10 15:46:19', 2),
(10, 3, 'Teaser', 'Teaser', '', 'Text', '1', 'C(65535)', 1024, 2, 0, 0, 1, 0, 0, 0, 'A', '2013-09-10 15:47:45', 2, '2013-09-10 15:47:45', 2),
(11, 3, 'Text', 'Text', '', 'Text', '1', 'C(65535)', 6000, 3, 0, 0, 0, 0, 0, 0, 'A', '2013-09-10 15:48:22', 2, '2013-09-10 15:48:22', 2);

-- --------------------------------------------------------

--
-- Table structure for table `clip_pubtypes`
--

CREATE TABLE `clip_pubtypes` (
  `tid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `urltitle` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `fixedfilter` varchar(255) DEFAULT NULL,
  `defaultfilter` varchar(255) DEFAULT NULL,
  `itemsperpage` int(11) NOT NULL DEFAULT '15',
  `cachelifetime` bigint(20) NOT NULL DEFAULT '0',
  `sortfield1` varchar(255) DEFAULT NULL,
  `sortdesc1` tinyint(1) DEFAULT NULL,
  `sortfield2` varchar(255) DEFAULT NULL,
  `sortdesc2` tinyint(1) DEFAULT NULL,
  `sortfield3` varchar(255) DEFAULT NULL,
  `sortdesc3` tinyint(1) DEFAULT NULL,
  `enableeditown` tinyint(1) NOT NULL DEFAULT '0',
  `enablerevisions` tinyint(1) NOT NULL DEFAULT '0',
  `folder` varchar(255) NOT NULL DEFAULT '',
  `workflow` varchar(255) NOT NULL DEFAULT '',
  `grouptype` int(11) DEFAULT NULL,
  `config` text,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clip_pubtypes`
--

INSERT INTO `clip_pubtypes` (`tid`, `title`, `urltitle`, `description`, `fixedfilter`, `defaultfilter`, `itemsperpage`, `cachelifetime`, `sortfield1`, `sortdesc1`, `sortfield2`, `sortdesc2`, `sortfield3`, `sortdesc3`, `enableeditown`, `enablerevisions`, `folder`, `workflow`, `grouptype`, `config`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'Blog', 'blog', 'Express yourself!', NULL, '', 10, 0, '', 0, '', 0, '', 0, 0, 0, 'blog', 'standard.xml', 2, 'a:3:{s:4:\"view\";a:6:{s:4:\"load\";b:0;s:7:\"onlyown\";b:1;s:11:\"processrefs\";b:0;s:9:\"checkperm\";b:0;s:13:\"handleplugins\";b:0;s:12:\"loadworkflow\";b:0;}s:7:\"display\";a:6:{s:4:\"load\";b:1;s:7:\"onlyown\";b:1;s:11:\"processrefs\";b:1;s:9:\"checkperm\";b:1;s:13:\"handleplugins\";b:0;s:12:\"loadworkflow\";b:0;}s:4:\"edit\";a:1:{s:7:\"onlyown\";b:1;}}', 'A', '2013-09-10 15:25:43', 2, '2013-09-10 15:25:43', 2),
(2, 'Pages', 'staticpages', 'Static pages of the site', NULL, '', 25, 0, '', 0, '', 0, '', 0, 0, 0, 'pages', 'none.xml', 2, 'a:3:{s:4:\"view\";a:6:{s:4:\"load\";b:0;s:7:\"onlyown\";b:1;s:11:\"processrefs\";b:0;s:9:\"checkperm\";b:0;s:13:\"handleplugins\";b:0;s:12:\"loadworkflow\";b:0;}s:7:\"display\";a:6:{s:4:\"load\";b:0;s:7:\"onlyown\";b:1;s:11:\"processrefs\";b:1;s:9:\"checkperm\";b:1;s:13:\"handleplugins\";b:0;s:12:\"loadworkflow\";b:0;}s:4:\"edit\";a:1:{s:7:\"onlyown\";b:1;}}', 'A', '2013-09-10 15:25:45', 2, '2013-09-10 15:25:45', 2),
(3, 'TestPageStd', 'testpagestd', 'Testpage in Clip - Standard', '', '', 15, 0, '', 0, '', 0, '', 0, 1, 0, '/web/userdata/Clip/Doc', 'standard.xml', 2, 'a:3:{s:4:\"list\";a:3:{s:4:\"load\";b:0;s:7:\"onlyown\";b:1;s:9:\"checkperm\";b:0;}s:7:\"display\";a:3:{s:4:\"load\";b:1;s:7:\"onlyown\";b:1;s:9:\"checkperm\";b:1;}s:4:\"edit\";a:2:{s:4:\"load\";b:1;s:7:\"onlyown\";b:1;}}', 'A', '2013-09-10 15:44:54', 2, '2013-09-10 16:02:31', 2);

-- --------------------------------------------------------

--
-- Table structure for table `clip_relations`
--

CREATE TABLE `clip_relations` (
  `id` int(11) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `tid1` int(11) DEFAULT NULL,
  `alias1` varchar(100) DEFAULT NULL,
  `title1` varchar(100) DEFAULT NULL,
  `desc1` text,
  `tid2` int(11) DEFAULT NULL,
  `alias2` varchar(100) DEFAULT NULL,
  `title2` varchar(100) DEFAULT NULL,
  `desc2` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `clip_workflowvars`
--

CREATE TABLE `clip_workflowvars` (
  `id` int(11) NOT NULL,
  `tid` int(11) NOT NULL DEFAULT '0',
  `workflow` varchar(255) NOT NULL DEFAULT '',
  `setting` varchar(255) NOT NULL DEFAULT '',
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `content_content`
--

CREATE TABLE `content_content` (
  `con_id` int(11) NOT NULL,
  `con_pageid` int(11) NOT NULL DEFAULT '0',
  `con_areaindex` int(11) NOT NULL DEFAULT '0',
  `con_position` int(11) NOT NULL DEFAULT '0',
  `con_module` varchar(100) NOT NULL,
  `con_type` varchar(100) NOT NULL,
  `con_data` longtext,
  `con_active` tinyint(4) NOT NULL DEFAULT '1',
  `con_visiblefor` tinyint(4) NOT NULL DEFAULT '1',
  `con_stylepos` varchar(20) NOT NULL DEFAULT 'none',
  `con_stylewidth` varchar(20) NOT NULL DEFAULT 'wauto',
  `con_styleclass` varchar(100) NOT NULL,
  `con_obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `con_cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `con_cr_uid` int(11) NOT NULL DEFAULT '0',
  `con_lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `con_lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_content`
--

INSERT INTO `content_content` (`con_id`, `con_pageid`, `con_areaindex`, `con_position`, `con_module`, `con_type`, `con_data`, `con_active`, `con_visiblefor`, `con_stylepos`, `con_stylewidth`, `con_styleclass`, `con_obj_status`, `con_cr_date`, `con_cr_uid`, `con_lu_date`, `con_lu_uid`) VALUES
(1, 1, 0, 0, 'Content', 'Heading', 'a:2:{s:4:\"text\";s:67:\"A Content page consists of various content items in a chosen layout\";s:10:\"headerSize\";s:2:\"h3\";}', 1, 1, 'none', 'wauto', '', 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:26:40', 2),
(2, 1, 1, 0, 'Content', 'Html', 'a:2:{s:4:\"text\";s:673:\"<p>Each created page has a specific layout, like 1 column with and without a header, 2 columns, 3 columns. The chosen layout contains various content areas. In each area you can place 1 or more content items of various kinds like:</p> <ul> <li>HTML text;</li> <li>YouTube videos;</li> <li>Google maps;</li> <li>Flickr photos;</li> <li>RSS feeds;</li> <li>Computer Code;</li> <li>the output of another Zikula module.</li> </ul> <p>Within these content areas you can sort the content items by means of drag & drop.<br /> You can make an unlimited number of pages and structure them hierarchical. Your page structure can be displayed in a multi level menu in your website.</p>\";s:9:\"inputType\";s:4:\"text\";}', 1, 1, 'none', 'wauto', '', 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:21:56', 2),
(3, 1, 1, 1, 'Content', 'Html', 'a:2:{s:4:\"text\";s:323:\"<p><strong>This is a second HTML text content item in the left column</strong><br /> Content is an extendible module. You can create your own content plugins and layouts and other Zikula modules can also offer content items. The News published module for instance has a Content plugin for a list of the latest articles.</p>\";s:9:\"inputType\";s:4:\"text\";}', 1, 1, 'none', 'wauto', '', 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:21:56', 2),
(4, 1, 2, 2, 'Content', 'Quote', 'a:3:{s:4:\"text\";s:59:\"No matter what your needs, Zikula can provide the solution.\";s:6:\"source\";s:17:\"http://zikula.org\";s:4:\"desc\";s:15:\"Zikula homepage\";}', 1, 1, 'none', 'wauto', '', 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:21:56', 2),
(5, 1, 2, 0, 'Content', 'ComputerCode', 'a:1:{s:4:\"text\";s:40:\"$this->doAction($var); // just some code\";}', 1, 1, 'none', 'wauto', '', 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:37:22', 2),
(6, 1, 2, 1, 'Content', 'Html', 'a:2:{s:4:\"text\";s:307:\"<p>So you see that you can place all kinds of content on the page in your own style and liking. This makes Content a really powerful module.</p> <p>This page uses the <strong>2 column (62|38) layout</strong> which has a header, 2 colums with 62% width on the left and 38% width on the right and a footer</p>\";s:9:\"inputType\";s:4:\"text\";}', 1, 1, 'none', 'wauto', '', 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:37:29', 2),
(7, 1, 3, 0, 'Content', 'Html', 'a:2:{s:4:\"text\";s:346:\"This <strong>footer</strong> finishes of this introduction page. Good luck with using Content. The <a href=\"index.php?module=content&type=admin\">Edit Contents</a> interface lets you edit or delete this introduction page. In the <a href=\"index.php?module=content&type=admin\">administration</a> interface you can further control the Content module.\";s:9:\"inputType\";s:4:\"text\";}', 1, 1, 'none', 'wauto', '', 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:21:56', 2),
(8, 2, 2, 0, 'Content', 'Html', 'a:2:{s:4:\"text\";s:231:\"Vi har introduceret 4 nye services og starter med at give 1. måneds anvendelse gratis som demo periode.\n\nVælg de nye spændende services som demo og se om det er noget for din butik inden du betaler.\n\nVenlig hilsen\nTeam CityPilot\";s:9:\"inputType\";s:4:\"html\";}', 1, 0, 'none', 'wauto', '', 'A', '2013-09-27 01:32:58', 2, '2013-09-27 01:34:36', 2);

-- --------------------------------------------------------

--
-- Table structure for table `content_history`
--

CREATE TABLE `content_history` (
  `ch_id` int(11) NOT NULL,
  `ch_pageid` int(11) NOT NULL DEFAULT '0',
  `ch_data` longtext NOT NULL,
  `ch_revisionno` int(11) NOT NULL DEFAULT '0',
  `ch_action` varchar(255) NOT NULL,
  `ch_date` datetime NOT NULL,
  `ch_ipno` varchar(30) NOT NULL,
  `ch_userid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `content_page`
--

CREATE TABLE `content_page` (
  `page_id` int(11) NOT NULL,
  `page_ppid` int(11) NOT NULL DEFAULT '0',
  `page_title` varchar(255) NOT NULL,
  `page_showtitle` tinyint(4) NOT NULL DEFAULT '1',
  `page_urlname` varchar(255) NOT NULL,
  `page_metadescription` longtext NOT NULL,
  `page_metakeywords` longtext NOT NULL,
  `page_nohooks` tinyint(4) NOT NULL DEFAULT '0',
  `page_layout` varchar(100) NOT NULL,
  `page_categoryid` int(11) DEFAULT '0',
  `page_views` int(11) DEFAULT '0',
  `page_active` tinyint(4) NOT NULL DEFAULT '1',
  `page_activefrom` datetime DEFAULT NULL,
  `page_activeto` datetime DEFAULT NULL,
  `page_inmenu` tinyint(4) NOT NULL DEFAULT '1',
  `page_pos` int(11) NOT NULL DEFAULT '0',
  `page_level` int(11) NOT NULL DEFAULT '0',
  `page_setleft` int(11) NOT NULL DEFAULT '0',
  `page_setright` int(11) NOT NULL DEFAULT '0',
  `page_language` varchar(10) DEFAULT NULL,
  `page_obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `page_cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `page_cr_uid` int(11) NOT NULL DEFAULT '0',
  `page_lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `page_lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_page`
--

INSERT INTO `content_page` (`page_id`, `page_ppid`, `page_title`, `page_showtitle`, `page_urlname`, `page_metadescription`, `page_metakeywords`, `page_nohooks`, `page_layout`, `page_categoryid`, `page_views`, `page_active`, `page_activefrom`, `page_activeto`, `page_inmenu`, `page_pos`, `page_level`, `page_setleft`, `page_setright`, `page_language`, `page_obj_status`, `page_cr_date`, `page_cr_uid`, `page_lu_date`, `page_lu_uid`) VALUES
(1, 0, 'Content introduction page', 1, 'content-introduction-page', '', '', 0, 'Column2d6238', NULL, 0, 1, NULL, NULL, 1, 0, 0, 0, 1, 'en', 'A', '2013-09-10 14:21:56', 2, '2013-09-10 14:37:38', 2),
(2, 0, 'CityPilot får 4 nye services', 1, 'citypilot-far-4-nye-services', '', '', 0, 'Column1top', NULL, 0, 1, NULL, NULL, 1, 1, 0, 2, 3, 'en', 'A', '2013-09-27 01:32:25', 2, '2013-09-27 01:35:06', 2);

-- --------------------------------------------------------

--
-- Table structure for table `content_pagecategory`
--

CREATE TABLE `content_pagecategory` (
  `con_pageid` int(11) NOT NULL DEFAULT '0',
  `con_categoryid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `content_searchable`
--

CREATE TABLE `content_searchable` (
  `search_cid` int(11) NOT NULL,
  `search_text` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `content_searchable`
--

INSERT INTO `content_searchable` (`search_cid`, `search_text`) VALUES
(8, 'Vi har introduceret 4 nye services og starter med at give 1. måneds anvendelse gratis som demo periode.\n\nVælg de nye spændende services som demo og se om det er noget for din butik inden du betaler.\n\nVenlig hilsen\nTeam CityPilot');

-- --------------------------------------------------------

--
-- Table structure for table `content_translatedcontent`
--

CREATE TABLE `content_translatedcontent` (
  `transc_cid` int(11) NOT NULL DEFAULT '0',
  `transc_lang` varchar(10) NOT NULL,
  `transc_data` longtext,
  `transc_obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `transc_cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `transc_cr_uid` int(11) NOT NULL DEFAULT '0',
  `transc_lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `transc_lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `content_translatedpage`
--

CREATE TABLE `content_translatedpage` (
  `transp_pid` int(11) NOT NULL DEFAULT '0',
  `transp_lang` varchar(10) NOT NULL,
  `transp_title` varchar(255) NOT NULL,
  `transp_metadescription` longtext NOT NULL,
  `transp_metakeywords` longtext NOT NULL,
  `transp_obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `transp_cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `transp_cr_uid` int(11) NOT NULL DEFAULT '0',
  `transp_lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `transp_lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `faqanswer`
--

CREATE TABLE `faqanswer` (
  `id` int(11) NOT NULL,
  `question` longtext,
  `urltitle` longtext NOT NULL,
  `answer` longtext,
  `submittedbyid` int(11) NOT NULL,
  `answeredbyid` int(11) NOT NULL,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `fconnect`
--

CREATE TABLE `fconnect` (
  `id` int(11) NOT NULL,
  `fb_id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fconnect`
--

INSERT INTO `fconnect` (`id`, `fb_id`, `user_id`) VALUES
(30, 100007685161502, 108),
(40, 1730233823857909, 137),
(49, 100005664426990, 3);

-- --------------------------------------------------------

--
-- Table structure for table `google`
--

CREATE TABLE `google` (
  `id` int(11) NOT NULL,
  `google_id` longtext NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `google`
--

INSERT INTO `google` (`id`, `google_id`, `user_id`) VALUES
(1, '100742141262572601677', 3),
(2, '110470125841417864088', 135);

-- --------------------------------------------------------

--
-- Table structure for table `group_applications`
--

CREATE TABLE `group_applications` (
  `app_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL DEFAULT '0',
  `gid` int(11) NOT NULL DEFAULT '0',
  `application` longtext NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `group_membership`
--

CREATE TABLE `group_membership` (
  `gid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_membership`
--

INSERT INTO `group_membership` (`gid`, `uid`) VALUES
(1, 1),
(1, 2),
(2, 2),
(1, 3),
(2, 3),
(4, 3),
(5, 3),
(6, 3),
(1, 9),
(5, 9),
(5, 13),
(1, 21),
(4, 21),
(6, 21),
(1, 22),
(4, 22),
(6, 22),
(1, 24),
(4, 24),
(6, 24),
(1, 30),
(1, 31),
(1, 32),
(1, 55),
(4, 55),
(1, 56),
(4, 56),
(6, 56),
(1, 57),
(4, 57),
(1, 58),
(4, 58),
(1, 59),
(4, 59),
(1, 60),
(4, 60),
(1, 61),
(4, 61),
(1, 62),
(4, 62),
(1, 63),
(4, 63),
(1, 64),
(4, 64),
(1, 65),
(1, 69),
(4, 69),
(1, 73),
(4, 73),
(1, 97),
(4, 98),
(1, 99),
(4, 99),
(6, 99),
(4, 100),
(1, 108),
(1, 116),
(1, 125),
(4, 125),
(5, 125),
(1, 131),
(1, 135),
(2, 135),
(4, 135),
(5, 135),
(1, 136),
(4, 136),
(6, 136),
(1, 137),
(4, 137),
(6, 137);

-- --------------------------------------------------------

--
-- Table structure for table `group_perms`
--

CREATE TABLE `group_perms` (
  `pid` int(11) NOT NULL,
  `gid` int(11) NOT NULL DEFAULT '0',
  `sequence` int(11) NOT NULL DEFAULT '0',
  `realm` int(11) NOT NULL DEFAULT '0',
  `component` varchar(255) NOT NULL,
  `instance` varchar(255) NOT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `bond` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_perms`
--

INSERT INTO `group_perms` (`pid`, `gid`, `sequence`, `realm`, `component`, `instance`, `level`, `bond`) VALUES
(1, 2, 2, 0, '.*', '.*', 800, 0),
(2, -1, 4, 0, 'ExtendedMenublock::', '1:1:', 0, 0),
(3, 1, 17, 0, '.*', '.*', 300, 0),
(4, 0, 18, 0, 'ExtendedMenublock::', '1:(1|2|3|5):', 0, 0),
(5, 0, 22, 0, '.*', '.*', 200, 0),
(7, 4, 8, 0, 'ZSELEX::', '.*', 600, 0),
(8, 4, 10, 0, '.*', '.*', 300, 0),
(9, 1, 15, 0, 'ExtendedMenublock::', '1:(5):', 0, 0),
(10, 4, 6, 0, 'News:pictureupload:', '.*', 600, 0),
(11, 4, 7, 0, 'News::', '.*', 700, 0),
(12, 4, 9, 0, 'Users::', 'user::createshopadmin', 800, 0),
(13, 5, 14, 0, '.*', '.*', 300, 0),
(14, 5, 12, 0, 'ExtendedMenublock::', '1:1:', 0, 0),
(15, 5, 13, 0, 'ZSELEX::', '.*', 500, 0),
(16, 0, 21, 0, 'Minisitemenu::', '75:(3):', 0, 0),
(17, 1, 16, 0, 'Minisitemenu::', '75:(3):', 0, 0),
(18, 0, 0, 0, 'ExtendedMenublock::', '64:(4):', 200, 0),
(19, -1, 1, 0, 'ExtendedMenublock::', '64:(4):', 0, 0),
(24, 0, 19, 0, 'ExtendedMenublock::', '64:(3):', 0, 0),
(25, 5, 11, 0, 'ExtendedMenublock::', '64:(3):', 0, 0),
(26, 4, 5, 0, 'ExtendedMenublock::', '64:(3):', 0, 0),
(27, 0, 20, 0, 'ExtendedMenublock::', '64:(5):', 0, 0),
(29, -1, 3, 0, 'Profile:Members:online', '.*', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `gid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gtype` tinyint(4) NOT NULL DEFAULT '0',
  `description` varchar(200) NOT NULL,
  `prefix` varchar(25) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0',
  `nbuser` int(11) NOT NULL DEFAULT '0',
  `nbumax` int(11) NOT NULL DEFAULT '0',
  `link` int(11) NOT NULL DEFAULT '0',
  `uidmaster` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`gid`, `name`, `gtype`, `description`, `prefix`, `state`, `nbuser`, `nbumax`, `link`, `uidmaster`) VALUES
(1, 'Users', 0, 'By default, all users are made members of this group.', 'usr', 0, 0, 0, 0, 0),
(2, 'Administrators', 0, 'Group of administrators of this site.', 'adm', 0, 0, 0, 0, 0),
(4, 'Shop Owner', 0, '', '', 0, 0, 0, 0, 0),
(5, 'Shop Admin', 0, '', '', 0, 0, 0, 0, 0),
(6, 'DOB', 0, 'Dansk Overfladebehandling', '', 0, 0, 0, 0, 0),
(7, 'Fredericia Shopping', 0, 'Group of shops', '', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hook_area`
--

CREATE TABLE `hook_area` (
  `id` int(11) NOT NULL,
  `owner` varchar(40) NOT NULL,
  `subowner` varchar(40) DEFAULT NULL,
  `areatype` varchar(1) NOT NULL,
  `category` varchar(20) NOT NULL,
  `areaname` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hook_area`
--

INSERT INTO `hook_area` (`id`, `owner`, `subowner`, `areatype`, `category`, `areaname`) VALUES
(1, 'Users', NULL, 's', 'ui_hooks', 'subscriber.users.ui_hooks.user'),
(2, 'Users', NULL, 's', 'ui_hooks', 'subscriber.users.ui_hooks.registration'),
(3, 'Users', NULL, 's', 'ui_hooks', 'subscriber.users.ui_hooks.login_screen'),
(4, 'Users', NULL, 's', 'ui_hooks', 'subscriber.users.ui_hooks.login_block'),
(22, 'News', NULL, 's', 'filter_hooks', 'subscriber.news.filter_hooks.articles'),
(21, 'News', NULL, 's', 'ui_hooks', 'subscriber.news.ui_hooks.articles'),
(20, 'ShopProducts', NULL, 's', 'filter_hooks', 'subscriber.shopproducts.filter_hooks.products'),
(19, 'ShopProducts', NULL, 's', 'ui_hooks', 'subscriber.shopproducts.ui_hooks.products'),
(18, 'ShopProducts', NULL, 's', 'filter_hooks', 'subscriber.shopproducts.filter_hooks.shops'),
(17, 'ShopProducts', NULL, 's', 'ui_hooks', 'subscriber.shopproducts.ui_hooks.shops'),
(16, 'ShopProducts', NULL, 's', 'filter_hooks', 'subscriber.shopproducts.filter_hooks.cities'),
(15, 'ShopProducts', NULL, 's', 'ui_hooks', 'subscriber.shopproducts.ui_hooks.cities'),
(23, 'FAQ', NULL, 's', 'ui_hooks', 'subscriber.faq.ui_hooks.questions'),
(24, 'FAQ', NULL, 's', 'filter_hooks', 'subscriber.faq.filter_hooks.questions'),
(25, 'Content', NULL, 's', 'ui_hooks', 'subscriber.content.ui_hooks.pages'),
(26, 'Content', NULL, 's', 'filter_hooks', 'subscriber.content.filter_hooks.pages'),
(27, 'Clip', NULL, 's', 'ui_hooks', 'subscriber.clip.ui_hooks.pubtype1'),
(28, 'Clip', NULL, 's', 'filter_hooks', 'subscriber.clip.filter_hooks.pubtype1'),
(29, 'Clip', NULL, 's', 'ui_hooks', 'subscriber.clip.ui_hooks.pubtype2'),
(30, 'Clip', NULL, 's', 'filter_hooks', 'subscriber.clip.filter_hooks.pubtype2'),
(31, 'Clip', NULL, 's', 'ui_hooks', 'subscriber.clip.ui_hooks.pubtype3'),
(32, 'Clip', NULL, 's', 'filter_hooks', 'subscriber.clip.filter_hooks.pubtype3'),
(33, 'Blocks', NULL, 's', 'ui_hooks', 'subscriber.blocks.ui_hooks.htmlblock.content');

-- --------------------------------------------------------

--
-- Table structure for table `hook_binding`
--

CREATE TABLE `hook_binding` (
  `id` int(11) NOT NULL,
  `sowner` varchar(40) NOT NULL,
  `subsowner` varchar(40) DEFAULT NULL,
  `powner` varchar(40) NOT NULL,
  `subpowner` varchar(40) DEFAULT NULL,
  `sareaid` int(11) NOT NULL,
  `pareaid` int(11) NOT NULL,
  `category` varchar(20) NOT NULL,
  `sortorder` smallint(6) NOT NULL DEFAULT '999'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `hook_provider`
--

CREATE TABLE `hook_provider` (
  `id` int(11) NOT NULL,
  `owner` varchar(40) NOT NULL,
  `subowner` varchar(40) DEFAULT NULL,
  `pareaid` int(11) NOT NULL,
  `hooktype` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `classname` varchar(60) NOT NULL,
  `method` varchar(20) NOT NULL,
  `serviceid` varchar(60) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `hook_runtime`
--

CREATE TABLE `hook_runtime` (
  `id` int(11) NOT NULL,
  `sowner` varchar(40) NOT NULL,
  `subsowner` varchar(40) DEFAULT NULL,
  `powner` varchar(40) NOT NULL,
  `subpowner` varchar(40) DEFAULT NULL,
  `sareaid` int(11) NOT NULL,
  `pareaid` int(11) NOT NULL,
  `eventname` varchar(100) NOT NULL,
  `classname` varchar(60) NOT NULL,
  `method` varchar(20) NOT NULL,
  `serviceid` varchar(60) DEFAULT NULL,
  `priority` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `hook_subscriber`
--

CREATE TABLE `hook_subscriber` (
  `id` int(11) NOT NULL,
  `owner` varchar(40) NOT NULL,
  `subowner` varchar(40) DEFAULT NULL,
  `sareaid` int(11) NOT NULL,
  `hooktype` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `eventname` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hook_subscriber`
--

INSERT INTO `hook_subscriber` (`id`, `owner`, `subowner`, `sareaid`, `hooktype`, `category`, `eventname`) VALUES
(1, 'Users', NULL, 1, 'display_view', 'ui_hooks', 'users.ui_hooks.user.display_view'),
(2, 'Users', NULL, 1, 'form_edit', 'ui_hooks', 'users.ui_hooks.user.form_edit'),
(3, 'Users', NULL, 1, 'validate_edit', 'ui_hooks', 'users.ui_hooks.user.validate_edit'),
(4, 'Users', NULL, 1, 'process_edit', 'ui_hooks', 'users.ui_hooks.user.process_edit'),
(5, 'Users', NULL, 1, 'form_delete', 'ui_hooks', 'users.ui_hooks.user.form_delete'),
(6, 'Users', NULL, 1, 'validate_delete', 'ui_hooks', 'users.ui_hooks.user.validate_delete'),
(7, 'Users', NULL, 1, 'process_delete', 'ui_hooks', 'users.ui_hooks.user.process_delete'),
(8, 'Users', NULL, 2, 'display_view', 'ui_hooks', 'users.ui_hooks.registration.display_view'),
(9, 'Users', NULL, 2, 'form_edit', 'ui_hooks', 'users.ui_hooks.registration.form_edit'),
(10, 'Users', NULL, 2, 'validate_edit', 'ui_hooks', 'users.ui_hooks.registration.validate_edit'),
(11, 'Users', NULL, 2, 'process_edit', 'ui_hooks', 'users.ui_hooks.registration.process_edit'),
(12, 'Users', NULL, 2, 'form_delete', 'ui_hooks', 'users.ui_hooks.registration.form_delete'),
(13, 'Users', NULL, 2, 'validate_delete', 'ui_hooks', 'users.ui_hooks.registration.validate_delete'),
(14, 'Users', NULL, 2, 'process_delete', 'ui_hooks', 'users.ui_hooks.registration.process_delete'),
(15, 'Users', NULL, 3, 'form_edit', 'ui_hooks', 'users.ui_hooks.login_screen.form_edit'),
(16, 'Users', NULL, 3, 'validate_edit', 'ui_hooks', 'users.ui_hooks.login_screen.validate_edit'),
(17, 'Users', NULL, 3, 'process_edit', 'ui_hooks', 'users.ui_hooks.login_screen.process_edit'),
(18, 'Users', NULL, 4, 'form_edit', 'ui_hooks', 'users.ui_hooks.login_block.form_edit'),
(19, 'Users', NULL, 4, 'validate_edit', 'ui_hooks', 'users.ui_hooks.login_block.validate_edit'),
(20, 'Users', NULL, 4, 'process_edit', 'ui_hooks', 'users.ui_hooks.login_block.process_edit'),
(90, 'News', NULL, 21, 'process_edit', 'ui_hooks', 'news.ui_hooks.articles.process_edit'),
(89, 'News', NULL, 21, 'validate_delete', 'ui_hooks', 'news.ui_hooks.articles.validate_delete'),
(88, 'News', NULL, 21, 'validate_edit', 'ui_hooks', 'news.ui_hooks.articles.validate_edit'),
(87, 'News', NULL, 21, 'form_delete', 'ui_hooks', 'news.ui_hooks.articles.form_delete'),
(86, 'News', NULL, 21, 'form_edit', 'ui_hooks', 'news.ui_hooks.articles.form_edit'),
(85, 'News', NULL, 21, 'display_view', 'ui_hooks', 'news.ui_hooks.articles.display_view'),
(84, 'ShopProducts', NULL, 20, 'filter', 'filter_hooks', 'shopproducts.filter_hooks.products.filter'),
(83, 'ShopProducts', NULL, 19, 'process_delete', 'ui_hooks', 'shopproducts.ui_hooks.products.process_delete'),
(82, 'ShopProducts', NULL, 19, 'process_edit', 'ui_hooks', 'shopproducts.ui_hooks.products.process_edit'),
(81, 'ShopProducts', NULL, 19, 'validate_delete', 'ui_hooks', 'shopproducts.ui_hooks.products.validate_delete'),
(80, 'ShopProducts', NULL, 19, 'validate_edit', 'ui_hooks', 'shopproducts.ui_hooks.products.validate_edit'),
(79, 'ShopProducts', NULL, 19, 'form_delete', 'ui_hooks', 'shopproducts.ui_hooks.products.form_delete'),
(78, 'ShopProducts', NULL, 19, 'form_edit', 'ui_hooks', 'shopproducts.ui_hooks.products.form_edit'),
(77, 'ShopProducts', NULL, 19, 'display_view', 'ui_hooks', 'shopproducts.ui_hooks.products.display_view'),
(76, 'ShopProducts', NULL, 18, 'filter', 'filter_hooks', 'shopproducts.filter_hooks.shops.filter'),
(75, 'ShopProducts', NULL, 17, 'process_delete', 'ui_hooks', 'shopproducts.ui_hooks.shops.process_delete'),
(74, 'ShopProducts', NULL, 17, 'process_edit', 'ui_hooks', 'shopproducts.ui_hooks.shops.process_edit'),
(73, 'ShopProducts', NULL, 17, 'validate_delete', 'ui_hooks', 'shopproducts.ui_hooks.shops.validate_delete'),
(72, 'ShopProducts', NULL, 17, 'validate_edit', 'ui_hooks', 'shopproducts.ui_hooks.shops.validate_edit'),
(71, 'ShopProducts', NULL, 17, 'form_delete', 'ui_hooks', 'shopproducts.ui_hooks.shops.form_delete'),
(70, 'ShopProducts', NULL, 17, 'form_edit', 'ui_hooks', 'shopproducts.ui_hooks.shops.form_edit'),
(69, 'ShopProducts', NULL, 17, 'display_view', 'ui_hooks', 'shopproducts.ui_hooks.shops.display_view'),
(68, 'ShopProducts', NULL, 16, 'filter', 'filter_hooks', 'shopproducts.filter_hooks.cities.filter'),
(67, 'ShopProducts', NULL, 15, 'process_delete', 'ui_hooks', 'shopproducts.ui_hooks.cities.process_delete'),
(66, 'ShopProducts', NULL, 15, 'process_edit', 'ui_hooks', 'shopproducts.ui_hooks.cities.process_edit'),
(65, 'ShopProducts', NULL, 15, 'validate_delete', 'ui_hooks', 'shopproducts.ui_hooks.cities.validate_delete'),
(64, 'ShopProducts', NULL, 15, 'validate_edit', 'ui_hooks', 'shopproducts.ui_hooks.cities.validate_edit'),
(63, 'ShopProducts', NULL, 15, 'form_delete', 'ui_hooks', 'shopproducts.ui_hooks.cities.form_delete'),
(62, 'ShopProducts', NULL, 15, 'form_edit', 'ui_hooks', 'shopproducts.ui_hooks.cities.form_edit'),
(61, 'ShopProducts', NULL, 15, 'display_view', 'ui_hooks', 'shopproducts.ui_hooks.cities.display_view'),
(91, 'News', NULL, 21, 'process_delete', 'ui_hooks', 'news.ui_hooks.articles.process_delete'),
(92, 'News', NULL, 22, 'filter', 'filter_hooks', 'news.filter_hooks.articles.filter'),
(93, 'FAQ', NULL, 23, 'display_view', 'ui_hooks', 'faq.ui_hooks.questions.display_view'),
(94, 'FAQ', NULL, 23, 'form_edit', 'ui_hooks', 'faq.ui_hooks.questions.form_edit'),
(95, 'FAQ', NULL, 23, 'validate_edit', 'ui_hooks', 'faq.ui_hooks.questions.validate_edit'),
(96, 'FAQ', NULL, 23, 'process_edit', 'ui_hooks', 'faq.ui_hooks.questions.process_edit'),
(97, 'FAQ', NULL, 23, 'process_delete', 'ui_hooks', 'faq.ui_hooks.questions.process_delete'),
(98, 'FAQ', NULL, 24, 'filter', 'filter_hooks', 'faq.filter_hooks.questions.filter'),
(99, 'Content', NULL, 25, 'display_view', 'ui_hooks', 'content.ui_hooks.pages.display_view'),
(100, 'Content', NULL, 25, 'form_edit', 'ui_hooks', 'content.ui_hooks.pages.form_edit'),
(101, 'Content', NULL, 25, 'form_delete', 'ui_hooks', 'content.ui_hooks.pages.form_delete'),
(102, 'Content', NULL, 25, 'validate_edit', 'ui_hooks', 'content.ui_hooks.pages.validate_edit'),
(103, 'Content', NULL, 25, 'validate_delete', 'ui_hooks', 'content.ui_hooks.pages.validate_delete'),
(104, 'Content', NULL, 25, 'process_edit', 'ui_hooks', 'content.ui_hooks.pages.process_edit'),
(105, 'Content', NULL, 25, 'process_delete', 'ui_hooks', 'content.ui_hooks.pages.process_delete'),
(106, 'Content', NULL, 26, 'filter', 'filter_hooks', 'content.filter_hooks.pages.filter'),
(107, 'Clip', NULL, 27, 'display_view', 'ui_hooks', 'clip.ui_hooks.pubtype1.display_view'),
(108, 'Clip', NULL, 27, 'form_edit', 'ui_hooks', 'clip.ui_hooks.pubtype1.form_edit'),
(109, 'Clip', NULL, 27, 'form_delete', 'ui_hooks', 'clip.ui_hooks.pubtype1.form_delete'),
(110, 'Clip', NULL, 27, 'validate_edit', 'ui_hooks', 'clip.ui_hooks.pubtype1.validate_edit'),
(111, 'Clip', NULL, 27, 'validate_delete', 'ui_hooks', 'clip.ui_hooks.pubtype1.validate_delete'),
(112, 'Clip', NULL, 27, 'process_edit', 'ui_hooks', 'clip.ui_hooks.pubtype1.process_edit'),
(113, 'Clip', NULL, 27, 'process_delete', 'ui_hooks', 'clip.ui_hooks.pubtype1.process_delete'),
(114, 'Clip', NULL, 28, 'filter', 'filter_hooks', 'clip.filter_hooks.pubtype1.filter'),
(115, 'Clip', NULL, 29, 'display_view', 'ui_hooks', 'clip.ui_hooks.pubtype2.display_view'),
(116, 'Clip', NULL, 29, 'form_edit', 'ui_hooks', 'clip.ui_hooks.pubtype2.form_edit'),
(117, 'Clip', NULL, 29, 'form_delete', 'ui_hooks', 'clip.ui_hooks.pubtype2.form_delete'),
(118, 'Clip', NULL, 29, 'validate_edit', 'ui_hooks', 'clip.ui_hooks.pubtype2.validate_edit'),
(119, 'Clip', NULL, 29, 'validate_delete', 'ui_hooks', 'clip.ui_hooks.pubtype2.validate_delete'),
(120, 'Clip', NULL, 29, 'process_edit', 'ui_hooks', 'clip.ui_hooks.pubtype2.process_edit'),
(121, 'Clip', NULL, 29, 'process_delete', 'ui_hooks', 'clip.ui_hooks.pubtype2.process_delete'),
(122, 'Clip', NULL, 30, 'filter', 'filter_hooks', 'clip.filter_hooks.pubtype2.filter'),
(123, 'Clip', NULL, 31, 'display_view', 'ui_hooks', 'clip.ui_hooks.pubtype3.display_view'),
(124, 'Clip', NULL, 31, 'form_edit', 'ui_hooks', 'clip.ui_hooks.pubtype3.form_edit'),
(125, 'Clip', NULL, 31, 'form_delete', 'ui_hooks', 'clip.ui_hooks.pubtype3.form_delete'),
(126, 'Clip', NULL, 31, 'validate_edit', 'ui_hooks', 'clip.ui_hooks.pubtype3.validate_edit'),
(127, 'Clip', NULL, 31, 'validate_delete', 'ui_hooks', 'clip.ui_hooks.pubtype3.validate_delete'),
(128, 'Clip', NULL, 31, 'process_edit', 'ui_hooks', 'clip.ui_hooks.pubtype3.process_edit'),
(129, 'Clip', NULL, 31, 'process_delete', 'ui_hooks', 'clip.ui_hooks.pubtype3.process_delete'),
(130, 'Clip', NULL, 32, 'filter', 'filter_hooks', 'clip.filter_hooks.pubtype3.filter'),
(131, 'Blocks', NULL, 33, 'form_edit', 'ui_hooks', 'blocks.ui_hooks.htmlblock.content.form_edit');

-- --------------------------------------------------------

--
-- Table structure for table `hooks`
--

CREATE TABLE `hooks` (
  `id` int(11) NOT NULL,
  `object` varchar(64) NOT NULL,
  `action` varchar(64) NOT NULL,
  `smodule` varchar(64) NOT NULL,
  `stype` varchar(64) NOT NULL,
  `tarea` varchar(64) NOT NULL,
  `tmodule` varchar(64) NOT NULL,
  `ttype` varchar(64) NOT NULL,
  `tfunc` varchar(64) NOT NULL,
  `sequence` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `markers`
--

CREATE TABLE `markers` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL,
  `address2` text NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `lat2` float(10,6) NOT NULL,
  `lng2` float(10,6) NOT NULL,
  `road_width` int(100) NOT NULL,
  `area` int(100) NOT NULL,
  `type` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `markers`
--

INSERT INTO `markers` (`id`, `name`, `address`, `address2`, `lat`, `lng`, `lat2`, `lng2`, `road_width`, `area`, `type`) VALUES
(90, '', 'domlur , bangalore', 'koramnagala , bangalore', 0.000000, 0.000000, 0.000000, 0.000000, 0, 0, ''),
(89, '', 'domlur , bangalore', 'ejipura , bangalore', 0.000000, 0.000000, 0.000000, 0.000000, 0, 0, ''),
(91, '', 'bangalore', 'kerala', 0.000000, 0.000000, 0.000000, 0.000000, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `module_deps`
--

CREATE TABLE `module_deps` (
  `id` int(11) NOT NULL,
  `modid` int(11) NOT NULL DEFAULT '0',
  `modname` varchar(64) NOT NULL,
  `minversion` varchar(10) NOT NULL,
  `maxversion` varchar(10) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `module_deps`
--

INSERT INTO `module_deps` (`id`, `modid`, `modname`, `minversion`, `maxversion`, `status`) VALUES
(2703, 3, 'Scribite', '5.0.0', '', 2),
(2704, 15, 'Scribite', '4.2.1', '', 2),
(2705, 22, 'Scribite', '4.2.1', '', 2),
(2706, 22, 'EZComments', '3.0.1', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `module_vars`
--

CREATE TABLE `module_vars` (
  `id` int(11) NOT NULL,
  `modname` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `value` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `module_vars`
--

INSERT INTO `module_vars` (`id`, `modname`, `name`, `value`) VALUES
(1, '/EventHandlers', 'Extensions', 'a:2:{i:0;a:3:{s:9:\"eventname\";s:27:\"controller.method_not_found\";s:8:\"callable\";a:2:{i:0;s:17:\"Extensions_HookUI\";i:1;s:5:\"hooks\";}s:6:\"weight\";i:10;}i:1;a:3:{s:9:\"eventname\";s:27:\"controller.method_not_found\";s:8:\"callable\";a:2:{i:0;s:17:\"Extensions_HookUI\";i:1;s:14:\"moduleservices\";}s:6:\"weight\";i:10;}}'),
(2, 'Extensions', 'itemsperpage', 'i:25;'),
(3, 'ZConfig', 'debug', 's:1:\"0\";'),
(4, 'ZConfig', 'sitename', 's:5:\"SELEX\";'),
(5, 'ZConfig', 'slogan', 's:15:\"SELEX demo site\";'),
(6, 'ZConfig', 'metakeywords', 's:237:\"zikula, portal, portal web, open source, web site, website, weblog, blog, content management, content management system, web content management, web content management system, enterprise web content management, cms, application framework\";'),
(7, 'ZConfig', 'defaultpagetitle', 's:5:\"SELEX\";'),
(8, 'ZConfig', 'defaultmetadescription', 's:15:\"SELEX demo site\";'),
(9, 'ZConfig', 'startdate', 's:7:\"02/2012\";'),
(10, 'ZConfig', 'adminmail', 's:14:\"kim@acta-it.dk\";'),
(11, 'ZConfig', 'Default_Theme', 's:19:\"CityPilotResponsive\";'),
(12, 'ZConfig', 'timezone_offset', 's:1:\"0\";'),
(13, 'ZConfig', 'timezone_server', 's:1:\"1\";'),
(14, 'ZConfig', 'funtext', 's:1:\"1\";'),
(15, 'ZConfig', 'reportlevel', 's:1:\"0\";'),
(16, 'ZConfig', 'startpage', 's:0:\"\";'),
(17, 'ZConfig', 'Version_Num', 's:5:\"1.3.9\";'),
(18, 'ZConfig', 'Version_ID', 's:6:\"Zikula\";'),
(19, 'ZConfig', 'Version_Sub', 's:3:\"vai\";'),
(20, 'ZConfig', 'debug_sql', 's:1:\"0\";'),
(21, 'ZConfig', 'multilingual', 's:1:\"1\";'),
(22, 'ZConfig', 'useflags', 's:1:\"0\";'),
(23, 'ZConfig', 'theme_change', 'b:0;'),
(24, 'ZConfig', 'UseCompression', 's:1:\"0\";'),
(25, 'ZConfig', 'siteoff', 's:1:\"0\";'),
(26, 'ZConfig', 'siteoffreason', 's:120:\"Hi Sharaz.<br />\r\nI have disabled the site for test reasons.<br />\r\nWill get it online asap...<br />\r\nRegards<br />\r\nKim\";'),
(27, 'ZConfig', 'starttype', 's:0:\"\";'),
(28, 'ZConfig', 'startfunc', 's:0:\"\";'),
(29, 'ZConfig', 'startargs', 's:0:\"\";'),
(30, 'ZConfig', 'entrypoint', 's:9:\"index.php\";'),
(31, 'ZConfig', 'language_detect', 'i:0;'),
(32, 'ZConfig', 'shorturls', 's:1:\"1\";'),
(33, 'ZConfig', 'shorturlstype', 's:1:\"0\";'),
(34, 'ZConfig', 'shorturlsseparator', 's:1:\"-\";'),
(35, 'ZConfig', 'shorturlsstripentrypoint', 's:1:\"1\";'),
(36, 'ZConfig', 'shorturlsdefaultmodule', 's:6:\"ZSELEX\";'),
(37, 'ZConfig', 'profilemodule', 's:0:\"\";'),
(38, 'ZConfig', 'messagemodule', 's:0:\"\";'),
(39, 'ZConfig', 'languageurl', 'i:0;'),
(40, 'ZConfig', 'ajaxtimeout', 's:5:\"60000\";'),
(41, 'ZConfig', 'permasearch', 's:161:\"À,Á,Â,Ã,Å,à,á,â,ã,å,Ò,Ó,Ô,Õ,Ø,ò,ó,ô,õ,ø,È,É,Ê,Ë,è,é,ê,ë,Ç,ç,Ì,Í,Î,Ï,ì,í,î,ï,Ù,Ú,Û,ù,ú,û,ÿ,Ñ,ñ,ß,ä,Ä,ö,Ö,ü,Ü\";'),
(42, 'ZConfig', 'permareplace', 's:114:\"A,A,A,A,A,a,a,a,a,a,O,O,O,O,O,o,o,o,o,o,E,E,E,E,e,e,e,e,C,c,I,I,I,I,i,i,i,i,U,U,U,u,u,u,y,N,n,ss,ae,Ae,oe,Oe,ue,Ue\";'),
(43, 'ZConfig', 'language', 's:3:\"eng\";'),
(44, 'ZConfig', 'locale', 's:2:\"en\";'),
(45, 'ZConfig', 'language_i18n', 's:2:\"en\";'),
(46, 'ZConfig', 'idnnames', 'i:1;'),
(47, 'Theme', 'modulesnocache', 's:29:\"ZSELEX,ZPayment,ZBlocks,ZTEXT\";'),
(48, 'Theme', 'enablecache', 'b:0;'),
(49, 'Theme', 'compile_check', 'b:1;'),
(50, 'Theme', 'cache_lifetime', 'i:3600;'),
(51, 'Theme', 'force_compile', 'b:0;'),
(52, 'Theme', 'trimwhitespace', 'b:1;'),
(53, 'Theme', 'maxsizeforlinks', 'i:30;'),
(54, 'Theme', 'itemsperpage', 'i:40;'),
(55, 'Theme', 'cssjscombine', 'b:0;'),
(56, 'Theme', 'cssjscompress', 'b:1;'),
(57, 'Theme', 'cssjsminify', 'b:1;'),
(58, 'Theme', 'cssjscombine_lifetime', 'i:36000;'),
(59, 'Theme', 'render_compile_check', 'b:1;'),
(60, 'Theme', 'render_force_compile', 'b:1;'),
(61, 'Theme', 'render_cache', 'i:0;'),
(62, 'Theme', 'render_expose_template', 'b:1;'),
(63, 'Theme', 'render_lifetime', 'i:3600;'),
(64, 'Admin', 'modulesperrow', 's:1:\"3\";'),
(65, 'Admin', 'itemsperpage', 's:2:\"15\";'),
(66, 'Admin', 'defaultcategory', 's:1:\"7\";'),
(67, 'Admin', 'admingraphic', 's:1:\"1\";'),
(68, 'Admin', 'startcategory', 's:1:\"1\";'),
(69, 'Admin', 'ignoreinstallercheck', 'b:0;'),
(70, 'Admin', 'admintheme', 's:0:\"\";'),
(71, 'Admin', 'displaynametype', 's:1:\"1\";'),
(72, 'Permissions', 'filter', 'b:1;'),
(73, 'Permissions', 'warnbar', 'i:1;'),
(74, 'Permissions', 'rowview', 'i:20;'),
(75, 'Permissions', 'rowedit', 'i:20;'),
(76, 'Permissions', 'lockadmin', 'b:1;'),
(77, 'Permissions', 'adminid', 'i:1;'),
(78, 'Groups', 'itemsperpage', 'i:25;'),
(79, 'Groups', 'defaultgroup', 'i:1;'),
(80, 'Groups', 'mailwarning', 'i:0;'),
(81, 'Groups', 'hideclosed', 'i:0;'),
(82, 'Groups', 'primaryadmingroup', 'i:2;'),
(83, 'Blocks', 'collapseable', 'i:0;'),
(84, 'Users', 'accountdisplaygraphics', 'b:1;'),
(85, 'Users', 'accountitemsperpage', 'i:25;'),
(86, 'Users', 'accountitemsperrow', 'i:5;'),
(87, 'Users', 'userimg', 's:11:\"images/menu\";'),
(88, 'Users', 'anonymous', 's:5:\"Guest\";'),
(89, 'Users', 'avatarpath', 's:13:\"images/avatar\";'),
(90, 'Users', 'chgemail_expiredays', 'i:0;'),
(91, 'Users', 'chgpass_expiredays', 'i:0;'),
(92, 'Users', 'reg_expiredays', 'i:0;'),
(93, 'Users', 'allowgravatars', 'b:1;'),
(94, 'Users', 'gravatarimage', 's:12:\"gravatar.gif\";'),
(95, 'Users', 'hash_method', 's:6:\"sha256\";'),
(96, 'Users', 'itemsperpage', 'i:25;'),
(97, 'Users', 'login_displayapproval', 'b:0;'),
(98, 'Users', 'login_displaydelete', 'b:0;'),
(99, 'Users', 'login_displayinactive', 'b:0;'),
(100, 'Users', 'login_displayverify', 'b:0;'),
(101, 'Users', 'loginviaoption', 'i:0;'),
(102, 'Users', 'login_redirect', 'b:1;'),
(103, 'Users', 'changeemail', 'b:1;'),
(104, 'Users', 'minpass', 'i:5;'),
(105, 'Users', 'use_password_strength_meter', 'b:0;'),
(106, 'Users', 'reg_notifyemail', 's:0:\"\";'),
(107, 'Users', 'reg_question', 's:0:\"\";'),
(108, 'Users', 'reg_answer', 's:0:\"\";'),
(109, 'Users', 'moderation', 'b:0;'),
(110, 'Users', 'moderation_order', 'i:0;'),
(111, 'Users', 'reg_autologin', 'b:0;'),
(112, 'Users', 'reg_noregreasons', 's:51:\"Sorry! New user registration is currently disabled.\";'),
(113, 'Users', 'reg_allowreg', 'b:1;'),
(114, 'Users', 'reg_Illegaluseragents', 's:0:\"\";'),
(115, 'Users', 'reg_Illegaldomains', 's:0:\"\";'),
(116, 'Users', 'reg_Illegalusername', 's:66:\"root, webmaster, admin, administrator, nobody, anonymous, username\";'),
(117, 'Users', 'reg_verifyemail', 'i:2;'),
(118, 'Users', 'reg_uniemail', 'b:1;'),
(119, '/EventHandlers', 'Users', 'a:4:{i:0;a:3:{s:9:\"eventname\";s:19:\"get.pending_content\";s:8:\"callable\";a:2:{i:0;s:29:\"Users_Listener_PendingContent\";i:1;s:22:\"pendingContentListener\";}s:6:\"weight\";i:10;}i:1;a:3:{s:9:\"eventname\";s:15:\"user.login.veto\";s:8:\"callable\";a:2:{i:0;s:35:\"Users_Listener_ForcedPasswordChange\";i:1;s:28:\"forcedPasswordChangeListener\";}s:6:\"weight\";i:10;}i:2;a:3:{s:9:\"eventname\";s:21:\"user.logout.succeeded\";s:8:\"callable\";a:2:{i:0;s:34:\"Users_Listener_ClearUsersNamespace\";i:1;s:27:\"clearUsersNamespaceListener\";}s:6:\"weight\";i:10;}i:3;a:3:{s:9:\"eventname\";s:25:\"frontcontroller.exception\";s:8:\"callable\";a:2:{i:0;s:34:\"Users_Listener_ClearUsersNamespace\";i:1;s:27:\"clearUsersNamespaceListener\";}s:6:\"weight\";i:10;}}'),
(120, 'SecurityCenter', 'itemsperpage', 'i:10;'),
(121, 'ZConfig', 'updatecheck', 'i:0;'),
(122, 'ZConfig', 'updatefrequency', 'i:7;'),
(123, 'ZConfig', 'updatelastchecked', 'i:0;'),
(124, 'ZConfig', 'updateversion', 's:5:\"1.3.9\";'),
(125, 'ZConfig', 'keyexpiry', 'i:0;'),
(126, 'ZConfig', 'sessionauthkeyua', 'i:0;'),
(127, 'ZConfig', 'secure_domain', 's:0:\"\";'),
(128, 'ZConfig', 'signcookies', 'i:1;'),
(129, 'ZConfig', 'signingkey', 's:40:\"3fe84bd364981389328e8a262ab8d187a009d561\";'),
(130, 'ZConfig', 'seclevel', 's:6:\"Medium\";'),
(131, 'ZConfig', 'secmeddays', 'i:7;'),
(132, 'ZConfig', 'secinactivemins', 'i:60;'),
(133, 'ZConfig', 'sessionstoretofile', 'i:0;'),
(134, 'ZConfig', 'sessionsavepath', 's:0:\"\";'),
(135, 'ZConfig', 'gc_probability', 'i:100;'),
(136, 'ZConfig', 'anonymoussessions', 'i:1;'),
(137, 'ZConfig', 'sessionrandregenerate', 'i:1;'),
(138, 'ZConfig', 'sessionregenerate', 'i:1;'),
(139, 'ZConfig', 'sessionregeneratefreq', 'i:10;'),
(140, 'ZConfig', 'sessionipcheck', 'i:0;'),
(141, 'ZConfig', 'sessionname', 's:5:\"_zsid\";'),
(142, 'ZConfig', 'sessioncsrftokenonetime', 'i:0;'),
(143, 'ZConfig', 'filtergetvars', 'i:1;'),
(144, 'ZConfig', 'filterpostvars', 'i:1;'),
(145, 'ZConfig', 'filtercookievars', 'i:1;'),
(146, 'ZConfig', 'outputfilter', 's:1:\"1\";'),
(147, 'ZConfig', 'htmlpurifierlocation', 's:46:\"system/SecurityCenter/lib/vendor/htmlpurifier/\";'),
(148, 'SecurityCenter', 'htmlpurifierConfig', 's:3923:\"a:10:{s:4:\"Attr\";a:15:{s:14:\"AllowedClasses\";N;s:19:\"AllowedFrameTargets\";a:0:{}s:10:\"AllowedRel\";a:2:{s:8:\"nofollow\";b:1;s:11:\"imageviewer\";b:1;}s:10:\"AllowedRev\";a:0:{}s:13:\"ClassUseCDATA\";N;s:15:\"DefaultImageAlt\";N;s:19:\"DefaultInvalidImage\";s:0:\"\";s:22:\"DefaultInvalidImageAlt\";s:13:\"Invalid image\";s:14:\"DefaultTextDir\";s:3:\"ltr\";s:8:\"EnableID\";b:0;s:16:\"ForbiddenClasses\";a:0:{}s:11:\"IDBlacklist\";a:0:{}s:17:\"IDBlacklistRegexp\";N;s:8:\"IDPrefix\";s:0:\"\";s:13:\"IDPrefixLocal\";s:0:\"\";}s:10:\"AutoFormat\";a:10:{s:13:\"AutoParagraph\";b:0;s:6:\"Custom\";a:0:{}s:14:\"DisplayLinkURI\";b:0;s:7:\"Linkify\";b:0;s:22:\"PurifierLinkify.DocURL\";s:3:\"#%s\";s:15:\"PurifierLinkify\";b:0;s:33:\"RemoveEmpty.RemoveNbsp.Exceptions\";a:2:{s:2:\"td\";b:1;s:2:\"th\";b:1;}s:22:\"RemoveEmpty.RemoveNbsp\";b:0;s:11:\"RemoveEmpty\";b:0;s:28:\"RemoveSpansWithoutAttributes\";b:0;}s:3:\"CSS\";a:9:{s:14:\"AllowImportant\";b:0;s:11:\"AllowTricky\";b:0;s:12:\"AllowedFonts\";N;s:17:\"AllowedProperties\";N;s:13:\"DefinitionRev\";i:1;s:19:\"ForbiddenProperties\";a:0:{}s:12:\"MaxImgLength\";s:6:\"1200px\";s:11:\"Proprietary\";b:0;s:7:\"Trusted\";b:0;}s:5:\"Cache\";a:3:{s:14:\"DefinitionImpl\";s:10:\"Serializer\";s:14:\"SerializerPath\";N;s:21:\"SerializerPermissions\";i:493;}s:4:\"Core\";a:17:{s:17:\"AggressivelyFixLt\";b:1;s:13:\"CollectErrors\";b:0;s:13:\"ColorKeywords\";a:17:{s:6:\"maroon\";s:7:\"#800000\";s:3:\"red\";s:7:\"#FF0000\";s:6:\"orange\";s:7:\"#FFA500\";s:6:\"yellow\";s:7:\"#FFFF00\";s:5:\"olive\";s:7:\"#808000\";s:6:\"purple\";s:7:\"#800080\";s:7:\"fuchsia\";s:7:\"#FF00FF\";s:5:\"white\";s:7:\"#FFFFFF\";s:4:\"lime\";s:7:\"#00FF00\";s:5:\"green\";s:7:\"#008000\";s:4:\"navy\";s:7:\"#000080\";s:4:\"blue\";s:7:\"#0000FF\";s:4:\"aqua\";s:7:\"#00FFFF\";s:4:\"teal\";s:7:\"#008080\";s:5:\"black\";s:7:\"#000000\";s:6:\"silver\";s:7:\"#C0C0C0\";s:4:\"gray\";s:7:\"#808080\";}s:25:\"ConvertDocumentToFragment\";b:1;s:31:\"DirectLexLineNumberSyncInterval\";i:0;s:8:\"Encoding\";s:5:\"utf-8\";s:21:\"EscapeInvalidChildren\";b:0;s:17:\"EscapeInvalidTags\";b:0;s:24:\"EscapeNonASCIICharacters\";b:0;s:14:\"HiddenElements\";a:2:{s:6:\"script\";b:1;s:5:\"style\";b:1;}s:8:\"Language\";s:2:\"en\";s:9:\"LexerImpl\";N;s:19:\"MaintainLineNumbers\";N;s:17:\"NormalizeNewlines\";b:1;s:16:\"RemoveInvalidImg\";b:1;s:28:\"RemoveProcessingInstructions\";b:0;s:20:\"RemoveScriptContents\";N;}s:6:\"Filter\";a:6:{s:6:\"Custom\";a:0:{}s:27:\"ExtractStyleBlocks.Escaping\";b:1;s:24:\"ExtractStyleBlocks.Scope\";N;s:27:\"ExtractStyleBlocks.TidyImpl\";N;s:18:\"ExtractStyleBlocks\";b:0;s:7:\"YouTube\";b:0;}s:4:\"HTML\";a:26:{s:7:\"Allowed\";N;s:17:\"AllowedAttributes\";N;s:15:\"AllowedElements\";N;s:14:\"AllowedModules\";N;s:18:\"Attr.Name.UseCDATA\";b:0;s:12:\"BlockWrapper\";s:1:\"p\";s:11:\"CoreModules\";a:7:{s:9:\"Structure\";b:1;s:4:\"Text\";b:1;s:9:\"Hypertext\";b:1;s:4:\"List\";b:1;s:22:\"NonXMLCommonAttributes\";b:1;s:19:\"XMLCommonAttributes\";b:1;s:16:\"CommonAttributes\";b:1;}s:13:\"CustomDoctype\";N;s:12:\"DefinitionID\";N;s:13:\"DefinitionRev\";i:1;s:7:\"Doctype\";s:22:\"HTML 4.01 Transitional\";s:20:\"FlashAllowFullScreen\";b:0;s:19:\"ForbiddenAttributes\";a:0:{}s:17:\"ForbiddenElements\";a:0:{}s:12:\"MaxImgLength\";i:1200;s:8:\"Nofollow\";b:0;s:6:\"Parent\";s:3:\"div\";s:11:\"Proprietary\";b:0;s:9:\"SafeEmbed\";b:1;s:10:\"SafeObject\";b:1;s:6:\"Strict\";b:0;s:7:\"TidyAdd\";a:0:{}s:9:\"TidyLevel\";s:6:\"medium\";s:10:\"TidyRemove\";a:0:{}s:7:\"Trusted\";b:0;s:5:\"XHTML\";b:1;}s:6:\"Output\";a:6:{s:21:\"CommentScriptContents\";b:1;s:12:\"FixInnerHTML\";b:1;s:11:\"FlashCompat\";b:1;s:7:\"Newline\";N;s:8:\"SortAttr\";b:0;s:10:\"TidyFormat\";b:0;}s:4:\"Test\";a:1:{s:12:\"ForceNoIconv\";b:0;}s:3:\"URI\";a:16:{s:14:\"AllowedSchemes\";a:6:{s:4:\"http\";b:1;s:5:\"https\";b:1;s:6:\"mailto\";b:1;s:3:\"ftp\";b:1;s:4:\"nntp\";b:1;s:4:\"news\";b:1;}s:4:\"Base\";N;s:13:\"DefaultScheme\";s:4:\"http\";s:12:\"DefinitionID\";N;s:13:\"DefinitionRev\";i:1;s:7:\"Disable\";b:0;s:15:\"DisableExternal\";b:0;s:24:\"DisableExternalResources\";b:0;s:16:\"DisableResources\";b:0;s:4:\"Host\";N;s:13:\"HostBlacklist\";a:0:{}s:12:\"MakeAbsolute\";b:0;s:5:\"Munge\";N;s:14:\"MungeResources\";b:0;s:14:\"MungeSecretKey\";N;s:22:\"OverrideAllowedSchemes\";b:1;}}\";'),
(149, 'ZConfig', 'useids', 'b:0;'),
(150, 'ZConfig', 'idsmail', 'b:0;'),
(151, 'ZConfig', 'idsrulepath', 's:32:\"config/phpids_zikula_default.xml\";'),
(152, 'ZConfig', 'idssoftblock', 'b:1;'),
(153, 'ZConfig', 'idsfilter', 's:3:\"xml\";'),
(154, 'ZConfig', 'idsimpactthresholdone', 'i:1;'),
(155, 'ZConfig', 'idsimpactthresholdtwo', 'i:10;'),
(156, 'ZConfig', 'idsimpactthresholdthree', 'i:25;'),
(157, 'ZConfig', 'idsimpactthresholdfour', 'i:75;'),
(158, 'ZConfig', 'idsimpactmode', 'i:1;'),
(159, 'ZConfig', 'idshtmlfields', 'a:1:{i:0;s:14:\"POST.__wysiwyg\";}'),
(160, 'ZConfig', 'idsjsonfields', 'a:1:{i:0;s:15:\"POST.__jsondata\";}'),
(161, 'ZConfig', 'idsexceptions', 'a:12:{i:0;s:10:\"GET.__utmz\";i:1;s:10:\"GET.__utmc\";i:2;s:18:\"REQUEST.linksorder\";i:3;s:15:\"POST.linksorder\";i:4;s:19:\"REQUEST.fullcontent\";i:5;s:16:\"POST.fullcontent\";i:6;s:22:\"REQUEST.summarycontent\";i:7;s:19:\"POST.summarycontent\";i:8;s:19:\"REQUEST.filter.page\";i:9;s:16:\"POST.filter.page\";i:10;s:20:\"REQUEST.filter.value\";i:11;s:17:\"POST.filter.value\";}'),
(162, 'ZConfig', 'summarycontent', 's:1130:\"For the attention of %sitename% administration staff:\n\nOn %date% at %time%, Zikula detected that somebody tried to interact with the site in a way that may have been intended compromise its security. This is not necessarily the case: it could have been caused by work you were doing on the site, or may have been due to some other reason. In any case, it was detected and blocked. \n\nThe suspicious activity was recognised in \'%filename%\' at line %linenumber%.\n\nType: %type%. \n\nAdditional information: %additionalinfo%.\n\nBelow is logged information that may help you identify what happened and who was responsible.\n\n=====================================\nInformation about the user:\n=====================================\nUser name:  %username%\nUser\'s e-mail address: %useremail%\nUser\'s real name: %userrealname%\n\n=====================================\nIP numbers (if this was a cracker, the IP numbers may not be the true point of origin)\n=====================================\nIP according to HTTP_CLIENT_IP: %httpclientip%\nIP according to REMOTE_ADDR: %remoteaddr%\nIP according to GetHostByName($REMOTE_ADDR): %gethostbyremoteaddr%\n\";'),
(163, 'ZConfig', 'fullcontent', 's:1289:\"=====================================\nInformation in the $_REQUEST array\n=====================================\n%requestarray%\n\n=====================================\nInformation in the $_GET array\n(variables that may have been in the URL string or in a \'GET\'-type form)\n=====================================\n%getarray%\n\n=====================================\nInformation in the $_POST array\n(visible and invisible form elements)\n=====================================\n%postarray%\n\n=====================================\nBrowser information\n=====================================\n%browserinfo%\n\n=====================================\nInformation in the $_SERVER array\n=====================================\n%serverarray%\n\n=====================================\nInformation in the $_ENV array\n=====================================\n%envarray%\n\n=====================================\nInformation in the $_COOKIE array\n=====================================\n%cookiearray%\n\n=====================================\nInformation in the $_FILES array\n=====================================\n%filearray%\n\n=====================================\nInformation in the $_SESSION array\n(session information -- variables starting with PNSV are Zikula session variables)\n=====================================\n%sessionarray%\n\";'),
(164, 'ZConfig', 'usehtaccessbans', 'i:0;'),
(165, 'ZConfig', 'extrapostprotection', 'i:0;'),
(166, 'ZConfig', 'extragetprotection', 'i:0;'),
(167, 'ZConfig', 'checkmultipost', 'i:0;'),
(168, 'ZConfig', 'maxmultipost', 'i:4;'),
(169, 'ZConfig', 'cpuloadmonitor', 'i:0;'),
(170, 'ZConfig', 'cpumaxload', 'd:10;'),
(171, 'ZConfig', 'ccisessionpath', 's:0:\"\";'),
(172, 'ZConfig', 'htaccessfilelocation', 's:9:\".htaccess\";'),
(173, 'ZConfig', 'nocookiebanthreshold', 'i:10;'),
(174, 'ZConfig', 'nocookiewarningthreshold', 'i:2;'),
(175, 'ZConfig', 'fastaccessbanthreshold', 'i:40;'),
(176, 'ZConfig', 'fastaccesswarnthreshold', 'i:10;'),
(177, 'ZConfig', 'javababble', 'i:0;'),
(178, 'ZConfig', 'javaencrypt', 'i:0;'),
(179, 'ZConfig', 'preservehead', 'i:0;'),
(180, 'ZConfig', 'filterarrays', 'i:1;'),
(181, 'ZConfig', 'htmlentities', 's:1:\"1\";'),
(182, 'ZConfig', 'AllowableHTML', 'a:110:{s:3:\"!--\";i:2;s:1:\"a\";i:2;s:4:\"abbr\";i:1;s:7:\"acronym\";i:1;s:7:\"address\";i:1;s:6:\"applet\";i:0;s:4:\"area\";i:0;s:7:\"article\";i:1;s:5:\"aside\";i:1;s:5:\"audio\";i:0;s:1:\"b\";i:1;s:4:\"base\";i:0;s:8:\"basefont\";i:0;s:3:\"bdo\";i:0;s:3:\"big\";i:0;s:10:\"blockquote\";i:2;s:2:\"br\";i:2;s:6:\"button\";i:0;s:6:\"canvas\";i:0;s:7:\"caption\";i:1;s:6:\"center\";i:2;s:4:\"cite\";i:1;s:4:\"code\";i:0;s:3:\"col\";i:1;s:8:\"colgroup\";i:1;s:7:\"command\";i:0;s:8:\"datalist\";i:0;s:2:\"dd\";i:1;s:3:\"del\";i:0;s:7:\"details\";i:1;s:3:\"dfn\";i:0;s:3:\"dir\";i:0;s:3:\"div\";i:2;s:2:\"dl\";i:1;s:2:\"dt\";i:1;s:2:\"em\";i:2;s:5:\"embed\";i:0;s:8:\"fieldset\";i:1;s:10:\"figcaption\";i:0;s:6:\"figure\";i:0;s:6:\"footer\";i:0;s:4:\"font\";i:0;s:4:\"form\";i:0;s:2:\"h1\";i:1;s:2:\"h2\";i:1;s:2:\"h3\";i:1;s:2:\"h4\";i:1;s:2:\"h5\";i:1;s:2:\"h6\";i:1;s:6:\"header\";i:0;s:6:\"hgroup\";i:0;s:2:\"hr\";i:2;s:1:\"i\";i:1;s:6:\"iframe\";i:0;s:3:\"img\";i:2;s:5:\"input\";i:0;s:3:\"ins\";i:0;s:6:\"keygen\";i:0;s:3:\"kbd\";i:0;s:5:\"label\";i:1;s:6:\"legend\";i:1;s:2:\"li\";i:2;s:3:\"map\";i:0;s:4:\"mark\";i:0;s:4:\"menu\";i:0;s:7:\"marquee\";i:0;s:5:\"meter\";i:0;s:3:\"nav\";i:0;s:4:\"nobr\";i:0;s:6:\"object\";i:0;s:2:\"ol\";i:2;s:8:\"optgroup\";i:0;s:6:\"option\";i:0;s:6:\"output\";i:0;s:1:\"p\";i:2;s:5:\"param\";i:0;s:3:\"pre\";i:2;s:8:\"progress\";i:0;s:1:\"q\";i:0;s:2:\"rp\";i:0;s:2:\"rt\";i:0;s:4:\"ruby\";i:0;s:1:\"s\";i:0;s:4:\"samp\";i:0;s:6:\"script\";i:0;s:7:\"section\";i:0;s:6:\"select\";i:0;s:5:\"small\";i:0;s:6:\"source\";i:0;s:4:\"span\";i:2;s:6:\"strike\";i:0;s:6:\"strong\";i:2;s:3:\"sub\";i:1;s:7:\"summary\";i:1;s:3:\"sup\";i:0;s:5:\"table\";i:2;s:5:\"tbody\";i:1;s:2:\"td\";i:2;s:8:\"textarea\";i:0;s:5:\"tfoot\";i:1;s:2:\"th\";i:2;s:5:\"thead\";i:0;s:4:\"time\";i:0;s:2:\"tr\";i:2;s:2:\"tt\";i:2;s:1:\"u\";i:0;s:2:\"ul\";i:2;s:3:\"var\";i:0;s:5:\"video\";i:0;s:3:\"wbr\";i:0;}'),
(183, 'Categories', 'userrootcat', 's:17:\"/__SYSTEM__/Users\";'),
(184, 'Categories', 'allowusercatedit', 'i:0;'),
(185, 'Categories', 'autocreateusercat', 'i:0;'),
(186, 'Categories', 'autocreateuserdefaultcat', 'i:0;'),
(187, 'Categories', 'userdefaultcatname', 's:7:\"Default\";'),
(188, 'Legal', 'legalNoticeActive', 'b:1;'),
(189, 'Legal', 'termsOfUseActive', 'b:1;'),
(190, 'Legal', 'privacyPolicyActive', 'b:1;'),
(191, 'Legal', 'accessibilityStatementActive', 'b:1;'),
(192, 'Legal', 'cancellationRightPolicyActive', 'b:0;'),
(193, 'Legal', 'tradeConditionsActive', 'b:0;'),
(194, 'Legal', 'legalNoticeUrl', 's:0:\"\";'),
(195, 'Legal', 'termsOfUseUrl', 's:0:\"\";'),
(196, 'Legal', 'privacyPolicyUrl', 's:0:\"\";'),
(197, 'Legal', 'accessibilityStatementUrl', 's:0:\"\";'),
(198, 'Legal', 'cancellationRightPolicyUrl', 's:0:\"\";'),
(199, 'Legal', 'tradeConditionsUrl', 's:0:\"\";'),
(200, 'Legal', 'minimumAge', 'i:13;'),
(201, '/EventHandlers', 'Legal', 'a:2:{i:0;a:3:{s:9:\"eventname\";s:15:\"user.login.veto\";s:8:\"callable\";a:2:{i:0;s:29:\"Legal_Listener_UsersLoginVeto\";i:1;s:22:\"acceptPoliciesListener\";}s:6:\"weight\";i:10;}i:1;a:1:{s:9:\"classname\";s:29:\"Legal_Listener_UsersUiHandler\";}}'),
(202, 'Mailer', 'mailertype', 'i:1;'),
(203, 'Mailer', 'charset', 's:5:\"utf-8\";'),
(204, 'Mailer', 'encoding', 's:4:\"8bit\";'),
(205, 'Mailer', 'html', 'b:1;'),
(206, 'Mailer', 'wordwrap', 'i:50;'),
(207, 'Mailer', 'msmailheaders', 'b:0;'),
(208, 'Mailer', 'sendmailpath', 's:18:\"/usr/sbin/sendmail\";'),
(209, 'Mailer', 'smtpauth', 'b:0;'),
(210, 'Mailer', 'smtpserver', 's:9:\"localhost\";'),
(211, 'Mailer', 'smtpport', 'i:25;'),
(212, 'Mailer', 'smtptimeout', 'i:10;'),
(213, 'Mailer', 'smtpusername', 's:2:\"r2\";'),
(214, 'Mailer', 'smtppassword', 's:7:\"adminr2\";'),
(215, 'Mailer', 'smtpsecuremethod', 's:3:\"ssl\";'),
(216, 'Search', 'itemsperpage', 'i:10;'),
(217, 'Search', 'limitsummary', 'i:255;'),
(218, '/EventHandlers', 'Search', 'a:1:{i:0;a:3:{s:9:\"eventname\";s:26:\"installer.module.installed\";s:8:\"callable\";a:2:{i:0;s:20:\"Search_EventHandlers\";i:1;s:13:\"moduleInstall\";}s:6:\"weight\";i:10;}}'),
(276, 'News', 'morearticlesincat', 'i:0;'),
(271, 'News', 'enableattribution', 'b:0;'),
(272, 'News', 'topicproperty', 's:4:\"Main\";'),
(273, 'News', 'catimagepath', 's:18:\"images/categories/\";'),
(274, 'News', 'enableajaxedit', 'b:0;'),
(275, 'News', 'enablemorearticlesincat', 'b:0;'),
(269, 'News', 'enablecategorization', 'b:1;'),
(270, 'News', 'refereronprint', 'i:0;'),
(299, 'News', 'picupload_picmaxheight', 'i:768;'),
(296, 'News', 'picupload_maxpictures', 'i:3;'),
(297, 'News', 'picupload_sizing', 's:1:\"0\";'),
(298, 'News', 'picupload_picmaxwidth', 'i:1024;'),
(294, 'News', 'picupload_article_float', 's:4:\"left\";'),
(295, 'News', 'picupload_maxfilesize', 'i:500000;'),
(291, 'News', 'picupload_enabled', 'b:1;'),
(292, 'News', 'picupload_allowext', 's:11:\"jpg,gif,png\";'),
(293, 'News', 'picupload_index_float', 's:4:\"left\";'),
(290, 'News', 'pdflink_enablecache', 'b:1;'),
(289, 'News', 'pdflink_headerlogo_width', 's:2:\"30\";'),
(288, 'News', 'pdflink_headerlogo', 's:14:\"tcpdf_logo.jpg\";'),
(286, 'News', 'notifyonpending_html', 'b:1;'),
(287, 'News', 'pdflink', 'b:0;'),
(285, 'News', 'notifyonpending_subject', 's:54:\"A News Publisher article has been submitted for review\";'),
(284, 'News', 'notifyonpending_toaddress', 's:0:\"\";'),
(283, 'News', 'notifyonpending_toname', 's:0:\"\";'),
(281, 'News', 'notifyonpending_fromname', 's:0:\"\";'),
(282, 'News', 'notifyonpending_fromaddress', 's:0:\"\";'),
(278, 'News', 'enabledescriptionvar', 'b:0;'),
(279, 'News', 'descriptionvarchars', 'i:250;'),
(280, 'News', 'notifyonpending', 'b:0;'),
(277, 'News', 'enablecategorybasedpermissions', 'b:1;'),
(264, 'News', 'storyhome', 'i:10;'),
(265, 'News', 'storyorder', 'i:1;'),
(266, 'News', 'itemsperpage', 'i:25;'),
(267, 'News', 'itemsperadminpage', 'i:15;'),
(268, 'News', 'permalinkformat', 's:14:\"%articletitle%\";'),
(262, 'Categories', 'EntityCategorySubclasses', 'a:0:{}'),
(300, 'News', 'picupload_thumbmaxwidth', 'i:298;'),
(301, 'News', 'picupload_thumbmaxheight', 'i:133;'),
(302, 'News', 'picupload_thumb2maxwidth', 'i:200;'),
(303, 'News', 'picupload_thumb2maxheight', 'i:200;'),
(304, 'News', 'picupload_uploaddir', 's:21:\"images/news_picupload\";'),
(305, '/EventHandlers', 'News', 'a:2:{i:0;a:3:{s:9:\"eventname\";s:19:\"get.pending_content\";s:8:\"callable\";a:2:{i:0;s:13:\"News_Handlers\";i:1;s:14:\"pendingContent\";}s:6:\"weight\";i:10;}i:1;a:3:{s:9:\"eventname\";s:23:\"module.content.gettypes\";s:8:\"callable\";a:2:{i:0;s:13:\"News_Handlers\";i:1;s:8:\"getTypes\";}s:6:\"weight\";i:10;}}'),
(306, 'ZSELEX', 'showAdminZSELEX', 's:1:\"1\";'),
(307, 'News', 'pdflink_tcpdfpath', 's:0:\"\";'),
(308, 'News', 'pdflink_tcpdflang', 's:0:\"\";'),
(309, '/EventHandlers', 'ZSELEX', 'a:11:{i:0;a:3:{s:9:\"eventname\";s:32:\"module_dispatch.custom_classname\";s:8:\"callable\";a:2:{i:0;s:20:\"ZSELEX_Listener_User\";i:1;s:15:\"customClassname\";}s:6:\"weight\";i:10;}i:1;a:3:{s:9:\"eventname\";s:13:\"user.gettheme\";s:8:\"callable\";a:2:{i:0;s:20:\"ZSELEX_Listener_User\";i:1;s:8:\"getTheme\";}s:6:\"weight\";i:10;}i:2;a:3:{s:9:\"eventname\";s:31:\"module.users.ui.login.succeeded\";s:8:\"callable\";a:2:{i:0;s:25:\"ZSELEX_Listener_UserLogin\";i:1;s:9:\"succeeded\";}s:6:\"weight\";i:10;}i:3;a:3:{s:9:\"eventname\";s:19:\"user.account.create\";s:8:\"callable\";a:2:{i:0;s:20:\"ZSELEX_Listener_User\";i:1;s:6:\"create\";}s:6:\"weight\";i:10;}i:4;a:3:{s:9:\"eventname\";s:19:\"user.account.delete\";s:8:\"callable\";a:2:{i:0;s:20:\"ZSELEX_Listener_User\";i:1;s:6:\"delete\";}s:6:\"weight\";i:10;}i:5;a:3:{s:9:\"eventname\";s:32:\"module.users.ui.logout.succeeded\";s:8:\"callable\";a:2:{i:0;s:25:\"ZSELEX_Listener_UserLogin\";i:1;s:6:\"logout\";}s:6:\"weight\";i:10;}i:6;a:3:{s:9:\"eventname\";s:19:\"user.account.create\";s:8:\"callable\";a:2:{i:0;s:20:\"ZSELEX_Listener_User\";i:1;s:6:\"create\";}s:6:\"weight\";i:10;}i:7;a:3:{s:9:\"eventname\";s:19:\"user.account.delete\";s:8:\"callable\";a:2:{i:0;s:20:\"ZSELEX_Listener_User\";i:1;s:6:\"delete\";}s:6:\"weight\";i:10;}i:8;a:3:{s:9:\"eventname\";s:19:\"user.account.update\";s:8:\"callable\";a:2:{i:0;s:20:\"ZSELEX_Listener_User\";i:1;s:6:\"update\";}s:6:\"weight\";i:10;}i:9;a:3:{s:9:\"eventname\";s:25:\"frontcontroller.exception\";s:8:\"callable\";a:2:{i:0;s:28:\"ZSELEX_Listener_ErrorListner\";i:1;s:20:\"frontcontrollerError\";}s:6:\"weight\";i:10;}i:10;a:3:{s:9:\"eventname\";s:11:\"systemerror\";s:8:\"callable\";a:2:{i:0;s:28:\"ZSELEX_Listener_ErrorListner\";i:1;s:11:\"systemError\";}s:6:\"weight\";i:10;}}'),
(310, 'ZSELEX', 'ZSELEXthemes', 'a:12:{i:6;s:11:\"KeepRunning\";i:9;s:10:\"ZAndreas08\";i:10;s:10:\"ZSeaBreeze\";i:15;s:10:\"ZLimelight\";i:22;s:5:\"ZWine\";i:17;s:9:\"ZLightBiz\";i:18;s:9:\"ZGreenway\";i:19;s:10:\"ZFruitopia\";i:20;s:13:\"ZNaturalGloom\";i:21;s:8:\"ZSunrise\";i:23;s:12:\"ZOrangeJuice\";i:25;s:7:\"ZLGBlue\";}'),
(312, 'ZSELEX', 'themeprice', 'N;'),
(311, 'ZSELEX', 'shops', 'a:0:{}'),
(313, 'ZSELEX', 'permalinkformat', 's:38:\"%year%/%monthnum%/%day%/%articletitle%\";'),
(314, 'Theme', 'cache_lifetime_mods', 'i:3600;'),
(315, 'ZSELEX', 'fullimagewidth', 's:4:\"1024\";'),
(316, 'ZSELEX', 'fullimageheight', 's:3:\"768\";'),
(317, 'ZSELEX', 'medimagewidth', 's:3:\"220\";'),
(318, 'ZSELEX', 'medimageheight', 's:3:\"200\";'),
(319, 'ZSELEX', 'thumbimagewidth', 's:3:\"150\";'),
(320, 'ZSELEX', 'thumbimageheight', 's:3:\"150\";'),
(321, '/EventHandlers', 'Scribite', 'a:1:{i:0;a:3:{s:9:\"eventname\";s:13:\"core.postinit\";s:8:\"callable\";a:2:{i:0;s:18:\"Scribite_Listeners\";i:1;s:8:\"coreinit\";}s:6:\"weight\";i:10;}}'),
(322, 'Scribite', 'editors_path', 's:25:\"modules/Scribite/includes\";'),
(323, 'Scribite', 'DefaultEditor', 's:1:\"-\";'),
(324, 'Scribite', 'xinha_language', 's:2:\"en\";'),
(325, 'Scribite', 'xinha_skin', 's:9:\"blue-look\";'),
(326, 'Scribite', 'xinha_barmode', 's:7:\"reduced\";'),
(327, 'Scribite', 'xinha_width', 's:4:\"auto\";'),
(328, 'Scribite', 'xinha_height', 's:4:\"auto\";'),
(329, 'Scribite', 'xinha_style', 's:39:\"modules/Scribite/style/xinha/editor.css\";'),
(330, 'Scribite', 'xinha_style_dynamiccss', 's:43:\"modules/Scribite/style/xinha/DynamicCSS.css\";'),
(331, 'Scribite', 'xinha_style_stylist', 's:40:\"modules/Scribite/style/xinha/stylist.css\";'),
(332, 'Scribite', 'xinha_statusbar', 'i:1;'),
(333, 'Scribite', 'xinha_converturls', 'i:1;'),
(334, 'Scribite', 'xinha_showloading', 'i:1;'),
(335, 'Scribite', 'xinha_activeplugins', 's:48:\"a:2:{i:0;s:7:\"GetHtml\";i:1;s:12:\"SmartReplace\";}\";'),
(336, 'Scribite', 'nicedit_xhtml', 'i:0;'),
(337, 'Scribite', 'yui_type', 's:6:\"Simple\";'),
(338, 'Scribite', 'yui_width', 's:4:\"auto\";'),
(339, 'Scribite', 'yui_height', 's:5:\"300px\";'),
(340, 'Scribite', 'yui_dombar', 'b:1;'),
(341, 'Scribite', 'yui_animate', 'b:1;'),
(342, 'Scribite', 'yui_collapse', 'b:1;'),
(343, 'Scribite', 'markitup_width', 's:3:\"65%\";'),
(344, 'Scribite', 'markitup_height', 's:5:\"400px\";'),
(345, 'Scribite', 'tinymce_language', 's:2:\"en\";'),
(346, 'Scribite', 'tinymce_style', 's:40:\"modules/Scribite/style/tinymce/style.css\";'),
(347, 'Scribite', 'tinymce_theme', 's:8:\"advanced\";'),
(348, 'Scribite', 'tinymce_width', 's:3:\"65%\";'),
(349, 'Scribite', 'tinymce_height', 's:5:\"400px\";'),
(350, 'Scribite', 'tinymce_dateformat', 's:8:\"%Y-%m-%d\";'),
(351, 'Scribite', 'tinymce_timeformat', 's:8:\"%H:%M:%S\";'),
(352, 'Scribite', 'tinymce_activeplugins', 's:0:\"\";'),
(353, 'Scribite', 'ckeditor_language', 's:2:\"en\";'),
(354, 'Scribite', 'ckeditor_barmode', 's:4:\"Full\";'),
(355, 'Scribite', 'ckeditor_maxheight', 's:5:\"400px\";'),
(356, 'Scribite', 'ckeditor_style_editor', 's:43:\"modules/Scribite/style/ckeditor/content.css\";'),
(357, 'Scribite', 'ckeditor_skin', 's:4:\"kama\";'),
(358, 'ZSELEX', 'shopAdminGroup', 's:1:\"5\";'),
(359, 'ZSELEX', 'shopOwnerGroup', 's:1:\"4\";'),
(360, 'Theme', 'enable_mobile_theme', 'b:0;'),
(361, 'ZConfig', 'pagetitle', 's:11:\"%pagetitle%\";'),
(362, 'ZSELEX', 'paypalzselexemail', 's:41:\"seller_1357558142_biz@r2international.com\";'),
(390, 'Profile', 'memberslistitemsperpage', 'i:20;'),
(366, 'ZSELEX', 'serviceexpiryday', 's:1:\"5\";'),
(367, 'ZSELEX', 'diskquotaitem', 's:1:\"1\";'),
(368, 'Socialise', 'sexybookmarks', 'a:8:{i:1;s:8:\"facebook\";i:2;s:7:\"twitter\";i:3;s:8:\"linkedin\";i:4;s:9:\"delicious\";i:5;s:7:\"myspace\";i:6;s:4:\"digg\";i:7;s:10:\"technorati\";i:8;s:4:\"mail\";}'),
(369, 'Socialise', 'services', 'a:1:{s:8:\"Facebook\";a:2:{s:6:\"app_id\";s:6:\"App ID\";s:6:\"admins\";s:12:\"Person ID(s)\";}}'),
(370, 'Socialise', 'keys', 'a:1:{s:8:\"Facebook\";a:2:{s:6:\"app_id\";s:15:\"285399811628152\";s:6:\"admins\";s:32:\"0305a2adc939a913241b924b26e0f4d2\";}}'),
(371, '/EventHandlers', 'Socialise', 'a:1:{i:0;a:3:{s:9:\"eventname\";s:9:\"view.init\";s:8:\"callable\";a:2:{i:0;s:14:\"Socialise_Util\";i:1;s:17:\"registerPluginDir\";}s:6:\"weight\";i:10;}}'),
(485, '/EventHandlers', 'Google', 'a:1:{i:0;a:3:{s:9:\"eventname\";s:19:\"user.account.delete\";s:8:\"callable\";a:2:{i:0;s:20:\"Google_Listener_User\";i:1;s:6:\"delete\";}s:6:\"weight\";i:10;}}'),
(423, 'FConnect', 'appid', 's:15:\"643554682381670\";'),
(424, 'FConnect', 'secretkey', 's:32:\"abe3aba7cefb2a46a6425c55b3dc77dc\";'),
(425, 'FConnect', 'isenabled', 's:1:\"1\";'),
(426, 'FConnect', 'jsisenabled', 'b:0;'),
(427, 'FConnect', 'userdataisenabled', 'b:0;'),
(487, 'Google', 'secretkey', 's:24:\"CkobQXAV0ZNsTNin463F4zNv\";'),
(488, 'Google', 'redirecturi', 's:29:\"http://z13x.acta-it.dk/Google\";'),
(486, 'Google', 'clientid', 's:72:\"701711225479-3hcq3kgnrbv7g6jl7css8d16ttm2a1jr.apps.googleusercontent.com\";'),
(382, '/EventHandlers', 'TwitterLogin', 'a:1:{i:0;a:3:{s:9:\"eventname\";s:19:\"user.account.delete\";s:8:\"callable\";a:2:{i:0;s:26:\"TwitterLogin_Listener_User\";i:1;s:6:\"delete\";}s:6:\"weight\";i:10;}}'),
(383, 'TwitterLogin', 'consumerkey', 's:21:\"jRZWDhI9SBEumEZoi4j6A\";'),
(384, 'TwitterLogin', 'consumersecret', 's:41:\"xZMwzIKIeL5EJPFVutHxSKYupBAySkJd5jVVP2SJ0\";'),
(385, 'TwitterLogin', 'redirecturi', 's:51:\"http://z13x.acta-it.dk/TwitterLogin/twitterResponse\";'),
(386, 'systemplugin.imagine', 'version', 's:5:\"1.0.0\";'),
(387, 'systemplugin.imagine', 'thumb_dir', 's:20:\"systemplugin.imagine\";'),
(388, 'systemplugin.imagine', 'thumb_auto_cleanup', 'b:0;'),
(389, 'systemplugin.imagine', 'presets', 'a:1:{s:7:\"default\";C:27:\"SystemPlugin_Imagine_Preset\":178:{x:i:2;a:7:{s:5:\"width\";i:100;s:6:\"height\";i:100;s:4:\"mode\";N;s:9:\"extension\";N;s:8:\"__module\";N;s:9:\"__imagine\";N;s:16:\"__transformation\";N;};m:a:1:{s:7:\"\0*\0name\";s:7:\"default\";}}}'),
(391, 'Profile', 'onlinemembersitemsperpage', 'i:20;'),
(392, 'Profile', 'recentmembersitemsperpage', 'i:10;'),
(393, 'Profile', 'filterunverified', 'b:1;'),
(394, 'Profile', 'dudregshow', 'a:7:{i:0;s:2:\"17\";i:1;s:2:\"18\";i:2;s:2:\"20\";i:3;s:2:\"19\";i:4;s:2:\"21\";i:5;s:2:\"16\";i:6;s:2:\"23\";}'),
(395, '/EventHandlers', 'Profile', 'a:1:{i:0;a:1:{s:9:\"classname\";s:31:\"Profile_Listener_UsersUiHandler\";}}'),
(396, 'Profile', 'viewregdate', 'b:0;'),
(397, 'ZSELEX', 'remindercontentdays', 's:0:\"\";'),
(398, 'ZSELEX', 'invoiceday', 's:2:\"23\";'),
(399, 'FAQ', 'itemsperpage', 'i:25;'),
(400, 'FAQ', 'enablecategorization', 'b:1;'),
(401, 'FAQ', 'catmapcount', 'b:1;'),
(402, 'FAQ', 'addcategorytitletopermalink', 'b:0;'),
(403, 'Content', 'shorturlsuffix', 's:5:\".html\";'),
(404, 'Content', 'styleClasses', 's:71:\"greybox|Grey box\nredbox|Red box\nyellowbox|Yellow box\ngreenbox|Green box\";'),
(405, 'Content', 'enableVersioning', 'b:0;'),
(406, 'Content', 'flickrApiKey', 's:0:\"\";'),
(407, 'Content', 'googlemapApiKey', 's:0:\"\";'),
(408, 'Content', 'categoryUsage', 's:1:\"3\";'),
(409, 'Content', 'categoryPropPrimary', 's:7:\"primary\";'),
(410, 'Content', 'categoryPropSecondary', 's:7:\"primary\";'),
(411, 'Content', 'newPageState', 's:1:\"1\";'),
(412, 'Content', 'countViews', 's:1:\"0\";'),
(413, 'Content', 'enableRawPlugin', 'b:0;'),
(414, '/EventHandlers', 'Content', 'a:1:{i:0;a:3:{s:9:\"eventname\";s:23:\"module.content.gettypes\";s:8:\"callable\";a:2:{i:0;s:12:\"Content_Util\";i:1;s:8:\"getTypes\";}s:6:\"weight\";i:10;}}'),
(422, '/EventHandlers', 'Clip', 'a:2:{i:0;a:3:{s:9:\"eventname\";s:36:\"zikula.filterutil.get_plugin_classes\";s:8:\"callable\";a:2:{i:0;s:27:\"Clip_EventHandler_Listeners\";i:1;s:16:\"getFilterClasses\";}s:6:\"weight\";i:10;}i:1;a:3:{s:9:\"eventname\";s:23:\"module.content.gettypes\";s:8:\"callable\";a:2:{i:0;s:27:\"Clip_EventHandler_Listeners\";i:1;s:15:\"getContentTypes\";}s:6:\"weight\";i:10;}}'),
(428, 'FConnect', 'contentisenabled', 'b:0;'),
(429, 'ZSELEX', 'shoporderby', 's:3:\"new\";'),
(430, 'ZSELEX', 'shopfrontlimit', 's:2:\"20\";'),
(459, 'ZPayment', 'Paypal_enabled_general', 's:1:\"1\";'),
(457, 'ZPayment', 'Directpay_enabled', 'i:1;'),
(458, 'ZPayment', 'Netaxept_enabled_general', 's:1:\"1\";'),
(440, 'ZSELEX', 'default_country_id', 's:2:\"61\";'),
(441, 'ZSELEX', 'default_country_name', 's:7:\"DENMARK\";'),
(456, 'ZPayment', 'Paypal_testmode', 's:1:\"1\";'),
(451, 'ZPayment', 'Netaxept_enabled', 's:1:\"1\";'),
(452, 'ZPayment', 'Netaxept_testmode', 's:1:\"1\";'),
(453, 'ZPayment', 'Netaxept_merchant_id', 's:8:\"11001393\";'),
(454, 'ZPayment', 'Netaxept_token', 's:8:\"8Sr-Bd/6\";'),
(455, 'ZPayment', 'Paypal_enabled', 's:1:\"1\";'),
(460, 'ZPayment', 'Directpay_enabled_general', 's:1:\"1\";'),
(461, 'ZSELEX', 'termsConditionInfo', 's:9592:\"a:2:{s:2:\"da\";a:6:{s:12:\"termsoftrade\";s:631:\"\r\nHvad er Lorem Ipsum?\r\n\r\nLorem Ipsum er ganske enkelt fyldtekst fra print- og typografiindustrien. Lorem Ipsum har været standard fyldtekst siden 1500-tallet, hvor en ukendt trykker sammensatte en tilfældig spalte for at trykke en bog til sammenligning af forskellige skrifttyper. Lorem Ipsum har ikke alene overlevet fem århundreder, men har også vundet indpas i elektronisk typografi uden væsentlige ændringer. Sætningen blev gjordt kendt i 1960\'erne med lanceringen af Letraset-ark, som indeholdt afsnit med Lorem Ipsum, og senere med layoutprogrammer som Aldus PageMaker, som også indeholdt en udgave af Lorem Ipsum.\r\n\";s:3:\"rma\";s:1111:\"\r\nHvor kommer det fra?\r\n\r\nI modsætning til hvad mange tror, er Lorem Ipsum ikke bare tilfældig tekst. Det stammer fra et stykke litteratur på latin fra år 45 f.kr., hvilket gør teksten over 2000 år gammel. Richard McClintock, professor i latin fra Hampden-Sydney universitet i Virginia, undersøgte et af de mindst kendte ord \"consectetur\" fra en del af Lorem Ipsum, og fandt frem til dets oprindelse ved at studere brugen gennem klassisk litteratur. Lorem Ipsum stammer fra afsnittene 1.10.32 og 1.10.33 fra \"de Finibus Bonorum et Malorum\" (Det gode og ondes ekstremer), som er skrevet af Cicero i år 45 f.kr. Bogen, som var meget populær i renæssancen, er en afhandling om etik. Den første linie af Lorem Ipsum \"Lorem ipsum dolor sit amet...\" kommer fra en linje i afsnit 1.10.32.\r\n\r\nStandardafsnittet af Lorem Ipsum, som er brugt siden 1500-tallet, er gengivet nedenfor for de, der er interesserede. Afsnittene 1.10.32 og 1.10.33 fra \"de Finibus Bonorum et Malorum\" af Cicero er også gengivet i deres nøjagtige udgave i selskab med den engelske udgave fra oversættelsen af H. Rackham fra 1914.\r\n\";s:14:\"deliveryprices\";s:654:\"\r\nHvorfor bruger vi det?\r\n\r\nDet er en kendsgerning, at man bliver distraheret af læsbart indhold på en side, når man betragter dens layout. Meningen med at bruge Lorem Ipsum er, at teksten indeholder mere eller mindre almindelig tekstopbygning i modsætning til \"Tekst her – og mere tekst her\", mens det samtidigt ligner almindelig tekst. Mange layoutprogrammer og webdesignere bruger Lorem Ipsum som fyldtekst. En søgning på Lorem Ipsum afslører mange websider, som stadig er på udviklingsstadiet. Der har været et utal af variationer, som er opstået enten på grund af fejl og andre gange med vilje (som blandt andet et resultat af humor).\r\n\";s:12:\"deliverytime\";s:776:\"Hvor kan jeg få fat i det?\r\n\r\nDer er mange tilgængelige udgaver af Lorem Ipsum, men de fleste udgaver har gennemgået forandringer, når nogen har tilføjet humor eller tilfældige ord, som på ingen måde ser ægte ud. Hvis du skal bruge en udgave af Lorem Ipsum, skal du sikre dig, at der ikke indgår noget pinligt midt i teksten. Alle Lorem Ipsum-generatore på nettet har en tendens til kun at dublere små brudstykker af Lorem Ipsum efter behov, hvilket gør dette til den første ægte generator på internettet. Den bruger en ordbog på over 200 ord på latin kombineret med en håndfuld sætningsstrukturer til at generere sætninger, som ser pålidelige ud. Resultatet af Lorem Ipsum er derfor altid fri for gentagelser, tilføjet humor eller utroværdige ord osv.\";s:7:\"privacy\";s:493:\"Standard-afsnittet brugt siden 1500-tallet\r\n\r\n\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"\";s:13:\"securepayment\";s:951:\"Afsnit 1.10.32 fra \"de Finibus Bonorum et Malorum\", skrevet af Cicero i 45 f.kr.\r\n\r\n\"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\"\";}s:2:\"en\";a:6:{s:12:\"termsoftrade\";s:631:\"\r\nHvad er Lorem Ipsum?\r\n\r\nLorem Ipsum er ganske enkelt fyldtekst fra print- og typografiindustrien. Lorem Ipsum har været standard fyldtekst siden 1500-tallet, hvor en ukendt trykker sammensatte en tilfældig spalte for at trykke en bog til sammenligning af forskellige skrifttyper. Lorem Ipsum har ikke alene overlevet fem århundreder, men har også vundet indpas i elektronisk typografi uden væsentlige ændringer. Sætningen blev gjordt kendt i 1960\'erne med lanceringen af Letraset-ark, som indeholdt afsnit med Lorem Ipsum, og senere med layoutprogrammer som Aldus PageMaker, som også indeholdt en udgave af Lorem Ipsum.\r\n\";s:3:\"rma\";s:1111:\"\r\nHvor kommer det fra?\r\n\r\nI modsætning til hvad mange tror, er Lorem Ipsum ikke bare tilfældig tekst. Det stammer fra et stykke litteratur på latin fra år 45 f.kr., hvilket gør teksten over 2000 år gammel. Richard McClintock, professor i latin fra Hampden-Sydney universitet i Virginia, undersøgte et af de mindst kendte ord \"consectetur\" fra en del af Lorem Ipsum, og fandt frem til dets oprindelse ved at studere brugen gennem klassisk litteratur. Lorem Ipsum stammer fra afsnittene 1.10.32 og 1.10.33 fra \"de Finibus Bonorum et Malorum\" (Det gode og ondes ekstremer), som er skrevet af Cicero i år 45 f.kr. Bogen, som var meget populær i renæssancen, er en afhandling om etik. Den første linie af Lorem Ipsum \"Lorem ipsum dolor sit amet...\" kommer fra en linje i afsnit 1.10.32.\r\n\r\nStandardafsnittet af Lorem Ipsum, som er brugt siden 1500-tallet, er gengivet nedenfor for de, der er interesserede. Afsnittene 1.10.32 og 1.10.33 fra \"de Finibus Bonorum et Malorum\" af Cicero er også gengivet i deres nøjagtige udgave i selskab med den engelske udgave fra oversættelsen af H. Rackham fra 1914.\r\n\";s:14:\"deliveryprices\";s:654:\"\r\nHvorfor bruger vi det?\r\n\r\nDet er en kendsgerning, at man bliver distraheret af læsbart indhold på en side, når man betragter dens layout. Meningen med at bruge Lorem Ipsum er, at teksten indeholder mere eller mindre almindelig tekstopbygning i modsætning til \"Tekst her – og mere tekst her\", mens det samtidigt ligner almindelig tekst. Mange layoutprogrammer og webdesignere bruger Lorem Ipsum som fyldtekst. En søgning på Lorem Ipsum afslører mange websider, som stadig er på udviklingsstadiet. Der har været et utal af variationer, som er opstået enten på grund af fejl og andre gange med vilje (som blandt andet et resultat af humor).\r\n\";s:12:\"deliverytime\";s:776:\"Hvor kan jeg få fat i det?\r\n\r\nDer er mange tilgængelige udgaver af Lorem Ipsum, men de fleste udgaver har gennemgået forandringer, når nogen har tilføjet humor eller tilfældige ord, som på ingen måde ser ægte ud. Hvis du skal bruge en udgave af Lorem Ipsum, skal du sikre dig, at der ikke indgår noget pinligt midt i teksten. Alle Lorem Ipsum-generatore på nettet har en tendens til kun at dublere små brudstykker af Lorem Ipsum efter behov, hvilket gør dette til den første ægte generator på internettet. Den bruger en ordbog på over 200 ord på latin kombineret med en håndfuld sætningsstrukturer til at generere sætninger, som ser pålidelige ud. Resultatet af Lorem Ipsum er derfor altid fri for gentagelser, tilføjet humor eller utroværdige ord osv.\";s:7:\"privacy\";s:493:\"Standard-afsnittet brugt siden 1500-tallet\r\n\r\n\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\"\";s:13:\"securepayment\";s:951:\"Afsnit 1.10.32 fra \"de Finibus Bonorum et Malorum\", skrevet af Cicero i 45 f.kr.\r\n\r\n\"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?\"\";}}\";'),
(463, 'ZPayment', 'QuickPay_enabled_general', 's:1:\"1\";'),
(464, 'ZPayment', 'QuickPay_enabled', 's:1:\"1\";'),
(462, 'ZPayment', 'Paypal_business_email', 's:35:\"r2internation-facilitator@india.com\";'),
(465, 'ZPayment', 'QuickPay_testmode', 's:1:\"1\";'),
(466, 'ZPayment', 'QuickPay_ID', 's:8:\"15370300\";'),
(467, 'ZPayment', 'QuickPay_md5', 's:64:\"a2aa3b62eacbe78baec92162ca99d93171b0115295fe87c65cebe91d3d5a1685\";'),
(468, 'ZSELEX', 'da_region1', 's:1:\"9\";'),
(469, 'ZSELEX', 'da_region2', 's:1:\"8\";'),
(470, 'ZSELEX', 'da_region3', 's:1:\"7\";'),
(471, 'ZSELEX', 'da_region4', 's:2:\"14\";'),
(472, 'ZSELEX', 'da_region5', 's:2:\"10\";'),
(473, 'ZSELEX', 'da_region6', 's:2:\"11\";'),
(474, 'ZSELEX', 'da_region7', 's:2:\"15\";'),
(475, 'ZPayment', 'CardsAccepted', 's:877:\"a:17:{s:6:\"paypal\";s:17:\"PayPal|paypal.png\";s:11:\"VisaDankort\";s:32:\"Dankort/Visa-Dankort|dankort.png\";s:9:\"Maestro3D\";s:27:\"Maestro (3D)|3d-maestro.png\";s:12:\"Mastercard3D\";s:33:\"Mastercard (3D)|3d-mastercard.png\";s:15:\"MastercardDebet\";s:43:\"Mastercard-Debet|3d-mastercard-debet-dk.png\";s:6:\"Visa3D\";s:21:\"Visa (3D)|3d-visa.png\";s:14:\"VisaElectron3D\";s:39:\"Visa-Electron (3D)|3d-visa-electron.png\";s:5:\"JCB3D\";s:19:\"JCB (3D)|3d-jcb.png\";s:13:\"LICMASTERCARD\";s:22:\"LIC Mastercard|lic.png\";s:4:\"paii\";s:13:\"Paii|paii.png\";s:8:\"edankort\";s:21:\"eDankort|edankort.png\";s:10:\"mastercard\";s:25:\"Mastercard|mastercard.png\";s:15:\"mastercarddebet\";s:40:\"Mastercard-Debet|mastercard-debet-dk.png\";s:4:\"visa\";s:13:\"Visa|visa.png\";s:12:\"visaelectron\";s:31:\"Visa-Electron|visa-electron.png\";s:3:\"jcb\";s:11:\"JCB|jcb.png\";s:15:\"americanexpress\";s:37:\"American Express|american-express.png\";}\";'),
(476, 'ZSELEX', 'additional_mail_text', 's:0:\"\";'),
(477, 'ZSELEX', 'enabled_mail_text', 's:1:\"1\";'),
(478, '/EventHandlers', 'Zvelo', 'a:1:{i:0;a:3:{s:9:\"eventname\";s:13:\"user.gettheme\";s:8:\"callable\";a:2:{i:0;s:19:\"Zvelo_Listener_User\";i:1;s:8:\"getTheme\";}s:6:\"weight\";i:10;}}'),
(479, 'ZPayment', 'Epay_enabled_general', 's:1:\"1\";'),
(480, 'ZPayment', 'Epay_enabled', 's:1:\"1\";'),
(481, 'ZPayment', 'Epay_testmode', 's:1:\"1\";'),
(482, 'ZPayment', 'Epay_merchant_number', 's:7:\"8018211\";'),
(483, 'ZPayment', 'Epay_test_merchant_number', 's:7:\"8018211\";'),
(484, 'ZPayment', 'Epay_md5_hash', 's:0:\"\";');

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `displayname` varchar(64) NOT NULL,
  `url` varchar(64) NOT NULL,
  `description` varchar(255) NOT NULL,
  `directory` varchar(64) NOT NULL,
  `version` varchar(10) NOT NULL DEFAULT '0',
  `capabilities` longtext NOT NULL,
  `state` smallint(6) NOT NULL DEFAULT '0',
  `securityschema` longtext NOT NULL,
  `core_min` varchar(9) NOT NULL,
  `core_max` varchar(9) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`id`, `name`, `type`, `displayname`, `url`, `description`, `directory`, `version`, `capabilities`, `state`, `securityschema`, `core_min`, `core_max`) VALUES
(1, 'Extensions', 3, 'Extensions', 'extensions', 'Manage your modules and plugins.', 'Extensions', '3.7.10', 'a:1:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:12:\"Extensions::\";s:2:\"::\";}', '', ''),
(2, 'Admin', 3, 'Administration panel', 'adminpanel', 'Backend administration interface.', 'Admin', '1.9.1', 'a:1:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:7:\"Admin::\";s:38:\"Admin Category name::Admin Category ID\";}', '', ''),
(3, 'Blocks', 3, 'Blocks', 'blocks', 'Block administration module.', 'Blocks', '3.8.2', 'a:3:{s:15:\"hook_subscriber\";a:1:{s:7:\"enabled\";b:1;}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:4:{s:8:\"Blocks::\";s:30:\"Block key:Block title:Block ID\";s:16:\"Blocks::position\";s:26:\"Position name::Position ID\";s:23:\"Menutree:menutreeblock:\";s:26:\"Block ID:Link Name:Link ID\";s:19:\"ExtendedMenublock::\";s:17:\"Block ID:Link ID:\";}', '', ''),
(4, 'Categories', 3, 'Categories', 'categories', 'Category administration.', 'Categories', '1.2.1', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:20:\"Categories::Category\";s:40:\"Category ID:Category Path:Category IPath\";}', '', ''),
(5, 'Errors', 3, 'Errors', 'errors', 'Error display module.', 'Errors', '1.1.1', 'a:1:{s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:8:\"Errors::\";s:2:\"::\";}', '', ''),
(6, 'Groups', 3, 'Groups', 'groups', 'User group administration module.', 'Groups', '2.3.2', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:8:\"Groups::\";s:10:\"Group ID::\";}', '', ''),
(7, 'Mailer', 3, 'Mailer', 'mailer', 'Mailer module, provides mail API and mail setting administration.', 'Mailer', '1.3.2', 'a:1:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:8:\"Mailer::\";s:2:\"::\";}', '', ''),
(8, 'PageLock', 3, 'Page lock', 'pagelock', 'Provides the ability to lock pages when they are in use, for content and access control.', 'PageLock', '1.1.1', 'a:0:{}', 1, 'a:1:{s:10:\"PageLock::\";s:2:\"::\";}', '', ''),
(9, 'Permissions', 3, 'Permissions', 'permissions', 'User permissions manager.', 'Permissions', '1.1.1', 'a:1:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:13:\"Permissions::\";s:2:\"::\";}', '', ''),
(10, 'Search', 3, 'Site search', 'search', 'Site search module.', 'Search', '1.5.2', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:8:\"Search::\";s:13:\"Module name::\";}', '', ''),
(11, 'SecurityCenter', 3, 'Security Center', 'securitycenter', 'Manage site security and settings.', 'SecurityCenter', '1.4.4', 'a:1:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:16:\"SecurityCenter::\";s:2:\"::\";}', '', ''),
(12, 'Settings', 3, 'General settings', 'settings', 'General site configuration interface.', 'Settings', '2.9.7', 'a:1:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:10:\"Settings::\";s:2:\"::\";}', '', ''),
(13, 'Theme', 3, 'Themes', 'theme', 'Themes module to manage site layout, render and cache settings.', 'Theme', '3.4.2', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:7:\"Theme::\";s:12:\"Theme name::\";}', '', ''),
(14, 'Users', 3, 'Users', 'users', 'Provides an interface for configuring and administering registered user accounts. Incorporates all needed functionality, but can work in close unison with the third party profile module configured in the general settings of the site.', 'Users', '2.2.0', 'a:4:{s:14:\"authentication\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:15:\"hook_subscriber\";a:1:{s:7:\"enabled\";b:1;}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:2:{s:7:\"Users::\";s:14:\"Uname::User ID\";s:16:\"Users::MailUsers\";s:2:\"::\";}', '1.3.0', ''),
(15, 'Content', 2, 'Content editing', 'content', 'Content is a page editing module. With it you can insert and edit various content items, such as HTML texts, videos, Google maps and much more.', 'Content', '4.0.0', 'a:3:{s:15:\"hook_subscriber\";a:1:{s:7:\"enabled\";b:1;}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:4:{s:9:\"Content::\";s:2:\"::\";s:22:\"Content:plugins:layout\";s:13:\"Layout name::\";s:23:\"Content:plugins:content\";s:19:\"Content type name::\";s:13:\"Content:page:\";s:9:\"Page id::\";}', '1.3.0', ''),
(16, 'Legal', 2, 'Legal info manager', 'legalmod', 'Provides an interface for managing the site\'s legal documents.', 'Legal', '2.0.1', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:8:{s:7:\"Legal::\";s:2:\"::\";s:18:\"Legal::legalnotice\";s:2:\"::\";s:17:\"Legal::termsofuse\";s:2:\"::\";s:20:\"Legal::privacypolicy\";s:2:\"::\";s:16:\"Legal::agepolicy\";s:2:\"::\";s:29:\"Legal::accessibilitystatement\";s:2:\"::\";s:30:\"Legal::cancellationrightpolicy\";s:2:\"::\";s:22:\"Legal::tradeconditions\";s:2:\"::\";}', '1.3.0', '1.3.99'),
(22, 'News', 2, 'News publisher', 'news', 'Provides the ability to publish and manage news articles contributed by site users, with support for news categories and various associated blocks.', 'News', '3.0.0', 'a:3:{s:15:\"hook_subscriber\";a:1:{s:7:\"enabled\";b:1;}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:3:{s:6:\"News::\";s:26:\"Contributor ID::Article ID\";s:19:\"News:pictureupload:\";s:2:\"::\";s:24:\"News:publicationdetails:\";s:2:\"::\";}', '1.3.0', ''),
(18, 'Profile', 2, 'Profile', 'profile', 'Provides a personal account control panel for each registered user, an interface to administer the personal information items displayed within it, and a registered users list functionality. Works in close unison with the \'Users\' module.', 'Profile', '1.6.1', 'a:3:{s:7:\"profile\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:6:{s:9:\"Profile::\";s:2:\"::\";s:13:\"Profile::view\";s:2:\"::\";s:13:\"Profile::item\";s:56:\"DynamicUserData PropertyName::DynamicUserData PropertyID\";s:16:\"Profile:Members:\";s:2:\"::\";s:22:\"Profile:Members:recent\";s:2:\"::\";s:22:\"Profile:Members:online\";s:2:\"::\";}', '1.3.0', '1.3.99'),
(23, 'ZSELEX', 2, 'ZSELEX', 'zselex', 'ZSELEX Module!', 'ZSELEX', '1.5.42', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:8:\"ZSELEX::\";s:2:\"::\";}', '1.3.0', ''),
(24, 'Scribite', 2, 'Scribite', 'scribite', 'WYSIWYG for Zikula', 'Scribite', '4.3.0', 'a:1:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:10:\"Scribite::\";s:12:\"Modulename::\";}', '1.3.0', '1.3.99'),
(26, 'ZMAP', 2, 'ZMAP', 'zmap', 'ZMAP module for map project!', 'ZMAP', '1.0.0', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:6:\"ZMAP::\";s:2:\"::\";}', '1.3.0', ''),
(50, 'Google', 2, 'Google', 'Google', 'Google Zikula Google integration module', 'Google', '1.0.0', 'a:3:{s:14:\"authentication\";a:1:{s:7:\"version\";s:5:\"1.0.0\";}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:8:\"Google::\";s:2:\"::\";}', '1.3.4', '1.3.99'),
(28, 'Socialise', 2, 'Socialise!', 'socialise', 'Share content with social websites like Facebook and Twitter and handle your site Keys.', 'Socialise', '0.2.3', 'a:1:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:11:\"Socialise::\";s:2:\"::\";}', '', ''),
(38, 'FConnect', 2, 'FConnect', 'FConnect', 'FConnect Zikula Facebook integration module', 'FConnect', '1.0.0', 'a:3:{s:14:\"authentication\";a:1:{s:7:\"version\";s:5:\"1.0.0\";}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:10:\"FConnect::\";s:2:\"::\";}', '1.3.4', '1.3.99'),
(34, 'TwitterLogin', 2, 'TwitterLogin', 'TwitterLogin', 'TwitterLogin Zikula integration module', 'TwitterLogin', '1.0.0', 'a:3:{s:14:\"authentication\";a:1:{s:7:\"version\";s:5:\"1.0.0\";}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 2, 'a:1:{s:14:\"TwitterLogin::\";s:2:\"::\";}', '1.3.4', '1.3.99'),
(36, 'FAQ', 2, 'FAQ', 'faq', 'Frequently Asked Questions', 'FAQ', '2.3.2', 'a:3:{s:15:\"hook_subscriber\";a:1:{s:7:\"enabled\";b:1;}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:5:\"FAQ::\";s:8:\"FAQ ID::\";}', '', ''),
(43, 'ZPayment', 2, 'ZPayment', 'ZPayment', 'ZPayment payment module!', 'ZPayment', '1.0.2', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:10:\"ZPayment::\";s:2:\"::\";}', '1.3.0', ''),
(46, 'Zvelo', 2, 'Zvelo', 'zvelo', 'Zvelo module', 'Zvelo', '0.0.2', 'a:3:{s:13:\"hook_provider\";a:1:{s:7:\"enabled\";b:1;}s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:7:\"Zvelo::\";s:2:\"::\";}', '1.3.2', '1.3.99'),
(47, 'ZBlocks', 2, 'ZBlocks', 'ZBlocks', 'ZBlocks block module!', 'ZBlocks', '0.0.1', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:9:\"ZBlocks::\";s:2:\"::\";}', '1.3.0', ''),
(48, 'ZTEXT', 2, 'ZTEXT', 'ztext', 'ZTEXT block module!', 'ZTEXT', '0.0.5', 'a:2:{s:5:\"admin\";a:1:{s:7:\"version\";s:3:\"1.0\";}s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:7:\"ZTEXT::\";s:2:\"::\";}', '1.3.0', ''),
(49, 'ZAPP', 2, 'ZAPP', 'app', 'ZAPP module!', 'ZAPP', '0.0.1', 'a:1:{s:4:\"user\";a:1:{s:7:\"version\";s:3:\"1.0\";}}', 3, 'a:1:{s:6:\"ZAPP::\";s:2:\"::\";}', '1.3.0', '');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `sid` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `urltitle` varchar(255) DEFAULT NULL,
  `hometext` longtext NOT NULL,
  `bodytext` longtext NOT NULL,
  `counter` int(11) DEFAULT '0',
  `contributor` varchar(25) NOT NULL,
  `approver` int(11) DEFAULT '0',
  `notes` longtext NOT NULL,
  `displayonindex` tinyint(4) NOT NULL DEFAULT '0',
  `language` varchar(30) NOT NULL,
  `allowcomments` tinyint(4) NOT NULL DEFAULT '0',
  `format_type` tinyint(4) NOT NULL DEFAULT '0',
  `published_status` tinyint(4) DEFAULT '0',
  `ffrom` datetime DEFAULT NULL,
  `tto` datetime DEFAULT NULL,
  `weight` tinyint(4) DEFAULT '0',
  `pictures` int(11) DEFAULT '0',
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`sid`, `title`, `urltitle`, `hometext`, `bodytext`, `counter`, `contributor`, `approver`, `notes`, `displayonindex`, `language`, `allowcomments`, `format_type`, `published_status`, `ffrom`, `tto`, `weight`, `pictures`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'News introduction article', 'news_introduction_article', 'A news article is divided into an article teaser text (which is the lead-in text you are reading now) and an article body text (which you can view by clicking on the article\'s title or the \'Read more\' link). The teaser will generally be a short introduction to the article, but if you plan to publish only very short bulletins, the teaser can contain the full draft and the article body can be left empty. Click on the article title for more information about Zikula\'s News publisher module.', '<h3>More about the News module</h3><p>You are now reading the body text of the article (starting as from the \'More about the News module\' title above). Both the article teaser and the article body can contain URL links, images, mark-up (HTML tags and, if you have the additional necessary add-ons installed, other mark-up languages such as BBCode) You can learn more about the News module by reading the <a href=\"http://code.zikula.org/news/wiki#Documentation\">News Wiki Documentation</a>.</p><h3>Some more details</h3><p><img src=\"modules/News/images/admin.png\" width=\"48\" height=\"48\" class=\"z-floatleft\" alt=\"News publisher admin image\" />To control what HTML tags can be included in an article to format and enhance it, the site administrator should set the desired tags to enabled status by visiting the <a href=\"index.php?module=SecurityCenter&type=admin&func=allowedhtml\">Security center</a>. With the News module, you can take advantage of Zikula\'s permissions system to control who gets what access to which parts of the News module. A moderator group can be created, containing registered site users who can add, edit and delete articles. This is just a simple example: the Zikula permissions system is sufficiently flexible to let you implement practically any organisation you want.</p><p>You can edit or delete this introductory article by clicking on the link beside the article title, or you can visit to the <a href=\"index.php?module=News&type=admin&func=view\">News admin pages</a>.</p>', 113, 'r2', 3, '', 1, '', 0, 0, 0, '2012-02-16 09:12:53', NULL, 0, 0, 'A', '2012-02-16 09:12:53', 3, '2012-10-17 16:46:22', 3),
(2, 'MY News', 'my-news', '<p>test....</p>', '<p>testtttt</p>', 89, 'r2', 3, '', 1, 'en', 1, 5, 0, '2012-02-24 15:54:38', NULL, 0, 3, 'A', '2012-02-24 15:54:38', 3, '2012-10-17 16:46:22', 3),
(3, 'Latest News', 'latest-news', 'the latest news..', '', 63, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-05-23 10:09:49', NULL, 0, 1, 'A', '2012-05-23 10:09:49', 3, '2012-10-17 16:46:22', 3),
(4, 'Trends', 'trends', 'Trend of the...', '', 75, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-05-23 10:12:32', NULL, 0, 1, 'A', '2012-05-23 10:12:32', 3, '2012-10-17 16:46:22', 3),
(5, 'test artciles 11', 'test-artciles-11', 'sdfdsfdsfsdf', 'sdfsdfsdfsdfsdf', 9, 'testowner', 5, '', 1, 'en', 1, 0, 0, '2012-07-12 15:08:13', NULL, 0, 1, 'A', '2012-07-12 15:08:13', 5, '2012-10-17 16:46:22', 3),
(6, 'test ishop article', 'test-ishop-article', 'adsasd', 'asdsadasdasd', 8, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-07-12 18:23:19', NULL, 0, 1, 'A', '2012-07-12 18:23:19', 3, '2012-10-17 16:46:22', 3),
(7, 'article for Frisør Jytte', 'article-for-frisor-jytte', 'testing....', 'testing article.....', 32, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-07-14 19:24:14', NULL, 0, 1, 'A', '2012-07-14 19:24:14', 3, '2012-10-17 16:46:22', 3),
(8, 'article for Grillen', 'article-for-grillen', 'test...', 'testingggg.....', 61, 'r2', 3, '', 1, '', 1, 0, 0, '2012-07-19 09:06:13', NULL, 0, 2, 'A', '2012-07-19 09:06:13', 3, '2012-10-17 16:46:22', 3),
(9, 'article for testIshop', 'article-for-testishop', 'testtttt', 'testrtttttt', 21, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-07-20 11:16:59', NULL, 0, 1, 'A', '2012-07-20 11:16:59', 3, '2012-10-17 16:45:50', 3),
(10, 'test artcile', 'test-artcile', 'asdasdasd', 'asdsadasdasdasd', 3, 'testowner', 5, '', 1, 'en', 1, 0, 0, '2012-07-20 11:21:10', NULL, 0, 0, 'A', '2012-07-20 11:21:10', 5, '2012-10-17 16:45:50', 3),
(20, 'tewerwrwer', 'tewerwrwer', 'werwerwer', '', 33, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-08-06 11:56:19', NULL, 0, 1, 'A', '2012-08-06 11:56:19', 3, '2012-10-17 16:45:50', 3),
(19, 'teewrwerwer', 'teewrwerwer', '', 'werwerwer', 1, 'testowner', 5, '', 1, 'en', 1, 0, 0, '2012-08-06 11:53:26', NULL, 0, 1, 'A', '2012-08-06 11:53:26', 5, '2012-10-17 16:45:50', 3),
(14, 'test artcilessss', 'test-artcilessss', 'sddsfsdfds', 'sdfdsfsdfsdfsd', 1, 'testowner', 5, '', 1, '', 1, 0, 0, '2012-08-01 13:32:11', NULL, 0, 0, 'A', '2012-08-01 13:32:11', 5, '2012-10-17 16:45:50', 3),
(15, 'iiuyty', 'iiuyty', 'tyututyu', 'tyutyutyutyu', 0, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-08-01 13:35:39', NULL, 0, 1, 'A', '2012-08-01 13:35:39', 3, '2012-10-17 16:45:50', 3),
(16, 'hesport test article', 'hesport-4', 'fdgdgdfg', 'dgdfgdfg', 12, 'testowner', 5, '', 1, 'en', 1, 0, 0, '2012-08-01 13:36:48', NULL, 0, 1, 'A', '2012-08-01 13:36:48', 5, '2012-10-17 16:45:50', 3),
(17, 'test sample....', 'test-sample', 'sdsdfsdf', 'sdfsdfsdfdsf', 18, 'testowner', 5, '', 1, 'en', 1, 0, 0, '2012-08-03 13:42:06', NULL, 0, 0, 'A', '2012-08-03 13:42:06', 5, '2012-10-17 16:45:50', 3),
(18, 'test 3', 'test-3', '<p>testarticle from Kim</p>\r\n<p>hellooo world.....</p>\r\n<p></p>', '<p>body text</p>\r\n<p>helloooooooooooo..................</p>\r\n<p>&lt;img src=\"http://z13x.acta-it.dk/modules/ZSELEX/images/shops/medium/1349445883_ContRightImg.jpg\"&gt;</p>', 8, 'testowner', 5, '', 1, 'en', 1, 5, 0, '2012-08-06 11:11:49', NULL, 0, 0, 'A', '2012-08-06 11:11:49', 5, '2012-10-17 16:47:09', 3),
(21, 'hello testtt', 'hello-testtt', 'asdasdas', 'asdasd', 24, 'testowner', 5, '', 1, 'en', 1, 0, 0, '2012-08-06 12:11:53', NULL, 0, 1, 'A', '2012-08-06 12:11:53', 5, '2012-10-17 16:45:50', 3),
(22, 'test4444', 'test4444', 'adasdadadsaSD', '', 37, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-08-06 12:16:31', NULL, 0, 1, 'A', '2012-08-06 12:16:31', 3, '2012-10-17 16:45:50', 3),
(23, 'TEST567', 'test567', 'sdfsdfsdfsdf', '', 23, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-08-06 12:19:39', NULL, 0, 1, 'A', '2012-08-06 12:19:39', 3, '2012-10-17 16:45:50', 3),
(24, 'test artcle Demo shop', 'test-artcle-demo-shop', 'sadasdasd', 'asdasdasdasd', 40, 'testowner', 5, '', 1, 'en', 1, 0, 0, '2012-08-06 16:51:55', NULL, 0, 1, 'A', '2012-08-06 16:51:55', 5, '2012-10-17 16:45:50', 3),
(25, 'test article 100', 'test-article-100', 'sdsfdsfsdf', 'sdfsdfsdfsdfsd', 20, 'testowner', 5, '', 1, 'en', 1, 0, 0, '2012-08-07 09:13:39', NULL, 0, 1, 'A', '2012-08-07 09:13:39', 5, '2012-10-17 16:45:50', 3),
(26, 'article test', 'article-test', 'testtttt', 'testtttt........', 42, 'r2', 3, '', 1, 'en', 1, 0, 0, '2012-08-21 18:08:34', NULL, 0, 1, 'A', '2012-08-21 18:08:34', 3, '2012-10-17 16:45:50', 3),
(28, 'keep running artcile1', 'test', 'keep running artcile1 test test...', 'keep running artcile1 test test...', 8, 'r2', 3, '', 1, 'en', 1, 0, 0, '2013-01-23 16:39:04', NULL, 0, 1, 'A', '2013-01-23 16:39:04', 3, '2013-01-23 16:39:04', 3),
(29, 'keep running artcile2 ', 'sdfsdfsdf', 'keep running artcile2 test2 test2...', 'keep running artcile2 test2 test2...', 0, 'r2', 3, '', 1, 'en', 1, 0, 0, '2013-01-23 16:40:17', NULL, 0, 1, 'A', '2013-01-23 16:40:17', 3, '2013-01-23 16:40:17', 3),
(30, 'indian shop article1', 'test', '<p>indian shop article1 test1111111</p>', '<p>indian shop article1 test1111111</p>', 8, 'r2', 3, '', 1, 'en', 1, 5, 0, '2013-01-23 18:05:14', NULL, 0, 1, 'A', '2013-01-23 18:05:14', 3, '2013-01-23 18:19:14', 3),
(31, 'test artile keep running', 'test-artile-keep-running', 'adaDSAd', 'aSDASd', 51, 'r2', 3, '', 1, '', 1, 0, 0, '2013-02-18 09:58:15', NULL, 0, 1, 'A', '2013-02-18 09:58:15', 3, '2013-02-18 09:58:15', 3),
(32, 'keep running 111', 'keep-running-111', 'sdfsadfasf', 'sfsadfsadfsadf', 27, 'r2', 3, '', 1, 'en', 1, 0, 0, '2013-02-18 10:01:38', NULL, 0, 0, 'A', '2013-02-18 10:01:38', 3, '2013-02-18 10:01:38', 3),
(33, 'event for kesoft', 'event-for-kesoft', 'This is my error event as article', 'This is my event\'s body text', 2, 'admin', 2, '', 1, '', 1, 0, 0, '2013-02-18 10:25:05', NULL, 0, 0, 'A', '2013-02-18 10:25:05', 2, '2013-02-18 10:25:05', 2),
(34, 'hellloooo', 'hellloooo', 'sadfasdf', 'asdfdasfasdf', 25, 'r2', 3, '', 1, 'en', 1, 0, 0, '2013-02-18 13:15:28', NULL, 0, 0, 'A', '2013-02-18 13:15:28', 3, '2013-02-18 13:15:28', 3),
(35, 'Ole \"Miami\" Mortensen', 'ole-miami-mortensen', '', 'Ole har ejet butikken i over 22 år det allervigtigste for Miami er at deres kunder for den bedste service, hvergang! Dette er kun muligt med det mest engagerede personale og de fedeste tøjvarer, så det har vi selvfølgelig!', 1, 'olemiami', 55, '', 1, '', 1, 0, 0, '2013-08-20 10:01:17', NULL, 0, 1, 'A', '2013-08-20 10:01:17', 55, '2013-08-20 10:01:17', 55),
(36, 'Om CityPilot', 'om-citypilot', '', '<p>CityPilot er et ambiti&oslash;st projekt, som skal skabe mere opm&aelig;rksomhed omkring byen som lokalt oplevelsescenter.</p>\r\n<p>Med CityPilot vil vi forbinde de 3 B\'er.</p>\r\n<p>Borger</p>\r\n<p>By</p>\r\n<p>Butik&nbsp;</p>\r\n<p><a href=\"CityPilot/CityPilot_praesentation.pdf\"><img src=\"themes/CityPilot/images/bbb.jpg\" alt=\"BBB\" width=\"565\" height=\"400\" /></a></p>', 474, 'admin', 2, '', 0, '', 0, 5, 0, '2013-09-05 13:05:53', NULL, 0, 0, 'A', '2013-09-05 13:05:53', 2, '2013-09-05 20:00:25', 2),
(37, 'Kontakt os', 'kontakt-os', '', '<p>CityPilot<br />Prinsessegade 18<br />7000 Fredericia</p>\r\n<p>+45 7594 2434</p>\r\n<p>support: ken@citypilot.dk<br />&nbsp;</p>', 328, 'admin', 2, '', 0, '', 0, 4, 0, '2013-09-05 20:03:56', NULL, 0, 0, 'A', '2013-09-05 20:03:56', 2, '2013-09-05 20:03:56', 2),
(38, '4 nye moduler', '4-nye-moduler', '<p>4 nye moduler</p>', '<p>Vi har introduceret 4 nye services og starter med at give 1. m&aring;neds anvendelse gratis som demo periode.</p>\r\n<p>V&aelig;lg de nye sp&aelig;ndende services som demo og se om det er noget for din butik inden du betaler.</p>\r\n<p>Venlig hilsen<br />Team CityPilot</p>\r\n<p>&nbsp;</p>', 62, 'admin', 2, '', 1, '', 1, 0, 0, '2013-09-27 00:56:08', NULL, 0, 0, 'A', '2013-09-27 00:56:08', 2, '2013-09-27 00:56:08', 2);

-- --------------------------------------------------------

--
-- Table structure for table `objectdata_attributes`
--

CREATE TABLE `objectdata_attributes` (
  `id` int(11) NOT NULL,
  `attribute_name` varchar(80) NOT NULL,
  `object_id` int(11) NOT NULL DEFAULT '0',
  `object_type` varchar(80) NOT NULL,
  `value` longtext NOT NULL,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `objectdata_attributes`
--

INSERT INTO `objectdata_attributes` (`id`, `attribute_name`, `object_id`, `object_type`, `value`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'code', 5, 'categories_category', 'Y', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(2, 'code', 6, 'categories_category', 'N', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(3, 'code', 11, 'categories_category', 'P', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(4, 'code', 12, 'categories_category', 'C', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(5, 'code', 13, 'categories_category', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(6, 'code', 14, 'categories_category', 'O', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(7, 'code', 15, 'categories_category', 'R', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(8, 'code', 17, 'categories_category', 'M', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(9, 'code', 18, 'categories_category', 'F', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(10, 'code', 26, 'categories_category', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(11, 'code', 27, 'categories_category', 'I', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(12, 'code', 29, 'categories_category', 'P', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(13, 'code', 30, 'categories_category', 'A', 'A', '2012-02-13 12:54:06', 0, '2012-02-13 12:54:06', 0),
(15, '_Legal_termsOfUseAccepted', 3, 'users', '2016-08-25T19:58:02+0000', 'A', '2012-02-13 16:11:56', 0, '2016-08-25 21:58:02', 3),
(16, '_Legal_privacyPolicyAccepted', 3, 'users', '2016-08-25T19:58:02+0000', 'A', '2012-02-13 16:11:56', 0, '2016-08-25 21:58:02', 3),
(17, '_Legal_agePolicyConfirmed', 3, 'users', '2016-08-25T19:58:02+0000', 'A', '2012-02-13 16:11:56', 0, '2016-08-25 21:58:02', 3),
(68, '_Legal_termsOfUseAccepted', 22, 'users', '2012-11-19T13:04:34+0000', 'A', '2012-11-19 14:04:34', 0, '2012-11-19 14:04:34', 0),
(67, '_Legal_agePolicyConfirmed', 22, 'users', '2012-11-19T13:04:17+0000', 'A', '2012-11-19 14:04:17', 3, '2012-11-19 14:04:17', 3),
(66, '_Legal_privacyPolicyAccepted', 22, 'users', '2012-11-19T13:04:17+0000', 'A', '2012-11-19 14:04:17', 3, '2012-11-19 14:04:17', 3),
(65, '_Users_isVerified', 22, 'users', '0', 'A', '2012-11-19 14:04:17', 3, '2012-11-19 14:04:17', 3),
(36, '_Legal_termsOfUseAccepted', 9, 'users', '2012-10-05T07:16:20+0000', 'A', '2012-10-05 09:16:20', 0, '2012-10-05 09:16:20', 0),
(37, '_Legal_privacyPolicyAccepted', 9, 'users', '2012-10-05T07:16:20+0000', 'A', '2012-10-05 09:16:20', 0, '2012-10-05 09:16:20', 0),
(38, '_Legal_agePolicyConfirmed', 9, 'users', '2012-10-05T07:16:20+0000', 'A', '2012-10-05 09:16:20', 0, '2012-10-05 09:16:20', 0),
(42, '_Users_isVerified', 13, 'users', '0', 'A', '2012-10-08 11:19:30', 5, '2012-10-08 11:19:30', 5),
(43, '_Legal_termsOfUseAccepted', 13, 'users', '2012-10-08T09:20:17+0000', 'A', '2012-10-08 11:20:17', 0, '2012-10-08 11:20:17', 0),
(44, '_Legal_privacyPolicyAccepted', 13, 'users', '2012-10-08T09:20:17+0000', 'A', '2012-10-08 11:20:17', 0, '2012-10-08 11:20:17', 0),
(45, '_Legal_agePolicyConfirmed', 13, 'users', '2012-10-08T09:20:17+0000', 'A', '2012-10-08 11:20:17', 0, '2012-10-08 11:20:17', 0),
(674, 'shipping address', 99, 'users', '', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(673, 'user_mobile', 99, 'users', '', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(671, 'user_state', 99, 'users', '', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(672, 'user_country', 99, 'users', '', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(61, '_Users_isVerified', 21, 'users', '0', 'A', '2012-10-24 07:25:53', 2, '2012-10-24 07:25:53', 2),
(62, '_Legal_termsOfUseAccepted', 21, 'users', '2012-10-24T05:25:53+0000', 'A', '2012-10-24 07:25:53', 2, '2012-10-24 07:25:53', 2),
(63, '_Legal_privacyPolicyAccepted', 21, 'users', '2012-10-24T05:25:53+0000', 'A', '2012-10-24 07:25:53', 2, '2012-10-24 07:25:53', 2),
(64, '_Legal_agePolicyConfirmed', 21, 'users', '2012-10-24T05:25:53+0000', 'A', '2012-10-24 07:25:53', 2, '2012-10-24 07:25:53', 2),
(73, '_Users_isVerified', 24, 'users', '0', 'A', '2012-12-05 16:10:35', 3, '2012-12-05 16:10:35', 3),
(74, '_Legal_termsOfUseAccepted', 24, 'users', '2012-12-05T15:10:35+0000', 'A', '2012-12-05 16:10:35', 3, '2012-12-05 16:10:35', 3),
(75, '_Legal_privacyPolicyAccepted', 24, 'users', '2012-12-05T15:10:35+0000', 'A', '2012-12-05 16:10:35', 3, '2012-12-05 16:10:35', 3),
(76, '_Legal_agePolicyConfirmed', 24, 'users', '2012-12-05T15:10:35+0000', 'A', '2012-12-05 16:10:35', 3, '2012-12-05 16:10:35', 3),
(367, '_Legal_privacyPolicyAccepted', 73, 'users', '2014-01-22T07:11:59+0000', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(366, '_Legal_termsOfUseAccepted', 73, 'users', '2014-01-22T07:11:59+0000', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(365, '_Users_isVerified', 73, 'users', '0', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(98, '_Legal_termsOfUseAccepted', 30, 'users', '2013-04-16T16:36:37+0000', 'A', '2013-04-16 18:36:37', 0, '2013-04-16 18:36:37', 0),
(99, '_Legal_privacyPolicyAccepted', 30, 'users', '2013-04-16T16:36:37+0000', 'A', '2013-04-16 18:36:37', 0, '2013-04-16 18:36:37', 0),
(100, '_Legal_agePolicyConfirmed', 30, 'users', '2013-04-16T16:36:37+0000', 'A', '2013-04-16 18:36:37', 0, '2013-04-16 18:36:37', 0),
(102, '_Legal_termsOfUseAccepted', 31, 'users', '2013-04-17T10:09:47+0000', 'A', '2013-04-17 12:09:47', 0, '2013-04-17 12:09:47', 0),
(103, '_Legal_privacyPolicyAccepted', 31, 'users', '2013-04-17T10:09:47+0000', 'A', '2013-04-17 12:09:47', 0, '2013-04-17 12:09:47', 0),
(104, '_Legal_agePolicyConfirmed', 31, 'users', '2013-04-17T10:09:47+0000', 'A', '2013-04-17 12:09:47', 0, '2013-04-17 12:09:47', 0),
(106, '_Legal_termsOfUseAccepted', 32, 'users', '2013-04-17T10:13:34+0000', 'A', '2013-04-17 12:13:34', 0, '2013-04-17 12:13:34', 0),
(107, '_Legal_privacyPolicyAccepted', 32, 'users', '2013-04-17T10:13:34+0000', 'A', '2013-04-17 12:13:34', 0, '2013-04-17 12:13:34', 0),
(108, '_Legal_agePolicyConfirmed', 32, 'users', '2013-04-17T10:13:34+0000', 'A', '2013-04-17 12:13:34', 0, '2013-04-17 12:13:34', 0),
(194, '_Users_isVerified', 55, 'users', '0', 'A', '2013-08-19 10:10:33', 2, '2013-08-19 10:10:33', 2),
(195, '_Legal_termsOfUseAccepted', 55, 'users', '2013-11-19T01:00:16+0000', 'A', '2013-08-19 10:10:34', 2, '2013-11-19 02:00:16', 2),
(196, '_Legal_privacyPolicyAccepted', 55, 'users', '2013-11-19T01:00:16+0000', 'A', '2013-08-19 10:10:34', 2, '2013-11-19 02:00:16', 2),
(197, 'first_name', 55, 'users', 'Kim', 'A', '2013-08-19 10:10:34', 2, '2013-11-19 02:00:16', 2),
(198, 'last_name', 55, 'users', 'Enemark', 'A', '2013-08-19 10:10:34', 2, '2013-11-19 02:00:16', 2),
(199, 'user_state', 55, 'users', 'Outside US & Canada', 'A', '2013-08-19 10:10:34', 2, '2013-11-19 02:00:16', 2),
(200, 'user_country', 55, 'users', 'Danmark', 'A', '2013-08-19 10:10:34', 2, '2013-11-19 02:00:16', 2),
(201, 'user_mobile', 55, 'users', '4575942434', 'A', '2013-08-19 10:10:34', 2, '2013-11-19 02:00:16', 2),
(202, 'shipping address', 55, 'users', 'Prinsessegade 18\r\n7000 Fredericia', 'A', '2013-08-19 10:10:34', 2, '2013-11-19 02:00:16', 2),
(203, 'pincode', 55, 'users', '', 'A', '2013-08-19 10:10:34', 2, '2013-08-19 10:10:34', 2),
(204, '_Legal_agePolicyConfirmed', 55, 'users', '2013-11-19T01:00:16+0000', 'A', '2013-08-19 12:44:35', 0, '2013-11-19 02:00:16', 2),
(205, '_Users_isVerified', 56, 'users', '0', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(206, '_Legal_termsOfUseAccepted', 56, 'users', '2013-08-20T08:59:46+0000', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(207, '_Legal_privacyPolicyAccepted', 56, 'users', '2013-08-20T08:59:46+0000', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(208, '_Legal_agePolicyConfirmed', 56, 'users', '2013-08-20T08:59:46+0000', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(209, 'first_name', 56, 'users', 'Kim', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(210, 'last_name', 56, 'users', 'Enemark', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(211, 'user_state', 56, 'users', 'Outside US & Canada', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(212, 'user_country', 56, 'users', 'Danmark', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(213, 'user_mobile', 56, 'users', '4575942434', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(214, 'shipping address', 56, 'users', '', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(215, 'zip', 56, 'users', '7000', 'A', '2013-08-20 10:59:46', 2, '2013-08-20 10:59:46', 2),
(224, '_Legal_termsOfUseAccepted', 57, 'users', '2013-08-26T09:02:18+0000', 'A', '2013-08-26 11:02:18', 0, '2013-08-26 11:02:18', 0),
(217, 'first_name', 57, 'users', 'Rasmus', 'A', '2013-08-26 10:53:35', 2, '2013-08-26 10:53:35', 2),
(218, 'last_name', 57, 'users', 'Hansen', 'A', '2013-08-26 10:53:35', 2, '2013-08-26 10:53:35', 2),
(219, 'user_state', 57, 'users', '', 'A', '2013-08-26 10:53:35', 2, '2013-08-26 10:53:35', 2),
(220, 'user_country', 57, 'users', '', 'A', '2013-08-26 10:53:35', 2, '2013-08-26 10:53:35', 2),
(221, 'user_mobile', 57, 'users', '', 'A', '2013-08-26 10:53:35', 2, '2013-08-26 10:53:35', 2),
(222, 'shipping address', 57, 'users', '', 'A', '2013-08-26 10:53:35', 2, '2013-08-26 10:53:35', 2),
(223, 'zip', 57, 'users', '', 'A', '2013-08-26 10:53:35', 2, '2013-08-26 10:53:35', 2),
(225, '_Legal_privacyPolicyAccepted', 57, 'users', '2013-08-26T09:02:18+0000', 'A', '2013-08-26 11:02:18', 0, '2013-08-26 11:02:18', 0),
(226, '_Legal_agePolicyConfirmed', 57, 'users', '2013-08-26T09:02:18+0000', 'A', '2013-08-26 11:02:18', 0, '2013-08-26 11:02:18', 0),
(227, '_Users_isVerified', 58, 'users', '0', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(228, '_Legal_termsOfUseAccepted', 58, 'users', '2013-09-05T10:38:06+0000', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(229, '_Legal_privacyPolicyAccepted', 58, 'users', '2013-09-05T10:38:06+0000', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(230, '_Legal_agePolicyConfirmed', 58, 'users', '2013-09-05T10:38:06+0000', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(231, 'first_name', 58, 'users', 'Kim', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(232, 'last_name', 58, 'users', 'Enemark', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(233, 'user_state', 58, 'users', 'Outside US & Canada', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(234, 'user_country', 58, 'users', 'Danmark', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(235, 'user_mobile', 58, 'users', '4575942434', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(236, 'shipping address', 58, 'users', '', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(237, 'zip', 58, 'users', '7000', 'A', '2013-09-05 12:38:06', 2, '2013-09-05 12:38:06', 2),
(238, '_Users_isVerified', 59, 'users', '0', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(239, '_Legal_termsOfUseAccepted', 59, 'users', '2013-09-11T14:55:10+0000', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(240, '_Legal_privacyPolicyAccepted', 59, 'users', '2013-09-11T14:55:10+0000', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(241, '_Legal_agePolicyConfirmed', 59, 'users', '2013-09-11T14:55:10+0000', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(242, 'first_name', 59, 'users', 'Kim', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(243, 'last_name', 59, 'users', 'Enemark', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(244, 'user_state', 59, 'users', 'Outside US & Canada', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(245, 'user_country', 59, 'users', 'Danmark', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(246, 'user_mobile', 59, 'users', '4575942434', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(247, 'shipping address', 59, 'users', '', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(248, 'zip', 59, 'users', '7000', 'A', '2013-09-11 16:55:10', 2, '2013-09-11 16:55:10', 2),
(249, '_Users_isVerified', 60, 'users', '0', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(250, '_Legal_termsOfUseAccepted', 60, 'users', '2013-09-11T15:07:43+0000', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(251, '_Legal_privacyPolicyAccepted', 60, 'users', '2013-09-11T15:07:43+0000', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(252, '_Legal_agePolicyConfirmed', 60, 'users', '2013-09-11T15:07:43+0000', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(253, 'first_name', 60, 'users', 'Kim', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(254, 'last_name', 60, 'users', 'Enemark', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(255, 'user_state', 60, 'users', 'Outside US & Canada', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(256, 'user_country', 60, 'users', 'Danmark', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(257, 'user_mobile', 60, 'users', '4575942434', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(258, 'shipping address', 60, 'users', '', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(259, 'zip', 60, 'users', '7000', 'A', '2013-09-11 17:07:43', 2, '2013-09-11 17:07:43', 2),
(260, '_Users_isVerified', 61, 'users', '0', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(261, '_Legal_termsOfUseAccepted', 61, 'users', '2013-09-16T18:16:35+0000', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(262, '_Legal_privacyPolicyAccepted', 61, 'users', '2013-09-16T18:16:35+0000', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(263, '_Legal_agePolicyConfirmed', 61, 'users', '2013-09-16T18:16:35+0000', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(264, 'first_name', 61, 'users', 'Kim', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(265, 'last_name', 61, 'users', 'Enemark', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(266, 'user_state', 61, 'users', 'Outside US & Canada', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(267, 'user_country', 61, 'users', 'Danmark', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(268, 'user_mobile', 61, 'users', '4575942434', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(269, 'shipping address', 61, 'users', '', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(270, 'zip', 61, 'users', '7000', 'A', '2013-09-16 20:16:35', 2, '2013-09-16 20:16:35', 2),
(271, '_Users_isVerified', 62, 'users', '0', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(272, '_Legal_termsOfUseAccepted', 62, 'users', '2013-09-17T06:25:18+0000', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(273, '_Legal_privacyPolicyAccepted', 62, 'users', '2013-09-17T06:25:18+0000', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(274, '_Legal_agePolicyConfirmed', 62, 'users', '2013-09-17T06:25:18+0000', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(275, 'first_name', 62, 'users', 'Kaj', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(276, 'last_name', 62, 'users', 'Cykel', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(277, 'user_state', 62, 'users', '', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(278, 'user_country', 62, 'users', '', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(279, 'user_mobile', 62, 'users', '', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(280, 'shipping address', 62, 'users', '', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(281, 'zip', 62, 'users', '7000', 'A', '2013-09-17 08:25:18', 2, '2013-09-17 08:25:18', 2),
(282, '_Users_isVerified', 63, 'users', '0', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(283, '_Legal_termsOfUseAccepted', 63, 'users', '2013-09-17T06:50:07+0000', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(284, '_Legal_privacyPolicyAccepted', 63, 'users', '2013-09-17T06:50:07+0000', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(285, '_Legal_agePolicyConfirmed', 63, 'users', '2013-09-17T06:50:07+0000', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(286, 'first_name', 63, 'users', '', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(287, 'last_name', 63, 'users', '', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(288, 'user_state', 63, 'users', '', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(289, 'user_country', 63, 'users', '', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(290, 'user_mobile', 63, 'users', '', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(291, 'shipping address', 63, 'users', '', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(292, 'zip', 63, 'users', '7000', 'A', '2013-09-17 08:50:07', 2, '2013-09-17 08:50:07', 2),
(293, '_Users_isVerified', 64, 'users', '0', 'A', '2013-10-10 07:47:59', 2, '2013-10-10 07:47:59', 2),
(294, '_Legal_termsOfUseAccepted', 64, 'users', '2013-10-10T05:48:00+0000', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(295, '_Legal_privacyPolicyAccepted', 64, 'users', '2013-10-10T05:48:00+0000', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(296, '_Legal_agePolicyConfirmed', 64, 'users', '2013-10-10T05:48:00+0000', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(297, 'first_name', 64, 'users', 'Flair', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(298, 'last_name', 64, 'users', '', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(299, 'user_state', 64, 'users', '', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(300, 'user_country', 64, 'users', 'Danmark', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(301, 'user_mobile', 64, 'users', '4575942434', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(302, 'shipping address', 64, 'users', '', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(303, 'zip', 64, 'users', '7000', 'A', '2013-10-10 07:48:00', 2, '2013-10-10 07:48:00', 2),
(304, '_Users_isVerified', 65, 'users', '0', 'A', '2013-11-09 15:15:16', 2, '2013-11-09 15:15:16', 2),
(305, '_Legal_termsOfUseAccepted', 65, 'users', '2013-11-09T14:15:16+0000', 'A', '2013-11-09 15:15:16', 2, '2013-11-09 15:15:16', 2),
(306, '_Legal_privacyPolicyAccepted', 65, 'users', '2013-11-09T14:15:16+0000', 'A', '2013-11-09 15:15:16', 2, '2013-11-09 15:15:16', 2),
(307, '_Legal_agePolicyConfirmed', 65, 'users', '2013-11-09T14:15:16+0000', 'A', '2013-11-09 15:15:16', 2, '2013-11-09 15:15:16', 2),
(308, 'first_name', 65, 'users', 'Kim', 'A', '2013-11-09 15:15:16', 2, '2013-11-09 15:15:17', 2),
(309, 'last_name', 65, 'users', 'Enemark', 'A', '2013-11-09 15:15:17', 2, '2013-11-09 15:15:17', 2),
(310, 'user_state', 65, 'users', 'Outside US & Canada', 'A', '2013-11-09 15:15:17', 2, '2013-11-09 15:15:17', 2),
(311, 'user_country', 65, 'users', 'Danmark', 'A', '2013-11-09 15:15:17', 2, '2013-11-09 15:15:17', 2),
(312, 'user_mobile', 65, 'users', '75942434', 'A', '2013-11-09 15:15:17', 2, '2013-11-09 15:15:17', 2),
(313, 'shipping address', 65, 'users', '', 'A', '2013-11-09 15:15:17', 2, '2013-11-09 15:15:17', 2),
(314, 'zip', 65, 'users', '7000', 'A', '2013-11-09 15:15:17', 2, '2013-11-09 15:15:17', 2),
(334, '_Users_isVerified', 69, 'users', '0', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(335, '_Legal_termsOfUseAccepted', 69, 'users', '2013-11-18T12:40:11+0000', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(336, '_Legal_privacyPolicyAccepted', 69, 'users', '2013-11-18T12:40:11+0000', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(337, '_Legal_agePolicyConfirmed', 69, 'users', '2013-11-18T12:40:11+0000', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(338, 'first_name', 69, 'users', '', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(339, 'last_name', 69, 'users', '', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(340, 'user_state', 69, 'users', '', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(341, 'user_country', 69, 'users', '', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(342, 'user_mobile', 69, 'users', '', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(343, 'shipping address', 69, 'users', '', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(344, 'zip', 69, 'users', '', 'A', '2013-11-18 13:40:11', 2, '2013-11-18 13:40:11', 2),
(345, 'zip', 55, 'users', '7000', 'A', '2013-11-19 02:00:16', 2, '2013-11-19 02:00:16', 2),
(368, '_Legal_agePolicyConfirmed', 73, 'users', '2014-01-22T07:11:59+0000', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(369, 'first_name', 73, 'users', 'Kim', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(370, 'last_name', 73, 'users', 'Enemark', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(371, 'user_state', 73, 'users', '', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(372, 'user_country', 73, 'users', '', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(373, 'user_mobile', 73, 'users', '', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(374, 'shipping address', 73, 'users', '', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(375, 'zip', 73, 'users', '', 'A', '2014-01-22 08:11:59', 2, '2014-01-22 08:11:59', 2),
(669, 'first_name', 99, 'users', '', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(670, 'last_name', 99, 'users', '', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(668, '_Legal_agePolicyConfirmed', 99, 'users', '2014-04-23T08:34:15+0000', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(667, '_Legal_privacyPolicyAccepted', 99, 'users', '2014-04-23T08:34:15+0000', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(643, '_Users_isVerified', 97, 'users', '0', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(644, '_Legal_termsOfUseAccepted', 97, 'users', '2014-04-17T13:38:59+0000', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(645, '_Legal_privacyPolicyAccepted', 97, 'users', '2014-04-17T13:38:59+0000', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(646, '_Legal_agePolicyConfirmed', 97, 'users', '2014-04-17T13:38:59+0000', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(647, 'first_name', 97, 'users', '', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(648, 'last_name', 97, 'users', '', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(649, 'user_state', 97, 'users', '', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(650, 'user_country', 97, 'users', '', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(651, 'user_mobile', 97, 'users', '', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(652, 'shipping address', 97, 'users', '', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(653, 'zip', 97, 'users', '', 'A', '2014-04-17 15:38:59', 2, '2014-04-17 15:38:59', 2),
(666, '_Legal_termsOfUseAccepted', 99, 'users', '2014-04-23T08:34:15+0000', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(665, '_Users_isVerified', 99, 'users', '0', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(675, 'zip', 99, 'users', '', 'A', '2014-04-23 10:34:15', 3, '2014-04-23 10:34:15', 3),
(733, '_Legal_termsOfUseAccepted', 108, 'users', '2014-05-07T15:30:02+0000', 'A', '2014-05-07 17:30:02', 0, '2014-05-07 17:30:02', 0),
(734, '_Legal_privacyPolicyAccepted', 108, 'users', '2014-05-07T15:30:02+0000', 'A', '2014-05-07 17:30:02', 0, '2014-05-07 17:30:02', 0),
(735, '_Legal_agePolicyConfirmed', 108, 'users', '2014-05-07T15:30:02+0000', 'A', '2014-05-07 17:30:02', 0, '2014-05-07 17:30:02', 0),
(767, '_Legal_agePolicyConfirmed', 116, 'users', '2014-05-08T10:10:56+0000', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(766, '_Legal_privacyPolicyAccepted', 116, 'users', '2014-05-08T10:10:56+0000', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(764, '_Users_isVerified', 116, 'users', '0', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(765, '_Legal_termsOfUseAccepted', 116, 'users', '2014-05-08T10:10:56+0000', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(768, 'first_name', 116, 'users', '', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(769, 'last_name', 116, 'users', '', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(770, 'user_state', 116, 'users', '', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(771, 'user_country', 116, 'users', '', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(772, 'user_mobile', 116, 'users', '', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(773, 'shipping address', 116, 'users', '', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(774, 'zip', 116, 'users', '', 'A', '2014-05-08 12:10:56', 2, '2014-05-08 12:10:56', 2),
(852, '_Legal_agePolicyConfirmed', 131, 'users', '2014-08-06T14:12:32+0000', 'A', '2014-08-06 16:12:32', 0, '2014-08-06 16:12:32', 0),
(851, '_Legal_privacyPolicyAccepted', 131, 'users', '2014-08-06T14:12:32+0000', 'A', '2014-08-06 16:12:32', 0, '2014-08-06 16:12:32', 0),
(850, '_Legal_termsOfUseAccepted', 131, 'users', '2014-08-06T14:12:32+0000', 'A', '2014-08-06 16:12:32', 0, '2014-08-06 16:12:32', 0),
(800, 'first_name', 3, 'users', '', 'A', '2014-06-10 16:17:13', 3, '2016-08-25 21:58:02', 3),
(801, 'last_name', 3, 'users', '', 'A', '2014-06-10 16:17:13', 3, '2016-08-25 21:58:02', 3),
(802, 'user_state', 3, 'users', '', 'A', '2014-06-10 16:17:13', 3, '2016-08-25 21:58:02', 3),
(803, 'user_country', 3, 'users', '', 'A', '2014-06-10 16:17:13', 3, '2016-08-25 21:58:02', 3),
(804, 'user_mobile', 3, 'users', '', 'A', '2014-06-10 16:17:13', 3, '2016-08-25 21:58:02', 3),
(805, 'shipping address', 3, 'users', '', 'A', '2014-06-10 16:17:13', 3, '2016-08-25 21:58:02', 3),
(806, 'zip', 3, 'users', '', 'A', '2014-06-10 16:17:13', 3, '2016-08-25 21:58:02', 3),
(818, '_Users_isVerified', 125, 'users', '0', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(819, '_Legal_termsOfUseAccepted', 125, 'users', '2014-08-04T07:25:28+0000', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(820, '_Legal_privacyPolicyAccepted', 125, 'users', '2014-08-04T07:25:28+0000', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(821, '_Legal_agePolicyConfirmed', 125, 'users', '2014-08-04T07:25:28+0000', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(822, 'first_name', 125, 'users', '', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(823, 'last_name', 125, 'users', '', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(824, 'user_state', 125, 'users', '', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(825, 'user_country', 125, 'users', '', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(826, 'user_mobile', 125, 'users', '', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(827, 'shipping address', 125, 'users', '', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(828, 'zip', 125, 'users', '', 'A', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(870, '_Legal_termsOfUseAccepted', 135, 'users', '2016-09-19T17:41:51+0000', 'A', '2016-01-08 18:08:30', 0, '2016-09-19 19:41:51', 3),
(871, '_Legal_privacyPolicyAccepted', 135, 'users', '2016-09-19T17:41:51+0000', 'A', '2016-01-08 18:08:30', 0, '2016-09-19 19:41:51', 3),
(872, '_Legal_agePolicyConfirmed', 135, 'users', '2016-09-19T17:41:51+0000', 'A', '2016-01-08 18:08:30', 0, '2016-09-19 19:41:51', 3),
(873, '_Users_isVerified', 136, 'users', '0', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(874, '_Legal_termsOfUseAccepted', 136, 'users', '2016-02-10T16:51:39+0000', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(875, '_Legal_privacyPolicyAccepted', 136, 'users', '2016-02-10T16:51:39+0000', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(876, '_Legal_agePolicyConfirmed', 136, 'users', '2016-02-10T16:51:39+0000', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(877, 'first_name', 136, 'users', '', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(878, 'last_name', 136, 'users', '', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(879, 'user_state', 136, 'users', '', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(880, 'user_country', 136, 'users', '', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(881, 'user_mobile', 136, 'users', '', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(882, 'shipping address', 136, 'users', '', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(883, 'zip', 136, 'users', '', 'A', '2016-02-10 17:51:39', 3, '2016-02-10 17:51:39', 3),
(884, 'avatar', 137, 'users', 'pers_137.jpg', 'A', '2016-03-21 18:29:57', 0, '2016-03-21 18:29:57', 0),
(885, '_Legal_termsOfUseAccepted', 137, 'users', '2016-03-21T17:46:32+0000', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:46:32', 0),
(886, '_Legal_privacyPolicyAccepted', 137, 'users', '2016-03-21T17:46:32+0000', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:46:32', 0),
(887, '_Legal_agePolicyConfirmed', 137, 'users', '2016-03-21T17:46:32+0000', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:46:32', 0),
(888, 'first_name', 137, 'users', '', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:42:04', 3),
(889, 'last_name', 137, 'users', '', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:42:04', 3),
(890, 'user_state', 137, 'users', '', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:42:04', 3),
(891, 'user_country', 137, 'users', '', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:42:04', 3),
(892, 'user_mobile', 137, 'users', '', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:42:04', 3),
(893, 'shipping address', 137, 'users', '', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:42:04', 3),
(894, 'zip', 137, 'users', '', 'A', '2016-03-21 18:42:04', 3, '2016-03-21 18:42:04', 3),
(937, 'user_mobile', 135, 'users', '', 'A', '2016-09-19 19:41:51', 3, '2016-09-19 19:41:51', 3),
(938, 'shipping address', 135, 'users', '', 'A', '2016-09-19 19:41:51', 3, '2016-09-19 19:41:51', 3),
(939, 'zip', 135, 'users', '', 'A', '2016-09-19 19:41:51', 3, '2016-09-19 19:41:51', 3),
(933, 'first_name', 135, 'users', '', 'A', '2016-09-19 19:41:51', 3, '2016-09-19 19:41:51', 3),
(934, 'last_name', 135, 'users', '', 'A', '2016-09-19 19:41:51', 3, '2016-09-19 19:41:51', 3),
(935, 'user_state', 135, 'users', '', 'A', '2016-09-19 19:41:51', 3, '2016-09-19 19:41:51', 3),
(936, 'user_country', 135, 'users', '', 'A', '2016-09-19 19:41:51', 3, '2016-09-19 19:41:51', 3);

-- --------------------------------------------------------

--
-- Table structure for table `objectdata_log`
--

CREATE TABLE `objectdata_log` (
  `id` int(11) NOT NULL,
  `object_type` varchar(80) NOT NULL,
  `object_id` int(11) NOT NULL DEFAULT '0',
  `op` varchar(16) NOT NULL,
  `diff` longtext,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `objectdata_meta`
--

CREATE TABLE `objectdata_meta` (
  `id` int(11) NOT NULL,
  `module` varchar(40) NOT NULL,
  `tablename` varchar(40) NOT NULL,
  `idcolumn` varchar(40) NOT NULL,
  `obj_id` int(11) NOT NULL DEFAULT '0',
  `permissions` varchar(255) DEFAULT NULL,
  `dc_title` varchar(80) DEFAULT NULL,
  `dc_author` varchar(80) DEFAULT NULL,
  `dc_subject` varchar(255) DEFAULT NULL,
  `dc_keywords` varchar(128) DEFAULT NULL,
  `dc_description` varchar(255) DEFAULT NULL,
  `dc_publisher` varchar(128) DEFAULT NULL,
  `dc_contributor` varchar(128) DEFAULT NULL,
  `dc_startdate` datetime DEFAULT '1970-01-01 00:00:00',
  `dc_enddate` datetime DEFAULT '1970-01-01 00:00:00',
  `dc_type` varchar(128) DEFAULT NULL,
  `dc_format` varchar(128) DEFAULT NULL,
  `dc_uri` varchar(255) DEFAULT NULL,
  `dc_source` varchar(128) DEFAULT NULL,
  `dc_language` varchar(32) DEFAULT NULL,
  `dc_relation` varchar(255) DEFAULT NULL,
  `dc_coverage` varchar(64) DEFAULT NULL,
  `dc_entity` varchar(64) DEFAULT NULL,
  `dc_comment` varchar(255) DEFAULT NULL,
  `dc_extra` varchar(255) DEFAULT NULL,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sc_intrusion`
--

CREATE TABLE `sc_intrusion` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `tag` varchar(40) DEFAULT NULL,
  `value` longtext NOT NULL,
  `page` longtext NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `ip` varchar(40) NOT NULL,
  `impact` int(11) NOT NULL DEFAULT '0',
  `filters` longtext NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `scribite`
--

CREATE TABLE `scribite` (
  `mid` int(11) NOT NULL,
  `modname` varchar(64) NOT NULL,
  `modfuncs` longtext NOT NULL,
  `modareas` longtext NOT NULL,
  `modeditor` varchar(20) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `scribite`
--

INSERT INTO `scribite` (`mid`, `modname`, `modfuncs`, `modareas`, `modeditor`) VALUES
(1, 'Blocks', 'a:1:{i:0;s:6:\"modify\";}', 'a:1:{i:0;s:14:\"blocks_content\";}', '-'),
(2, 'Book', 'a:1:{i:0;s:3:\"all\";}', 'a:1:{i:0;s:7:\"content\";}', '-'),
(3, 'ContentExpress', 'a:2:{i:0;s:10:\"newcontent\";i:1;s:11:\"editcontent\";}', 'a:1:{i:0;s:4:\"text\";}', '-'),
(4, 'crpCalendar', 'a:2:{i:0;s:3:\"new\";i:1;s:6:\"modify\";}', 'a:1:{i:0;s:22:\"crpcalendar_event_text\";}', '-'),
(5, 'crpVideo', 'a:2:{i:0;s:3:\"new\";i:1;s:6:\"modify\";}', 'a:1:{i:0;s:13:\"video_content\";}', '-'),
(6, 'Downloads', 'a:1:{i:0;s:4:\"edit\";}', 'a:1:{i:0;s:11:\"description\";}', '-'),
(7, 'FAQ', 'a:2:{i:0;s:6:\"newfaq\";i:1;s:6:\"modify\";}', 'a:1:{i:0;s:9:\"faqanswer\";}', '-'),
(8, 'htmlpages', 'a:2:{i:0;s:3:\"new\";i:1;s:6:\"modify\";}', 'a:1:{i:0;s:17:\"htmlpages_content\";}', '-'),
(9, 'Mailer', 'a:1:{i:0;s:10:\"testconfig\";}', 'a:1:{i:0;s:11:\"mailer_body\";}', '-'),
(10, 'Mediashare', 'a:4:{i:0;s:8:\"addmedia\";i:1;s:8:\"edititem\";i:2;s:8:\"addalbum\";i:3;s:9:\"editalbum\";}', 'a:1:{i:0;s:3:\"all\";}', '-'),
(11, 'News', 'a:2:{i:0;s:7:\"newitem\";i:1;s:6:\"modify\";}', 'a:2:{i:0;s:13:\"news_hometext\";i:1;s:13:\"news_bodytext\";}', 'tinymce'),
(12, 'Newsletter', 'a:1:{i:0;s:11:\"add_message\";}', 'a:1:{i:0;s:7:\"message\";}', '-'),
(13, 'PagEd', 'a:1:{i:0;s:3:\"all\";}', 'a:1:{i:0;s:5:\"PagEd\";}', '-'),
(14, 'Pages', 'a:2:{i:0;s:7:\"newitem\";i:1;s:6:\"modify\";}', 'a:1:{i:0;s:13:\"pages_content\";}', '-'),
(15, 'Clip', 'a:1:{i:0;s:7:\"pubedit\";}', 'a:1:{i:0;s:3:\"all\";}', '-'),
(16, 'PhotoGallery', 'a:2:{i:0;s:11:\"editgallery\";i:1;s:9:\"editphoto\";}', 'a:1:{i:0;s:17:\"photogallery_desc\";}', '-'),
(17, 'Profile', 'a:1:{i:0;s:6:\"modify\";}', 'a:3:{i:0;s:14:\"prop_signature\";i:1;s:14:\"prop_extrainfo\";i:2;s:15:\"prop_yinterests\";}', '-'),
(18, 'PostCalendar', 'a:1:{i:0;s:3:\"all\";}', 'a:1:{i:0;s:11:\"description\";}', '-'),
(19, 'Reviews', 'a:2:{i:0;s:3:\"new\";i:1;s:6:\"modify\";}', 'a:1:{i:0;s:14:\"reviews_review\";}', '-'),
(20, 'ShoppingCart', 'a:1:{i:0;s:3:\"all\";}', 'a:1:{i:0;s:11:\"description\";}', '-'),
(21, 'ZSELEX', 'a:1:{i:0;s:8:\"mailtext\";}', 'a:1:{i:0;s:20:\"additional_mail_text\";}', 'tinymce');

-- --------------------------------------------------------

--
-- Table structure for table `search_result`
--

CREATE TABLE `search_result` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` longtext,
  `module` varchar(100) DEFAULT NULL,
  `extra` varchar(100) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `found` datetime DEFAULT NULL,
  `sesid` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_result`
--

INSERT INTO `search_result` (`id`, `title`, `text`, `module`, `extra`, `created`, `found`, `sesid`) VALUES
(373, 'PUMA FAAS 300 MEN', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '240,zproduct,shop.keeprunning.dk', '2011-12-13 13:13:48', NULL, 'eedfe3e5e802731edaacb63747c97770bedb18ef'),
(374, 'PUMA FAAS 300 MEN', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '241,zproduct,shop.keeprunning.dk', '2011-12-13 13:16:49', NULL, 'eedfe3e5e802731edaacb63747c97770bedb18ef'),
(375, 'PUMA FAAS 500 MEN', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '242,zproduct,shop.keeprunning.dk', '2011-12-13 13:17:55', NULL, 'eedfe3e5e802731edaacb63747c97770bedb18ef'),
(376, 'PUMA FAAS 500 W', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '263,zproduct,shop.keeprunning.dk', '2012-01-18 13:35:42', NULL, 'eedfe3e5e802731edaacb63747c97770bedb18ef'),
(377, 'PUMA FAAS 300W', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '373,zproduct,shop.keeprunning.dk', '2012-03-27 12:00:17', NULL, 'eedfe3e5e802731edaacb63747c97770bedb18ef'),
(378, 'PUMA FAAS 300W', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '374,zproduct,shop.keeprunning.dk', '2012-03-27 12:01:29', NULL, 'eedfe3e5e802731edaacb63747c97770bedb18ef'),
(1122, 'SAUCONY RIDE4  Saucony', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '298,zproduct,shop.keeprunning.dk', '2012-01-21 16:52:43', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1123, 'SAUCONY RIDE4 WOMEN  Saucony', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '288,zproduct,shop.keeprunning.dk', '2012-01-21 13:43:09', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1119, 'PUMA FAAS 500 W  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '263,zproduct,shop.keeprunning.dk', '2012-01-18 13:35:42', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1120, 'SAUCONY RIDE3  Saucony', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '158,zproduct,shop.keeprunning.dk', '2011-12-07 10:11:46', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1121, 'SAUCONY RIDE3 WOMEN  Saucony', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '165,zproduct,shop.keeprunning.dk', '2011-12-07 11:02:56', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1117, 'PUMA FAAS 300W  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '373,zproduct,shop.keeprunning.dk', '2012-03-27 12:00:17', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1116, 'PUMA FAAS 300W  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '374,zproduct,shop.keeprunning.dk', '2012-03-27 12:01:29', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1115, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '240,zproduct,shop.keeprunning.dk', '2011-12-13 13:13:48', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1114, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '241,zproduct,shop.keeprunning.dk', '2011-12-13 13:16:49', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1099, 'PUMA FAAS 500 W  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '263,zproduct,shop.keeprunning.dk', '2012-01-18 13:35:42', NULL, '6887f869948c37de71f8fa23802f8f90e1a0c713'),
(1110, 'NEW BALANCE 1080  NewBalance', '<ul>\r\n<li>Stabil neu', 'ZSELEX', '270,zproduct,shop.keeprunning.dk', '2012-01-18 15:03:49', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1096, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '241,zproduct,shop.keeprunning.dk', '2011-12-13 13:16:49', NULL, '6887f869948c37de71f8fa23802f8f90e1a0c713'),
(1097, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '240,zproduct,shop.keeprunning.dk', '2011-12-13 13:13:48', NULL, '6887f869948c37de71f8fa23802f8f90e1a0c713'),
(1098, 'PUMA FAAS 500 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '242,zproduct,shop.keeprunning.dk', '2011-12-13 13:17:55', NULL, '6887f869948c37de71f8fa23802f8f90e1a0c713'),
(1118, 'PUMA FAAS 500 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '242,zproduct,shop.keeprunning.dk', '2011-12-13 13:17:55', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(862, 'PUMA FAAS 300W', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '373,zproduct,shop.keeprunning.dk', '2012-03-27 12:00:17', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(863, '', '', 'ZSELEX', '374,zproduct,shop.keeprunning.dk', '2012-03-27 12:01:29', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(864, 'PUMA FAAS 300W', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '374,zproduct,shop.keeprunning.dk', '2012-03-27 12:01:29', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(860, 'PUMA FAAS 500 MEN', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '242,zproduct,shop.keeprunning.dk', '2011-12-13 13:17:55', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(861, '', '', 'ZSELEX', '373,zproduct,shop.keeprunning.dk', '2012-03-27 12:00:17', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(859, '', '', 'ZSELEX', '242,zproduct,shop.keeprunning.dk', '2011-12-13 13:17:55', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(858, 'PUMA FAAS 300 MEN', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '241,zproduct,shop.keeprunning.dk', '2011-12-13 13:16:49', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(857, '', '', 'ZSELEX', '241,zproduct,shop.keeprunning.dk', '2011-12-13 13:16:49', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(856, 'PUMA FAAS 300 MEN', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '240,zproduct,shop.keeprunning.dk', '2011-12-13 13:13:48', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(855, '', '', 'ZSELEX', '240,zproduct,shop.keeprunning.dk', '2011-12-13 13:13:48', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(854, 'PUMA CONCINNITY WOME', '<ul>\r\n<li>Antipronat', 'ZSELEX', '235,zproduct,shop.keeprunning.dk', '2011-12-12 23:58:17', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(853, '', '', 'ZSELEX', '235,zproduct,shop.keeprunning.dk', '2011-12-12 23:58:17', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(852, 'PUMA CONCINNITY MEN', '<ul>\r\n<li>Antipronat', 'ZSELEX', '234,zproduct,shop.keeprunning.dk', '2011-12-12 23:54:55', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(851, '', '', 'ZSELEX', '234,zproduct,shop.keeprunning.dk', '2011-12-12 23:54:55', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(849, '', '', 'ZSELEX', '263,zproduct,shop.keeprunning.dk', '2012-01-18 13:35:42', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(850, 'PUMA FAAS 500 W', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '263,zproduct,shop.keeprunning.dk', '2012-01-18 13:35:42', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(847, '', '', 'ZSELEX', '225,zproduct,shop.keeprunning.dk', '2011-12-12 22:42:26', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(848, 'PUMA ROADRACER MEN', '<ul>\r\n<li>Neutral, s', 'ZSELEX', '225,zproduct,shop.keeprunning.dk', '2011-12-12 22:42:26', NULL, '0a03e63c9f28d21759043c081b9954f34771e767'),
(1113, 'NEW BALANCE 880  NewBalance', '<ul>\r\n<li>Stabil neu', 'ZSELEX', '273,zproduct,shop.keeprunning.dk', '2012-01-18 15:14:39', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1112, 'NEW BALANCE 1080 N2   NewBalance', '<ul>\r\n<li>Stabil neu', 'ZSELEX', '272,zproduct,shop.keeprunning.dk', '2012-01-18 15:12:32', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1111, 'NEW BALANCE 1080 N2  NewBalance', '<ul>\r\n<li>Stabil neu', 'ZSELEX', '271,zproduct,shop.keeprunning.dk', '2012-01-18 15:04:02', NULL, 'c6e650669b22c1b4c20977d393295bcf4a54b593'),
(1288, 'PUMA FAAS 500 W  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '263,zproduct,shop.keeprunning.dk', NULL, NULL, '680262514cd1dcaa41c1ee23fd134346d4e80135'),
(1287, 'PUMA FAAS 500 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '242,zproduct,shop.keeprunning.dk', NULL, NULL, '680262514cd1dcaa41c1ee23fd134346d4e80135'),
(1286, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '240,zproduct,shop.keeprunning.dk', NULL, NULL, '680262514cd1dcaa41c1ee23fd134346d4e80135'),
(1285, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '241,zproduct,shop.keeprunning.dk', NULL, NULL, '680262514cd1dcaa41c1ee23fd134346d4e80135'),
(1370, 'PUMA FAAS 500 W  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '263,zproduct,shop.keeprunning.dk', NULL, NULL, '6bc0651709d337afa81365a8f05c10869fd73d7d'),
(1369, 'PUMA FAAS 500 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '242,zproduct,shop.keeprunning.dk', NULL, NULL, '6bc0651709d337afa81365a8f05c10869fd73d7d'),
(1368, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '240,zproduct,shop.keeprunning.dk', NULL, NULL, '6bc0651709d337afa81365a8f05c10869fd73d7d'),
(1367, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sk', 'ZSELEX', '241,zproduct,shop.keeprunning.dk', NULL, NULL, '6bc0651709d337afa81365a8f05c10869fd73d7d'),
(1451, 'TRAILROC 245  Inov8', '<ul>\r\n<li>Trailsko fra Inov8</li>\r\n<li>Kontant og meget nem ', 'ZSELEX', '423,zproduct,shop.keeprunning.dk', NULL, NULL, 'cd925f86251b0c81358731df4f4f1a9c77202de3'),
(1450, 'Inov8 X-talon 212 MEN  Inov8', '<p>Inov8 X-talon 212<br />Bl&oslash;d mellems&aring;l som un', 'ZSELEX', '191,zproduct,shop.keeprunning.dk', NULL, NULL, 'cd925f86251b0c81358731df4f4f1a9c77202de3'),
(1446, 'INOV8 BARE-XF 210  Inov8', '<ul>\r\n<li>Barfodssko</li>\r\n<li>Velegnet til Crossfit</li>\r\n<', 'ZSELEX', '381,zproduct,shop.keeprunning.dk', NULL, NULL, 'cd925f86251b0c81358731df4f4f1a9c77202de3'),
(1447, 'INOV8 BARE-XF 210  Inov8', '<ul>\r\n<li>Barfodssko</li>\r\n<li>Velegnet til Crossfit</li>\r\n<', 'ZSELEX', '382,zproduct,shop.keeprunning.dk', NULL, NULL, 'cd925f86251b0c81358731df4f4f1a9c77202de3'),
(1448, 'INOV8 F-LITE 195  Inov8', '<ul>\r\n<li>Flad letv&aelig;gter</li>\r\n<li>Kontant sko med god', 'ZSELEX', '199,zproduct,shop.keeprunning.dk', NULL, NULL, 'cd925f86251b0c81358731df4f4f1a9c77202de3'),
(1449, 'INOV8 ROAD-X 233  Inov8', '<ul>\r\n<li>Flad letv&aelig;gter</li>\r\n<li>Lasersk&aring;ret s', 'ZSELEX', '383,zproduct,shop.keeprunning.dk', NULL, NULL, 'cd925f86251b0c81358731df4f4f1a9c77202de3'),
(1547, 'Microsoft IntelliMouse Pro  Microsoft', 'Every element of IntelliMouse Pro - from its unique arched s', 'ZSELEX', '3,zproduct,demo.keeprunning.dk', NULL, NULL, '610557c26bdaed3089d0e5f4bd643b79da8b6106'),
(1548, 'Microsoft Internet Keyboard PS/2  Microsoft', 'The Internet Keyboard has 10 Hot Keys on a comfortable stand', 'ZSELEX', '25,zproduct,demo.keeprunning.dk', NULL, NULL, '610557c26bdaed3089d0e5f4bd643b79da8b6106'),
(1546, 'Microsoft IntelliMouse Explorer  Microsoft', '<p>Microsoft introduces its most advanced mouse, the Intelli', 'ZSELEX', '26,zproduct,demo.keeprunning.dk', NULL, NULL, '610557c26bdaed3089d0e5f4bd643b79da8b6106'),
(1542, 'PUMA ROADRACER MEN  Puma', '<ul>\r\n<li>Neutral, smal, bl&oslash;d letv&aelig;gter</li>\r\n<', 'ZSELEX', '225,zproduct,shop.keeprunning.dk', NULL, NULL, '515f300b31dd35f7a3bd496efd9fe0b5155492d2'),
(1541, 'PUMA FAAS 500 W  Puma', '<ul>\r\n<li>Neutral sko med bl&oslash;d&nbsp;mellems&aring;l</', 'ZSELEX', '263,zproduct,shop.keeprunning.dk', NULL, NULL, '515f300b31dd35f7a3bd496efd9fe0b5155492d2'),
(1540, 'PUMA FAAS 500 MEN  Puma', '<ul>\r\n<li>Neutral sko med bl&oslash;d&nbsp;mellems&aring;l</', 'ZSELEX', '242,zproduct,shop.keeprunning.dk', NULL, NULL, '515f300b31dd35f7a3bd496efd9fe0b5155492d2'),
(1539, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sko med meget bl&oslash;d mellems&aring;l<', 'ZSELEX', '241,zproduct,shop.keeprunning.dk', NULL, NULL, '515f300b31dd35f7a3bd496efd9fe0b5155492d2'),
(1538, 'PUMA FAAS 300 MEN  Puma', '<ul>\r\n<li>Neutral sko med meget bl&oslash;d mellems&aring;l<', 'ZSELEX', '240,zproduct,shop.keeprunning.dk', NULL, NULL, '515f300b31dd35f7a3bd496efd9fe0b5155492d2'),
(1537, 'PUMA CONCINNITY WOMEN  Puma', '<ul>\r\n<li>Antipronationssko uden statisk kile</li>\r\n<li>Bl&o', 'ZSELEX', '235,zproduct,shop.keeprunning.dk', NULL, NULL, '515f300b31dd35f7a3bd496efd9fe0b5155492d2'),
(1536, 'PUMA CONCINNITY MEN  Puma', '<ul>\r\n<li>Antipronationssko uden statisk kile</li>\r\n<li>Bl&o', 'ZSELEX', '234,zproduct,shop.keeprunning.dk', NULL, NULL, '515f300b31dd35f7a3bd496efd9fe0b5155492d2'),
(1549, 'product1', 'test product....', 'ZSELEX', '13,product', '2012-12-07 16:33:10', NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1550, 'product2', 'product sample...', 'ZSELEX', '14,product', '2012-12-07 16:33:48', NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1551, 'product test', 'sample product....', 'ZSELEX', '15,product', '2012-12-07 16:34:35', NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1552, 'A Call for Price Product  ', 'This is a Call for Price product that is also on special.\r\n<', 'ZSELEX', '40,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1553, 'A Call for Price Product SALE  ', 'This is a Call for Price product that is also on special and', 'ZSELEX', '41,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1554, 'A Call No Price  ', 'This is a Call for Price product with no price<br />\r\n\r\nThis', 'ZSELEX', '174,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1555, 'A Free Product  ', 'This is a free product that is also on special.\r\n<br /><br /', 'ZSELEX', '39,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1556, 'A Free Product - All  ', 'This is a free product where there are no prices at all.\r\n<b', 'ZSELEX', '57,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1557, 'A Free Product - SALE  ', 'This is a free product that is also on special.\r\n<br />\r\n\r\nT', 'ZSELEX', '42,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1558, 'A Free Product with Attributes  ', 'This is a free product that is also on special.\r\n<br /><br /', 'ZSELEX', '43,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1559, 'A Maximum Sample of 1  ', 'This product only allows Quantity 1 because the Products Qty', 'ZSELEX', '105,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1560, 'A Maximum Sample of 3  ', 'This product only allows Quantity 1 because the Products Qty', 'ZSELEX', '106,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1561, 'A Mixed OFF Product with Attributes  ', 'This product has attributes and a minimum qty and units.\r\n<b', 'ZSELEX', '44,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1562, 'A Mixed ON Product with Attributes  ', 'This product has attributes and a minimum qty and units.\r\n<b', 'ZSELEX', '46,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1563, 'A Sold Out Product  ', 'This product is Sold Out because the product quantity is <= ', 'ZSELEX', '108,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1564, 'Book  ', 'This Book is sold as a Book that is shipped to the customer ', 'ZSELEX', '173,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1565, 'Free Ship & Payment Virtual  ', 'Product Price is set to 0\r\n<br /><br />\r\n\r\nPayment weight is', 'ZSELEX', '52,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1566, 'Free Ship & Payment Virtual weight 10  ', 'Free Shipping and Payment\r\n<br /><br />\r\n\r\nThe Price is set ', 'ZSELEX', '51,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1567, 'Free Shipping Product with Weight  ', 'This product has Free Shipping.\r\n<br /><br />\r\n\r\nThe weight ', 'ZSELEX', '99,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1568, 'Free Shipping Product without Weight  ', 'This product has Free Shipping.\r\n<br /><br />\r\n\r\nThe weight ', 'ZSELEX', '107,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1569, 'Golf Clubs  ', '<p>Products Price is set to 0 and Products Weight is set to ', 'ZSELEX', '132,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1570, 'Golf Clubs  ', '<p>Products Price is set to 0 and Products Weight is set to ', 'ZSELEX', '160,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1571, 'Hewlett Packard - by attributes  Hewlett Packard', 'The Product Price is set to 0.00\r\n<br /><br />\r\n\r\nThe Produc', 'ZSELEX', '59,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1572, 'Hewlett Packard - by attributes SALE  Hewlett Packard', 'The Product Price is set to 0.00\r\n<br /><br />\r\n\r\nThe Produc', 'ZSELEX', '36,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1573, 'Hewlett Packard - by attributes SALE with Special  Hewlett Packard', 'The Product Price is set to 0.00\r\n<br /><br />\r\n\r\nThe Produc', 'ZSELEX', '100,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1574, 'Hewlett Packard - by attributes with Special% no SALE  Hewlett Packard', 'The Product Price is set to 0.00 Special is set to 20%\r\n<br ', 'ZSELEX', '74,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1575, 'Hewlett Packard - Sale with Attributes NOT on Sale  Hewlett Packard', 'The Product Price is set to 499.75\r\n<br /><br />\r\n\r\nA Sale M', 'ZSELEX', '61,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1576, 'Hewlett Packard - Sale with Attributes on Sale  Hewlett Packard', 'The Product Price is set to 499.75\r\n<br /><br />\r\n\r\nA Sale M', 'ZSELEX', '60,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1577, 'Hide Quantity Box  ', 'This product does not show the Quantity Box when Adding to t', 'ZSELEX', '104,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1578, 'Hide Quantity Box Methods  ', 'This product does not show the Quantity Box when Adding to t', 'ZSELEX', '109,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1579, 'Microsoft IntelliMouse Pro  Microsoft', 'Every element of IntelliMouse Pro - from its unique arched s', 'ZSELEX', '3,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1580, 'Min and Units MIX  ', 'This product is purchased based on minimums and units.\r\n<br ', 'ZSELEX', '53,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1581, 'Min and Units MIX - Sale  ', 'This product is purchased based on minimums and units.\r\n<br ', 'ZSELEX', '55,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1582, 'Min and Units NOMIX  ', 'This product is purchased based on minimums and units.\r\n<br ', 'ZSELEX', '54,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1583, 'Min and Units NOMIX - Sale  ', 'This product is purchased based on minimums and units.\r\n<br ', 'ZSELEX', '56,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1584, 'Multiple Downloads  ', '<p>This product is set up to have multiple downloads.</p><p>', 'ZSELEX', '133,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1585, 'Normal Product  ', '<p>This is a normal product priced at $15</p><p>There are qu', 'ZSELEX', '127,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1586, 'Normal Product by the dozen  ', '<p>This is a normal product priced at $100</p><p>There are q', 'ZSELEX', '176,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1587, 'One Time Charge  ', '<p>This product is $45 with a one time charge set on the col', 'ZSELEX', '158,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1588, 'Per letter - required  ', '<p>Product is priced by attribute</p><p>The Option Name Line', 'ZSELEX', '134,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1589, 'Per word - required  ', '<p>Product is priced by attribute</p><p>The Option Name Line', 'ZSELEX', '131,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1590, 'Price Factor  ', '<p>This product is priced at $10.00</p><p>The attributes are', 'ZSELEX', '155,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1591, 'Price Factor Offset  ', '<p>This product is priced at $10.00</p><p>The attributes are', 'ZSELEX', '156,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1592, 'Price Factor Offset by Attribute  ', '<p>This product is priced at $10.00</p><p>It is marked Price', 'ZSELEX', '157,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1593, 'Qty Discounts by 1  ', '<p>This is a normal product priced at $60</p><p>There are qu', 'ZSELEX', '175,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1594, 'Qty Discounts by 1 Special  ', '<p>This is a normal product priced at $60 with a special of ', 'ZSELEX', '178,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1595, 'Rope  ', '<p>Rope is sold by foot or yard with a minimum length of 10 ', 'ZSELEX', '165,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1596, 'Rope  ', '<p>Rope is sold by foot or yard with a minimum length of 10 ', 'ZSELEX', '154,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1597, 'Single Download  ', '<p>This product is set up to have a single download.</p><p>T', 'ZSELEX', '179,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1598, 'Special Product  ', '<p>This is a Special product priced at $15 with a $10 Specia', 'ZSELEX', '130,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1599, 'Special Product by the dozen  ', '<p>This is a Special product priced at $100 with a $75 Speci', 'ZSELEX', '177,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1600, 'TEST $120  ', 'Product is $120\r\n<br /><br />\r\n\r\nThere is no special and no ', 'ZSELEX', '84,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1601, 'TEST $120 Sale -$5.00  ', '<p>Product is $120 <br /><br /> Sale is -$5.00 <br /><br /> ', 'ZSELEX', '82,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1602, 'TEST $120 Sale -$5.00 Skip  ', 'Product is $120\r\n<br /><br />\r\nSale is -$5.00\r\n<br /><br />\r', 'ZSELEX', '110,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1603, 'TEST $120 Sale 10% Special  ', '<p>Product is $120 <br /><br /> Special is 25% or $90 <br />', 'ZSELEX', '90,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1604, 'TEST $120 Sale 10% Special - Apply to price  ', 'Product is $120\r\n<br /><br />\r\nSpecial is 25% or $90\r\n<br />', 'ZSELEX', '97,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1605, 'TEST $120 Sale 10% Special off  ', 'Product is $120\r\n<br /><br />\r\nSpecial does not exist\r\n<br /', 'ZSELEX', '92,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1606, 'TEST $120 Sale 10% Special off  ', 'Product is Priced by Attributes.\r\n<br /><br />\r\n\r\nAttribute ', 'ZSELEX', '101,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1607, 'TEST $120 Sale 10% Special off - Apply to Price  ', 'Product is $120\r\n<br /><br />\r\nSpecial does not exist\r\n<br /', 'ZSELEX', '98,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1608, 'TEST $120 Sale 10% Special off Skip  ', 'Product is $120\r\n<br /><br />\r\nSpecial does not exist\r\n<br /', 'ZSELEX', '89,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1609, 'TEST $120 Sale Special $90 Skip  ', 'Product is $120\r\n<br /><br />\r\nSpecial is $105\r\n<br /><br />', 'ZSELEX', '88,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1610, 'TEST $120 Special $90  ', 'Product is $120\r\n<br /><br />\r\n\r\nThere is a $90.00 or 25% Sp', 'ZSELEX', '85,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1611, 'TEST $120 Special $90.00 Sale -$5.00  ', 'Product is $120\r\n<br /><br />\r\n\r\nSpecial $90.00 or 25%\r\n<br ', 'ZSELEX', '83,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1612, 'TEST $120 Special $90.00 Sale -$5.00 Skip  ', 'Product is $120\r\n<br /><br />\r\n\r\nSpecial $90.00 or 25% - Spe', 'ZSELEX', '111,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1613, 'TEST $120 Special 25% Sale New Price $100  ', 'Product is $120\r\n<br /><br />\r\nSpecial 25% or $90\r\n<br /><br', 'ZSELEX', '94,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1614, 'TEST $120 Special 25% Sale New Price $100 Skip Specials  ', 'Product is $120\r\n<br /><br />\r\nSpecial 25% or $90\r\n<br /><br', 'ZSELEX', '95,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1615, 'TEST $120 Special off Sale New Price $100  ', 'Product is $120\r\n<br /><br />\r\nSpecial does not exist\r\n<br /', 'ZSELEX', '93,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1616, 'TEST $120 Special off Sale New Price $100 Skip Specials  ', 'Product is $120\r\n<br /><br />\r\nSpecial does not exist\r\n<br /', 'ZSELEX', '96,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1617, 'Test 1  ', 'This is a test product for copying and deleting attributes.\r', 'ZSELEX', '48,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1618, 'Test 2  ', 'This is a test product for copying and deleting attributes.\r', 'ZSELEX', '49,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1619, 'TEST 25% Special  ', 'Product is $100.00\r\n<br /><br />\r\nSpecial is 25%\r\n<br /><br ', 'ZSELEX', '80,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1620, 'TEST 25% special 10% Sale  ', 'Product is $100.00\r\n<br /><br />\r\nSpecial is 25%\r\n<br /><br ', 'ZSELEX', '76,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1621, 'TEST 25% special 10% Sale Attribute Priced  ', 'Priced by Attributes - Product price is set to $0.00\r\n<br />', 'ZSELEX', '78,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1622, 'TEST 25% Special Attribute Priced  ', 'Priced by Attributes - Product price is set to $0.00\r\n<br />', 'ZSELEX', '79,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1623, 'Test 3  ', 'This is a test product for copying and deleting attributes.\r', 'ZSELEX', '50,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1624, 'Test One  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '115,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1625, 'Test Two  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '112,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1626, 'Test Three  ', '<p>This is a test product to fill this category with more 12', 'ZSELEX', '117,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1627, 'Test Four  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '113,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1628, 'Test Five  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '114,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1629, 'Test Six  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '119,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1630, 'Test Seven  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '120,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1631, 'Test Eight  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '116,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1632, 'Test Nine  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '122,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1633, 'Sample of Product General Type  ', 'Product General Type are your regular products.\r\n\r\nThere are', 'ZSELEX', '168,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1634, 'Test Ten  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '118,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1635, 'Test Eleven  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '123,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1636, 'Test Twelve  ', 'This is a test product to fill this category with more 12 ra', 'ZSELEX', '121,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1637, 'Sample of Product Music Type  ', 'The Product Music Type is specially designed for music media', 'ZSELEX', '169,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1638, 'Sample of Document General Type  ', 'Document General Type is used for Products that are actually', 'ZSELEX', '170,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1639, 'Sample of Document Product Type  ', 'Document Product Type is used for Documents that are also av', 'ZSELEX', '171,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1640, 'Sample of Product Free Shipping Type  ', '<p>Product Free Shipping can be setup to highlight the Free ', 'ZSELEX', '172,zproduct,demo.keeprunning.dk', NULL, NULL, '41f99524d6af00c45f0e7b0b4ec76d52042ebd66'),
(1658, 'Single Download  ', '<p>This product is set up to have a single download.</p><p>T', 'ZSELEX', '179,zproduct,demo.keeprunning.dk', NULL, NULL, '1d163794dfaecd33b79689f34b5dc0f0b0031928'),
(1659, 'test', 'test', 'ZSELEX', '14,shoppdf', '0000-00-00 00:00:00', NULL, '1d163794dfaecd33b79689f34b5dc0f0b0031928'),
(1657, 'Multiple Downloads  ', '<p>This product is set up to have multiple downloads.</p><p>', 'ZSELEX', '133,zproduct,demo.keeprunning.dk', NULL, NULL, '1d163794dfaecd33b79689f34b5dc0f0b0031928'),
(1661, 'Test PDF', 'Test PDF', 'ZSELEX', '37,shoppdf', '0000-00-00 00:00:00', NULL, '5e43ed77b8b1c0b9b13390819332d92afd438877'),
(1662, 'LAGERSALG I ', '', 'ZSELEX', '426,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1663, 'NIKE ATLAS MEN  Nike', '<ul>\r\n<li>Neutral stabil sko fra Nike</li>\r\n<li>Samme brede ', 'ZSELEX', '144,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1664, 'NIKE FREE 3.0 V4  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '387,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1665, 'NIKE FREE 3.0 V4 WOMEN LGREEN  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '384,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1666, 'NIKE FREE 3.0 V4 WOMEN SORT  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '371,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1667, 'NIKE FREE 4.0 V2 grey/yellow  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '395,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1668, 'NIKE FREE 4.0 W grey/yellow  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '393,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1669, 'NIKE FREE RUN 3  BLAA  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '215,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1670, 'NIKE FREE RUN 3 electric  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '396,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1671, 'NIKE FREE RUN 3 SORT  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '389,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1672, 'NIKE FREE RUN 3 W BLAA  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '372,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1673, 'NIKE FREE RUN 3 W SHIELD  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '385,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1674, 'NIKE FREE RUN KIDS  Nike', '<ul>\r\n<li>Free motion til b&oslash;rn</li>\r\n<li>Meget fleksi', 'ZSELEX', '277,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1675, 'NIKE FREE RUN KIDS  Nike', '<ul>\r\n<li>Free motion til b&oslash;rn</li>\r\n<li>Meget fleksi', 'ZSELEX', '278,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1676, 'NIKE FREE RUN SHIELD MEN  Nike', '<ul>\r\n<li>Free st&aring;r for free motion, hvilket skoen lev', 'ZSELEX', '157,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1677, 'NIKE GPS UR  Nike', '', 'ZSELEX', '310,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1678, 'NIKE LUNAGLIDE 3 MEN  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '305,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1679, 'NIKE LUNAGLIDE 3 MEN  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '148,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1680, 'NIKE LUNAGLIDE4 MEN  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '394,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1681, 'NIKE LUNAR SWIFT BOYS  Nike', '<ul>\r\n<li>Dynamisk support i h&aelig;l</li>\r\n<li>Giver lidt ', 'ZSELEX', '280,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1682, 'NIKE LUNAR SWIFT GIRLS  Nike', '<ul>\r\n<li>Dynamisk support i h&aelig;l</li>\r\n<li>Giver lidt ', 'ZSELEX', '281,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1683, 'NIKE LUNAR SWIFT GIRLS  Nike', '<ul>\r\n<li>Dynamisk support i h&aelig;l</li>\r\n<li>Giver lidt ', 'ZSELEX', '279,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1684, 'NIKE LUNARACER  Nike', '<ul>\r\n<li>Letv&aelig;get med bl&oslash;d mellems&aring;l</li', 'ZSELEX', '391,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1685, 'NIKE LUNARACER W  Nike', '<ul>\r\n<li>Letv&aelig;get med bl&oslash;d mellems&aring;l</li', 'ZSELEX', '390,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1686, 'NIKE LUNARECLIPSE MEN  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '149,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1687, 'NIKE LUNARECLIPSE SHIELD MEN  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '146,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1688, 'NIKE LUNARECLIPSE SHIELD W  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '205,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1689, 'NIKE LUNARECLIPSE2 MEN  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '303,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1690, 'NIKE LUNARECLIPSE2 SHIELD MEN  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '302,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1691, 'NIKE LUNARECLIPSE2 W  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '289,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1692, 'NIKE LUNARGLIDE3 SHIELD  ', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '209,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1693, 'NIKE LUNARGLIDE3 SHIELD W  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '207,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1694, 'NIKE LUNARGLIDE4 W  Nike', '<ul>\r\n<li>Dynamisk antipronation fra h&aelig;l</li>\r\n<li>Fas', 'ZSELEX', '392,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1695, 'NIKE PEGASUS W SHIELD  Nike', '<ul>\r\n<li>Neutral bl&oslash;d sko fra Nike</li>\r\n<li>Vandafv', 'ZSELEX', '218,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1696, 'NIKE STREAK MEN  Nike', '<ul>\r\n<li>Neutral, smalafstivet letv&aelig;gter</li>\r\n<li>En', 'ZSELEX', '397,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1697, 'NIKE STRUCTURE  WOMEN  Nike', '<ul>\r\n<li>Antipronations sko med god st&oslash;tte ved h&ael', 'ZSELEX', '222,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1698, 'NIKE STRUCTURE MEN GREEN  Nike', '<ul>\r\n<li>Antipronations sko med god st&oslash;tte ved h&ael', 'ZSELEX', '422,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1699, 'NIKE STRUCTURE SHIELD MEN  Nike', '<ul>\r\n<li>Antipronations sko med god st&oslash;tte ved h&ael', 'ZSELEX', '147,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1700, 'NIKE STRUCTURE SHIELD MEN SORT  Nike', '<ul>\r\n<li>Antipronations sko med god st&oslash;tte ved h&ael', 'ZSELEX', '421,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1701, 'NIKE STRUCTURE TRIAX 15 MEN  ', '<ul>\r\n<li>Antipronations sko med god st&oslash;tte ved h&ael', 'ZSELEX', '145,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1702, 'NIKE VOMERO 6  Nike', '<ul>\r\n<li>Neutral l&oslash;besko med bl&oslash;d mellems&ari', 'ZSELEX', '296,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1703, 'NIKE VOMERO 6  Nike', '<ul>\r\n<li>Neutral l&oslash;besko med bl&oslash;d mellems&ari', 'ZSELEX', '142,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1704, 'NIKE VOMERO MEN SORT  Nike', '<ul>\r\n<li>Neutral bl&oslash;d sko fra Nike</li>\r\n<li>God st&', 'ZSELEX', '282,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1705, 'NIKE ZOOM STREAK MEN  Nike', '<ul>\r\n<li>Neutral, smal og kontant racer</li>\r\n<li>Afstivet ', 'ZSELEX', '226,zproduct,shop.keeprunning.dk', NULL, NULL, '9bf3119f0c28f224298f993609282ef899d735ff'),
(1715, 'event for kesoft', 'This is my error event as article', 'News', '33', '2013-02-18 10:25:05', NULL, 'e5994b6ce7860339ff3d033385dd8d851bb7e0fe'),
(1713, 'event for kesoft', 'This is my error event as article', 'News', '33', '2013-02-18 10:25:05', NULL, 'a7f38fc8298c9b8eed2a4e5f8f12469e9a1ccf5f'),
(1716, 'hesport test article', 'fdgdgdfg', 'News', '16', '2012-08-01 13:36:48', NULL, '2fe48d73993165da551a2019f85251f8c9c2d423'),
(1717, 'Hesport', 'jkuik ', 'ZSELEX', '15,shop', '2012-03-07 19:02:14', NULL, '2fe48d73993165da551a2019f85251f8c9c2d423'),
(1718, 'event for kesoft', 'This is my error event as article', 'News', '33', '2013-02-18 10:25:05', NULL, '9af236ff4578446a974e9866750e684331fa8e68'),
(1723, 'sample event', 'event desc', 'ZSELEX', '18,events', '0000-00-00 00:00:00', NULL, '5df3a973fe002fc55ba620f743e9074629111f6f'),
(1722, 'event for kesoft', 'This is my error event as article', 'News', '33', '2013-02-18 10:25:05', NULL, '5df3a973fe002fc55ba620f743e9074629111f6f'),
(1781, 'DemoShop', ' ', 'ZSELEX', '23,shop', '2012-03-08 11:44:44', NULL, 'a67dc99ef2ce6111dfee9f99174b4d3da01fd081'),
(1780, 'test artcle Demo shop', 'sadasdasd', 'News', '24', '2012-08-06 16:51:55', NULL, 'a67dc99ef2ce6111dfee9f99174b4d3da01fd081'),
(1782, 'hellloooo', 'sadfasdf', 'News', '34', '2013-02-18 13:15:28', NULL, '2a8cfd9eec4eded1a8a40f909cb54faf2e7b4ba9');

-- --------------------------------------------------------

--
-- Table structure for table `search_stat`
--

CREATE TABLE `search_stat` (
  `id` int(11) NOT NULL,
  `search` varchar(50) NOT NULL,
  `scount` int(11) NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `search_stat`
--

INSERT INTO `search_stat` (`id`, `search`, `scount`, `date`) VALUES
(1, 'zikula', 1, '2012-02-13'),
(2, 'sdf', 1, '2012-02-13'),
(3, 'fhg', 1, '2012-03-07'),
(4, 'test', 11, '2013-05-15'),
(5, 'po', 1, '2012-05-19'),
(6, 'asda', 1, '2012-05-30'),
(7, 'product', 5, '2012-12-08'),
(8, 'p', 1, '2012-05-30'),
(9, 'ds', 1, '2012-06-12'),
(10, 'fsdfdsf', 2, '2012-06-12'),
(11, 'dsfsdf', 2, '2012-06-12'),
(12, 'gfhfgh', 1, '2012-06-13'),
(13, 'tyuytu', 1, '2012-06-13'),
(14, 'ret', 1, '2012-06-15'),
(15, 'j', 1, '2012-07-14'),
(16, 'demoshop', 1, '2012-08-30'),
(17, 'demo', 3, '2012-12-07'),
(18, 'search...', 3, '2012-10-26'),
(19, 'vcxvxvz', 1, '2012-11-26'),
(20, 'search....', 1, '2012-12-07'),
(21, 'keep', 5, '2012-12-07'),
(22, 'hesport', 2, '2013-03-27'),
(23, 'new', 2, '2013-03-18'),
(24, 'zczxcxz', 1, '2012-12-07'),
(25, 'kim', 1, '2012-12-07'),
(26, 'Hes', 1, '2012-12-07'),
(27, 'shop', 7, '2012-12-10'),
(28, 'sample', 1, '2012-12-07'),
(29, 'fsdf', 2, '2012-12-07'),
(30, 'shops', 1, '2012-12-07'),
(31, 'xzzxczxc', 2, '2012-12-10'),
(32, 'images', 1, '2012-12-07'),
(33, 'sample....', 1, '2012-12-07'),
(34, 'shaop', 1, '2012-12-08'),
(35, 'shop product', 1, '2012-12-08'),
(36, 'image', 1, '2012-12-10'),
(37, 'shop\\\\', 1, '2012-12-10'),
(38, 'sadasds', 2, '2012-12-10'),
(39, 'fgdfgdfg', 1, '2012-12-10'),
(40, 'nike', 3, '2013-02-19'),
(41, 'NIKE STRUCTURE', 1, '2012-12-10'),
(42, 'MIZUNO ', 9, '2012-12-11'),
(43, 'Matrox', 6, '2012-12-10'),
(44, 'PUMA FAAS', 1, '2012-12-10'),
(45, 'PUMA', 39, '2012-12-28'),
(46, 'Microsoft ', 5, '2012-12-28'),
(47, 'Fox ', 1, '2012-12-10'),
(48, 'Courage ', 1, '2012-12-10'),
(49, 'VOMERO ', 1, '2012-12-10'),
(50, 'A200 ', 1, '2012-12-10'),
(51, 'Fusion ', 1, '2012-12-10'),
(52, 'NewLine ', 1, '2012-12-10'),
(53, 'Saucony ', 1, '2012-12-10'),
(54, 'FAAC', 2, '2012-12-11'),
(55, 'FAAS', 28, '2012-12-11'),
(56, 'men', 1, '2012-12-10'),
(57, 'Trailsko ', 1, '2012-12-10'),
(58, 'LUNARECLIPSE2 ', 1, '2012-12-10'),
(59, 'NIKE Microsoft', 1, '2012-12-10'),
(60, 'icrosoft', 1, '2012-12-10'),
(61, 'pr', 1, '2012-12-10'),
(62, 'flat', 1, '2012-12-10'),
(63, 'mizuna', 2, '2012-12-10'),
(64, 'mat', 3, '2012-12-11'),
(65, 'concin', 1, '2012-12-10'),
(66, 'sdfsdf', 1, '2012-12-10'),
(67, 'FAAS 500', 1, '2012-12-10'),
(68, 'LUNARGLIDE3 ', 2, '2012-12-10'),
(69, 'matrix', 3, '2012-12-11'),
(70, 'atlas', 1, '2012-12-10'),
(71, '300', 1, '2012-12-10'),
(72, 'Neutral sk', 1, '2012-12-10'),
(73, 'PUMA CONCINNITY', 1, '2012-12-11'),
(74, 'nirvana', 1, '2012-12-11'),
(75, 'dfsdf', 2, '2012-12-11'),
(76, 'dssasd', 1, '2012-12-11'),
(77, 'newbalance', 1, '2012-12-11'),
(78, 'inov', 1, '2012-12-11'),
(79, 'micro', 1, '2012-12-28'),
(80, 'dvfdf', 1, '2013-01-21'),
(81, 'prod', 1, '2013-01-21'),
(82, 'check', 2, '2013-01-21'),
(83, 'check1', 1, '2013-01-21'),
(84, 'pdf', 1, '2013-01-21'),
(85, 'zimbra', 2, '2013-02-05'),
(86, 'ishop', 1, '2013-03-18'),
(87, 'india', 2, '2013-03-18'),
(88, 'indian', 1, '2013-03-18'),
(89, 'kesoft', 2, '2013-03-18'),
(90, 'event', 4, '2013-04-04'),
(91, 'evnet', 1, '2013-04-04'),
(92, 'vcbvxb', 1, '2013-05-15'),
(93, 'gal', 1, '2013-05-15'),
(94, 'dfgfsdg', 1, '2013-06-27');

-- --------------------------------------------------------

--
-- Table structure for table `session_info`
--

CREATE TABLE `session_info` (
  `sessid` varchar(40) NOT NULL,
  `ipaddr` varchar(32) NOT NULL,
  `lastused` datetime DEFAULT '1970-01-01 00:00:00',
  `uid` int(11) DEFAULT '0',
  `remember` tinyint(4) NOT NULL DEFAULT '0',
  `vars` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `session_info`
--

INSERT INTO `session_info` (`sessid`, `ipaddr`, `lastused`, `uid`, `remember`, `vars`) VALUES
('8urmbp6oqa6qf6ovn76hkronlfrqo0ov', '837ec5754f503cfaaee0929fd48974e7', '2018-02-03 06:50:26', 0, 0, '/|a:3:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"016d425a301ffee20ddbbf2e8fbe5dc4b840177c\";s:3:\"uid\";i:0;}_zikula_messages|a:1:{s:5:\"error\";a:0:{}}temp_user_id|s:13:\"5a754da26b694\";'),
('9f2lfo85uq84jnm6opkp3kpucsbg84h9', '837ec5754f503cfaaee0929fd48974e7', '2018-02-03 06:44:38', 0, 0, '/|a:3:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"016d425a301ffee20ddbbf2e8fbe5dc4b840177c\";s:3:\"uid\";i:0;}_zikula_messages|a:1:{s:5:\"error\";a:0:{}}temp_user_id|s:13:\"5a754c4629887\";'),
('3buh43m31gj97fnhar1q36er7gvqggqi', '837ec5754f503cfaaee0929fd48974e7', '2018-02-03 06:44:17', 0, 0, '/|a:3:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"016d425a301ffee20ddbbf2e8fbe5dc4b840177c\";s:3:\"uid\";i:0;}_zikula_messages|a:1:{s:5:\"error\";a:0:{}}temp_user_id|s:13:\"5a754c2ef4172\";'),
('rnqe028kf19959kfv16g2rcfpjkgfelb', '837ec5754f503cfaaee0929fd48974e7', '2018-02-03 08:18:12', 3, 0, '/|a:6:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"016d425a301ffee20ddbbf2e8fbe5dc4b840177c\";s:3:\"uid\";s:1:\"3\";s:12:\"cart_shop_id\";s:2:\"26\";s:7:\"_tokens\";a:4:{s:23:\"5a756190d78849.51437330\";a:2:{s:5:\"token\";s:92:\"NWE3NTYxOTBkNzg4NDkuNTE0MzczMzA6ZTAzZjk4Y2M1MjIwY2UwN2VhOWY1MGZhMWRmMWVhNGM6MTUxNzY0MjEyOA==\";s:9:\"timestamp\";i:1517642128;}s:23:\"5a7561f61c9ab9.24364667\";a:2:{s:5:\"token\";s:92:\"NWE3NTYxZjYxYzlhYjkuMjQzNjQ2Njc6NTZkZjQ4OGJkZGRkMDNmZmYyZjAzZTNhMzdlZjI1NDM6MTUxNzY0MjIzMA==\";s:9:\"timestamp\";i:1517642230;}s:23:\"5a7561f685b044.09974659\";a:2:{s:5:\"token\";s:92:\"NWE3NTYxZjY4NWIwNDQuMDk5NzQ2NTk6OTZkODEzZDNhNGI4YjZmMTE1ODMzNmE4YmU1NzM0Y2M6MTUxNzY0MjIzMA==\";s:9:\"timestamp\";i:1517642230;}s:23:\"5a7561fdb68106.92481661\";a:2:{s:5:\"token\";s:92:\"NWE3NTYxZmRiNjgxMDYuOTI0ODE2NjE6ZWI5ZTBiODgwMjJkMTg1MDUyNTlmNmI5ZmU4Y2U3MjY6MTUxNzY0MjIzNw==\";s:9:\"timestamp\";i:1517642237;}}s:7:\"shop_id\";N;}_zikula_messages|a:1:{s:5:\"error\";a:0:{}}temp_user_id|s:13:\"5a754c2bbdc6c\";linkedOption|a:0:{}otherOption|a:0:{}otherOption2|a:0:{}checkboxOption|a:0:{}netaxept|a:0:{}cart_menu|a:0:{}checkoutsession|s:1:\"1\";userInfo|a:8:{s:10:\"first_name\";N;s:9:\"last_name\";N;s:6:\"mobile\";N;s:3:\"zip\";N;s:4:\"city\";N;s:7:\"country\";N;s:7:\"address\";N;s:5:\"email\";N;}checkoutinfo|a:17:{s:5:\"fname\";s:7:\"ssadasd\";s:5:\"lname\";s:6:\"sasdas\";s:7:\"address\";s:10:\"sdfcsdfdsf\";s:3:\"zip\";s:5:\"dsfsf\";s:4:\"city\";s:8:\"scfsdfsf\";s:5:\"phone\";s:10:\"4444444444\";s:5:\"email\";s:13:\"sssss@sdd.com\";s:7:\"country\";s:0:\"\";s:5:\"state\";s:0:\"\";s:13:\"shipping_info\";a:9:{s:5:\"fname\";s:7:\"ssadasd\";s:5:\"lname\";s:6:\"sasdas\";s:7:\"address\";s:10:\"sdfcsdfdsf\";s:3:\"zip\";s:5:\"dsfsf\";s:4:\"city\";s:8:\"scfsdfsf\";s:5:\"phone\";s:10:\"4444444444\";s:5:\"email\";s:13:\"sssss@sdd.com\";s:7:\"country\";s:0:\"\";s:5:\"state\";s:0:\"\";}s:7:\"shop_id\";s:2:\"26\";s:10:\"cartstatus\";N;s:8:\"shipping\";s:8:\"200.0000\";s:3:\"VAT\";d:45.400000000000006;s:10:\"totalprice\";d:27;s:15:\"grand_total_all\";d:227;s:11:\"final_price\";d:227;}Zikula_Users|a:1:{s:21:\"authentication_method\";a:2:{s:7:\"modname\";s:5:\"Users\";s:6:\"method\";s:5:\"uname\";}}mainshop|N;'),
('cg8ri1tafvf47dkf1kis70ojugh7v97h', '837ec5754f503cfaaee0929fd48974e7', '2018-02-03 06:44:29', 0, 0, '/|a:5:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"016d425a301ffee20ddbbf2e8fbe5dc4b840177c\";s:3:\"uid\";i:0;s:14:\"_ZErrorMsgType\";i:403;s:7:\"_tokens\";a:2:{s:23:\"5a754c335a9334.60408985\";a:2:{s:5:\"token\";s:92:\"NWE3NTRjMzM1YTkzMzQuNjA0MDg5ODU6NGQwMGFlNTQzZTMxZGQ0OWFjNGRiMzc5MDJiMDM2OGM6MTUxNzYzNjY1OQ==\";s:9:\"timestamp\";i:1517636659;}s:23:\"5a754c352a7248.99782701\";a:2:{s:5:\"token\";s:92:\"NWE3NTRjMzUyYTcyNDguOTk3ODI3MDE6ZDZmMjYzMzQ4ZWM4YjY2YWQ4YWYwYzBkNTM2MjY3Y2Y6MTUxNzYzNjY2MQ==\";s:9:\"timestamp\";i:1517636661;}}}_zikula_messages|a:1:{s:5:\"error\";a:0:{}}temp_user_id|s:13:\"5a754c3b89bcc\";'),
('1rkmglk1pihbbmdl6cn8dui250ba67rb', '837ec5754f503cfaaee0929fd48974e7', '2018-02-03 06:44:29', 0, 0, '/|a:5:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"016d425a301ffee20ddbbf2e8fbe5dc4b840177c\";s:3:\"uid\";i:0;s:14:\"_ZErrorMsgType\";i:403;s:7:\"_tokens\";a:2:{s:23:\"5a754c335a93e2.57713424\";a:2:{s:5:\"token\";s:92:\"NWE3NTRjMzM1YTkzZTIuNTc3MTM0MjQ6MGZiMzU2NzUxYTdjNzk3YjRiNTE0ODMyZTUyMjA3Mjk6MTUxNzYzNjY1OQ==\";s:9:\"timestamp\";i:1517636659;}s:23:\"5a754c352ad0c8.38019107\";a:2:{s:5:\"token\";s:92:\"NWE3NTRjMzUyYWQwYzguMzgwMTkxMDc6ODJhMTQ2NzBkNjMwNDNiM2E0MDg0MTQwYmQ3MjY2OTE6MTUxNzYzNjY2MQ==\";s:9:\"timestamp\";i:1517636661;}}}_zikula_messages|a:1:{s:5:\"error\";a:0:{}}temp_user_id|s:13:\"5a754c3b8c19e\";'),
('flls9fj9gknfc818oijr3thp03amroai', '837ec5754f503cfaaee0929fd48974e7', '2018-02-03 06:43:20', 0, 0, '/|a:3:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"016d425a301ffee20ddbbf2e8fbe5dc4b840177c\";s:3:\"uid\";i:0;}_zikula_messages|a:0:{}temp_user_id|s:13:\"5a754bf7b5fbf\";'),
('d5lgdcmio1bdsune5oqr62gv2a54rfk9', '837ec5754f503cfaaee0929fd48974e7', '2017-12-10 15:14:09', 0, 0, '/|a:3:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"da39a3ee5e6b4b0d3255bfef95601890afd80709\";s:3:\"uid\";i:0;}_zikula_messages|a:1:{s:5:\"error\";a:2:{i:0;s:59:\"Error! A problem occurred while sending the e-mail message.\";i:1;s:59:\"Error! A problem occurred while sending the e-mail message.\";}}'),
('2mcmg0bveimb06ul4ostfopsepg7p3gn', '837ec5754f503cfaaee0929fd48974e7', '2017-12-10 15:16:15', 3, 0, '/|a:5:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"443e725a89423b2aace6c304ba5bf2dc89a1e02c\";s:3:\"uid\";s:1:\"3\";s:7:\"_tokens\";a:8:{s:23:\"5a2d203ca777f7.72555799\";a:2:{s:5:\"token\";s:92:\"NWEyZDIwM2NhNzc3ZjcuNzI1NTU3OTk6ZTcwYTNlNjMzZDMwOTIxMzI4YmJmNDBmM2EwNTliN2M6MTUxMjkwNjgxMg==\";s:9:\"timestamp\";i:1512906812;}s:23:\"5a2d20423ca1b0.45889619\";a:2:{s:5:\"token\";s:92:\"NWEyZDIwNDIzY2ExYjAuNDU4ODk2MTk6ZWRjMWEzZWY1ZjEyNTA0ODAxZWUwNTg3ZjI4ZTY0OTI6MTUxMjkwNjgxOA==\";s:9:\"timestamp\";i:1512906818;}s:23:\"5a2d2042b40882.07813681\";a:2:{s:5:\"token\";s:92:\"NWEyZDIwNDJiNDA4ODIuMDc4MTM2ODE6MWZhMTQxNWE2OWZhZWYyNzBjZDQ0OThlMmVjNjEyMTU6MTUxMjkwNjgxOA==\";s:9:\"timestamp\";i:1512906818;}s:23:\"5a2d204a3c12d9.95973969\";a:2:{s:5:\"token\";s:92:\"NWEyZDIwNGEzYzEyZDkuOTU5NzM5Njk6NmQyMmU4YzRkNThjNzE3N2U3ZDc0NGNhNDdjZDlmNDk6MTUxMjkwNjgyNg==\";s:9:\"timestamp\";i:1512906826;}s:23:\"5a2d204f4bbd44.90706458\";a:2:{s:5:\"token\";s:92:\"NWEyZDIwNGY0YmJkNDQuOTA3MDY0NTg6NjNlMmNjMTY4OTg0ZjEzOGU0YzRiNGYyMmFiMGY2OGI6MTUxMjkwNjgzMQ==\";s:9:\"timestamp\";i:1512906831;}s:23:\"5a2d2b8805e3a5.00741108\";a:2:{s:5:\"token\";s:92:\"NWEyZDJiODgwNWUzYTUuMDA3NDExMDg6NjJkZTU1MDYyM2UwODkzNWQ2OWQ5NTQ3ODgwYTNhMDc6MTUxMjkwOTcwNA==\";s:9:\"timestamp\";i:1512909704;}s:23:\"5a2d353cd88a36.44944461\";a:2:{s:5:\"token\";s:92:\"NWEyZDM1M2NkODhhMzYuNDQ5NDQ0NjE6YmY2NjU2N2I2OTUxOGIzZDRiYTg3OGUyZGU0NzkzMjc6MTUxMjkxMjE4OA==\";s:9:\"timestamp\";i:1512912188;}s:23:\"5a2d412d3c8760.38595947\";a:2:{s:5:\"token\";s:92:\"NWEyZDQxMmQzYzg3NjAuMzg1OTU5NDc6OTMyNDFiYTE1YWQ3MzU3ZDAyMmY0NWVmZTYwMWExYjE6MTUxMjkxNTI0NQ==\";s:9:\"timestamp\";i:1512915245;}}s:7:\"shop_id\";N;}_zikula_messages|a:2:{s:5:\"error\";a:0:{}s:6:\"status\";a:0:{}}Zikula_Users|a:1:{s:21:\"authentication_method\";a:2:{s:7:\"modname\";s:5:\"Users\";s:6:\"method\";s:5:\"uname\";}}mainshop|N;linkedOption|a:0:{}otherOption|a:0:{}otherOption2|a:0:{}checkboxOption|a:0:{}'),
('j5nok4vpr7c4046p8p0023eel8ogr4dc', '837ec5754f503cfaaee0929fd48974e7', '2017-12-10 12:48:23', 0, 0, '/|a:3:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"443e725a89423b2aace6c304ba5bf2dc89a1e02c\";s:3:\"uid\";i:0;}_zikula_messages|a:0:{}temp_user_id|s:13:\"5a2d1f01eafec\";'),
('i9vovruu4ajmv7amogkr5mqvvu47e6i6', '837ec5754f503cfaaee0929fd48974e7', '2017-12-10 12:48:24', 0, 0, '/|a:3:{s:4:\"rand\";a:0:{}s:9:\"useragent\";s:40:\"443e725a89423b2aace6c304ba5bf2dc89a1e02c\";s:3:\"uid\";i:0;}_zikula_messages|a:0:{}');

-- --------------------------------------------------------

--
-- Table structure for table `shoppr_city`
--

CREATE TABLE `shoppr_city` (
  `id` int(11) NOT NULL,
  `cityname` varchar(255) NOT NULL,
  `address` varchar(2000) NOT NULL,
  `createdUserId` int(11) NOT NULL,
  `updatedUserId` int(11) NOT NULL,
  `createdDate` datetime NOT NULL,
  `updatedDate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppr_city`
--

INSERT INTO `shoppr_city` (`id`, `cityname`, `address`, `createdUserId`, `updatedUserId`, `createdDate`, `updatedDate`) VALUES
(1, 'City cityname 1', 'City address 1', 3, 3, '2012-02-14 17:30:29', '2012-02-14 17:30:29'),
(2, 'City cityname 2', 'City address 2', 3, 3, '2012-02-14 17:30:29', '2012-02-14 17:30:29'),
(6, 'Texas', 'texax city', 3, 3, '2012-02-14 17:30:55', '2012-02-14 17:30:55'),
(7, 'Ney York', 'dsdsfsdf', 3, 3, '2012-02-14 17:50:42', '2012-02-14 17:50:42');

-- --------------------------------------------------------

--
-- Table structure for table `shoppr_cityshops`
--

CREATE TABLE `shoppr_cityshops` (
  `shopproducts_entity_city_id` int(11) NOT NULL,
  `shopproducts_entity_shop_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppr_cityshops`
--

INSERT INTO `shoppr_cityshops` (`shopproducts_entity_city_id`, `shopproducts_entity_shop_id`) VALUES
(6, 6),
(7, 7);

-- --------------------------------------------------------

--
-- Table structure for table `shoppr_product`
--

CREATE TABLE `shoppr_product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `imageMeta` longtext NOT NULL COMMENT '(DC2Type:array)',
  `image` varchar(255) NOT NULL,
  `createdUserId` int(11) NOT NULL,
  `updatedUserId` int(11) NOT NULL,
  `createdDate` datetime NOT NULL,
  `updatedDate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppr_product`
--

INSERT INTO `shoppr_product` (`id`, `product_name`, `description`, `price`, `imageMeta`, `image`, `createdUserId`, `updatedUserId`, `createdDate`, `updatedDate`) VALUES
(6, 'prod1', 'test desc..', 'DKK 1.100,00', 'a:6:{s:9:\"extension\";s:3:\"jpg\";s:4:\"size\";i:76647;s:7:\"isImage\";b:1;s:5:\"width\";i:800;s:6:\"height\";i:573;s:6:\"format\";s:9:\"landscape\";}', 'mizuno2.jpg', 3, 3, '2012-02-14 17:31:39', '2012-02-14 17:31:39'),
(7, 'prod2', 'good prod', 'DKK 900,00', 'a:6:{s:9:\"extension\";s:3:\"jpg\";s:4:\"size\";i:19401;s:7:\"isImage\";b:1;s:5:\"width\";i:378;s:6:\"height\";i:231;s:6:\"format\";s:9:\"landscape\";}', 'saucony2.jpg', 3, 3, '2012-02-14 17:47:41', '2012-02-14 17:47:41'),
(8, 'prod3', 'asd', 'DKK 1.100,0', 'a:6:{s:9:\"extension\";s:3:\"jpg\";s:4:\"size\";i:65885;s:7:\"isImage\";b:1;s:5:\"width\";i:800;s:6:\"height\";i:573;s:6:\"format\";s:9:\"landscape\";}', 'wave lightning men and women2.jpg', 3, 3, '2012-02-14 17:49:36', '2012-02-14 17:49:36'),
(9, 'testprod', 'testinggg', 'DKK 500,00', 'a:6:{s:9:\"extension\";s:3:\"jpg\";s:4:\"size\";i:9438;s:7:\"isImage\";b:1;s:5:\"width\";i:228;s:6:\"height\";i:228;s:6:\"format\";s:6:\"square\";}', 'faas_500_men-roed2.jpg', 3, 3, '2012-02-14 17:51:37', '2012-02-14 17:51:37'),
(10, 'testprod2', 'sdfsdfsdf', 'DKK 500,00', 'a:6:{s:9:\"extension\";s:3:\"jpg\";s:4:\"size\";i:28461;s:7:\"isImage\";b:1;s:5:\"width\";i:400;s:6:\"height\";i:280;s:6:\"format\";s:9:\"landscape\";}', '443812_101_3.jpg', 3, 3, '2012-02-14 17:53:16', '2012-02-14 17:53:16');

-- --------------------------------------------------------

--
-- Table structure for table `shoppr_shop`
--

CREATE TABLE `shoppr_shop` (
  `id` int(11) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `address` varchar(2000) NOT NULL,
  `createdUserId` int(11) NOT NULL,
  `updatedUserId` int(11) NOT NULL,
  `createdDate` datetime NOT NULL,
  `updatedDate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppr_shop`
--

INSERT INTO `shoppr_shop` (`id`, `shop_name`, `address`, `createdUserId`, `updatedUserId`, `createdDate`, `updatedDate`) VALUES
(1, 'Shop shop_name 1', 'Shop address 1', 3, 3, '2012-02-14 17:30:29', '2012-02-14 17:30:29'),
(2, 'Shop shop_name 2', 'Shop address 2', 3, 3, '2012-02-14 17:30:29', '2012-02-14 17:30:29'),
(3, 'Shop shop_name 3', 'Shop address 3', 3, 3, '2012-02-14 17:30:29', '2012-02-14 17:30:29'),
(4, 'Shop shop_name 4', 'Shop address 4', 3, 3, '2012-02-14 17:30:29', '2012-02-14 17:30:29'),
(5, 'Shop shop_name 5', 'Shop address 5', 3, 3, '2012-02-14 17:30:29', '2012-02-14 17:30:29'),
(6, 'KeepRunning', 'addresssss', 3, 3, '2012-02-14 17:31:11', '2012-02-14 17:31:11'),
(7, 'shopNewYork', 'sfsfsdf', 3, 3, '2012-02-14 17:51:06', '2012-02-14 17:51:06');

-- --------------------------------------------------------

--
-- Table structure for table `shoppr_shopproducts`
--

CREATE TABLE `shoppr_shopproducts` (
  `shopproducts_entity_shop_id` int(11) NOT NULL,
  `shopproducts_entity_product_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `shoppr_shopproducts`
--

INSERT INTO `shoppr_shopproducts` (`shopproducts_entity_shop_id`, `shopproducts_entity_product_id`) VALUES
(6, 6),
(6, 7),
(6, 8),
(7, 9),
(7, 10);

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `displayname` varchar(64) NOT NULL,
  `description` varchar(255) NOT NULL,
  `directory` varchar(64) NOT NULL,
  `version` varchar(10) NOT NULL DEFAULT '0',
  `contact` varchar(255) NOT NULL,
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `user` tinyint(4) NOT NULL DEFAULT '0',
  `system` tinyint(4) NOT NULL DEFAULT '0',
  `state` tinyint(4) NOT NULL DEFAULT '0',
  `xhtml` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `name`, `type`, `displayname`, `description`, `directory`, `version`, `contact`, `admin`, `user`, `system`, `state`, `xhtml`) VALUES
(1, 'Andreas08', 3, 'Andreas08', 'Based on the theme Andreas08 by Andreas Viklund and extended for Zikula with the CSS Framework \'fluid960gs\'.', 'Andreas08', '2.0', '', 1, 1, 0, 1, 1),
(2, 'Atom', 3, 'Atom', 'The Atom theme is an auxiliary theme specially designed for rendering pages in Atom mark-up.', 'Atom', '1.0', '', 0, 0, 1, 1, 0),
(3, 'Printer', 3, 'Printer', 'The Printer theme is an auxiliary theme designed specially for outputting pages in a printer-friendly format.', 'Printer', '2.0', '', 0, 0, 1, 1, 1),
(4, 'RSS', 3, 'RSS', 'The RSS theme is an auxiliary theme designed specially for outputting pages as an RSS feed.', 'RSS', '1.0', '', 0, 0, 1, 1, 0),
(5, 'SeaBreeze', 3, 'SeaBreeze', 'The SeaBreeze theme is a browser-oriented theme, and was updated for the release of Zikula 1.0, with revised colours and new graphics.', 'SeaBreeze', '3.2', '', 0, 1, 0, 1, 1),
(6, 'KeepRunning', 3, 'KeepRunning', 'KeepRunning theme for zikula.', 'KeepRunning', '1.1', 'http://dbrucas.povpromotions.com, http://www.markwest.me.uk, http://www.andreasviklund.com', 1, 1, 0, 1, 1),
(7, 'ACTA-IT', 3, 'ACTA-IT', 'The ACTA-ITtheme is a very good template for light CSS-compatible browser-oriented themes.', 'ACTA-IT', '1.1', 'http://dbrucas.povpromotions.com, http://www.markwest.me.uk, http://www.andreasviklund.com', 1, 1, 0, 1, 1),
(8, 'Mobile', 3, 'Mobile', 'The mobile theme is an auxiliary theme designed specially for outputting pages in a mobile-friendly format.', 'Mobile', '1.0', '', 0, 0, 1, 1, 1),
(9, 'ZAndreas08', 3, 'ZAndreas08', 'Based on the theme Andreas08 by Andreas Viklund and extended for Zikula with the CSS Framework \'fluid960gs\'.', 'ZAndreas08', '2.0', '', 0, 1, 0, 1, 1),
(10, 'ZSeaBreeze', 3, 'ZSeaBreeze', 'The ZSeaBreeze theme is a browser-oriented theme made specific for ZSELEX.', 'ZSeaBreeze', '3.2.1', '', 0, 1, 0, 1, 1),
(11, 'ZAtom', 3, 'ZAtom', 'The ZAtom theme is an auxiliary theme specially designed for rendering pages in Atom mark-up for ZSELEX.', 'ZAtom', '1.0.1', '', 0, 0, 1, 1, 0),
(12, 'ZMobile', 3, 'ZMobile', 'The ZMobile theme is an auxiliary theme designed specially for outputting pages in a mobile-friendly format for ZSELEX.', 'ZMobile', '1.0.1', '', 0, 0, 1, 1, 1),
(15, 'ZLimelight', 3, 'ZLimelight', 'Limelight Open Designs template for ZSELEX', 'ZLimelight', '3.1', 'http://www.markwest.me.uk, http://www.mitchinson.net/, http://acta-it.dk', 0, 1, 0, 1, 1),
(22, 'ZWine', 3, 'ZWine', 'ZWine for ZSELEX', 'ZWine', '2.0.1', 'http://www.markwest.me.uk, http://www.mitchinson.net/, http://acta-it.dk', 0, 1, 0, 1, 1),
(17, 'ZLightBiz', 3, 'ZLightBiz', 'ZLightBiz', 'ZLightBiz', '2.0.1', 'http://www.markwest.me.uk, http://www.free-css-templates.com, http://acta-it.dk', 0, 1, 0, 1, 1),
(18, 'ZGreenway', 3, 'ZGreenway', 'ZGreenway template for ZSELEX', 'ZGreenway', '2.0.1', 'http://www.markwest.me.uk, http://www.free-css-templates.com, htp://acta-it.dk', 0, 1, 0, 1, 1),
(19, 'ZFruitopia', 3, 'ZFruitopia', 'ZFruitopia OWD template for ZSELEX', 'ZFruitopia', '2.0.1', 'http://www.markwest.me.uk, http://DesignsByDarren.com/, http://acta-it.dk', 0, 1, 0, 1, 1),
(20, 'ZNaturalGloom', 3, 'ZNaturalGloom', 'ZNatural Gloom open source template for ZSELEX', 'ZNaturalGloom', '2.0.1', 'http://www.zikulathemes.com, http://www.arcsin.se, http://acta-it.dk', 0, 1, 0, 1, 1),
(21, 'ZSunrise', 3, 'ZSunrise', 'ZSunrise template for ZSELEX', 'ZSunrise', '2.0.1', 'http://www.markwest.me.uk, http://www.free-css-templates.com, http://acta-it.dk', 0, 1, 0, 1, 1),
(23, 'ZOrangeJuice', 3, 'ZOrangeJuice', 'ZOrangeJuice OWD template for ZSELEX', 'ZOrangeJuice', '2.0.1', 'http://www.markwest.me.uk, http://www.mitchinson.net, http://acta-it.dk', 0, 1, 0, 1, 1),
(25, 'ZLGBlue', 3, 'ZLGBlue', 'ZLGBlue template for ZSELEX', 'ZLGBlue', '2.0.1', 'http://www.markwest.me.uk, http://www.free-css-templates.com, http://acta-it.dk', 0, 1, 0, 1, 1),
(27, 'decorative', 3, 'decorative', 'decorative for Zikula', 'decorative', '0', 'http://www.cmods-dev.de or http://www.postnuke-themes.de', 0, 1, 0, 1, 1),
(28, 'CityPilot', 3, 'CityPilot', 'CityPilot theme for zikula.', 'CityPilot', '1.1', 'kim', 1, 1, 0, 1, 1),
(29, 'CityPilotSkin1', 3, 'CityPilotSkin1', 'CityPilot Skin1 theme for zikula.', 'CityPilotSkin1', '1.1', 'kim', 1, 1, 0, 1, 1),
(30, 'CityPilotSkin2', 3, 'CityPilotSkin2', 'CityPilot Skin2 theme for zikula.', 'CityPilotSkin2', '1.1', 'kim', 1, 1, 0, 1, 1),
(31, 'CityPilotSkin3', 3, 'CityPilotSkin3', 'CityPilot Skin3 theme for zikula.', 'CityPilotSkin3', '1.1', 'kim', 1, 1, 0, 1, 1),
(32, 'ZveloTheme', 3, 'ZveloTheme', 'ZveloTheme for Zikula.', 'ZveloTheme', '1.0', '', 1, 1, 0, 1, 1),
(33, 'CityPilotResponsive', 3, 'CityPilotResponsive', 'CityPilotResponsive theme for zikula.', 'CityPilotResponsive', '1.1', 'kim', 1, 1, 0, 1, 1),
(41, 'CityPilotShop', 3, 'CityPilotShop', 'CityPilotShop theme for zikula.', 'CityPilotShop', '1.1', 'kim', 1, 1, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `twitter_login`
--

CREATE TABLE `twitter_login` (
  `id` int(11) NOT NULL,
  `twitter_id` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `twitter_login`
--

INSERT INTO `twitter_login` (`id`, `twitter_id`, `user_id`, `email`, `status`) VALUES
(12, '1394678070', 0, 'kimenemark@gmail.com', 0),
(14, '2436626810', 108, 'ken@citypilot.dk', 1),
(20, '87414339', 3, 'sharazkhanz@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_property`
--

CREATE TABLE `user_property` (
  `id` int(11) NOT NULL,
  `label` varchar(255) NOT NULL,
  `dtype` int(11) NOT NULL DEFAULT '0',
  `modname` varchar(64) NOT NULL,
  `weight` int(11) NOT NULL DEFAULT '0',
  `validation` longtext,
  `attributename` varchar(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_property`
--

INSERT INTO `user_property` (`id`, `label`, `dtype`, `modname`, `weight`, `validation`, `attributename`) VALUES
(1, '_UREALNAME', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'realname'),
(2, '_UFAKEMAIL', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'publicemail'),
(3, '_YOURHOMEPAGE', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'url'),
(4, '_TIMEZONEOFFSET', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:4;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'tzoffset'),
(5, '_YOURAVATAR', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:4;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'avatar'),
(6, '_YICQ', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'icq'),
(7, '_YAIM', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'aim'),
(8, '_YYIM', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'yim'),
(9, '_YMSNM', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'msnm'),
(10, '_YLOCATION', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'city'),
(11, '_YOCCUPATION', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:0;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'occupation'),
(12, '_SIGNATURE', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:1;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'signature'),
(13, '_EXTRAINFO', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:1;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'extrainfo'),
(14, '_YINTERESTS', 1, '', 0, 'a:5:{s:8:\"required\";i:0;s:6:\"viewby\";i:0;s:11:\"displaytype\";i:1;s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'interests'),
(16, 'Shipping Address', 1, '', 6, 'a:5:{s:8:\"required\";s:1:\"0\";s:6:\"viewby\";s:1:\"0\";s:11:\"displaytype\";s:1:\"1\";s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:27:\"Enter your shipping address\";}', 'shipping address'),
(17, '_FIRSTNAME', 1, '', 1, 'a:5:{s:8:\"required\";s:1:\"0\";s:6:\"viewby\";s:1:\"0\";s:11:\"displaytype\";s:1:\"0\";s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'first_name'),
(18, 'Last Name', 1, '', 2, 'a:5:{s:8:\"required\";s:1:\"0\";s:6:\"viewby\";s:1:\"0\";s:11:\"displaytype\";s:1:\"0\";s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'last_name'),
(19, 'Country', 1, '', 4, 'a:5:{s:8:\"required\";s:1:\"0\";s:6:\"viewby\";s:1:\"0\";s:11:\"displaytype\";s:1:\"0\";s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'user_country'),
(20, 'State', 1, '', 3, 'a:5:{s:8:\"required\";s:1:\"0\";s:6:\"viewby\";s:1:\"0\";s:11:\"displaytype\";s:1:\"0\";s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'user_state'),
(21, 'Mobile', 1, '', 5, 'a:5:{s:8:\"required\";s:1:\"0\";s:6:\"viewby\";s:1:\"0\";s:11:\"displaytype\";s:1:\"0\";s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'user_mobile'),
(23, 'zip', 1, '', 7, 'a:5:{s:8:\"required\";s:1:\"0\";s:6:\"viewby\";s:1:\"0\";s:11:\"displaytype\";s:1:\"0\";s:11:\"listoptions\";s:0:\"\";s:4:\"note\";s:0:\"\";}', 'zip');

-- --------------------------------------------------------

--
-- Table structure for table `userblocks`
--

CREATE TABLE `userblocks` (
  `uid` int(11) NOT NULL DEFAULT '0',
  `bid` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `last_update` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `uname` varchar(25) NOT NULL,
  `email` varchar(60) NOT NULL,
  `pass` varchar(138) NOT NULL,
  `passreminder` varchar(255) NOT NULL,
  `activated` smallint(6) NOT NULL DEFAULT '0',
  `approved_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `approved_by` int(11) NOT NULL DEFAULT '0',
  `user_regdate` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lastlogin` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `theme` varchar(255) NOT NULL,
  `ublockon` tinyint(4) NOT NULL DEFAULT '0',
  `ublock` longtext NOT NULL,
  `tz` varchar(30) NOT NULL,
  `locale` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `uname`, `email`, `pass`, `passreminder`, `activated`, `approved_date`, `approved_by`, `user_regdate`, `lastlogin`, `theme`, `ublockon`, `ublock`, `tz`, `locale`) VALUES
(1, 'guest', '', '', '', 1, '1970-01-01 00:00:00', 0, '1970-01-01 00:00:00', '1970-01-01 00:00:00', '', 0, '', '', ''),
(2, 'admin', 'kim@acta-it.dk', '8$g(j]I$accef45c4506552aee2773bcee723dc8fed74b55a6cdc3be4404ea587de35ca9', 'my passwd', 1, '2012-02-13 11:54:03', 2, '2012-02-13 11:54:08', '2017-01-11 12:20:48', '', 0, '', '', ''),
(3, 'r2', 'sharazkhanz@gmail.com', '8$VqCS-$7cec2aa709f26c9e35198c47060669efbaef158d63daf815bcf0a42f415b1267', 'test', 1, '2012-02-13 11:57:21', 2, '2012-02-13 11:57:21', '2018-02-03 07:17:18', '', 0, '', '', ''),
(22, 'testowner', 'testowner@test.com', '8$A7Z7n$efa541c88cb8b80005c573aa16cfa60b23a7ba61033fc123c3e20b92153dbd7c', '(Password provided by site administrator)', 1, '2012-11-19 13:04:17', 3, '2012-11-19 13:04:17', '2013-09-19 09:34:23', '', 0, '', '', ''),
(9, 'kimenemark', 'kim@itvision.dk', '8$pumQH$3774f93b85dbf04e5e3f8ec194d4e4f9433cfae80f8c209fc7337a64b70fc916', 'kk', 1, '2012-10-05 07:12:23', 5, '2012-10-05 07:12:23', '2014-04-01 15:31:27', '', 0, '', '', ''),
(99, 'keeprunning', 'keep@test.com', '8$D#MXl$8f3d86adad631f22ddf7e661996d6a5e357ec955dd0d4612811d2732729fa0b7', '(Password provided by site administrator)', 1, '2014-04-23 08:34:15', 3, '2014-04-23 08:34:15', '2014-04-28 13:07:44', '', 0, '', '', ''),
(21, 'kim', 'kim@acta-it.dk', '8$))PYP$e307dd23113564ce650b4c08a38ce33b57412e408e22f8e3e51ea323a798f80b', '(Password provided by site administrator)', 1, '2012-10-24 05:25:53', 2, '2012-10-24 05:25:53', '2015-10-22 07:48:51', '', 0, '', '', ''),
(24, 'testowner1', 'testowner1@test.com', '8$SLXT|$4ed289502f043a42725bf500fa8e652c6c14118749664e25958e17bd9936645c', '(Password provided by site administrator)', 1, '2012-12-05 15:10:35', 3, '2012-12-05 15:10:35', '2015-10-22 07:47:09', '', 0, '', '', ''),
(73, 'kimgmail', 'kimenemark@gmail.com', '8$wQ+WI$9db0d4848b7a2adda8018d33380ae42a2c4c4d5b056e2248832971411e4beb17', '(Password provided by site administrator)', 1, '2014-01-22 07:11:59', 2, '2014-01-22 07:11:59', '2014-05-07 15:30:16', '', 0, '', '', ''),
(30, 'knude', 'knude@knude.net', 'NO_USERS_AUTHENTICATION', 'Account created with Facebook', 1, '2013-04-16 16:36:21', 30, '2013-04-16 16:36:21', '2013-04-17 14:54:30', '', 0, '', '', ''),
(55, 'olemiami', 'km@itvision.dk', '8$sT(gH$ae31a0187cb81a70faaf2e637598ec41699bc69c56596edce13f59877014237a', '(Password provided by site administrator)', 1, '2013-08-19 08:10:33', 2, '2013-08-19 08:10:33', '2013-12-18 08:40:21', '', 0, '', '', ''),
(56, 'bison', 'km@itvision.dk', '8$bZ9CD$616c7be14fbba7380f3fd396946a24db22cc0b3d084a4940b445cb2315cccdcb', '(Password provided by site administrator)', 1, '2013-08-20 08:59:46', 2, '2013-08-20 08:59:46', '2013-09-17 17:15:23', '', 0, '', '', ''),
(57, 'rasmuskeep', 'rasmus@hesport.dk', '8$%yLwZ$367779243c8c70534aba27a207d7c31d1656395778d66254f4b89b684dffb7da', 'minkode', 1, '2013-08-26 08:53:35', 2, '2013-08-26 08:53:35', '2013-08-26 09:02:18', '', 0, '', '', ''),
(58, 'jytte', 'kim@inethotel.dk', '8$=^5kg$a569d4c12c74e0b4c5be170cc72f2da1693cb8ea03c5df629689e1a7f48ff3a7', '(Password provided by site administrator)', 1, '2013-09-05 10:38:06', 2, '2013-09-05 10:38:06', '1970-01-01 00:00:00', '', 0, '', '', ''),
(59, 'uso', 'km@itvision.dk', '8$CJq12$46225f7f20f301ad88474b34ef5ca595682bc8372ac9346512953acc83cc0402', '(Password provided by site administrator)', 1, '2013-09-11 14:55:10', 2, '2013-09-11 14:55:10', '2013-11-11 06:03:56', '', 0, '', '', ''),
(60, 'kopkande', 'km@itvision.dk', '8$M3{Ri$cbdd415a3ac6b5c3a1b9d4e81735eb444d6c6f9c6a93ff9d4acc315e2047004c', '(Password provided by site administrator)', 1, '2013-09-11 15:07:43', 2, '2013-09-11 15:07:43', '1970-01-01 00:00:00', '', 0, '', '', ''),
(61, 'bianco', 'km@itvision.dk', '8$MiCBg$eed8e320632cce95656b52b107dac87c7f8dd4f7f46f931bef4760a6f6b2a749', '(Password provided by site administrator)', 1, '2013-09-16 18:16:35', 2, '2013-09-16 18:16:35', '2013-09-16 18:17:22', '', 0, '', '', ''),
(62, 'cykelkaj', 'km@itvision.dk', '8$*jNil$5e4ca6210ed2f7360b5e3e7ecf0715854fe1b3a9579badd47b008cc785a5726d', '(Password provided by site administrator)', 1, '2013-09-17 06:25:18', 2, '2013-09-17 06:25:18', '2013-09-17 06:27:48', '', 0, '', '', ''),
(63, 'profil', 'km@itvision.dk', '8$bjAZl$b2b8b86d2ff53405a0dd8974097357967ca8afdc90dc11f76f128fa2c77fed81', '(Password provided by site administrator)', 1, '2013-09-17 06:50:07', 2, '2013-09-17 06:50:07', '2013-10-10 07:54:21', '', 0, '', '', ''),
(64, 'flair', 'km@itvision.dk', '8$@@zsO$2e659c831d919c38e8112bfa4212b46299902ee100f49b7f56f18c4273705950', '(Password provided by site administrator)', 1, '2013-10-10 05:47:59', 2, '2013-10-10 05:47:59', '2013-10-10 05:51:35', '', 0, '', '', ''),
(65, 'kimene', 'service@itvision.dk', '8$~3+AK$9fb33fe775dbd474ece600e815461735440079adf06ee316b22420d237646370', '(Password provided by site administrator)', 1, '2013-11-09 14:15:16', 2, '2013-11-09 14:15:16', '2013-12-17 06:49:54', '', 0, '', '', ''),
(69, 'torbenhansen', 'torben@hesport.dk', '8$Z02AA$f0cf48aec1c1523d03a1064538ec61de955baf451a09855a1c3d803957b73437', '(Password provided by site administrator)', 1, '2013-11-18 12:40:11', 2, '2013-11-18 12:40:11', '2013-12-01 21:36:24', '', 0, '', '', ''),
(97, 'kime', 'info@inethotel.dk', '8$bdNSZ$30c1e300ad2b307d1fa6ad3f192cef959ff30b3c3d87b40853e58c866d5b6eb5', '(Password provided by site administrator)', 1, '2014-04-17 13:38:59', 2, '2014-04-17 13:38:59', '1970-01-01 00:00:00', '', 0, '', '', ''),
(108, 'ken', 'ken@citypilot.dk', 'NO_USERS_AUTHENTICATION', 'Account created with Twitter', 1, '2014-05-07 15:28:02', 108, '2014-05-07 15:28:02', '2014-05-08 17:33:24', '', 0, '', '', ''),
(116, 'lukasenemark', 'boss@lukaschat.dk', '8$sz{m6$1e2569b18e370d711aced311f551267bb96ea3ffea68ca22bda526ff97323bb6', '(Password provided by site administrator)', 1, '2014-05-08 10:10:56', 2, '2014-05-08 10:10:56', '2014-05-08 10:34:41', '', 0, '', '', ''),
(125, 'kimenemark2', 'salg@acta-it.dk', '8$BSEHu$89075a43b1cb72e54de31a2e85bdf939a73067a0eb57d6a8dea0c8949fe048ca', '(Password provided by site administrator)', 1, '2014-08-04 07:25:28', 2, '2014-08-04 07:25:28', '1970-01-01 00:00:00', '', 0, '', '', ''),
(135, 'tijosfx', 'tijosfx@gmail.com', '8$KJFZq$a093b0127495b7f2596a3eb2899ee27be2af41b77da2dc58d4e241d30cac64b8', 'A20', 1, '2016-01-08 17:08:05', 135, '2016-01-08 17:08:05', '2016-09-19 19:58:53', '', 0, '', '', ''),
(136, 'owner001', 'owner001@test.com', '8$Yq{zC$fa8ee1316c08e5b47582d83c9eb90499b56fda07c947389b9273ce1f58eb302b', '(Password provided by site administrator)', 1, '2016-02-10 16:51:39', 3, '2016-02-10 16:51:39', '1970-01-01 00:00:00', '', 0, '', '', ''),
(137, 'designer_tak', 'designer_tak@yahoo.com', 'NO_USERS_AUTHENTICATION', 'Account created with Facebook', 1, '2016-03-21 17:29:55', 137, '2016-03-21 17:29:55', '2016-03-21 17:46:32', '', 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users_verifychg`
--

CREATE TABLE `users_verifychg` (
  `id` int(11) NOT NULL,
  `changetype` tinyint(4) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL DEFAULT '0',
  `newemail` varchar(60) NOT NULL,
  `verifycode` varchar(138) NOT NULL,
  `created_dt` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_verifychg`
--

INSERT INTO `users_verifychg` (`id`, `changetype`, `uid`, `newemail`, `verifycode`, `created_dt`) VALUES
(54, 1, 3, '', '8$w7B78$332aad0f2944485548ab79939c3c6a789aa5b1626ac5332aef5093566da150a3', '2014-06-25 06:59:06'),
(57, 1, 2, '', '8$24a2a$c9265f3c0291e98e69545405cc4a11f2a70713629396fc1cdf67c307e9d7d3b5', '2015-12-05 17:22:48'),
(59, 1, 135, '', '8$lY9S%$644443cbfc22ba395c891701a925a8fb7eefb58d54aeaf3d6d975eec1b43236f', '2016-09-19 17:51:37');

-- --------------------------------------------------------

--
-- Table structure for table `workflows`
--

CREATE TABLE `workflows` (
  `id` int(11) NOT NULL,
  `metaid` int(11) NOT NULL DEFAULT '0',
  `module` varchar(255) NOT NULL,
  `schemaname` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `type` smallint(6) NOT NULL DEFAULT '1',
  `obj_table` varchar(40) NOT NULL,
  `obj_idcolumn` varchar(40) NOT NULL,
  `obj_id` int(11) NOT NULL DEFAULT '0',
  `busy` int(11) NOT NULL DEFAULT '0',
  `debug` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `workflows`
--

INSERT INTO `workflows` (`id`, `metaid`, `module`, `schemaname`, `state`, `type`, `obj_table`, `obj_idcolumn`, `obj_id`, `busy`, `debug`) VALUES
(1, 0, 'Clip', 'standard', 'approved', 1, 'clip_pubdata1', 'id', 1, 0, ''),
(2, 0, 'Clip', 'none', 'approved', 1, 'clip_pubdata2', 'id', 1, 0, ''),
(3, 0, 'Clip', 'none', 'approved', 1, 'clip_pubdata2', 'id', 2, 0, ''),
(4, 0, 'Clip', 'standard', 'approved', 1, 'clip_pubdata3', 'id', 1, 0, NULL),
(5, 0, 'Clip', 'standard', 'approved', 1, 'clip_pubdata3', 'id', 2, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `zmap`
--

CREATE TABLE `zmap` (
  `bid` bigint(20) UNSIGNED NOT NULL,
  `cid` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zmap_projects`
--

CREATE TABLE `zmap_projects` (
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zmap_projects`
--

INSERT INTO `zmap_projects` (`pid`, `cid`, `name`, `description`) VALUES
(1, 3, 'R2Proj1', 'testing r2....'),
(2, 2, 'DOBtest1', 'Dette er en test udarbejdet af Kim'),
(9, 1, 'sharaz_test', 'test'),
(5, 1, 'DOBtest', 'DOB test'),
(7, 1, 'FredericiaMidtby', ''),
(8, 1, 'PjedstedTest', 'Test i Pjedsted'),
(13, 1, 'FredericiaVold', 'Voldområdet'),
(14, 1, 'sharaz_test_1', 'sfsadfasdfs'),
(59, 1, 'DOBtest2', 'DOB test 2'),
(83, 4, 'test KIM', 'Kim'),
(84, 2, 'r2_test', 'sdafsadf'),
(85, 4, 'r2_test', 'test...'),
(86, 6, 'DOBtesttest', 'DOB\'s test test'),
(87, 2, 'r2_test1', 'sdafsadf'),
(89, 2, 'test3', 'test3'),
(90, 2, 'testr2', 'sadfsadfdsaf'),
(91, 2, 'test now', 'adssfsf');

-- --------------------------------------------------------

--
-- Table structure for table `zmap_roadmap`
--

CREATE TABLE `zmap_roadmap` (
  `rid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `start` text NOT NULL,
  `startdescription` text NOT NULL,
  `end` text NOT NULL,
  `enddescription` text NOT NULL,
  `start_lattitude` float(10,6) NOT NULL,
  `start_longitude` float(10,6) NOT NULL,
  `end_lattitude` float(10,6) NOT NULL,
  `end_longitude` float(10,6) NOT NULL,
  `waypoints` text NOT NULL,
  `length` varchar(50) NOT NULL,
  `width` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `cid` int(11) NOT NULL,
  `pid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zmap_roadmap`
--

INSERT INTO `zmap_roadmap` (`rid`, `name`, `description`, `start`, `startdescription`, `end`, `enddescription`, `start_lattitude`, `start_longitude`, `end_lattitude`, `end_longitude`, `waypoints`, `length`, `width`, `area`, `cid`, `pid`) VALUES
(3, 'Østergade-Århus', 'Østergade 1 til ca. Østergade 30 i Århus', 'Østergade 1, Aarhus, Danmark', 'Østergade 1', 'Østergade 30, Aarhus, Danmark', 'Østergade 30', 56.154449, 10.204830, 56.152161, 10.208180, '(56.15288959999999, 10.206499399999984)', '', '', '', 2, 2),
(4, 'Søndergade-Århus', 'Søndergade 10 til ca. Søndergade 100 i Århus', 'Søndergade 10, Aarhus, Danmark', 'Søndergade 10', 'Søndergade 100, Aarhus, Danmark', 'Søndergade 100', 56.155182, 10.207420, 56.153160, 10.205360, '', '', '', '', 2, 2),
(7, 'Østergade-Århus', 'Østergade 1 til ca. Østergade 30 i Århus', 'Østergade 1, Aarhus, Danmark', 'Østergade 1', 'Østergade 30, Aarhus, Danmark', 'Østergade 30', 56.154251, 10.200040, 56.154598, 10.212280, '', '', '', '', 1, 5),
(27, 'Elbosvinget', 'EB', 'Elbosvinget 1, Fredericia, Danmark', 'EB1', 'Elbosvinget 11, Fredericia, Danmark', 'EB11', 55.602390, 9.652950, 55.601780, 9.653940, '', '', '', '', 1, 8),
(16, 'Prinsessegade', 'Prinsessegade 11 til ca. Prinsessegade 100', 'Prinsessegade 11D, Fredericia, Danmark', 'P11', 'Prinsessegade 100, Fredericia, Danmark', 'P100', 55.564781, 9.755560, 55.559700, 9.756800, '(55.5630763, 9.759065299999975)', '', '', '', 1, 7),
(9, 'søndergade-Århus', 'test TEST', 's%C3%B8ndergade+10%2C+aarhus', 'sg10', 'S%C3%B8ndergade+100%2C+aarhus', 'sg100', 56.151360, 10.213410, 56.152260, 10.205240, '(56.1529836, 10.213943800000038),(56.1526108, 10.211530700000026),(56.1511766, 10.211768399999983)', '', '', '', 1, 5),
(23, 'kochi-kozhikode', 'dgdsfg', 'Cochin%2C+Kerala%2C+India', 'dsfgd', 'Calicut+Railway+Station%2C+Kuttichira%2C+Kozhikode%2C+Kerala%2C+India', 'fgdfsg', 10.223600, 76.702660, 11.260120, 76.225990, '(10.952003, 76.42105790000005)', '', '', '', 1, 9),
(17, 'Elboparken1', 'Elboparken tekst', 'Elboparken+1%2C+Fredericia%2C+Danmark', 'E1', 'Elboparken+50%2C+Fredericia%2C+Danmark', 'E50', 55.600479, 9.661760, 55.601490, 9.655170, '', '', '', '', 1, 8),
(131, 'søndergade-Århus2', 'test TEST', 's%C3%B8ndergade+10%2C+aarhus', 'sg10', 'S%C3%B8ndergade+100%2C+aarhus', 'sg100', 56.151360, 10.213410, 56.152260, 10.205240, '(56.1529836, 10.213943800000038),(56.1526108, 10.211530700000026),(56.1511766, 10.211768399999983)', '', '', '', 1, 59),
(25, 'devakottai', '', 'Devakottai, Tamil Nadu, India', '', 'Karunagappally, Kerala, India', '', 11.011660, 77.383072, 9.971150, 77.427231, '(10.7745424, 77.45596290000003),(10.0412976, 76.97486070000002),(9.8053089, 77.04178690000003),(9.606848399999999, 77.0494473)', '', '', '', 1, 9),
(41, 'punalur', '', 'Punalur, Kerala, India', '', 'Tenkasi, Tamil Nadu, India', '', 8.878930, 76.584862, 8.078600, 77.531693, '(8.7789813, 76.88005509999994)', '', '', '', 1, 9),
(29, 'Stationsvej', 'SV', 'Stationsvej 17, Fredericia, Danmark', 'SV17', 'Stationsvej 45, Fredericia, Danmark', 'SV45', 55.602459, 9.658140, 55.602390, 9.652550, '', '', '', '', 1, 8),
(130, 'Østergade-Århus2', 'Østergade 1 til ca. Østergade 30 i Århus', '%C3%98stergade+1%2C+Aarhus%2C+Danmark', 'Østergade 1', '%C3%98stergade+30%2C+Aarhus%2C+Danmark', 'Østergade 30', 56.154449, 10.204830, 56.153858, 10.207740, '', '', '', '', 1, 59),
(40, 'test2', '', '', '', '', '', 55.565639, 9.757770, 55.565609, 9.760550, '', '', '', '', 1, 13),
(42, 'kochi-kozhikode', 'dgdsfg', 'Cochin%2C+Kerala%2C+India', 'dsfgd', 'Calicut+Railway+Station%2C+Kuttichira%2C+Kozhikode%2C+Kerala%2C+India', 'fgdfsg', 9.931280, 76.267311, 11.246380, 75.780151, '(10.952003, 76.42105790000005)', '', '', '', 1, 14),
(43, 'punalur2', '', 'Punalur%2C+Kerala%2C+India', '', 'Tenkasi%2C+Tamil+Nadu%2C+India', '', 9.016280, 76.801758, 8.353990, 77.874969, '(8.829279099999999, 76.99664529999995),(8.6615754, 77.37005709999994)', '', '', '', 1, 14),
(44, 'devakottai', '', 'Devakottai, Tamil Nadu, India', '', 'Karunagappally, Kerala, India', '', 11.011660, 77.383072, 9.464340, 77.153992, '(10.7745424, 77.45596290000003),(10.9963312, 78.99687589999996),(10.3035204, 77.76234120000004),(10.5299511, 77.02797439999995),(10.0412976, 76.97486070000002),(9.8053089, 77.04178690000003),(9.606848399999999, 77.0494473)', '', '', '', 1, 14),
(45, 'punalur', '', 'Punalur, Kerala, India', '', 'Tenkasi, Tamil Nadu, India', '', 8.878930, 76.584862, 8.078600, 77.531693, '(8.7789813, 76.88005509999994),(8.5484586, 77.06368240000006),(8.3177428, 77.06577960000004),(8.393136799999999, 77.41344449999997)', '', '', '', 1, 14),
(172, 'madu-dev', '', 'Madurai, Tamil Nadu, India', 'test', 'Devakottai, Tamil Nadu, India', 'test..', 9.361990, 78.833847, 9.945520, 78.823463, '', '', '', '', 1, 9),
(179, 'punalur2', '', 'Punalur%2C+Kerala%2C+India', '', 'Tenkasi%2C+Tamil+Nadu%2C+India', '', 9.016280, 76.801758, 8.353990, 77.874969, '(8.829279099999999, 76.99664529999995),(8.6615754, 77.37005709999994)', '', '', '', 1, 9),
(180, 'test', '', 'Cochin, Kerala, India', '', 'Calicut, Kerala, India', '', 9.931276, 76.267311, 11.258750, 75.780418, '', '', '', '', 2, 84),
(181, 'cochi-calicut', '', 'Cochin, Kerala, India', '', 'Calicut, Kerala, India', '', 9.931280, 76.267311, 11.258750, 75.780411, '', '', '', '', 4, 85),
(182, 'tvm-mav', '', 'Trivandrum, Kerala, India', '', 'Mavelikkara, Kerala, India', '', 8.487430, 76.948570, 9.386870, 76.719673, '(9.0603179, 76.98341400000004)', '', '', '', 4, 85),
(183, 'Rosenkrantzgade', '', 'Rosenkrantzgade 4, Aarhus, Danmark', 'rg1', 'Rosenkrantzgade 6, Aarhus, Danmark', 'rg2', 56.151821, 10.207880, 56.152271, 10.205080, '', '', '', '', 2, 2),
(184, 'Graven', '', 'Graven 4, Aarhus, Danmark', 'g1', 'Graven 14B, Aarhus, Danmark', 'g2', 56.158199, 10.211820, 56.160690, 10.212080, '(56.1593922, 10.210014099999967)', '', '', '', 2, 2),
(185, 'test', '', 'Cochin, Kerala, India', '', 'Calicut, Kerala, India', '', 10.675710, 77.544678, 11.737000, 76.159149, '(10.3051026, 76.47938669999996),(10.9153581, 77.00751709999997),(11.0491325, 76.2310999)', '', '', '', 2, 87),
(187, 'Graven', '', 'Graven 4, Aarhus, Danmark', 'g1', 'Graven 14B, Aarhus, Danmark', 'g2', 56.158199, 10.211820, 56.160690, 10.212080, '(56.1593922, 10.210014099999967)', '', '', '', 2, 89),
(188, 'test1', '', 'Kottayam, Kerala, India', '', 'Trivandrum, Kerala, India', '', 9.504420, 77.689888, 8.600270, 77.030342, '(9.347500499999999, 77.39687379999998),(9.5905732, 76.89680810000004),(8.928497900000002, 77.3284132)', '', '', '', 2, 87),
(189, 'srilanka-road', 'test....', 'Kilinochchi, Northern Province, Sri Lanka', '', 'Dambulla, Central Province, Sri Lanka', '', 9.148650, 80.231850, 7.397030, 80.051788, '(9.0371247, 80.505766),(8.765483699999999, 80.9976107),(8.4731337, 80.75528919999999),(8.167895, 81.02977020000003),(7.681127099999999, 81.24527379999995)', '', '', '', 2, 90),
(190, 'erode-chennai', '', 'Erode, Tamil Nadu, India', '', 'Chennai, Tamil Nadu, India', '', 11.341911, 77.727402, 13.023762, 79.878166, '(12.3840479, 77.50960620000001),(13.3922331, 78.11160100000006),(12.5522187, 78.56367460000001),(12.247602, 79.34872659999996),(13.2593393, 79.46792430000005),(12.2813857, 80.01960220000001)', '', '', '', 2, 84),
(191, 'bangalore-whitefield', '', 'Bangalore,Karnataka,India', '', 'White Field, Bangalore, Karnataka, India', '', 12.971884, 77.594688, 12.969817, 77.749947, '(12.9864484, 77.63583510000001),(12.985676, 77.6908439),(12.9512042, 77.70733310000003)', '', '', '', 2, 91);

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_cards_accepted`
--

CREATE TABLE `zpayment_cards_accepted` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `cards` longtext NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_cards_accepted`
--

INSERT INTO `zpayment_cards_accepted` (`id`, `shop_id`, `owner_id`, `cards`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 26, 0, 'a:12:{s:6:\"paypal\";s:17:\"PayPal|paypal.png\";s:11:\"VisaDankort\";s:32:\"Dankort/Visa-Dankort|dankort.png\";s:12:\"Mastercard3D\";s:33:\"Mastercard (3D)|3d-mastercard.png\";s:15:\"MastercardDebet\";s:43:\"Mastercard-Debet|3d-mastercard-debet-dk.png\";s:14:\"VisaElectron3D\";s:39:\"Visa-Electron (3D)|3d-visa-electron.png\";s:5:\"JCB3D\";s:19:\"JCB (3D)|3d-jcb.png\";s:4:\"paii\";s:13:\"Paii|paii.png\";s:8:\"edankort\";s:21:\"eDankort|edankort.png\";s:15:\"mastercarddebet\";s:40:\"Mastercard-Debet|mastercard-debet-dk.png\";s:4:\"visa\";s:13:\"Visa|visa.png\";s:3:\"JCB\";s:11:\"JCB|jcb.png\";s:15:\"americanexpress\";s:37:\"American Express|american-express.png\";}', '2014-06-13 11:32:06', 3, '2014-06-13 11:32:06', 3),
(2, 60, 0, 'N;', '2014-08-06 07:00:36', 2, '2014-08-06 07:00:36', 2),
(3, 14, 0, 'a:1:{s:11:\"VisaDankort\";s:32:\"Dankort/Visa-Dankort|dankort.png\";}', '2014-08-12 07:25:17', 2, '2014-08-12 07:25:17', 2),
(4, 57, 0, 'N;', '2014-08-12 17:04:55', 3, '2014-08-12 17:04:55', 3),
(5, 61, 0, 'N;', '2014-09-29 10:01:22', 3, '2014-09-29 10:01:22', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_directpay_settings`
--

CREATE TABLE `zpayment_directpay_settings` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `info` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_directpay_settings`
--

INSERT INTO `zpayment_directpay_settings` (`id`, `shop_id`, `enabled`, `info`) VALUES
(1, 26, 1, 'Text written in this field will be presented to your customer as a selectable payment method. Here you can write something like: “Please make bank transfer to our account xxxx-xxxxxxxx.We will '),
(3, 14, 1, 'Please make bank transfer to our account xxxx-xxxxxxxx.We will ship your items when we register your payment.'),
(4, 57, 1, ''),
(5, 61, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_epay`
--

CREATE TABLE `zpayment_epay` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `status` varchar(2000) NOT NULL,
  `card_number` varchar(250) NOT NULL,
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_epay`
--

INSERT INTO `zpayment_epay` (`id`, `order_id`, `transaction_id`, `status`, `card_number`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'ZS2879482', '', 'Success', '555555XXXXXX5000', '2015-02-15', 3, '2015-02-15', 3),
(2, 'ZS288127', '', 'Cancelled', '', '2015-02-15', 3, '2015-02-15', 3),
(3, 'ZS2899271', '', 'Cancelled', '', '2015-02-15', 3, '2015-02-15', 3),
(4, 'ZS2908203', '41160542', 'Success', '555555XXXXXX5000', '2015-02-16', 3, '2015-02-16', 3),
(5, 'ZS2919359', '41166120', 'Success', '333333XXXXXX3000', '2015-02-16', 3, '2015-02-16', 3),
(6, 'ZS2927670', '41167499', 'Success', '444444XXXXXX4000', '2015-02-16', 3, '2015-02-16', 3),
(7, 'ZS2935692', '41170382', 'Success', '333333XXXXXX3000', '2015-02-16', 3, '2015-02-16', 3),
(8, 'ZS2959701', '', 'Placed', '', '2015-02-16', 3, '2015-02-16', 3),
(9, 'ZS3111170', '', 'Cancelled', '', '2015-07-19', 3, '2015-07-19', 3),
(10, 'ZS3142920', '', 'Cancelled', '', '2015-08-07', 3, '2015-08-07', 3),
(11, 'ZS3162015', '50047549', 'Success', '555555XXXXXX5000', '2015-08-18', 3, '2015-08-18', 3),
(12, 'ZS3192665', '', 'Placed', '', '2015-08-20', 3, '2015-08-20', 3),
(13, 'ZS3392735', '', 'Cancelled', '', '2016-01-23', 3, '2016-01-23', 3),
(14, 'ZS346884', '', 'Cancelled', '', '2016-01-23', 3, '2016-01-23', 3),
(15, 'ZS3529068', '', 'Placed', '', '2016-01-26', 0, '2016-01-26', 0),
(16, 'ZS360720', '', 'Cancelled', '', '2016-01-27', 0, '2016-01-27', 0),
(17, 'ZS3624375', '61494494', 'Success', '555555XXXXXX5000', '2016-01-31', 0, '2016-01-31', 0),
(18, 'ZS3632080', '', 'Placed', '', '2016-01-31', 0, '2016-01-31', 0),
(19, 'ZS3643425', '', 'Placed', '', '2016-01-31', 0, '2016-01-31', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_epay_settings`
--

CREATE TABLE `zpayment_epay_settings` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `test_mode` tinyint(1) NOT NULL,
  `merchant_number` varchar(500) NOT NULL,
  `md5_hash` longtext NOT NULL,
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `test_merchant_number` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_epay_settings`
--

INSERT INTO `zpayment_epay_settings` (`id`, `shop_id`, `enabled`, `test_mode`, `merchant_number`, `md5_hash`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `test_merchant_number`) VALUES
(1, 26, 1, 1, '8018211', 'hhjgjgjjhjgjhgj', '2015-02-14', 3, '2015-02-14', 3, '8018211'),
(2, 61, 0, 0, '', '', '2016-06-24', 3, '2016-06-24', 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_freight_settings`
--

CREATE TABLE `zpayment_freight_settings` (
  `freight_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `std_freight_price` decimal(15,4) DEFAULT NULL,
  `zero_freight_price` decimal(15,4) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_freight_settings`
--

INSERT INTO `zpayment_freight_settings` (`freight_id`, `shop_id`, `enabled`, `std_freight_price`, `zero_freight_price`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 26, 1, '200.0000', '1000.0000', '2014-11-13 13:48:15', 3, '2014-11-13 13:48:15', 3),
(2, 61, 0, '0.0000', '0.0000', '2016-06-24 19:42:49', 3, '2016-06-24 19:42:49', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_netaxept`
--

CREATE TABLE `zpayment_netaxept` (
  `id` int(11) NOT NULL,
  `zselex_order_id` varchar(255) NOT NULL,
  `nets_transaction_id` varchar(255) NOT NULL,
  `status` varchar(2000) NOT NULL,
  `info` longtext NOT NULL,
  `cardtype` varchar(250) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_netaxept`
--

INSERT INTO `zpayment_netaxept` (`id`, `zselex_order_id`, `nets_transaction_id`, `status`, `info`, `cardtype`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(19, 'ZS1365841', 'c778738c6cc34bf9b2a665c1def27122', 'Placed', '', '', '2014-06-10 00:00:00', 3, '2014-06-10 00:00:00', 3),
(18, 'ZS1314208', '5abfbf964a174d6da7eb6a0a1a7ac7c2', 'Placed', '', '', '2014-06-10 00:00:00', 3, '2014-06-10 00:00:00', 3),
(17, 'ZS1275941', 'e3f28d5dc9ce42ba89352944e9f9f706', 'Success', '', 'MasterCard', '2014-06-10 00:00:00', 3, '2014-06-10 00:00:00', 3),
(20, 'ZS1383063', '0f79bacf5b0a473aa899d5d80c6cbc34', 'Success', '', 'MasterCard', '2014-06-10 00:00:00', 3, '2014-06-10 00:00:00', 3),
(21, 'ZS140654', '2dca6da9cc3049f880dd1285025ec989', 'Success', '', 'MasterCard', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(22, 'ZS1415314', '43dfd35db9644481b77aad05fc3aeca7', 'Placed', '', '', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(23, 'ZS1429479', 'e3c9d2b289f149f2936a94d3354abc2c', 'Success', '', 'MasterCard', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(24, 'ZS1439539', '6accb44aa0994f1ca4128f7db244849c', 'Cancelled', '', '', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(25, 'ZS1451161', '0fff650877ce442ab6e9608738def680', 'Placed', '', '', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(26, 'ZS1465674', 'b3a0caa86faf44758aab20b470e8dcf3', 'Placed', '', '', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(27, 'ZS1471701', '386df44d5ca64935bf9b9d82098dec15', 'Placed', '', '', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(28, 'ZS1498443', '0b0e136245a044f982018a737e52a99d', 'Placed', '', '', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(29, 'ZS1509300', 'edea6e13c4a142c0a6f05385b9fba5a8', 'Placed', '', '', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(30, 'ZS1519625', '8fab058eaf1e4a98a39a7b5acd3c7dd6', 'Placed', '', '', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(31, 'ZS1539149', 'f252b5ae3f9f47dd89e3409d54580b10', 'Success', '', 'MasterCard', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(32, 'ZS1573451', 'c3b8b891707149a8ba815bc6c2a6ae91', 'Failed', 'Auth Reg Comp Failure)', '', '2014-07-23 00:00:00', 3, '2014-07-23 00:00:00', 3),
(33, 'ZS1584054', '512fd7ce939d4a3daba3e50dae68f5fa', 'Success', '', 'Visa', '2014-07-23 00:00:00', 3, '2014-07-23 00:00:00', 3),
(34, 'ZS1689424', '7e9641cea36b483fb541c72d486c0597', 'Failed', 'Auth Reg Comp Failure)', '', '2014-08-13 00:00:00', 3, '2014-08-13 00:00:00', 3),
(35, 'ZS1702778', '77adec3a35094b6e864cdfb6632fc9e8', 'Placed', '', '', '2014-08-13 00:00:00', 3, '2014-08-13 00:00:00', 3),
(36, 'ZS1713155', 'ff0113a282c142d6860d577b1c965251', 'Placed', '', '', '2014-08-13 00:00:00', 3, '2014-08-13 00:00:00', 3),
(37, 'ZS1735132', '9d95288360a74c85beef7119a9f83bb2', 'Success', '', 'Visa', '2014-08-13 00:00:00', 3, '2014-08-13 00:00:00', 3),
(38, 'ZS1755376', 'a9728c58bfee4548aef3b3f5187fff7f', 'Success', '', 'Visa', '2014-08-13 00:00:00', 3, '2014-08-13 00:00:00', 3),
(39, 'ZS1773622', '4e5e06546f7447abb44ba2c1dbf52ed3', 'Success', '', 'Visa', '2014-08-13 00:00:00', 3, '2014-08-13 00:00:00', 3),
(40, 'ZS1835485', '80133a62527d4e90adc4c6e01622c8fa', 'Success', '', 'Visa', '2014-09-01 00:00:00', 3, '2014-09-01 00:00:00', 3),
(41, 'ZS187481', 'd27bbcb301584735985147ae5a14d80d', 'Success', '', 'Visa', '2014-09-15 00:00:00', 3, '2014-09-15 00:00:00', 3),
(42, 'ZS2025254', '2fb0374853f841a6989ba4f55d2da39f', 'Cancelled', '', '', '2014-11-14 00:00:00', 3, '2014-11-14 00:00:00', 3),
(43, 'ZS2143807', '77a4970630b24baba4ae2c76868ba106', 'Cancelled', '', '', '2015-01-22 00:00:00', 3, '2015-01-22 00:00:00', 3),
(44, 'ZS2174031', 'cff7eea627fe45218d538c4d7dea394b', 'Placed', '', '', '2015-01-23 00:00:00', 3, '2015-01-23 00:00:00', 3),
(45, 'ZS2347309', 'b6f09b73b27442458d6b27d34a4286bd', 'Failed', 'Auth Reg Comp Failure)', '', '2015-01-24 00:00:00', 3, '2015-01-24 00:00:00', 3),
(46, 'ZS2359104', '20eee80fa23949bbab5362df102f6f60', 'Success', '', 'Visa', '2015-01-24 00:00:00', 3, '2015-01-24 00:00:00', 3),
(47, 'ZS2417652', '3477403c2ef44ea886040203da99a66b', 'Placed', '', '', '2015-01-28 00:00:00', 3, '2015-01-28 00:00:00', 3),
(48, 'ZS2428460', 'e779ef336fca41168aabc0aa929c4880', 'Success', '', 'Visa', '2015-01-28 00:00:00', 3, '2015-01-28 00:00:00', 3),
(49, 'ZS2448601', 'e6a6ae89ce7d4e6c9ff314ee59499bf0', 'Success', '', 'Visa', '2015-01-29 00:00:00', 3, '2015-01-29 00:00:00', 3),
(50, 'ZS2459164', '330585ffcdeb4263b0b39afb060672c8', 'Placed', '', '', '2015-01-29 00:00:00', 3, '2015-01-29 00:00:00', 3),
(51, 'ZS2468386', '069e2e48f6a543b5a88490dd7d86d36f', 'Placed', '', '', '2015-01-29 00:00:00', 3, '2015-01-29 00:00:00', 3),
(52, 'ZS2471599', '41e3ef2a5b4149289e6834c1e67c5e4a', 'Success', '', '', '2015-01-29 00:00:00', 3, '2015-01-29 00:00:00', 3),
(53, 'ZS2487738', '28f50721e0fb410899212dcebb92bcbe', 'Cancelled', '', '', '2015-01-29 00:00:00', 2, '2015-01-29 00:00:00', 2),
(54, 'ZS2504835', '520f9d7cf1da452baff0061656238c86', 'Success', '', '', '2015-01-30 00:00:00', 3, '2015-01-30 00:00:00', 3),
(55, 'ZS2516483', '72a6b5ee265640d9bc95ea8161df65db', 'Success', '', '', '2015-01-30 00:00:00', 3, '2015-01-30 00:00:00', 3),
(56, 'ZS2525830', '197622c273524907bf63718ea08d6b1d', 'Success', '', '', '2015-01-30 00:00:00', 3, '2015-01-30 00:00:00', 3),
(57, 'ZS2537559', 'f8d83368be434a099354693788100cd2', 'Success', '', '', '2015-01-30 00:00:00', 3, '2015-01-30 00:00:00', 3),
(58, 'ZS2544769', '82b5905a1503434cb5e91e5af680d0fe', 'Cancelled', '', '', '2015-01-30 00:00:00', 3, '2015-01-30 00:00:00', 3),
(59, 'ZS2558524', 'e4e63fda8a2a42c9bb3d05b24039c76c', 'Cancelled', '', '', '2015-01-30 00:00:00', 3, '2015-01-30 00:00:00', 3),
(60, 'ZS2563628', '974cc34653f54b71a3c16516dc8ba1ae', 'Cancelled', '', '', '2015-01-30 00:00:00', 3, '2015-01-30 00:00:00', 3),
(61, 'ZS2575036', 'ba3d82ddd285483d92e7f9826ccab870', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(62, 'ZS2585465', 'a4833a81f8d741ccaeea9d3aeea4f0ed', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(63, 'ZS2593628', '7f9a94e609544800bb1adfb5c7ae4d35', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(64, 'ZS2605938', 'f0f7f495a3264fbf8799ef541235e5b5', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(65, 'ZS2617859', 'c65208d49f4e42b09419c099198d749c', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(66, 'ZS2622778', '11ff93925559433aa0c33ef899383672', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(67, 'ZS263295', 'b40a48fd579e4df4946fa58843be5395', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(68, 'ZS2654320', '056bf280bd264903b3af57e782b5e496', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(69, 'ZS2668151', '3de77ab460484fac8f07089f4f7b1e97', 'Cancelled', '', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(70, 'ZS2675792', 'ba4762666e414322bb19586202998121', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(71, 'ZS2689837', '7d2f1a5fc7284928a3ed6349f6c497eb', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(72, 'ZS2693026', '868ca62b2edc46a0aaf90be577ba6369', 'Failed', 'Auth Reg Comp Failure)', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(73, 'ZS270528', 'b0b21aca25cc4300a05240a2c0a00cf5', 'Cancelled', '', '', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(74, 'ZS2713680', 'a35c2b2e0a9b4f2193ccbf46d0d01f22', 'Success', '', 'Visa', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(75, 'ZS2727686', 'fa5b352ef122437ba26fb070327079a3', 'Success', '', 'Visa', '2015-02-01 00:00:00', 3, '2015-02-01 00:00:00', 3),
(76, 'ZS2786600', 'a7e9b66e0b864e7f8a0be346965616ca', 'Cancelled', '', '', '2015-02-03 00:00:00', 3, '2015-02-03 00:00:00', 3),
(77, 'ZS3159360', '60a0da41201c4fb3b00dfaac864523e6', 'Placed', '', '', '2015-08-18 00:00:00', 3, '2015-08-18 00:00:00', 3),
(78, 'ZS3575893', 'c9c1c695469f4693b9b9425438fe7e9d', 'Cancelled', '', '', '2016-01-27 00:00:00', 0, '2016-01-27 00:00:00', 0),
(79, 'ZS3651658', 'd60b246be29b496b9499567efab92353', 'Success', '', 'Visa', '2016-02-15 00:00:00', 0, '2016-02-15 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_netaxept_settings`
--

CREATE TABLE `zpayment_netaxept_settings` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `test_mode` tinyint(1) NOT NULL,
  `merchant_id` varchar(500) NOT NULL,
  `token` varchar(255) NOT NULL,
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `return_url` longtext,
  `test_merchant_id` varchar(500) NOT NULL,
  `test_token` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_netaxept_settings`
--

INSERT INTO `zpayment_netaxept_settings` (`id`, `shop_id`, `enabled`, `test_mode`, `merchant_id`, `token`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `return_url`, `test_merchant_id`, `test_token`) VALUES
(1, 26, 1, 1, '11001393', '8Sr-Bd/6', '2014-04-24', 3, '2014-04-24', 3, '', '11001393', '8Sr-Bd/6'),
(3, 14, 0, 0, '0', '', '2014-08-12', 2, '2014-08-12', 2, NULL, '0', ''),
(4, 57, 0, 0, '0', '', '2014-08-12', 3, '2014-08-12', 3, NULL, '0', ''),
(5, 61, 0, 0, '0', '', '2014-09-29', 3, '2014-09-29', 3, '', '0', '');

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_paypal`
--

CREATE TABLE `zpayment_paypal` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `status` varchar(2000) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_paypal`
--

INSERT INTO `zpayment_paypal` (`id`, `order_id`, `transaction_id`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(12, 'ZS1524649', '', 'Placed', '2014-06-11 00:00:00', 3, '2014-06-11 00:00:00', 3),
(11, 'ZS1378298', '', 'Placed', '2014-06-10 00:00:00', 3, '2014-06-10 00:00:00', 3),
(10, 'ZS1343735', '45F69537MS339182P', 'Pending', '2014-06-10 00:00:00', 3, '2014-06-10 00:00:00', 3),
(9, 'ZS1234790', '', 'Placed', '2014-06-10 00:00:00', 3, '2014-06-10 00:00:00', 3),
(13, 'ZS1569699', '99S27283JL178820P', 'Pending', '2014-07-23 00:00:00', 3, '2014-07-23 00:00:00', 3),
(14, 'ZS1592078', '5W334011DK5640734', 'Pending', '2014-07-23 00:00:00', 3, '2014-07-23 00:00:00', 3),
(15, 'ZS1614944', '', 'Cancelled', '2014-07-23 00:00:00', 3, '2014-07-23 00:00:00', 3),
(16, 'ZS1628541', '', 'Cancelled', '2014-07-23 00:00:00', 3, '2014-07-23 00:00:00', 3),
(17, 'ZS1641379', '0MC09124NV0205131', 'Pending', '2014-07-23 00:00:00', 3, '2014-07-23 00:00:00', 3),
(18, 'ZS1656397', '2D535779U9428552A', 'Pending', '2014-07-23 00:00:00', 3, '2014-07-23 00:00:00', 3),
(19, 'ZS166813', '34P638542W013270C', 'Pending', '2014-07-24 00:00:00', 3, '2014-07-24 00:00:00', 3),
(20, 'ZS1673492', '5ES64512HL130262N', 'Pending', '2014-08-12 00:00:00', 3, '2014-08-12 00:00:00', 3),
(21, 'ZS1721979', '6BC80969F21623446', 'Pending', '2014-08-13 00:00:00', 3, '2014-08-13 00:00:00', 3),
(22, 'ZS1818982', '308365643P721645Y', 'Pending', '2014-08-21 00:00:00', 3, '2014-08-21 00:00:00', 3),
(23, 'ZS185908', '2YM76164S8968424E', 'Pending', '2014-09-01 00:00:00', 3, '2014-09-01 00:00:00', 3),
(24, 'ZS186174', '2T4147021G980721H', 'Pending', '2014-09-15 00:00:00', 3, '2014-09-15 00:00:00', 3),
(25, 'ZS1901022', '', 'Placed', '2014-09-24 00:00:00', 3, '2014-09-24 00:00:00', 3),
(26, 'ZS1916685', '3DA55982EK890972S', 'Pending', '2014-09-24 00:00:00', 3, '2014-09-24 00:00:00', 3),
(27, 'ZS1927491', '7KJ973812T2594009', 'Pending', '2014-10-29 00:00:00', 3, '2014-10-29 00:00:00', 3),
(28, 'ZS2007376', '6PX94388RR5863258', 'Pending', '2014-11-13 00:00:00', 3, '2014-11-13 00:00:00', 3),
(29, 'ZS2044703', '81541555C4384094W', 'Pending', '2014-11-14 00:00:00', 3, '2014-11-14 00:00:00', 3),
(30, 'ZS2053075', '', 'Cancelled', '2014-11-17 00:00:00', 3, '2014-11-17 00:00:00', 3),
(31, 'ZS2073031', '', 'Cancelled', '2014-11-17 00:00:00', 3, '2014-11-17 00:00:00', 3),
(32, 'ZS2292922', '', 'Placed', '2015-01-23 00:00:00', 3, '2015-01-23 00:00:00', 3),
(33, 'ZS2763931', '', 'Cancelled', '2015-02-03 00:00:00', 3, '2015-02-03 00:00:00', 3),
(34, 'ZS2777741', '', 'Cancelled', '2015-02-03 00:00:00', 3, '2015-02-03 00:00:00', 3),
(35, 'ZS2795784', '50235008997262437', 'Pending', '2015-02-08 00:00:00', 3, '2015-02-08 00:00:00', 3),
(36, 'ZS3049562', '', 'Placed', '2015-06-19 00:00:00', 3, '2015-06-19 00:00:00', 3),
(37, 'ZS3081173', '', 'Cancelled', '2015-07-14 00:00:00', 3, '2015-07-14 00:00:00', 3),
(38, 'ZS309609', '', 'Cancelled', '2015-07-14 00:00:00', 3, '2015-07-14 00:00:00', 3),
(39, 'ZS3109134', '', 'Placed', '2015-07-15 00:00:00', 3, '2015-07-15 00:00:00', 3),
(40, 'ZS3129972', '', 'Cancelled', '2015-07-19 00:00:00', 3, '2015-07-19 00:00:00', 3),
(41, 'ZS3135998', '', 'Cancelled', '2015-07-19 00:00:00', 3, '2015-07-19 00:00:00', 3),
(42, 'ZS3173441', '', 'Placed', '2015-08-20 00:00:00', 3, '2015-08-20 00:00:00', 3),
(43, 'ZS3236790', '', 'Placed', '2015-12-17 00:00:00', 3, '2015-12-17 00:00:00', 3),
(44, 'ZS3248538', '', 'Placed', '2015-12-17 00:00:00', 3, '2015-12-17 00:00:00', 3),
(45, 'ZS3254068', '', 'Placed', '2015-12-17 00:00:00', 3, '2015-12-17 00:00:00', 3),
(46, 'ZS3269886', '', 'Placed', '2015-12-17 00:00:00', 3, '2015-12-17 00:00:00', 3),
(47, 'ZS3279750', '', 'Placed', '2015-12-17 00:00:00', 3, '2015-12-17 00:00:00', 3),
(48, 'ZS3312212', '', 'Placed', '2016-01-23 00:00:00', 3, '2016-01-23 00:00:00', 3),
(49, 'ZS3323956', '', 'Placed', '2016-01-23 00:00:00', 3, '2016-01-23 00:00:00', 3),
(50, 'ZS3336713', '', 'Placed', '2016-01-23 00:00:00', 3, '2016-01-23 00:00:00', 3),
(51, 'ZS3361448', '', 'Placed', '2016-01-23 00:00:00', 3, '2016-01-23 00:00:00', 3),
(52, 'ZS3402780', '', 'Placed', '2016-01-23 00:00:00', 3, '2016-01-23 00:00:00', 3),
(53, 'ZS3417992', '', 'Placed', '2016-01-23 00:00:00', 3, '2016-01-23 00:00:00', 3),
(54, 'ZS3423157', '', 'Placed', '2016-01-23 00:00:00', 3, '2016-01-23 00:00:00', 3),
(55, 'ZS3479495', '', 'Placed', '2016-01-23 00:00:00', 3, '2016-01-23 00:00:00', 3),
(56, 'ZS3536208', '4TY84486BW574432T', 'Pending', '2016-01-26 00:00:00', 0, '2016-01-26 00:00:00', 0),
(57, 'ZS356803', '', 'Placed', '2016-01-27 00:00:00', 0, '2016-01-27 00:00:00', 0),
(58, 'ZS3583816', '', 'Placed', '2016-01-27 00:00:00', 0, '2016-01-27 00:00:00', 0),
(59, 'ZS3612583', '', 'Placed', '2016-01-27 00:00:00', 0, '2016-01-27 00:00:00', 0),
(60, 'ZS3669417', '', 'Cancelled', '2016-02-15 00:00:00', 0, '2016-02-15 00:00:00', 0),
(61, 'ZS3678252', '', 'Cancelled', '2016-02-15 00:00:00', 0, '2016-02-15 00:00:00', 0),
(62, 'ZS3685227', '', 'Cancelled', '2016-02-15 00:00:00', 0, '2016-02-15 00:00:00', 0),
(63, 'ZS3707868', '', 'Cancelled', '2016-02-15 00:00:00', 0, '2016-02-15 00:00:00', 0),
(64, 'ZS3748660', '', 'Placed', '2016-06-26 00:00:00', 3, '2016-06-26 00:00:00', 3),
(65, 'ZS3753530', '', 'Placed', '2016-06-26 00:00:00', 3, '2016-06-26 00:00:00', 3),
(66, 'ZS3768653', '', 'Placed', '2016-06-27 00:00:00', 0, '2016-06-27 00:00:00', 0),
(67, 'ZS377548', '22A1561459846801E', 'Pending', '2016-06-27 00:00:00', 0, '2016-06-27 00:00:00', 0),
(68, 'ZS378863', '73L24280EF442852K', 'Pending', '2016-06-28 00:00:00', 0, '2016-06-28 00:00:00', 0),
(69, 'ZS3796762', '', 'Placed', '2016-07-02 00:00:00', 0, '2016-07-02 00:00:00', 0),
(70, 'ZS3804262', '', 'Cancelled', '2016-07-03 00:00:00', 0, '2016-07-03 00:00:00', 0),
(71, 'ZS3813633', '9UJ78310UY027743N', 'Pending', '2016-08-25 00:00:00', 3, '2016-08-25 00:00:00', 3),
(72, 'ZS3822269', '5TM53385GP235961Y', 'Pending', '2016-08-25 00:00:00', 3, '2016-08-25 00:00:00', 3),
(73, 'ZS383327', '', 'Placed', '2016-08-25 00:00:00', 3, '2016-08-25 00:00:00', 3),
(74, 'ZS3849731', '', 'Placed', '2016-08-26 00:00:00', 0, '2016-08-26 00:00:00', 0),
(75, 'ZS3858213', '', 'Placed', '2016-08-26 00:00:00', 0, '2016-08-26 00:00:00', 0),
(76, 'ZS3867918', '', 'Placed', '2016-08-26 00:00:00', 0, '2016-08-26 00:00:00', 0),
(77, 'ZS3873945', '', 'Placed', '2016-08-26 00:00:00', 0, '2016-08-26 00:00:00', 0),
(78, 'ZS3884795', '1E267270FS2214143', 'Pending', '2016-08-26 00:00:00', 0, '2016-08-26 00:00:00', 0),
(79, 'ZS3899379', '', 'Cancelled', '2016-09-05 00:00:00', 3, '2016-09-05 00:00:00', 3),
(80, 'ZS3906979', '0KR45796YH0287106', 'Pending', '2016-09-05 00:00:00', 3, '2016-09-05 00:00:00', 3),
(81, 'ZS3914139', '0N632065FJ021534Y', 'Pending', '2016-09-05 00:00:00', 3, '2016-09-05 00:00:00', 3),
(82, 'ZS3929180', '2SW833539K6507626', 'Pending', '2016-09-05 00:00:00', 3, '2016-09-05 00:00:00', 3),
(83, 'ZS3939560', '9RF77459PW1206911', 'Authorized', '2017-10-29 00:00:00', 3, '2017-10-29 00:00:00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_paypal_settings`
--

CREATE TABLE `zpayment_paypal_settings` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `test_mode` tinyint(1) NOT NULL,
  `business_email` varchar(255) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_paypal_settings`
--

INSERT INTO `zpayment_paypal_settings` (`id`, `shop_id`, `enabled`, `test_mode`, `business_email`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 26, 1, 1, 'sharaz.khan-facilitator@r2international.com', '2014-04-28 09:42:47', 3, '2014-04-28 09:42:47', 3),
(3, 14, 0, 0, '', '2014-08-12 00:00:00', 2, '2014-08-12 00:00:00', 2),
(4, 57, 0, 0, '', '2014-08-12 00:00:00', 3, '2014-08-12 00:00:00', 3),
(5, 61, 0, 0, '', '2014-09-29 00:00:00', 3, '2014-09-29 00:00:00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_quickpay`
--

CREATE TABLE `zpayment_quickpay` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `status` varchar(2000) NOT NULL,
  `info` longtext NOT NULL,
  `cardtype` varchar(250) NOT NULL,
  `callback` tinyint(4) NOT NULL DEFAULT '0',
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_quickpay`
--

INSERT INTO `zpayment_quickpay` (`id`, `order_id`, `transaction_id`, `status`, `info`, `cardtype`, `callback`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(22, 'ZS1335025', '89803718', 'Success', 'OK', 'dankort', 0, '2014-06-10', 3, '2014-06-10', 3),
(21, 'ZS1327982', '89800579', 'Success', 'OK', 'dankort', 0, '2014-06-10', 3, '2014-06-10', 3),
(20, 'ZS1305145', '89800386', 'Success', 'OK', 'dankort', 0, '2014-06-10', 3, '2014-06-10', 3),
(19, 'ZS1299980', '89799929', 'Success', 'OK', 'dankort', 0, '2014-06-10', 3, '2014-06-10', 3),
(18, 'ZS1285641', '89799203', 'Success', 'OK', 'dankort', 0, '2014-06-10', 3, '2014-06-10', 3),
(23, 'ZS1356355', '89807951', 'Success', 'OK', 'dankort', 0, '2014-06-10', 3, '2014-06-10', 3),
(24, 'ZS1397629', '89834938', 'Success', 'OK', 'dankort', 0, '2014-06-11', 3, '2014-06-11', 3),
(25, 'ZS1446168', '', 'Placed', '', '', 0, '2014-06-11', 3, '2014-06-11', 3),
(26, 'ZS1541454', '', 'Cancelled', 'Payment Cancelled', '', 0, '2014-06-12', 3, '2014-06-12', 3),
(27, 'ZS1556128', '', 'Placed', '', '', 0, '2014-07-23', 3, '2014-07-23', 3),
(28, 'ZS1634062', '', 'Cancelled', 'Payment Cancelled', '', 0, '2014-07-23', 3, '2014-07-23', 3),
(29, 'ZS1695675', '93223140', 'Success', 'OK', 'dankort', 0, '2014-08-13', 3, '2014-08-13', 3),
(30, 'ZS1741886', '93223843', 'Success', 'OK', 'dankort', 0, '2014-08-13', 3, '2014-08-13', 3),
(31, 'ZS1765442', '93225599', 'Success', 'OK', 'dankort', 0, '2014-08-13', 3, '2014-08-13', 3),
(32, 'ZS1788028', '93226087', 'Success', 'OK', 'dankort', 0, '2014-08-13', 3, '2014-08-13', 3),
(33, 'ZS1792954', '93226603', 'Success', 'OK', 'dankort', 0, '2014-08-13', 3, '2014-08-13', 3),
(34, 'ZS1804950', '', 'Cancelled', 'Payment Cancelled', '', 0, '2014-08-18', 3, '2014-08-18', 3),
(35, 'ZS1847900', '94299733', 'Success', 'OK', 'dankort', 0, '2014-09-01', 3, '2014-09-01', 3),
(36, 'ZS1888080', '95352611', 'Success', 'OK', 'dankort', 0, '2014-09-15', 3, '2014-09-15', 3),
(37, 'ZS2036122', '', 'Placed', '', '', 0, '2014-11-14', 3, '2014-11-14', 3),
(38, 'ZS2068443', '', 'Cancelled', 'Payment Cancelled', '', 0, '2014-11-17', 3, '2014-11-17', 3),
(39, 'ZS2085992', '', 'Placed', '', '', 0, '2014-11-19', 3, '2014-11-19', 3),
(40, 'ZS2946749', '', 'Placed', '', '', 0, '2015-02-16', 3, '2015-02-16', 3),
(41, 'ZS2968313', '', 'Placed', '', '', 0, '2015-02-16', 3, '2015-02-16', 3),
(42, 'ZS2972930', '', 'Placed', '', '', 0, '2015-02-16', 3, '2015-02-16', 3),
(43, 'ZS2983815', '', 'Cancelled', 'Payment Cancelled', '', 0, '2015-02-16', 3, '2015-02-16', 3),
(44, 'ZS2998952', '', 'Placed', '', '', 0, '2015-02-16', 3, '2015-02-16', 3),
(45, 'ZS3185034', '', 'Placed', '', '', 0, '2015-08-20', 3, '2015-08-20', 3),
(46, 'ZS3304049', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(47, 'ZS3345967', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(48, 'ZS3357703', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(49, 'ZS3372161', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(50, 'ZS3383190', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(51, 'ZS3431311', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(52, 'ZS3445250', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(53, 'ZS3453692', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(54, 'ZS3486786', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(55, 'ZS349511', '', 'Placed', '', '', 0, '2016-01-23', 3, '2016-01-23', 3),
(56, 'ZS3515521', '', 'Placed', '', '', 0, '2016-01-26', 0, '2016-01-26', 0),
(57, 'ZS3549007', '', 'Placed', '', '', 0, '2016-01-26', 0, '2016-01-26', 0),
(58, 'ZS3598362', '', 'Placed', '', '', 0, '2016-01-27', 0, '2016-01-27', 0),
(59, 'ZS3719098', '9b698eb3105bd82528f23d0c92dedfc0577004a36606d0.85750509', 'Placed', '', '', 0, '2016-06-26', 0, '2016-06-26', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zpayment_quickpay_settings`
--

CREATE TABLE `zpayment_quickpay_settings` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `test_mode` tinyint(1) NOT NULL,
  `quickpay_id` int(11) NOT NULL,
  `merchant_id` varchar(250) NOT NULL,
  `agreement_id` varchar(250) NOT NULL,
  `md5_secret` varchar(255) NOT NULL,
  `api_key` text NOT NULL,
  `pay_type` varchar(250) NOT NULL,
  `return_url` text,
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zpayment_quickpay_settings`
--

INSERT INTO `zpayment_quickpay_settings` (`id`, `shop_id`, `enabled`, `test_mode`, `quickpay_id`, `merchant_id`, `agreement_id`, `md5_secret`, `api_key`, `pay_type`, `return_url`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 26, 1, 1, 15370300, '', '', 'a2aa3b62eacbe78baec92162ca99d93171b0115295fe87c65cebe91d3d5a1685', '', 'auto', NULL, '2014-06-04', 3, '2014-06-04', 3),
(2, 42, 1, 1, 15370300, '', '', 'a2aa3b62eacbe78baec92162ca99d93171b0115295fe87c65cebe91d3d5a1685', '', '', NULL, '2014-06-05', 3, '2014-06-05', 3),
(3, 14, 0, 0, 0, '', '', '', '', '', NULL, '2014-08-12', 2, '2014-08-12', 2),
(4, 57, 0, 0, 0, '', '', '', '', '', NULL, '2014-08-12', 3, '2014-08-12', 3),
(5, 61, 0, 0, 0, '', '', '', '', '', '', '2014-09-29', 3, '2014-09-29', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex`
--

CREATE TABLE `zselex` (
  `bid` bigint(20) UNSIGNED NOT NULL,
  `cid` varchar(150) DEFAULT NULL,
  `obj_status` varchar(1) NOT NULL DEFAULT 'A',
  `cr_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cr_uid` int(11) NOT NULL DEFAULT '0',
  `lu_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lu_uid` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zselex_advertise`
--

CREATE TABLE `zselex_advertise` (
  `advertise_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `adprice_id` int(11) DEFAULT NULL,
  `advertise_type` varchar(255) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `level` varchar(255) NOT NULL,
  `maxviews` int(11) NOT NULL,
  `totalviews` int(11) NOT NULL,
  `viewstoday` int(11) NOT NULL,
  `maxclicks` int(11) NOT NULL,
  `totalclicks` int(11) NOT NULL,
  `clickstoday` int(11) NOT NULL,
  `startdate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_advertise`
--

INSERT INTO `zselex_advertise` (`advertise_id`, `name`, `adprice_id`, `advertise_type`, `description`, `keywords`, `shop_id`, `country_id`, `region_id`, `city_id`, `area_id`, `level`, `maxviews`, `totalviews`, `viewstoday`, `maxclicks`, `totalclicks`, `clickstoday`, `startdate`, `enddate`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'COUNTRY-DENMARK', 1, 'productAd', '', '', 26, 61, NULL, NULL, NULL, 'COUNTRY', -1, 0, 0, -1, 0, 0, NULL, NULL, 0, '2015-01-22 14:58:55', 3, '2015-01-22 14:58:55', 3),
(2, 'COUNTRY-DENMARK', 3, 'productAd', '', '', 26, 61, NULL, NULL, NULL, 'COUNTRY', -1, 0, 0, -1, 0, 0, NULL, NULL, 0, '2015-08-22 13:25:41', 3, '2015-08-22 13:25:41', 3),
(3, 'COUNTRY-DENMARK', 1, 'productAd', '', '', 61, 61, NULL, NULL, NULL, 'COUNTRY', -1, 0, 0, -1, 0, 0, NULL, NULL, 0, '2016-06-24 19:35:17', 3, '2016-06-24 19:35:17', 3),
(4, 'COUNTRY-DENMARK', 3, 'productAd', '', '', 61, 61, NULL, NULL, NULL, 'COUNTRY', -1, 0, 0, -1, 0, 0, NULL, NULL, 0, '2016-06-24 19:35:24', 3, '2016-06-24 19:35:24', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_advertise_price`
--

CREATE TABLE `zselex_advertise_price` (
  `adprice_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `pricetype` varchar(255) DEFAULT NULL,
  `price` decimal(15,4) NOT NULL,
  `description` longtext,
  `status` tinyint(1) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_advertise_price`
--

INSERT INTO `zselex_advertise_price` (`adprice_id`, `name`, `identifier`, `pricetype`, `price`, `description`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'High', 'A', 'DKK', '3.0000', '', 1, '2012-03-26 00:00:00', 3, '2013-12-09 00:00:00', 3),
(2, 'Low', 'C', 'DKK', '1.0000', '', 1, '2012-03-26 00:00:00', 3, '2013-12-09 00:00:00', 3),
(3, 'Mid', 'B', 'DKK', '2.0000', '', 1, '2012-03-29 00:00:00', 2, '2013-12-09 00:00:00', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_area`
--

CREATE TABLE `zselex_area` (
  `area_id` int(11) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `area_name` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zselex_article_ads`
--

CREATE TABLE `zselex_article_ads` (
  `articlead_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `level` varchar(200) NOT NULL,
  `country_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `keywords` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` int(11) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_article_ads`
--

INSERT INTO `zselex_article_ads` (`articlead_id`, `name`, `shop_id`, `level`, `country_id`, `region_id`, `city_id`, `area_id`, `keywords`, `start_date`, `end_date`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'test ad', 14, 'COUNTRY', 61, 7, 28, 0, 'asdasd', '2013-01-23', '2013-07-24', 1, '2013-01-23 16:37:39', 3, '2013-07-23 11:02:11', 3),
(2, 'safsd', 18, 'CITY', 0, 0, 23, 0, 'sdfaasdf', '2013-01-25', '2013-01-30', 1, '2013-01-25 08:22:29', 20, '2013-01-25 08:22:29', 20),
(3, 'test', 26, 'COUNTRY', 61, 8, 28, 0, 'safddsa', '2013-06-11', '2013-07-31', 1, '2013-06-11 14:22:36', 3, '2013-07-23 11:02:49', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_basket`
--

CREATE TABLE `zselex_basket` (
  `basket_id` int(11) NOT NULL,
  `plugin_id` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `qty_based` tinyint(1) NOT NULL,
  `bundle_id` int(11) DEFAULT NULL,
  `top_bundle` tinyint(1) NOT NULL,
  `bundle_type` varchar(255) NOT NULL,
  `original_price` decimal(15,4) DEFAULT NULL,
  `price` decimal(15,4) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `service_status` smallint(6) NOT NULL,
  `subtotal` decimal(15,4) DEFAULT NULL,
  `timer_days` int(11) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `is_bundle` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_basket`
--

INSERT INTO `zselex_basket` (`basket_id`, `plugin_id`, `type`, `shop_id`, `user_id`, `owner_id`, `quantity`, `qty_based`, `bundle_id`, `top_bundle`, `bundle_type`, `original_price`, `price`, `status`, `service_status`, `subtotal`, `timer_days`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `is_bundle`) VALUES
(23, 104, 'minishop', 116, 4, 4, 1, 0, 0, 0, '', '0.0000', '1000.0000', 0, 0, '1000.0000', 0, '2013-03-19 14:43:39', 4, '2013-03-19 14:43:39', 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_branch`
--

CREATE TABLE `zselex_branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL,
  `obj_status` varchar(20) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_branch`
--

INSERT INTO `zselex_branch` (`branch_id`, `branch_name`, `description`, `status`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(3, 'branch1', 'sdfsdfdsf', 1, '', '2012-11-29 14:33:59', 3, '2012-11-29 14:33:59', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_cart`
--

CREATE TABLE `zselex_cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` varchar(250) DEFAULT NULL,
  `is_guest` smallint(6) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `cart_content` longtext,
  `original_price` decimal(15,4) DEFAULT NULL,
  `options_price` decimal(15,4) DEFAULT NULL,
  `final_price` decimal(15,4) DEFAULT NULL,
  `outofstock` smallint(6) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `prd_answer` longtext,
  `price` decimal(15,4) DEFAULT NULL,
  `discount_applied` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_cart`
--

INSERT INTO `zselex_cart` (`cart_id`, `user_id`, `is_guest`, `product_id`, `quantity`, `shop_id`, `cart_content`, `original_price`, `options_price`, `final_price`, `outofstock`, `stock`, `prd_answer`, `price`, `discount_applied`) VALUES
(2, '575d3f8434634', 1, 367, 9, 26, 'a:0:{}', '30.0000', '0.0000', '0.0000', 0, 0, '', '0.0000', 0),
(3, '575d3f8434634', 1, 358, 2, 26, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '401.0000', '150.0000', '300.0000', 0, 0, '', '150.0000', 0),
(4, '575d3f8434634', 1, 357, 1, 26, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '128.0000', '2.0000', '30.1600', 0, 0, '', '0.0000', 0),
(23, '577555922f688', 1, 367, 1, 26, 'a:0:{}', '30.0000', '0.0000', '27.0000', 0, 25, '', '27.0000', 1),
(41, '3', 0, 367, 1, 26, 'a:0:{}', '30.0000', '0.0000', '27.0000', 0, 17, '', '27.0000', 1),
(22, '577555922f688', 1, 358, 3, 26, 'a:0:{}', '401.0000', '0.0000', '1082.7000', 0, 100, '', '360.9000', 1),
(25, '5775712fc95c8', 1, 358, 2, 26, 'a:0:{}', '401.0000', '0.0000', '721.8000', 0, 100, '', '360.9000', 1),
(26, '57758f11ac4f0', 1, 358, 1, 26, 'a:0:{}', '401.0000', '0.0000', '360.9000', 0, 100, '', '360.9000', 1),
(40, '3', 0, 357, 1, 26, 'a:0:{}', '128.0000', '0.0000', '28.1600', 0, 59, '', '28.1600', 1);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_category`
--

CREATE TABLE `zselex_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `description` longtext,
  `status` tinyint(1) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_category`
--

INSERT INTO `zselex_category` (`category_id`, `category_name`, `description`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(2, 'Clothes', '', 1, '2012-03-15 00:00:00', 3, '2012-03-15 00:00:00', 3),
(3, 'Travel', '', 1, '2012-03-15 00:00:00', 3, '2012-03-15 00:00:00', 3),
(4, 'Food', '', 1, '2012-11-23 00:00:00', 2, '2013-04-19 00:00:00', 3),
(5, 'Other', '', 1, '2012-11-23 00:00:00', 2, '2012-11-23 00:00:00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_city`
--

CREATE TABLE `zselex_city` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(500) NOT NULL,
  `region_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL,
  `obj_status` varchar(10) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_city`
--

INSERT INTO `zselex_city` (`city_id`, `city_name`, `region_id`, `country_id`, `description`, `status`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(23, 'Fredericia', 7, 61, '', 1, '', '2012-03-07 18:45:24', 2, '2013-04-19 10:55:37', 2),
(24, 'Middelfart', 14, 61, '', 1, '', '2012-03-07 18:45:43', 2, '2013-06-13 11:00:35', 2),
(28, 'Aarhus', 8, 61, '', 1, '', '2012-03-07 18:48:50', 2, '2013-04-19 10:54:06', 2),
(26, 'København', 11, 61, '', 1, '', '2012-03-07 18:46:29', 2, '2013-04-19 10:54:57', 2),
(27, 'Aalborg', 9, 61, '', 1, '', '2012-03-07 18:47:31', 2, '2013-04-19 10:54:29', 2),
(29, 'Cochin', 0, 0, 'asdasd', 1, '', '2012-12-12 10:58:18', 3, '2012-12-12 10:58:18', 3),
(30, 'Vejle', 7, 61, '', 1, '', '2013-09-11 17:11:21', 2, '2013-09-11 17:11:21', 2),
(31, 'Kolding', 7, 61, '', 1, '', '2013-09-11 17:11:50', 2, '2013-09-11 17:11:50', 2),
(32, 'Odense', 14, 61, '', 1, '', '2013-09-11 17:12:22', 2, '2013-09-11 17:12:22', 2),
(33, 'Bangalore', 16, 61, '', 1, '', '2014-07-14 11:25:36', 3, '2014-07-14 11:25:36', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_country`
--

CREATE TABLE `zselex_country` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(100) NOT NULL,
  `description` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `obj_status` varchar(20) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_country`
--

INSERT INTO `zselex_country` (`country_id`, `country_name`, `description`, `status`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'AFGHANISTAN', 0, 1, '', '0000-00-00 00:00:00', 0, '2012-11-07 16:52:03', 3),
(2, 'ALAND ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(3, 'ALBANIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(4, 'ALGERIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(5, 'AMERICAN SAMOA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(6, 'ANDORRA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(7, 'ANGOLA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(8, 'ANGUILLA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(9, 'ANTARCTICA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(10, 'ANTIGUA AND BARBUDA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(11, 'ARGENTINA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(12, 'ARMENIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(13, 'ARUBA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(14, 'AUSTRALIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(15, 'AUSTRIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(16, 'AZERBAIJAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(17, 'BAHAMAS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(18, 'BAHRAIN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(19, 'BANGLADESH', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(20, 'BARBADOS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(21, 'BELARUS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(22, 'BELGIUM', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(23, 'BELIZE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(24, 'BENIN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(25, 'BERMUDA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(26, 'BHUTAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(27, 'BOLIVIA, PLURINATIONAL STATE OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(28, 'BONAIRE, SINT EUSTATIUS AND SABA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(29, 'BOSNIA AND HERZEGOVINA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(30, 'BOTSWANA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(31, 'BOUVET ISLAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(32, 'BRAZIL', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(33, 'BRITISH INDIAN OCEAN TERRITORY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(34, 'BRUNEI DARUSSALAM', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(35, 'BULGARIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(36, 'BURKINA FASO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(37, 'BURUNDI', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(38, 'CAMBODIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(39, 'CAMEROON', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(40, 'CANADA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(41, 'CAPE VERDE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(42, 'CAYMAN ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(43, 'CENTRAL AFRICAN REPUBLIC', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(44, 'CHAD', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(45, 'CHILE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(46, 'CHINA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(47, 'CHRISTMAS ISLAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(48, 'COCOS (KEELING) ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(49, 'COLOMBIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(50, 'COMOROS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(51, 'CONGO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(52, 'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(53, 'COOK ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(54, 'COSTA RICA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(55, 'COTE D\'IVOIRE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(56, 'CROATIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(57, 'CUBA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(58, 'CURACAO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(59, 'CYPRUS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(60, 'CZECH REPUBLIC', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(61, 'DENMARK', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(62, 'DJIBOUTI', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(63, 'DOMINICA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(64, 'DOMINICAN REPUBLIC', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(65, 'ECUADOR', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(66, 'EGYPT', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(67, 'EL SALVADOR', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(68, 'EQUATORIAL GUINEA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(69, 'ERITREA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(70, 'ESTONIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(71, 'ETHIOPIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(72, 'FALKLAND ISLANDS (MALVINAS)', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(73, 'FAROE ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(74, 'FIJI', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(75, 'FINLAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(76, 'FRANCE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(77, 'FRENCH GUIANA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(78, 'FRENCH POLYNESIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(79, 'FRENCH SOUTHERN TERRITORIES', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(80, 'GABON', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(81, 'GAMBIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(82, 'GEORGIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(83, 'GERMANY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(84, 'GHANA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(85, 'GIBRALTAR', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(86, 'GREECE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(87, 'GREENLAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(88, 'GRENADA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(89, 'GUADELOUPE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(90, 'GUAM', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(91, 'GUATEMALA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(92, 'GUERNSEY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(93, 'GUINEA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(94, 'GUINEA-BISSAU', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(95, 'GUYANA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(96, 'HAITI', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(97, 'HEARD ISLAND AND MCDONALD ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(98, 'HOLY SEE (VATICAN CITY STATE)', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(99, 'HONDURAS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(100, 'HONG KONG', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(101, 'HUNGARY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(102, 'ICELAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(103, 'INDIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(104, 'INDONESIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(105, 'IRAN, ISLAMIC REPUBLIC OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(106, 'IRAQ', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(107, 'IRELAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(108, 'ISLE OF MAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(109, 'ISRAEL', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(110, 'ITALY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(111, 'JAMAICA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(112, 'JAPAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(113, 'JERSEY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(114, 'JORDAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(115, 'KAZAKHSTAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(116, 'KENYA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(117, 'KIRIBATI', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(118, 'KOREA, DEMOCRATIC PEOPLE\'S REPUBLIC OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(119, 'KOREA, REPUBLIC OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(120, 'KUWAIT', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(121, 'KYRGYZSTAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(122, 'LAO PEOPLE\'S DEMOCRATIC REPUBLIC', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(123, 'LATVIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(124, 'LEBANON', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(125, 'LESOTHO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(126, 'LIBERIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(127, 'LIBYAN ARAB JAMAHIRIYA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(128, 'LIECHTENSTEIN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(129, 'LITHUANIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(130, 'LUXEMBOURG', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(131, 'MACAO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(132, 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(133, 'MADAGASCAR', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(134, 'MALAWI', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(135, 'MALAYSIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(136, 'MALDIVES', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(137, 'MALI', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(138, 'MALTA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(139, 'MARSHALL ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(140, 'MARTINIQUE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(141, 'MAURITANIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(142, 'MAURITIUS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(143, 'MAYOTTE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(144, 'MEXICO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(145, 'MICRONESIA, FEDERATED STATES OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(146, 'MOLDOVA, REPUBLIC OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(147, 'MONACO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(148, 'MONGOLIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(149, 'MONTENEGRO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(150, 'MONTSERRAT', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(151, 'MOROCCO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(152, 'MOZAMBIQUE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(153, 'MYANMAR', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(154, 'NAMIBIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(155, 'NAURU', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(156, 'NEPAL', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(157, 'NETHERLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(158, 'NEW CALEDONIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(159, 'NEW ZEALAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(160, 'NICARAGUA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(161, 'NIGER', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(162, 'NIGERIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(163, 'NIUE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(164, 'NORFOLK ISLAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(165, 'NORTHERN MARIANA ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(166, 'NORWAY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(167, 'OMAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(168, 'PAKISTAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(169, 'PALAU', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(170, 'PALESTINIAN TERRITORY, OCCUPIED', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(171, 'PANAMA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(172, 'PAPUA NEW GUINEA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(173, 'PARAGUAY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(174, 'PERU', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(175, 'PHILIPPINES', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(176, 'PITCAIRN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(177, 'POLAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(178, 'PORTUGAL', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(179, 'PUERTO RICO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(180, 'QATAR', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(181, 'REUNION', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(182, 'ROMANIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(183, 'RUSSIAN FEDERATION', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(184, 'RWANDA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(185, 'SAINT BARTHELEMY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(186, 'SAINT HELENA, ASCENSION AND TRISTAN DA CUNHA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(187, 'SAINT KITTS AND NEVIS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(188, 'SAINT LUCIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(189, 'SAINT MARTIN (FRENCH PART)', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(190, 'SAINT PIERRE AND MIQUELON', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(191, 'SAINT VINCENT AND THE GRENADINES', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(192, 'SAMOA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(193, 'SAN MARINO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(194, 'SAO TOME AND PRINCIPE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(195, 'SAUDI ARABIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(196, 'SENEGAL', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(197, 'SERBIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(198, 'SEYCHELLES', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(199, 'SIERRA LEONE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(200, 'SINGAPORE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(201, 'SINT MAARTEN (DUTCH PART)', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(202, 'SLOVAKIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(203, 'SLOVENIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(204, 'SOLOMON ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(205, 'SOMALIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(206, 'SOUTH AFRICA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(207, 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(208, 'SPAIN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(209, 'SRI LANKA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(210, 'SUDAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(211, 'SURINAME', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(212, 'SVALBARD AND JAN MAYEN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(213, 'SWAZILAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(214, 'SWEDEN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(215, 'SWITZERLAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(216, 'SYRIAN ARAB REPUBLIC', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(217, 'TAIWAN, PROVINCE OF CHINA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(218, 'TAJIKISTAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(219, 'TANZANIA, UNITED REPUBLIC OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(220, 'THAILAND', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(221, 'TIMOR-LESTE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(222, 'TOGO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(223, 'TOKELAU', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(224, 'TONGA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(225, 'TRINIDAD AND TOBAGO', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(226, 'TUNISIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(227, 'TURKEY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(228, 'TURKMENISTAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(229, 'TURKS AND CAICOS ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(230, 'TUVALU', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(231, 'UGANDA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(232, 'UKRAINE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(233, 'UNITED ARAB EMIRATES', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(234, 'UNITED KINGDOM', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(235, 'UNITED STATES', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(236, 'UNITED STATES MINOR OUTLYING ISLANDS', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(237, 'URUGUAY', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(238, 'UZBEKISTAN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(239, 'VANUATU', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(240, 'VENEZUELA, BOLIVARIAN REPUBLIC OF', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(241, 'VIET NAM', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(242, 'VIRGIN ISLANDS, BRITISH', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(243, 'VIRGIN ISLANDS, U.S.', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(244, 'WALLIS AND FUTUNA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(245, 'WESTERN SAHARA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(246, 'YEMEN', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(247, 'ZAMBIA', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(248, 'ZIMBABWE', 0, 1, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_discounts`
--

CREATE TABLE `zselex_discounts` (
  `discount_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `discount_code` varchar(250) NOT NULL,
  `discount` varchar(250) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_discounts`
--

INSERT INTO `zselex_discounts` (`discount_id`, `shop_id`, `discount_code`, `discount`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 26, 'test', '50', 1, '2015-12-17', 3, '2015-12-17', 3),
(2, 26, 'test1', '50%', 1, '2015-12-17', 3, '2015-12-17', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_dotd`
--

CREATE TABLE `zselex_dotd` (
  `dotdId` int(11) NOT NULL,
  `dotd_name` varchar(50) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `dotd_date` varchar(50) NOT NULL,
  `keywords` text NOT NULL,
  `column_name` varchar(50) NOT NULL,
  `value` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `cr_date` varchar(50) NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` varchar(50) NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_dotd`
--

INSERT INTO `zselex_dotd` (`dotdId`, `dotd_name`, `shop_id`, `user_id`, `dotd_date`, `keywords`, `column_name`, `value`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'DemoShop Deal of the day product', 23, 5, '2012-08-30', '', 'products_id', '23', 1, '2012-08-30 14:02:59', 5, '2012-08-30 14:02:59', 5),
(2, 'Test Buy', 26, 5, '2012-09-01', '', 'productId', '3', 1, '2012-08-31 15:55:11', 5, '2012-08-31 15:59:18', 5),
(3, 'Test2 Buy', 25, 5, '2012-08-31', '', 'productId', '3', 1, '2012-08-31 15:59:53', 5, '2012-08-31 15:59:53', 5),
(4, 'test2', 25, 5, '2012-10-03', '', 'productId', '1', 1, '2012-10-02 19:06:58', 5, '2012-10-02 19:06:58', 5),
(6, 'Test4', 14, 2, '2012-10-04', '', 'products_id', '408', 1, '2012-10-02 19:14:36', 2, '2012-10-04 19:53:27', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_files`
--

CREATE TABLE `zselex_files` (
  `file_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image_height` varchar(100) DEFAULT NULL,
  `image_width` varchar(100) DEFAULT NULL,
  `dispname` varchar(255) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `filedescription` longtext,
  `keywords` longtext,
  `defaultImg` smallint(6) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_files`
--

INSERT INTO `zselex_files` (`file_id`, `name`, `image_height`, `image_width`, `dispname`, `shop_id`, `user_id`, `filedescription`, `keywords`, `defaultImg`, `status`, `sort_order`) VALUES
(1, 'shop_newyork_pic.jpg', NULL, NULL, '', 18, 5, '', '', 0, 1, 0),
(2, 'Tulips.jpg', NULL, NULL, '', 23, 5, '', '', 0, 1, 0),
(3, '1351511242_preview_small.png', NULL, NULL, '', 23, 5, 'test...', '', 0, 1, 0),
(4, 'Chrysanthemum.jpg', NULL, NULL, '', 18, 5, 'sample....\r\n', '', 0, 1, 0),
(7, '1338556291_Shirt.jpg', NULL, NULL, '', 23, 5, '', '', 0, 1, 0),
(8, '1343130255_edit.gif', NULL, NULL, '', 18, 5, '', '', 0, 1, 0),
(9, '1343130599_template.gif', NULL, NULL, '', 25, 5, '', '', 0, 1, 0),
(10, '1345560278_shop_newyork_pic.jpg', NULL, NULL, '', 23, 3, 'xzzxczxc', '', 0, 1, 0),
(11, '1345810088_Life_1021090101.jpg', NULL, NULL, '', 25, 5, '', '', 0, 1, 0),
(12, '1345810117_shop_newyork_pic.jpg', NULL, NULL, '', 25, 5, '', '', 0, 1, 0),
(14, '1366100960_Life_1021090101.jpg', NULL, NULL, '', 14, 3, 'hellllooooooooo TEST', 'test keyword', 0, 1, 0),
(17, '1366373662_shop_newyork_pic.jpg', NULL, NULL, '', 14, 3, 'asdsadasdasd', 'check1 , check2', 0, 1, 0),
(18, '847be1e1814b_HK_Kln_Bay_Amoy_Plaza_shops.JPG', NULL, NULL, '', 14, 3, 'ghfghf fghfgh', '', 0, 1, 0),
(272, 'event-demo11_e44757dac908e1a02ebefe5894f9ba83.jpg', NULL, NULL, 'event-demo11_e44757dac908e1a02ebefe5894f9ba83.jpg', 26, 3, NULL, NULL, 0, 1, 0),
(263, 'e01-inactive.jpg', NULL, NULL, '', 57, 3, '', '', 0, 1, 0),
(264, 'e10-image_in_minishop_wrong.jpg', NULL, NULL, '', 57, 3, '', '', 0, 1, 0),
(269, 'Jellyfish.jpg', NULL, NULL, 'Jellyfish.jpg', 57, 3, NULL, NULL, 0, 1, 0),
(270, 'Tulips-2e2c22636972e036f74d4b1563ee555c.jpg', NULL, NULL, 'Tulips-2e2c22636972e036f74d4b1563ee555c.jpg', 26, 3, '', NULL, 1, 1, 0),
(271, 'mini_744ede88c4d244cb7a96e705a7101ef8.jpg', NULL, NULL, 'mini_744ede88c4d244cb7a96e705a7101ef8.jpg', 26, 3, NULL, NULL, 0, 1, 0),
(273, 'story_77_w69lzsMHbEoTTnZdeTsW_800X800_5d2ebc3b072a9b921fdb82bee17b8a8b.jpg', NULL, NULL, 'story_77_w69lzsMHbEoTTnZdeTsW_800X800_5d2ebc3b072a9b921fdb82bee17b8a8b.jpg', 61, 3, NULL, NULL, 0, 1, 0),
(274, 'Big_befe8bb69fcace452e200de59e2afee6.png', NULL, NULL, 'Big_befe8bb69fcace452e200de59e2afee6.png', 61, 3, NULL, NULL, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_keywords`
--

CREATE TABLE `zselex_keywords` (
  `keyword_id` int(11) NOT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_keywords`
--

INSERT INTO `zselex_keywords` (`keyword_id`, `keyword`, `type`, `type_id`, `shop_id`) VALUES
(1, 'KeepRunning', 'shop', 14, 14),
(2, 'DemoShop', 'shop', 23, 23),
(3, 'newIshop', 'shop', 26, 26),
(4, 'ishop2', 'shop', 57, 57),
(5, 'Spar Nord Fredericia', 'shop', 58, 58),
(6, 'trstshopFredrica', 'shop', 59, 59),
(7, 'Meldahls Rådhus', 'shop', 60, 60),
(8, 'MondayShop', 'shop', 61, 61),
(9, 'HEllooo2', 'shop', 63, 63),
(10, '6. juli garden', 'shop', 64, 64),
(11, 'Amoc', 'shop', 65, 65),
(12, 'Anne Vibeke Rossing', 'shop', 66, 66),
(13, 'Arbejdernes Landsbank', 'shop', 67, 67),
(14, 'Axeltorvs Apotek', 'shop', 68, 68),
(15, 'B H Magasinet', 'shop', 69, 69),
(16, 'Bianco', 'shop', 70, 70),
(17, 'Billunds Boghandel', 'shop', 71, 71),
(18, 'Bison Lædervarer ApS', 'shop', 72, 72),
(19, 'Bjerggeden og Byrotten', 'shop', 73, 73),
(20, 'Booking Huset', 'shop', 74, 74),
(21, 'BT Centralen', 'shop', 75, 75),
(22, 'BT Gulve og Gardiner A/S', 'shop', 76, 76),
(23, 'Budstikken', 'shop', 77, 77),
(24, 'Café den 7 himmel', 'shop', 78, 78),
(25, 'Café nr. 47', 'shop', 79, 79),
(26, 'Rustik Cafe & Restaurant', 'shop', 80, 80),
(27, 'Chilli', 'shop', 81, 81),
(28, 'Cykelservice', 'shop', 82, 82),
(29, 'DanmarkC TV', 'shop', 83, 83),
(30, 'Davidsen Tømmerhandel', 'shop', 84, 84),
(31, 'Deluxe', 'shop', 85, 85),
(32, 'Danske bank', 'shop', 86, 86),
(33, 'Den Engelske', 'shop', 87, 87),
(34, 'Det Bruunske Pakhus', 'shop', 88, 88),
(35, 'Ecco', 'shop', 89, 89),
(36, 'Elbo Bladet', 'shop', 90, 90),
(37, 'Event C', 'shop', 91, 91),
(38, 'Festmesteren', 'shop', 92, 92),
(39, 'Flair', 'shop', 93, 93),
(40, 'Flashlight gruppen', 'shop', 94, 94),
(41, 'Fleur', 'shop', 95, 95),
(42, 'Flügger Farve', 'shop', 96, 96),
(43, 'Fona', 'shop', 97, 97),
(44, 'Fotograf Helle S. Andersen', 'shop', 98, 98),
(45, 'Fredericia Bibliotek', 'shop', 99, 99),
(46, 'Fredericia Dagblad', 'shop', 100, 100),
(47, 'Fredericia Skiltefabrik', 'shop', 101, 101),
(48, 'Fredericia Teater', 'shop', 102, 102),
(49, 'Fredericia Vinhandel', 'shop', 103, 103),
(50, 'Føtex city', 'shop', 104, 104),
(51, 'Føtex Vest', 'shop', 105, 105),
(52, 'Geist & Gnist', 'shop', 106, 106),
(53, 'Guldbageren', 'shop', 107, 107),
(54, 'Guldperlen', 'shop', 108, 108),
(55, 'Handelsbanken', 'shop', 109, 109),
(56, 'Hauge', 'shop', 110, 110),
(57, 'Havanna sko', 'shop', 111, 111),
(58, 'Helsekosten', 'shop', 112, 112),
(59, 'Hennes & Mauritz', 'shop', 113, 113),
(60, 'High end sport', 'shop', 114, 114),
(61, 'HK Midt', 'shop', 115, 115),
(62, 'Holst sko', 'shop', 116, 116),
(63, 'Home Fredericia', 'shop', 117, 117),
(64, 'Imerco', 'shop', 118, 118),
(65, 'Jyske Bank', 'shop', 119, 119),
(66, 'Klokken', 'shop', 120, 120),
(67, 'Kop og Kande', 'shop', 121, 121),
(68, 'LB Dans', 'shop', 122, 122),
(69, 'Le noir', 'shop', 123, 123),
(70, 'Lucullus Smørebrød', 'shop', 124, 124),
(71, 'Løve Apoteket Vestcentretret', 'shop', 125, 125),
(72, 'Matas Gothersgade', 'shop', 126, 126),
(73, 'Matas Vendersgade', 'shop', 127, 127),
(74, 'Miami', 'shop', 128, 128),
(75, 'Middelfart Sparekasse', 'shop', 129, 129),
(76, 'Mr. Højer', 'shop', 130, 130),
(77, 'Nordea', 'shop', 131, 131),
(78, 'Nü by Staff', 'shop', 132, 132),
(79, 'Nykredit', 'shop', 133, 133),
(80, 'Optik Hallmann', 'shop', 134, 134),
(81, 'Ostejyden', 'shop', 135, 135),
(82, 'Panorama', 'shop', 136, 136),
(83, 'Photo care', 'shop', 137, 137),
(84, 'Pigernes Verden', 'shop', 138, 138),
(85, 'Pro Print', 'shop', 139, 139),
(86, 'Profil Optik', 'shop', 140, 140),
(87, 'Radio Fredericia', 'shop', 141, 141),
(88, 'Ranch Svendsen', 'shop', 142, 142),
(89, 'Restaurant Generalen', 'shop', 143, 143),
(90, 'Restaurant Oven Vande', 'shop', 144, 144),
(91, 'Sadolin Farvehandel', 'shop', 145, 145),
(92, 'Sejersen - Din tøjmand', 'shop', 146, 146),
(93, 'Simone', 'shop', 147, 147),
(94, 'Skoringen', 'shop', 148, 148),
(95, 'Nyt Syn', 'shop', 149, 149),
(96, 'Sport24', 'shop', 150, 150),
(97, 'Sportmaster', 'shop', 151, 151),
(98, 'Standard', 'shop', 152, 152),
(99, 'Stark Fredericia', 'shop', 153, 153),
(100, 'Støvsugereksperten', 'shop', 154, 154),
(101, 'Superbrugsen Erritsø', 'shop', 155, 155),
(102, 'Sydbank', 'shop', 156, 156),
(103, 'Synoptik', 'shop', 157, 157),
(104, 'Tantes Have', 'shop', 158, 158),
(105, 'Telenor', 'shop', 159, 159),
(106, 'The og ide', 'shop', 160, 160),
(107, 'Thiele Briller', 'shop', 161, 161),
(108, 'Tre-for', 'shop', 162, 162),
(109, 'Tøjeksperten', 'shop', 163, 163),
(110, 'USO ', 'shop', 164, 164),
(111, 'Vestbyens Herretøj', 'shop', 165, 165),
(112, 'Vestfyns Bank', 'shop', 166, 166),
(113, 'Vinoble', 'shop', 167, 167),
(114, 'Willox', 'shop', 168, 168),
(115, 'Zederkof', 'shop', 169, 169),
(116, 'Zizzi', 'shop', 170, 170),
(117, 'Zoffman Optik', 'shop', 171, 171),
(118, 'Spaabæk Clinic', 'shop', 172, 172),
(119, 'Frk Nipz', 'shop', 173, 173),
(120, 'Tegllund', 'shop', 174, 174),
(121, 'CompuConsult Data', 'shop', 175, 175),
(122, 'Coach til salg', 'shop', 176, 176),
(123, 'Skjold Burne', 'shop', 177, 177),
(124, 'Garn klip og styling', 'shop', 178, 178),
(125, 'Cykelsmeden', 'shop', 179, 179),
(126, 'Butik Smagløs', 'shop', 180, 180),
(127, 'Lydbureauet', 'shop', 181, 181),
(128, 'Marcus', 'shop', 182, 182),
(129, 'Cafe Mair', 'shop', 183, 183),
(130, 'Hårværk', 'shop', 184, 184),
(131, 'Botique Unique', 'shop', 185, 185),
(132, 'Calle & Co', 'shop', 186, 186),
(133, 'Dueholm Begravelsesforretning', 'shop', 187, 187),
(134, 'Frelsens Chokolade', 'shop', 188, 188),
(135, 'DE Eletronink/Skilte Værkstedet', 'shop', 189, 189),
(136, 'Garnkælderen', 'shop', 190, 190),
(137, 'Isabellas Reataurant og Steakhaouse', 'shop', 191, 191),
(138, 'fieV Photo & Design', 'shop', 192, 192),
(139, 'Domisil', 'shop', 193, 193),
(140, 'House of melfar', 'shop', 194, 194),
(141, 'Nybolig', 'shop', 195, 195),
(142, 'Vinspecialisten Fredericia', 'shop', 196, 196),
(143, 'Løve Apoteket Vestcentret', 'shop', 197, 197),
(144, 'hello 007', 'shop', 199, 199),
(145, 'Sharaz\\\'s Shop', 'shop', 198, 198),
(146, 'Tijo\\\'s Shop', 'shop', 200, 200),
(147, 'New Sharaz Shop', 'shop', 201, 201),
(261, 'story_83_8c7XnDJwMRK7b4rMased_800X800', 'product', 371, 61),
(262, 'story_77_w69lzsMHbEoTTnZdeTsW_800X800', 'product', 372, 61),
(258, 'Koala', 'product', 366, 198),
(259, 'preview_medium', 'product', 367, 26),
(260, 'XEvent-KlausServants_17e06999710685bf523c904bde57ed3d', 'product', 368, 26),
(257, 'Tulips', 'product', 365, 198),
(255, 'Jellyfish', 'product', 363, 198),
(256, 'Penguins', 'product', 364, 198),
(254, 'Lighthouse', 'product', 362, 198),
(253, 'Desert', 'product', 361, 198),
(252, 'Chrysanthemum', 'product', 360, 198),
(251, 'Hydrangeas', 'product', 359, 198),
(250, 'Nokia Lumia 724', 'product', 358, 26),
(247, 'social_icons', 'product', 370, 61),
(249, 'test007', 'product', 357, 26),
(248, 'vadakan', 'product', 369, 61),
(246, '20140718_143123', 'product', 162, 14),
(245, 'IMG-20140729-WA0004', 'product', 161, 14),
(244, 'IMG-20140729-WA0006', 'product', 160, 14),
(243, 'IMG-20140729-WA0009', 'product', 159, 14),
(242, 'vacancies banner 940 x 342 ver3', 'product', 158, 57),
(241, 'meal2012-940x340', 'product', 125, 57),
(240, 'images', 'product', 124, 57);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_manufacturer`
--

CREATE TABLE `zselex_manufacturer` (
  `manufacturer_id` bigint(20) NOT NULL,
  `manufacturer_name` varchar(255) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `description` longtext NOT NULL,
  `status` smallint(6) NOT NULL,
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_manufacturer`
--

INSERT INTO `zselex_manufacturer` (`manufacturer_id`, `manufacturer_name`, `shop_id`, `description`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(7, 'Nike', 26, '', 1, '2014-06-27', 3, '2014-06-27', 3),
(2, 'Puma', 26, '', 1, '2014-06-24', 3, '2014-06-24', 3),
(3, 'Nike', 26, '', 1, '2014-06-24', 3, '2014-06-24', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_minishop`
--

CREATE TABLE `zselex_minishop` (
  `id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `shoptype_id` smallint(6) DEFAULT NULL,
  `shoptype` varchar(255) DEFAULT NULL,
  `minishop_name` varchar(255) DEFAULT NULL,
  `description` longtext,
  `configured` tinyint(1) DEFAULT NULL,
  `cr_date` datetime DEFAULT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime DEFAULT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_minishop`
--

INSERT INTO `zselex_minishop` (`id`, `shop_id`, `shoptype_id`, `shoptype`, `minishop_name`, `description`, `configured`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 26, 0, 'iSHOP', 'dfgdfgdsfg', '', 1, '2014-10-17 16:48:30', 3, '2014-10-17 16:48:30', 3),
(2, 57, 0, 'iSHOP', '', '', 1, '2014-10-22 12:13:52', 3, '2014-10-22 12:13:52', 3),
(3, 14, 2, 'iSHOP', 'My Ishop', NULL, 1, '2014-11-10 16:02:55', 3, '2014-11-10 16:02:55', 3),
(4, 58, 2, 'iSHOP', 'My Ishop', NULL, 1, '2014-12-15 16:01:26', 2, '2014-12-15 16:01:26', 2),
(5, 63, 2, 'iSHOP', 'My Ishop', NULL, 1, '2015-02-28 18:55:19', 3, '2015-02-28 18:55:19', 3),
(6, 61, 2, 'iSHOP', 'My Ishop', NULL, 1, '2015-05-28 22:26:55', 3, '2015-05-28 22:26:55', 3),
(7, 23, 2, 'zSHOP', 'My Ishop', '', 1, '2015-10-05 00:33:02', 2, '2015-10-05 00:33:02', 2),
(8, 198, 2, 'iSHOP', 'My Ishop', NULL, 1, '2015-10-22 09:44:47', 3, '2015-10-22 09:44:47', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_ministe_updates`
--

CREATE TABLE `zselex_ministe_updates` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `update_date` varchar(100) NOT NULL,
  `is_updated_recent` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_ministe_updates`
--

INSERT INTO `zselex_ministe_updates` (`id`, `shop_id`, `owner_id`, `update_date`, `is_updated_recent`) VALUES
(1, 26, 3, '2016-06-14', 1),
(2, 14, 56, '2014-06-06', 1),
(6, 36, 0, '2013-05-22', 0),
(7, 23, 24, '2014-08-04', 1),
(8, 37, 21, '2013-12-14', 1),
(9, 15, 22, '2013-12-18', 1),
(10, 18, 20, '2013-08-28', 1),
(11, 32, 24, '2014-05-22', 1),
(12, 16, 55, '2013-09-16', 1),
(13, 38, 55, '2013-12-18', 1),
(14, 39, 56, '2014-03-06', 1),
(15, 33, 0, '2013-10-30', 1),
(16, 40, 57, '2013-09-04', 1),
(17, 17, 0, '2013-08-28', 1),
(18, 41, 59, '2013-09-25', 1),
(19, 42, 60, '2014-04-09', 1),
(20, 43, 0, '2013-09-11', 0),
(21, 44, 60, '2013-12-10', 1),
(22, 45, 0, '2013-09-11', 0),
(23, 46, 61, '2014-05-29', 1),
(24, 47, 62, '2013-09-17', 1),
(25, 48, 63, '2013-10-10', 1),
(26, 21, 0, '2013-10-09', 0),
(27, 49, 64, '2013-10-10', 1),
(28, 35, 0, '2013-11-18', 0),
(29, 50, 0, '2013-12-02', 0),
(30, 51, 0, '2014-04-28', 0),
(31, 52, 0, '2014-04-28', 0),
(32, 53, 0, '2014-05-30', 0),
(33, 54, 0, '2014-06-05', 0),
(34, 55, 0, '2014-06-05', 0),
(35, 56, 0, '2014-06-05', 0),
(36, 57, 22, '2014-10-22', 1),
(37, 58, 0, '2014-08-04', 1),
(38, 59, 0, '2014-08-04', 0),
(39, 60, 21, '2014-08-06', 1),
(40, 61, 3, '2016-06-24', 1),
(41, 62, 0, '2014-10-16', 0),
(42, 63, 0, '2014-10-16', 1),
(43, 196, 0, '2014-11-07', 0),
(44, 71, 0, '2014-11-07', 0),
(45, 192, 0, '2015-09-20', 1),
(46, 78, 0, '2014-12-15', 1),
(47, 197, 0, '2015-09-17', 0),
(48, 191, 0, '2015-09-17', 0),
(49, 125, 0, '2015-10-12', 1),
(50, 64, 0, '2015-10-22', 0),
(51, 198, 0, '2015-10-22', 0),
(52, 199, 0, '2016-02-10', 0),
(53, 200, 0, '2016-03-21', 0),
(54, 201, 0, '2016-03-21', 0),
(55, 73, 0, '2016-07-13', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_newsletter`
--

CREATE TABLE `zselex_newsletter` (
  `nl_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `user_email` varchar(2000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_newsletter`
--

INSERT INTO `zselex_newsletter` (`nl_id`, `user_id`, `shop_id`, `user_email`) VALUES
(1, 3, 26, 'sharaz.khan@r2international.com'),
(2, 2, 26, 'kim@acta-it.dk'),
(3, 576, 61, 'sharazkhanz@gmail.com'),
(4, 5775712, 26, 'sharazkhanz@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_order`
--

CREATE TABLE `zselex_order` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `address` longtext,
  `phone` varchar(255) DEFAULT NULL,
  `totalprice` decimal(15,4) DEFAULT NULL,
  `vat` decimal(15,4) DEFAULT NULL,
  `shipping` decimal(15,4) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `self_pickup` smallint(6) NOT NULL DEFAULT '0',
  `completed` smallint(6) NOT NULL DEFAULT '0',
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `zip` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_order`
--

INSERT INTO `zselex_order` (`id`, `order_id`, `shop_id`, `user_id`, `first_name`, `last_name`, `email`, `city`, `street`, `address`, `phone`, `totalprice`, `vat`, `shipping`, `status`, `payment_type`, `self_pickup`, `completed`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `zip`) VALUES
(121, 'ZS1212141', 26, '3', 'sharaz khan', 'ssdfasfaf', 'sharaz.khan@r2international.com', 'fasfds', '', 'asdfsdaf', '2147483647', '120.0000', '24.0000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(122, 'ZS1225994', 26, '3', 'asdfasdfs', 'fasdfasfsf', 'sharaz.khan@r2international.com', 'f', '', 'dasfasdf', '2147483647', '145.0000', '29.0000', '0.0000', '0', 'directpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(123, 'ZS1234790', 26, '3', 'sharaz khan', 'asdfsaf', 'sharaz.khan@r2international.com', 'fsad', '', 'sadfsdfsa', '2147483647', '120.0000', '24.0000', '0.0000', '0', 'paypal', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(124, 'ZS1247104', 26, '3', 'dsfgsdfgds', 'dsgdsg', 'sharaz.khan@r2international.com', 'aasfasf', '', 'dsfgdsg', '2147483647', '120.0000', '24.0000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(125, 'ZS1252622', 26, '3', 'gfsdfgsdf', 'gsdfgsdgfdsfgfsadds', 'sharaz.khan@r2international.com', 'gdfsg', '', 'fgdsgdsfg', '2147483647', '120.0000', '24.0000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(126, 'ZS1263939', 26, '3', 'dsfgsdfgdsssda', 'safsadf', 'sharaz.khan@r2international.com', 'sadfsadf', '', 'sadfsadfasa', '2147483647', '145.0000', '29.0000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(127, 'ZS1275941', 26, '3', 'sdfsfs', 'asdfsadfsasafsadff', 'sharaz.khan@r2international.com', 'fsadf', '', 'fsafsa', '2147483647', '353.0000', '70.6000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(128, 'ZS1285641', 26, '3', 'sdfsafasf', 'asfasdf', 'sharaz.khan@r2international.com', 'fsadf', '', 'sadfsdfsadf', '2147483647', '145.0000', '53.0000', '0.0000', '0', 'quickpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(129, 'ZS1299980', 26, '3', 'sharaz khan', 'asdfasdfdsaffssadf', 'sharaz.khan@r2international.com', 'sadfsadf', '', 'sadfsadfasa', '2147483647', '233.0000', '70.6000', '0.0000', '0', 'quickpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(130, 'ZS1305145', 26, '3', 'sadfsaf', 'dfsadfs', 'sharaz.khan@r2international.com', 'dfasdf', '', 'dfasdfsadf', '2147483647', '145.0000', '53.0000', '0.0000', '0', 'quickpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(131, 'ZS1314208', 26, '3', 'adsadaD', 'ADSAFASDF', 'sharaz.khan@r2international.com', 'DFF', '', 'SAFDASDF', '2147483647', '233.0000', '70.6000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(132, 'ZS1327982', 26, '3', 'sharaz khan', 'sdafasdsadfasf', 'sharaz.khan@r2international.com', 'sadfsadf', '', 'sadfsadfasdfsadf', '2147483647', '265.0000', '53.0000', '0.0000', '0', 'quickpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(133, 'ZS1335025', 26, '3', 'sharaz khan', 'fdsgsdg', 'sharaz.khan@r2international.com', 'gdsfg', '', 'sdgsdgds', '2147483647', '46.0000', '9.2000', '0.0000', '0', 'quickpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(134, 'ZS1343735', 26, '3', 'dsaf', 'sadfafasdfasfas', 'sharaz.khan@r2international.com', 'fasdfas', '', 'fasfasf', '2147483647', '12.0000', '2.4000', '0.0000', '0', 'paypal', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(135, 'ZS1356355', 26, '3', 'sdsadfsa', 'safasff', 'sharaz.khan@r2international.com', 'asfsaf', '', 'asffd', '2147483647', '46.0000', '9.2000', '0.0000', '0', 'quickpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(136, 'ZS1365841', 26, '3', 'sfafasf', 'asfasfasff', 'sharaz.khan@r2international.com', 'df', '', 'safsfsa', '2147483647', '46.0000', '6.8000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(137, 'ZS1378298', 26, '3', 'SFDASDFASDF', 'asdfasdfdsafdfasf', 'sharaz.khan@r2international.com', 'F', '', 'ASDFASDFAS', '2147483647', '34.0000', '13.6000', '0.0000', '0', 'paypal', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(138, 'ZS1383063', 26, '3', 'SFDASDFASDF', 'asdfasdfdsafdfasf', 'sharaz.khan@r2international.com', 'F', '', 'ASDFASDFAS', '2147483647', '34.0000', '6.8000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(139, 'ZS1397629', 26, '3', 'sharaz khan', 'dfgdsff', 'sharaz.khan@r2international.com', 'fsaf', '', 'asfsaff', '2147483647', '12.0000', '2.4000', '0.0000', '0', 'quickpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(140, 'ZS140654', 26, '3', 'sadfsadf', 'sadfsfda', 'sharaz.khan@r2international.com', 'safasfsdaf', '', 'asfasfsa', '7', '34.0000', '6.8000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(141, 'ZS1415314', 26, '3', 'sharaz khan', 'dfasfsaf', 'sharaz.khan@r2international.com', 'sadfasdf', '', 'sadfdsa', '2147483647', '12.0000', '2.4000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(142, 'ZS1429479', 26, '3', 'safd', 'safasdfsadf', 'sharaz.khan@r2international.com', 'fasdf', '', 'asdfasdf', '2147483647', '46.0000', '9.2000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(143, 'ZS1439539', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', '0', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(144, 'ZS1446168', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', '0', 'quickpay', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(145, 'ZS1451161', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', 'Placed', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(146, 'ZS1465674', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', 'Placed', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(147, 'ZS1471701', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', 'Placed', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(148, 'ZS1488149', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', 'Placed', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(149, 'ZS1498443', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', 'Placed', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(150, 'ZS1509300', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', 'Placed', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(151, 'ZS1519625', 26, '3', 'Armaan', 'Khan', 'sharaz.khan@r2international.com', 'bangalore', '', '05,spathagiri , ejipura , 24 f cross', '2147483647', '34.0000', '6.8000', '0.0000', 'Placed', 'netaxept', 0, 0, '0000-00-00', 0, '0000-00-00', 0, NULL),
(152, 'ZS1524649', 26, '3', 'sharaz', 'gvb', 'sharaz.khan@r2international.com', 'gghh', '', 'vvv', '7777777', '34.0000', '6.8000', '0.0000', 'Placed', 'paypal', 0, 0, '2014-06-11', 3, '2014-06-11', 3, NULL),
(153, 'ZS1539149', 26, '3', 'sharaz', 'gvb', 'sharazkhanz@gmail.com', 'gghh', '', 'vvv', '7777777', '34.0000', '6.8000', '0.0000', 'Success', 'netaxept', 0, 0, '2014-06-11', 3, '2014-06-11', 3, NULL),
(154, 'ZS1541454', 26, '3', 'sharaz ', 'khan', 'sharaz.khan@r2international.com', 'Bangalore', '', 'r2 , bangalore', '2147483647', '12.0000', '2.4000', '0.0000', 'Cancelled', 'quickpay', 0, 0, '2014-06-12', 3, '2014-06-12', 3, NULL),
(155, 'ZS1556128', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'fafsdf', '', 'hdfhgfdh', '2147483647', '24.7700', '4.9540', '0.0000', 'Placed', 'quickpay', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(156, 'ZS1569699', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'fafsdf', '', 'hdfhgfdh', '2147483647', '24.7700', '4.9540', '0.0000', 'Pending', 'paypal', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(157, 'ZS1573451', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'fafsdf', '', 'hdfhgfdh', '2147483647', '32.7700', '6.5540', '0.0000', 'Failed', 'netaxept', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(158, 'ZS1584054', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'fafsdf', '', 'hdfhgfdh', '2147483647', '32.7700', '6.5540', '0.0000', 'Success', 'netaxept', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(159, 'ZS1592078', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'fafsdf', '', 'hdfhgfdh', '2147483647', '29.7700', '5.9540', '0.0000', 'Pending', 'paypal', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(160, 'ZS1606639', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'sdfs', '', 'ddxfsd', '777777', '65.5400', '13.1080', '0.0000', 'Placed', 'directpay', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(161, 'ZS1614944', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'sdfs', '', 'ddxfsd', '777777', '65.5400', '13.1080', '0.0000', 'Cancelled', 'paypal', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(162, 'ZS1628541', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'sdfs', '', 'ddxfsd', '777777', '65.5400', '13.1080', '0.0000', 'Cancelled', 'paypal', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(163, 'ZS1634062', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'sdfs', '', 'ddxfsd', '777777', '65.5400', '13.1080', '0.0000', 'Cancelled', 'quickpay', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(164, 'ZS1641379', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'sdfs', '', 'ddxfsd', '777777', '26.7700', '5.3540', '0.0000', 'Pending', 'paypal', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(165, 'ZS1656397', 26, '3', 'sharaz', 'khan', 'sharazkhanz@gmail.com', 'sdfs', '', 'ddxfsd', '777777', '59.5400', '11.9080', '0.0000', 'Pending', 'paypal', 0, 0, '2014-07-23', 3, '2014-07-23', 3, NULL),
(166, 'ZS166813', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'fafsdf', '', 'hdfhgfdh', '2147483647', '58.9400', '11.7880', '0.0000', 'Pending', 'paypal', 0, 0, '2014-07-24', 3, '2014-07-24', 3, NULL),
(167, 'ZS1673492', 26, '3', 'sharaz khan', 'khan', 'sharaz.khan@r2international.com', 'Bangalore', '', 'sdfsadf', '2147483647', '192.0000', '38.4000', '0.0000', 'Pending', 'paypal', 0, 0, '2014-08-12', 3, '2014-08-12', 3, NULL),
(168, 'ZS1689424', 26, '3', 'sdsfsf', 'asdfsadfsasafsadf', 'sharaz.khan@r2international.com', 'fsadf', '', 'sadfsdf', '2147483647', '22.7700', '4.5540', '0.0000', 'Failed', 'netaxept', 0, 0, '2014-08-13', 3, '2014-08-13', 3, NULL),
(169, 'ZS1695675', 26, '3', 'sdsfsf', 'asdfsadfsasafsadf', 'sharaz.khan@r2international.com', 'fsadf', '', 'sadfsdf', '2147483647', '22.7700', '4.5540', '0.0000', 'Success', 'quickpay', 0, 0, '2014-08-13', 3, '2014-08-13', 0, NULL),
(170, 'ZS1702778', 26, '3', 'sdsfsf', 'asdfsadfsasafsadf', 'sharaz.khan@r2international.com', 'fsadf', '', 'sadfsdf', '2147483647', '22.7700', '4.5540', '0.0000', 'Placed', 'netaxept', 0, 0, '2014-08-13', 3, '2014-08-13', 3, NULL),
(171, 'ZS1713155', 26, '3', 'sdsfsf', 'asdfsadfsasafsadf', 'sharaz.khan@r2international.com', 'fsadf', '', 'sadfsdf', '2147483647', '22.7700', '4.5540', '0.0000', 'Placed', 'netaxept', 0, 0, '2014-08-13', 3, '2014-08-13', 3, NULL),
(172, 'ZS1721979', 26, '3', 'sdsfsf', 'asdfsadfsasafsadf', 'sharaz.khan@r2international.com', 'fsadf', '', 'sadfsdf', '2147483647', '22.7700', '4.5540', '0.0000', 'Pending', 'paypal', 0, 0, '2014-08-13', 3, '2014-08-13', 3, NULL),
(173, 'ZS1735132', 26, '3', 'saddsfds', 'fsdfs', 'sharaz.khan@r2international.com', 'fsadf', '', 'fsadfsaff', '2147483647', '24.7700', '4.9540', '0.0000', 'Success', 'netaxept', 0, 0, '2014-08-13', 3, '2014-08-13', 3, NULL),
(174, 'ZS1741886', 26, '3', 'saddsfds', 'fsdfs', 'sharaz.khan@r2international.com', 'fsadf', '', 'fsadfsaff', '2147483647', '22.7700', '4.5540', '0.0000', 'Success', 'quickpay', 0, 0, '2014-08-13', 3, '2014-08-13', 0, NULL),
(175, 'ZS1755376', 26, '3', 'saddsfds', 'fsdfs', 'sharaz.khan@r2international.com', 'fsadf', '', 'fsadfsaff', '2147483647', '22.7700', '4.5540', '0.0000', 'Success', 'netaxept', 0, 0, '2014-08-13', 3, '2014-08-13', 3, NULL),
(176, 'ZS1765442', 26, '3', 'saddsfds', 'fsdfs', 'sharaz.khan@r2international.com', 'fsadf', '', 'fsadfsaff', '2147483647', '22.7700', '4.5540', '0.0000', 'Success', 'quickpay', 0, 0, '2014-08-13', 3, '2014-08-13', 0, NULL),
(177, 'ZS1773622', 26, '3', 'saddsfds', 'fsdfs', 'sharaz.khan@r2international.com', 'fsadf', '', 'fsadfsaff', '2147483647', '22.7700', '4.5540', '0.0000', 'Success', 'netaxept', 0, 0, '2014-08-13', 3, '2014-08-13', 3, NULL),
(178, 'ZS1788028', 26, '3', 'sdsdfsa', 'sadfsafd', 'sharaz.khan@r2international.com', 'safsdaf', '', 'asfsaff', '2147483647', '25.7700', '5.1540', '0.0000', 'Success', 'quickpay', 0, 0, '2014-08-13', 3, '2014-08-13', 0, NULL),
(179, 'ZS1792954', 26, '3', 'sdsdfsa', 'sadfsafd', 'sharaz.khan@r2international.com', 'safsdaf', '', 'asfsaff', '2147483647', '25.7700', '5.1540', '0.0000', 'Success', 'quickpay', 0, 0, '2014-08-13', 3, '2014-08-13', 0, NULL),
(180, 'ZS1804950', 26, '3', 'sharaz', 'KHAN', 'sharaz.khan@r2international.com', 'sadfsdaf', '', 'dsfdsafsadf', '2147483647', '726.6000', '145.3200', '0.0000', 'Cancelled', 'quickpay', 0, 0, '2014-08-18', 3, '2014-08-18', 3, NULL),
(181, 'ZS1818982', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'dfsaf', '', 'sfdsdfa', '2147483647', '2289.0000', '457.8000', '0.0000', 'Pending', 'paypal', 0, 0, '2014-08-21', 3, '2014-08-21', 3, NULL),
(182, 'ZS1821989', 26, '2', 'kim', 'enemark', 'kim@acta-it.dk', 'Fredericia', '', 'prinsessegade 19', '75942434', '569.0000', '113.8000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-08-25', 2, '2014-08-25', 2, NULL),
(183, 'ZS1835485', 26, '3', 'sdsafas', 'adfsadff', 'sharaz.khan@r2international.com', 'fdsafdsaf', '', 'sdafsadf', '2147483647', '1132.0000', '226.4000', '0.0000', 'Success', 'netaxept', 0, 0, '2014-09-01', 3, '2014-09-01', 3, NULL),
(184, 'ZS1847900', 26, '3', 'ef', 'asfasdf', 'sharaz.khan@r2international.com', 'sadfsadf', '', 'fsadfsad', '2147483647', '1704.0000', '340.8000', '0.0000', 'Success', 'quickpay', 0, 0, '2014-09-01', 3, '2014-09-01', 0, NULL),
(185, 'ZS185908', 26, '3', 'sharaz', 'khan', 'sharaz.khan@r2international.com', 'asfdasdf', '', 'dfdasfsa', '2147483647', '6237.0000', '1247.4000', '0.0000', 'Pending', 'paypal', 0, 0, '2014-09-01', 3, '2014-09-01', 3, NULL),
(186, 'ZS186174', 26, '3', 'ssdasfs', 'sadfsafdf', 'sharaz.khan@r2international.com', 'fsdaf', '', 'sadfsafd', '2147483647', '3402.0000', '680.4000', '0.0000', 'Pending', 'paypal', 0, 0, '2014-09-15', 3, '2014-09-15', 3, NULL),
(187, 'ZS187481', 26, '3', 'adsad', 'safdsaf', 'sharaz.khan@r2international.com', 'sadf', '', 'safsaf', '2147483647', '567.0000', '113.4000', '0.0000', 'Success', 'netaxept', 0, 0, '2014-09-15', 3, '2014-09-15', 3, NULL),
(188, 'ZS1888080', 26, '3', 'sfsdfd', 'gsdfgdsf', 'sharaz.khan@r2international.com', 'fdsfg', '', 'gfdsgdsf', '2147483647', '567.0000', '113.4000', '0.0000', 'Success', 'quickpay', 0, 0, '2014-09-15', 3, '2014-09-15', 0, NULL),
(189, 'ZS189344', 26, '3', 'safsadfs', 'afsadfsa', 'sharaz.khan@r2international.com', 'dfsadfsaf', '', 'fsafas', '2147483647', '567.0000', '113.4000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-09-15', 3, '2014-09-15', 3, NULL),
(190, 'ZS1901022', 26, '3', 'sfsdfasdfd', 'fgdsgdsfgdsf', 'sharaz.khan@r2international.com', 'fgdsfgdsfg', '', 'fsgdsg', '7', '1134.0000', '226.8000', '0.0000', 'Placed', 'paypal', 0, 0, '2014-09-24', 3, '2014-09-24', 3, NULL),
(191, 'ZS1916685', 26, '3', 'sfsdfasdfd', 'fgdsgdsfgdsf', 'sharaz.khan@r2international.com', 'fgdsfgdsfg', '', 'fsgdsg', '7', '1134.0000', '226.8000', '0.0000', 'Pending', 'paypal', 0, 0, '2014-09-24', 3, '2014-09-24', 3, NULL),
(192, 'ZS1927491', 26, '3', 'Sharaz ', 'Khan', 'sharaz.khan@r2international.com', 'safsaf', '', 'safasfd', '2147483647', '567.0000', '113.4000', '0.0000', 'Pending', 'paypal', 0, 0, '2014-10-29', 3, '2014-10-29', 3, NULL),
(193, 'ZS1931053', 26, '3', 'fdsafsad', 'sadfsadfasdfsafdafafsafsa', 'sharaz.khan@r2international.com', 'sdfsdaf', '', 'bsfsafs', '2147483647', '567.0000', '113.4000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-10-29', 3, '2014-10-29', 3, NULL),
(194, 'ZS1943759', 26, '3', 'Shaaz', 'Khanz', 'sharaz.khan@r2international.com', 'Bangalore', '', 'BAngalore , r2', '2147483647', '567.0000', '113.4000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-10-30', 3, '2014-10-30', 3, NULL),
(195, 'ZS1956499', 26, '3', 'Shaaz', 'Khanz', 'sharaz.khan@r2international.com', 'Bangalore', '', 'BAngalore , r2', '2147483647', '567.0000', '113.4000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-10-30', 3, '2014-10-30', 3, NULL),
(196, 'ZS1967841', 26, '3', 'Shaaz', 'Khanz', 'sharaz.khan@r2international.com', 'Bangalore', '', 'BAngalore , r2', '2147483647', '567.0000', '113.4000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-10-30', 3, '2014-10-30', 3, NULL),
(197, 'ZS1976386', 26, '3', 'Shaaz', 'Khanz', 'sharaz.khan@r2international.com', 'Bangalore', '', 'Bangalore , r2', '2147483647', '567.0000', '113.4000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-10-30', 3, '2014-10-30', 3, NULL),
(198, 'ZS198697', 26, '3', 'Shaaz', 'Khanz', 'sharaz.khan@r2international.com', 'Bangalore', '', 'Bangalore , r2', '2147483647', '573.0000', '114.6000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-10-30', 3, '2014-10-30', 3, NULL),
(199, 'ZS1999663', 26, '3', 'Shaaz', 'Khanz', 'sharaz.khan@r2international.com', 'Bangalore', '', 'Bangalore , r2', '2147483647', '599.0000', '119.8000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-11-04', 3, '2014-11-04', 3, NULL),
(200, 'ZS2007376', 26, '3', 'Sharaz', 'sdgsdgsdgdsds', 'sharaz.khan@r2international.com', 'dfgdfg', '', 'gdsfgdsfg', '2147483647', '773.0000', '114.6000', '0.0000', 'Pending', 'paypal', 0, 0, '2014-11-13', 3, '2014-11-13', 3, NULL),
(201, 'ZS2011769', 26, '3', 'Sharaz', 'gdsgsdgdg', 'sharaz.khan@r2international.com', 'dsfgdsfgds', '', 'dsgfds', '2147483647', '500.0000', '60.0000', '200.0000', 'Placed', 'directpay', 0, 0, '2014-11-13', 3, '2014-11-13', 3, NULL),
(202, 'ZS2025254', 26, '3', 'Sharaz', 'Khan', 'sharazkhanz@gmail.com', 'dasfasfasdf', '', 'sadfsadfaaf', '2147483647', '773.0000', '114.6000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2014-11-14', 3, '2014-11-14', 3, NULL),
(203, 'ZS2036122', 26, '3', 'Sharaz', 'Khan', 'sharazkhanz@gmail.com', 'dasfasfasdf', '', 'sadfsadfaaf', '2147483647', '773.0000', '114.6000', '200.0000', 'Placed', 'quickpay', 0, 0, '2014-11-14', 3, '2014-11-14', 3, NULL),
(204, 'ZS2044703', 26, '3', 'Sharaz', 'Khan', 'sharazkhanz@gmail.com', 'dasfasfasdf', '', 'sadfsadfaaf', '2147483647', '773.0000', '114.6000', '200.0000', 'Pending', 'paypal', 0, 0, '2014-11-14', 3, '2014-11-14', 3, NULL),
(205, 'ZS2053075', 26, '3', 'Sharaz', 'sdgdsg', 'sharaz.khan@r2international.com', 'dsfgdsfgsdfg', '', 'dsgfdsg', '2147483647', '1132.0000', '226.4000', '0.0000', 'Cancelled', 'paypal', 0, 0, '2014-11-17', 3, '2014-11-17', 3, NULL),
(206, 'ZS2068443', 26, '3', 'Sharaz', 'sdgdsg', 'sharaz.khan@r2international.com', 'dsfgdsfgsdfg', '', 'dsgfdsg', '2147483647', '1132.0000', '226.4000', '0.0000', 'Cancelled', 'quickpay', 0, 0, '2014-11-17', 3, '2014-11-17', 3, NULL),
(207, 'ZS2073031', 26, '3', 'Sharaz', 'sdgdsg', 'sharaz.khan@r2international.com', 'dsfgdsfgsdfg', '', 'dsgfdsg', '2147483647', '800.0000', '120.0000', '200.0000', 'Cancelled', 'paypal', 0, 0, '2014-11-17', 3, '2014-11-17', 3, NULL),
(208, 'ZS2085992', 26, '3', 'Sharaz', 'sdgdsg', 'sharaz.khan@r2international.com', 'dsfgdsfgsdfg', '', 'dsgfdsg', '2147483647', '1133.0000', '226.6000', '0.0000', 'Placed', 'quickpay', 0, 0, '2014-11-19', 3, '2014-11-19', 3, NULL),
(209, 'ZS209190', 26, '3', 'Sharaz', 'sdgdsg', 'sharaz.khan@r2international.com', 'dsfgdsfgsdfg', '', 'dsgfdsg', '2147483647', '1133.0000', '226.6000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-11-19', 3, '2014-11-19', 3, NULL),
(210, 'ZS2104416', 26, '3', 'Sharaz', 'dsfsafssaf', 'sharaz.khan@r2international.com', 'sdf', '', 'bsfsafs', '2147483647', '202.0000', '0.4000', '200.0000', 'Placed', 'directpay', 0, 0, '2014-11-25', 3, '2014-11-25', 3, NULL),
(211, 'ZS2112939', 26, '3', 'Sharaz', 'gdsgf', 'sharaz.khan@r2international.com', 'dsgfdsfg', '', 'dsgsdg', '2147483647', '766.0000', '113.2000', '200.0000', 'Placed', 'directpay', 0, 0, '2014-11-28', 3, '2014-11-28', 3, NULL),
(212, 'ZS212210', 57, '3', 'Sharaz', 'gdsgf', 'sharaz.khan@r2international.com', 'dsgfdsfg', '', 'dsgsdg', '2147483647', '13.0000', '2.6000', '0.0000', 'Placed', 'directpay', 0, 0, '2014-11-28', 3, '2014-11-28', 3, NULL),
(213, 'ZS2132175', 26, '3', 'Sharaz', 'gdsgf', 'sharaz.khan@r2international.com', 'dsgfdsfg', '', 'dsgsdg', '2147483647', '773.0000', '114.6000', '200.0000', 'Placed', 'directpay', 0, 0, '2014-11-28', 3, '2014-11-28', 3, NULL),
(214, 'ZS2143807', 26, '3', 'sdsfdsfsfs', 'sdfsfs', 'sharaz.khan@r2international.com', 'dfsdfsdf', '', 'fsfsfs', '2147483647', '321.0000', '24.2000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2015-01-22', 3, '2015-01-22', 3, NULL),
(215, 'ZS2156880', 26, '3', 'cZCzxc', 'zxCzxc', 'sharazkhanz@gmail.com', 'xzcvxcv', '', 'zCzxc', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(216, 'ZS2163249', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(217, 'ZS2174031', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(218, 'ZS2183220', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(219, 'ZS2194273', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(220, 'ZS2208694', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(221, 'ZS2216736', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(222, 'ZS22279', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(223, 'ZS2231898', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(224, 'ZS2242680', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(225, 'ZS2252650', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(226, 'ZS2268442', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(227, 'ZS2279028', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(228, 'ZS2283228', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(229, 'ZS2292922', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'paypal', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(230, 'ZS230192', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(231, 'ZS2319866', 26, '3', 'sdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sfdsfdsdf', '', 'sdfsdf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-23', 3, '2015-01-23', 3, NULL),
(232, 'ZS2325827', 26, '3', 'sdfsdafsadf', 'sadfsafs', 'sharazkhanz@gmail.com', 'dsfsdafd', '', 'dfsdf', '2147483647', '321.0000', '24.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-24', 3, '2015-01-24', 3, NULL),
(233, 'ZS2338588', 26, '3', 'sdfsdafsadf', 'sadfsafs', 'sharazkhanz@gmail.com', 'dsfsdafd', '', 'dfsdf', '2147483647', '321.0000', '24.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-24', 3, '2015-01-24', 3, NULL),
(234, 'ZS2347309', 26, '3', 'sdfsdafsadf', 'sadfsafs', 'sharazkhanz@gmail.com', 'dsfsdafd', '', 'dfsdf', '2147483647', '321.0000', '24.2000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-01-24', 3, '2015-01-24', 3, NULL),
(235, 'ZS2359104', 26, '3', 'sdfsdafsadf', 'sadfsafs', 'sharazkhanz@gmail.com', 'dsfsdafd', '', 'dfsdf', '2147483647', '321.0000', '24.2000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-01-24', 3, '2015-01-24', 3, NULL),
(236, 'ZS2366335', 26, '3', 'fsadfsdfsa', 'sadfsafsg', 'sharazkhanz@gmail.com', 'dgdsgdsfg', '', 'dfsgdgdgd', '2147483647', '321.0000', '24.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-24', 3, '2015-01-24', 3, NULL),
(237, 'ZS2374837', 26, '3', 'fsadfsdfsa', 'sadfsafsg', 'sharazkhanz@gmail.com', 'dgdsgdsfg', '', 'dfsgdgdgd', '2147483647', '321.0000', '24.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-24', 3, '2015-01-24', 3, NULL),
(238, 'ZS2387392', 26, '3', 'cxvxzvxcvxzcvx', 'xzcvxczv', 'sharazkhanz@gmail.com', 'xvxvx', '', 'xcvxzcv', '2147483647', '321.0000', '24.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-24', 3, '2015-01-24', 3, NULL),
(239, 'ZS2397405', 26, '3', 'gdfdg', 'dfgfdsg', 'sharazkhanz@gmail.com', 'dfgfdsg', '', 'dfsgdfg', '2147483647', '621.0000', '84.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-28', 3, '2015-01-28', 3, NULL),
(240, 'ZS2401708', 26, '3', 'gdfdg', 'dfgfdsg', 'sharazkhanz@gmail.com', 'dfgfdsg', '', 'dfsgdfg', '2147483647', '621.0000', '84.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-28', 3, '2015-01-28', 3, NULL),
(241, 'ZS2417652', 26, '3', 'gdfdg', 'dfgfdsg', 'sharazkhanz@gmail.com', 'dfgfdsg', '', 'dfsgdfg', '2147483647', '621.0000', '84.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-28', 3, '2015-01-28', 3, NULL),
(242, 'ZS2428460', 26, '3', 'dfsafdsaf', 'sdfsadf', 'sharazkhanz@gmail.com', 'sadfsdaf', '', 'sdafsadf', '2147483647', '766.0000', '113.2000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-01-28', 3, '2015-01-28', 3, NULL),
(243, 'ZS2434220', 26, '3', 'sadfsadf', 'sadfsadf', 'sharazkhanz@gmail.com', 'sadfsdaf', '', 'sdfsadf', '2147483647', '766.0000', '113.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-29', 3, '2015-01-29', 3, NULL),
(244, 'ZS2448601', 26, '3', 'sadfsadf', 'sadfsadf', 'sharazkhanz@gmail.com', 'sadfsdaf', '', 'sdfsadf', '2147483647', '766.0000', '113.2000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-01-29', 3, '2015-01-29', 3, NULL),
(245, 'ZS2459164', 26, '3', 'fsdfsdaf', 'sdfsadf', 'sharazkhanz@gmail.com', 'sadfsdaf', '', 'sdafsdaf', '2147483647', '773.0000', '114.6000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-29', 3, '2015-01-29', 3, NULL),
(246, 'ZS2468386', 26, '3', 'fsdfsdaf', 'sdfsadf', 'sharazkhanz@gmail.com', 'sadfsdaf', '', 'sdafsdaf', '2147483647', '894.0000', '138.8000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-29', 3, '2015-01-29', 3, NULL),
(247, 'ZS2471599', 26, '3', 'fsdfsdaf', 'sdfsadf', 'sharazkhanz@gmail.com', 'sadfsdaf', '', 'sdafsdaf', '2147483647', '894.0000', '138.8000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-01-29', 3, '2015-01-29', 3, NULL),
(248, 'ZS2487738', 26, '2', 'Kim', 'Enemark', 'kim@acta-it.dk', '7000', '', 'Prinsessegade 18', '75942434', '321.0000', '24.2000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2015-01-29', 2, '2015-01-29', 2, NULL),
(249, 'ZS2496918', 26, '3', 'adfsafsadf', 'sadfsadf', 'sharazkhanz@gmail.com', 'sfdsdfsdaf', '', 'sdfsadf', '2147483647', '766.0000', '113.2000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-01-30', 3, '2015-01-30', 3, NULL),
(250, 'ZS2504835', 26, '3', 'adfsafsadf', 'sadfsadf', 'sharazkhanz@gmail.com', 'sfdsdfsdaf', '', 'sdfsadf', '2147483647', '766.0000', '113.2000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-01-30', 3, '2015-01-30', 3, NULL),
(251, 'ZS2516483', 26, '3', 'zxczXCzx', 'CzxC', 'sharazkhanz@gmail.com', 'xzcvxzcv', '', 'xzcvxzcv', '2147483647', '773.0000', '114.6000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-01-30', 3, '2015-01-30', 3, NULL),
(252, 'ZS2525830', 26, '3', 'hjhh', 'bv bbv', 'sharazkhanz@gmail.com', 'jkjkjk', '', 'nbgv', '2147483647', '766.0000', '113.2000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-01-30', 3, '2015-01-30', 3, NULL),
(253, 'ZS2537559', 26, '3', 'dfdsf', 'zxcvxzcv', 'sharazkhanz@gmail.com', 'vcxcvz', '', 'xvzxcv', '2147483647', '500.0000', '60.0000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-01-30', 3, '2015-01-30', 3, NULL),
(254, 'ZS2544769', 26, '3', 'gfsdgd', 'dgdfsg', 'sharazkhanz@gmail.com', 'dgdsgdsg', '', 'dgdsfg', '2147483647', '766.0000', '113.2000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2015-01-30', 3, '2015-01-30', 3, NULL),
(255, 'ZS2558524', 26, '3', 'gfsdgd', 'dgdfsg', 'sharazkhanz@gmail.com', 'dgdsgdsg', '', 'dgdsfg', '2147483647', '766.0000', '113.2000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2015-01-30', 3, '2015-01-30', 3, NULL),
(256, 'ZS2563628', 26, '3', 'gfsdgd', 'dgdfsg', 'sharazkhanz@gmail.com', 'dgdsgdsg', '', 'dgdsfg', '2147483647', '766.0000', '113.2000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2015-01-30', 3, '2015-01-30', 3, NULL),
(257, 'ZS2575036', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(258, 'ZS2585465', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(259, 'ZS2593628', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(260, 'ZS2605938', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(261, 'ZS2617859', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(262, 'ZS2622778', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(263, 'ZS263295', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(264, 'ZS2647621', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Placed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(265, 'ZS2654320', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(266, 'ZS2668151', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(267, 'ZS2675792', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(268, 'ZS2689837', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(269, 'ZS2693026', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Failed', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(270, 'ZS270528', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(271, 'ZS2713680', 26, '3', 'sdfsdf', 'sfdsdfs', 'sharazkhanz@gmail.com', 'sdfsdf', '', 'sfsdfsdf', '2147483647', '768.0000', '113.6000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(272, 'ZS2727686', 26, '3', 'xcvxcv', 'xcvxcv', 'sharazkhanz@gmail.com', 'xvxcv', '', 'xcvxv', '2147483647', '766.0000', '113.2000', '200.0000', 'Success', 'netaxept', 0, 0, '2015-02-01', 3, '2015-02-01', 3, NULL),
(273, 'ZS2736619', 26, '3', 'sdfsdf', 'sdfdsf', 'sharazkhanz@gmail.com', 'cochin', '', 'sfsdf', '7777777777', '202.0000', '40.4000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-02-02', 3, '2015-02-02', 3, '682002'),
(274, 'ZS2747149', 26, '3', 'sdfsdf', 'sdfdsf', 'sharazkhanz@gmail.com', 'cochin', '', 'sfsdf', '7777777777', '202.0000', '40.4000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-02-02', 3, '2015-02-02', 3, '682002'),
(275, 'ZS2758969', 26, '3', 'sdfsdf', 'sdfdsf', 'sharazkhanz@gmail.com', 'cochin', '', 'sfsdf', '7777777777', '766.0000', '153.2000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-02-02', 3, '2015-02-02', 3, '682002'),
(276, 'ZS2763931', 26, '3', 'sdfsdfsdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sdfsdfsdf', '', 'sdfsdf', 'sdfsdfsdfsdf', '202.0000', '40.4000', '0.0000', 'Cancelled', 'paypal', 0, 0, '2015-02-03', 3, '2015-02-03', 3, 'dfsdf'),
(277, 'ZS2777741', 26, '3', 'sdfsdfsdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sdfsdfsdf', '', 'sdfsdf', 'sdfsdfsdfsdf', '2.0000', '0.4000', '0.0000', 'Cancelled', 'paypal', 0, 0, '2015-02-03', 3, '2015-02-03', 3, 'dfsdf'),
(278, 'ZS2786600', 26, '3', 'sdfsdfsdfsdf', 'sdfsdf', 'sharazkhanz@gmail.com', 'sdfsdfsdf', '', 'sdfsdf', 'sdfsdfsdfsdf', '2.0000', '0.4000', '0.0000', 'Cancelled', 'netaxept', 0, 0, '2015-02-03', 3, '2015-02-03', 3, 'dfsdf'),
(279, 'ZS2795784', 26, '3', 'kjsdafkjsadj', 'fsdfsds', 'sharazkhanz@gmail.com', 'sdfsdfsdf', '', 'ddfs', '7777777777', '322.0000', '64.4000', '200.0000', 'Pending', 'paypal', 0, 0, '2015-02-08', 3, '2015-02-08', 3, 'dfdsf'),
(280, 'ZS2802919', 26, '3', 'sdfsdfs', 'fff', 'sharazkhanz@gmail.com', 'sdsfsdfs', '', 'ffff', '7777777777', '320.0000', '64.0000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-02-08', 3, '2015-02-08', 3, 'fff'),
(281, 'ZS2812997', 26, '3', 'sdfsdfs', 'fff', 'sharazkhanz@gmail.com', 'sdsfsdfs', '', 'ffff', '7777777777', '320.0000', '64.0000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-02-08', 3, '2015-02-08', 3, 'fff'),
(282, 'ZS2828147', 26, '3', 'sharaz', 'dssdf', 'sharazkhanz@gmail.com', 'sfsdfsdf', '', 'sdfsdf', '7777777777', '320.0000', '64.0000', '200.0000', 'Placed', 'epay', 0, 0, '2015-02-14', 3, '2015-02-14', 3, 'sfs'),
(283, 'ZS2833819', 26, '3', 'sharaz', 'dssdf', 'sharazkhanz@gmail.com', 'sfsdfsdf', '', 'sdfsdf', '7777777777', '320.0000', '64.0000', '200.0000', 'Placed', 'epay', 0, 0, '2015-02-14', 3, '2015-02-14', 3, 'sfs'),
(284, 'ZS2844659', 26, '3', 'sadfsadf', 'dsfsdsd', 'sharazkhanz@gmail.com', 'sdfsd', '', 'fsdfsdfsdf', '7777777777', '440.0000', '88.0000', '200.0000', 'Placed', 'epay', 0, 0, '2015-02-15', 3, '2015-02-15', 3, 'sdfsd'),
(285, 'ZS2859675', 26, '3', 'sadfsadf', 'dsfsdsd', 'sharazkhanz@gmail.com', 'sdfsd', '', 'fsdfsdfsdf', '7777777777', '440.0000', '88.0000', '200.0000', 'Cancelled', 'epay', 0, 0, '2015-02-15', 3, '2015-02-15', 3, 'sdfsd'),
(286, 'ZS2864693', 26, '3', 'sadfsadf', 'dsfsdsd', 'sharazkhanz@gmail.com', 'sdfsd', '', 'fsdfsdfsdf', '7777777777', '440.0000', '88.0000', '200.0000', 'Success', 'epay', 0, 0, '2015-02-15', 3, '2015-02-15', 3, 'sdfsd'),
(287, 'ZS2879482', 26, '3', 'fasfdsdfs', 'dafsadf', 'sharazkhanz@gmail.com', 'dfsafasdfsadf', '', 'sdfsadf', '7777777777', '320.0000', '64.0000', '200.0000', 'Success', 'epay', 0, 0, '2015-02-15', 3, '2015-02-15', 3, 'sadfsadf'),
(288, 'ZS288127', 26, '3', 'dsddsafsfs', 'sadfsafsgasadf', 'sharazkhanz@gmail.com', 'sfdsadfsf', '', 'sadfsadf', '7777777777', '202.0000', '40.4000', '200.0000', 'Cancelled', 'epay', 0, 0, '2015-02-15', 3, '2015-02-15', 3, 'sdfsadf'),
(289, 'ZS2899271', 26, '3', 'dsddsafsfs', 'sadfsafsgasadf', 'sharazkhanz@gmail.com', 'sfdsadfsf', '', 'sadfsadf', '7777777777', '202.0000', '40.4000', '200.0000', 'Cancelled', 'epay', 0, 0, '2015-02-15', 3, '2015-02-15', 3, 'sdfsadf'),
(290, 'ZS2908203', 26, '3', 'jjhbhjj', 'dfxffd', 'sharazkhanz@gmail.com', 'kjnkjnjknj', '', 'kjnknk', '77777', '768.0000', '153.6000', '200.0000', 'Success', 'epay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, ',nknkj'),
(291, 'ZS2919359', 26, '3', 'sssss', 'sdfsdf', 'sharazkhanz@gmail.com', 'sdfsdfsdf', '', 'sdfsdf', '7777', '766.0000', '153.2000', '200.0000', 'Success', 'epay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sdfsdf'),
(292, 'ZS2927670', 26, '3', 'sdfsdfsad', 'sdafsadf', 'sharazkhanz@gmail.com', 'sadfsafsd', '', 'sadfsadf', '7777', '1146.0000', '229.2000', '0.0000', 'Success', 'epay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sadf'),
(293, 'ZS2935692', 26, '3', 'sdfsdfsad', 'sdafsadf', 'sharazkhanz@gmail.com', 'sadfsafsd', '', 'sadfsadf', '7777', '1200.0000', '240.0000', '0.0000', 'Success', 'epay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sadf'),
(294, 'ZS2946749', 26, '3', 'sdfsdfsad', 'sdafsadf', 'sharazkhanz@gmail.com', 'sadfsafsd', '', 'sadfsadf', '7777', '500.0000', '100.0000', '200.0000', 'Placed', 'quickpay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sadf'),
(295, 'ZS2959701', 26, '3', 'sdfsdfsad', 'sdafsadf', 'sharazkhanz@gmail.com', 'sadfsafsd', '', 'sadfsadf', '7777', '500.0000', '100.0000', '200.0000', 'Placed', 'epay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sadf'),
(296, 'ZS2968313', 26, '3', 'sdfsdfsad', 'sdafsadf', 'sharazkhanz@gmail.com', 'sadfsafsd', '', 'sadfsadf', '7777', '500.0000', '100.0000', '200.0000', 'Placed', 'quickpay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sadf'),
(297, 'ZS2972930', 26, '3', 'sdfsdfsad', 'sdafsadf', 'sharazkhanz@gmail.com', 'sadfsafsd', '', 'sadfsadf', '7777', '500.0000', '100.0000', '200.0000', 'Placed', 'quickpay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sadf'),
(298, 'ZS2983815', 26, '3', 'sdfsdfsad', 'sdafsadf', 'sharazkhanz@gmail.com', 'sadfsafsd', '', 'sadfsadf', '7777', '500.0000', '100.0000', '200.0000', 'Cancelled', 'quickpay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sadf'),
(299, 'ZS2998952', 26, '3', 'sdfsdfsad', 'sdafsadf', 'sharazkhanz@gmail.com', 'sadfsafsd', '', 'sadfsadf', '7777', '500.0000', '100.0000', '200.0000', 'Placed', 'quickpay', 0, 0, '2015-02-16', 3, '2015-02-16', 3, 'sadf'),
(300, 'ZS3004389', 26, '3', 'sharaz', 'khan', 'sharazkhanz@gmail.com', 'asdasd', '', 'asdsadasda', '7777777777', '330.0000', '40.0000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-05-31', 3, '2015-05-31', 3, 'adsas'),
(301, 'ZS3016665', 26, '3', 'jbkjjkjk', 'zxzczz', 'sharazkhanz@gmail.com', 'zczxc', '', 'xczxc', '7777777777', '524.0000', '104.8000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-06-19', 3, '2015-06-19', 3, 'zcxzxc'),
(302, 'ZS3026918', 26, '3', 'jbkjjkjk', 'zxzczz', 'sharazkhanz@gmail.com', 'zczxc', '', 'xczxc', '7777777777', '560.0000', '40.0000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-06-19', 3, '2015-06-19', 3, 'zcxzxc'),
(303, 'ZS3036134', 26, '3', 'jbkjjkjk', 'zxzczz', 'sharazkhanz@gmail.com', 'zczxc', '', 'xczxc', '7777777777', '231.1600', '46.2320', '200.0000', 'Placed', 'directpay', 0, 0, '2015-06-19', 3, '2015-06-19', 3, 'zcxzxc'),
(304, 'ZS3049562', 26, '3', 'czczcz', 'cxzczx', 'sharazkhanz@gmail.com', 'czxczxczxc', '', 'zxczxc', '7777777777', '231.1600', '46.2320', '200.0000', 'Placed', 'paypal', 0, 0, '2015-06-19', 3, '2015-06-19', 3, 'zxczxcz'),
(305, 'ZS3057678', 26, '3', 'czczcz', 'cxzczx', 'sharazkhanz@gmail.com', 'czxczxczxc', '', 'zxczxc', '7777777777', '231.1600', '46.2320', '200.0000', 'Placed', 'directpay', 0, 0, '2015-06-19', 3, '2015-06-19', 3, 'zxczxcz'),
(306, 'ZS3062149', 26, '3', 'czczcz', 'cxzczx', 'sharazkhanz@gmail.com', 'czxczxczxc', '', 'zxczxc', '7777777777', '591.1600', '112.0000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-06-19', 3, '2015-06-19', 3, 'zxczxcz'),
(307, 'ZS3076185', 26, '3', 'asdsadas', 'dasd', 'sharazkhanz@gmail.com', 'dasdasdasd', '', 'adsasd', '7777777777', '70.0000', '14.0000', '0.0000', 'Placed', 'directpay', 0, 0, '2015-06-22', 3, '2015-06-22', 3, 'asdasda'),
(308, 'ZS3081173', 26, '3', 'sharaz', 'khan', 'sharazkhanz@gmail.com', 'dsfgsdfg', '', 'dfgdsg', '7777777777', '77.0000', '1.4000', '7.0000', 'Cancelled', 'paypal', 0, 0, '2015-07-14', 3, '2015-07-14', 3, 'dg'),
(309, 'ZS309609', 26, '3', 'sharaz', 'khan', 'sharazkhanz@gmail.com', 'dsfgsdfg', '', 'dfgdsg', '7777777777', '77.0000', '1.4000', '7.0000', 'Cancelled', 'paypal', 0, 0, '2015-07-14', 3, '2015-07-14', 3, 'dg'),
(310, 'ZS3109134', 26, '3', 'sffg', 'dgdsg', 'sharazkhanz@gmail.com', 'gdsgd', '', 'dg', '7777777777', '147.0000', '1.4000', '7.0000', 'Placed', 'paypal', 0, 0, '2015-07-15', 3, '2015-07-15', 3, 'dsgds'),
(311, 'ZS3111170', 26, '3', 'fasf', 'sdafsa', 'sharazkhanz@gmail.com', 'safsadfsadf', '', 'dfsadfs', '7025760973', '217.0000', '1.4000', '7.0000', 'Cancelled', 'epay', 0, 0, '2015-07-19', 3, '2015-07-19', 3, 'fasfsadf'),
(312, 'ZS3129972', 26, '3', 'fasf', 'sdafsa', 'sharazkhanz@gmail.com', 'safsadfsadf', '', 'dfsadfs', '7025760973', '217.0000', '1.4000', '7.0000', 'Cancelled', 'paypal', 0, 0, '2015-07-19', 3, '2015-07-19', 3, 'fasfsadf'),
(313, 'ZS3135998', 26, '3', 'fasf', 'sdafsa', 'sharazkhanz@gmail.com', 'safsadfsadf', '', 'dfsadfs', '7025760973', '217.0000', '1.4000', '7.0000', 'Cancelled', 'paypal', 0, 0, '2015-07-19', 3, '2015-07-19', 3, 'fasfsadf'),
(314, 'ZS3142920', 26, '3', 'sad', 'fasf', 'sharazkhanz@gmail.com', 'asfasdf', '', 'asfsdf', '7777777777', '1003.0000', '200.6000', '0.0000', 'Cancelled', 'epay', 0, 0, '2015-08-07', 3, '2015-08-07', 3, 'asfasf'),
(315, 'ZS3159360', 26, '3', 'sdfgsdf', 'gfdsg', 'sharazkhanz@gmail.com', 'dfsgfdsg', '', 'dfsg', '7777777777', '500.0000', '100.0000', '0.0000', 'Placed', 'netaxept', 0, 0, '2015-08-18', 3, '2015-08-18', 3, 'dsfg'),
(316, 'ZS3162015', 26, '3', 'sdfgsdf', 'gfdsg', 'sharazkhanz@gmail.com', 'dfsgfdsg', '', 'dfsg', '7777777777', '500.0000', '100.0000', '0.0000', 'Success', 'epay', 0, 0, '2015-08-18', 3, '2015-08-18', 3, 'dsfg'),
(317, 'ZS3173441', 26, '3', 'dsgsd', 'gffdsgdsf', 'sharazkhanz@gmail.com', 'dsfgdsfgsdfg', '', 'gdsfg', '7777777777', '70.0000', '14.0000', '0.0000', 'Placed', 'paypal', 0, 0, '2015-08-20', 3, '2015-08-20', 3, 'dfsg'),
(318, 'ZS3185034', 26, '3', 'dsgsd', 'gffdsgdsf', 'sharazkhanz@gmail.com', 'dsfgdsfgsdfg', '', 'gdsfg', '7777777777', '70.0000', '14.0000', '0.0000', 'Placed', 'quickpay', 0, 0, '2015-08-20', 3, '2015-08-20', 3, 'dfsg'),
(319, 'ZS3192665', 26, '3', 'dsgsd', 'gffdsgdsf', 'sharazkhanz@gmail.com', 'dsfgdsfgsdfg', '', 'gdsfg', '7777777777', '70.0000', '14.0000', '0.0000', 'Placed', 'epay', 0, 0, '2015-08-20', 3, '2015-08-20', 3, 'dfsg'),
(320, 'ZS3203470', 26, '3', 'dsgsd', 'gffdsgdsf', 'sharazkhanz@gmail.com', 'dsfgdsfgsdfg', '', 'gdsfg', '7777777777', '70.0000', '14.0000', '0.0000', 'Placed', 'directpay', 0, 0, '2015-08-20', 3, '2015-08-20', 3, 'dfsg'),
(321, 'ZS3216983', 26, '3', 'sharaz', 'khan', 'sharazkhanz@gmail.com', 'ernakulam', '', 'india. kerala ', '7025760973', '77.0000', '1.4000', '7.0000', 'Placed', 'directpay', 0, 0, '2015-09-30', 3, '2015-09-30', 3, '682032'),
(322, 'ZS3224724', 26, '3', 'sharaz', 'khan', 'sharazkhanz@gmail.com', 'ernakulam', '', 'india. kerala ', '7025760973', '77.0000', '1.4000', '7.0000', 'Placed', 'directpay', 0, 0, '2015-09-30', 3, '2015-09-30', 3, '682032'),
(323, 'ZS3236790', 26, '3', 'sdfgfdg', 'dfgd', 'sharazkhanz@gmail.com', 'gdfg', '', 'fgdg', '7777777777', '560.0000', '36.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2015-12-17', 3, '2015-12-17', 3, 'dgd'),
(324, 'ZS3248538', 26, '3', 'tett', 'ewtwert', 'sharazkhanz@gmail.com', 'tertret', '', 'tert', '7777777777', '560.0000', '56.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2015-12-17', 3, '2015-12-17', 3, 'eter'),
(325, 'ZS3254068', 26, '3', 'tett', 'ewtwert', 'sharazkhanz@gmail.com', 'tertret', '', 'tert', '7777777777', '560.0000', '56.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2015-12-17', 3, '2015-12-17', 3, 'eter'),
(326, 'ZS3269886', 26, '3', 'tett', 'ewtwert', 'sharazkhanz@gmail.com', 'tertret', '', 'tert', '7777777777', '560.0000', '36.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2015-12-17', 3, '2015-12-17', 3, 'eter'),
(327, 'ZS3279750', 26, '3', 'tett', 'ewtwert', 'sharazkhanz@gmail.com', 'tertret', '', 'tert', '7777777777', '360.0000', '76.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2015-12-17', 3, '2015-12-17', 3, 'eter'),
(328, 'ZS3283920', 26, '3', 'tett', 'ewtwert', 'sharazkhanz@gmail.com', 'tertret', '', 'tert', '7777777777', '560.0000', '76.0000', '200.0000', 'Placed', 'directpay', 0, 0, '2015-12-17', 3, '2015-12-17', 3, 'eter'),
(329, 'ZS3297088', 26, '56a27d8a34df3', 'sharaz', 'khan', 'sharazkhanz@gmail.com', 'sdfdsf', '', 'sfsfsf', '7777777777', '32.1600', '0.4000', '2.0000', 'Placed', 'directpay', 0, 0, '2016-01-22', 0, '2016-01-22', 0, 's'),
(330, 'ZS3304049', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(331, 'ZS3312212', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'paypal', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(332, 'ZS3323956', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'paypal', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(333, 'ZS3336713', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'paypal', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(334, 'ZS3345967', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(335, 'ZS3357703', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(336, 'ZS3361448', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'paypal', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(337, 'ZS3372161', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(338, 'ZS3383190', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(339, 'ZS3392735', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Cancelled', 'epay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(340, 'ZS3402780', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(341, 'ZS3417992', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '184.1600', '30.4000', '2.0000', 'Placed', 'paypal', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(342, 'ZS3423157', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '184.1600', '30.4000', '2.0000', 'Placed', 'paypal', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(343, 'ZS3431311', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '184.1600', '30.4000', '2.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(344, 'ZS3445250', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs');
INSERT INTO `zselex_order` (`id`, `order_id`, `shop_id`, `user_id`, `first_name`, `last_name`, `email`, `city`, `street`, `address`, `phone`, `totalprice`, `vat`, `shipping`, `status`, `payment_type`, `self_pickup`, `completed`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `zip`) VALUES
(345, 'ZS3453692', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(346, 'ZS346884', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Cancelled', 'epay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(347, 'ZS3479495', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(348, 'ZS3486786', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '184.1600', '30.4000', '2.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(349, 'ZS349511', 26, '3', 'Sharaz', 'sdsdfsdf', 'sharazkhanz@gmail.com', 'fsdfsdfsf', '', 'fsfsf', '7777777777', '184.1600', '30.4000', '2.0000', 'Placed', 'quickpay', 0, 0, '2016-01-23', 3, '2016-01-23', 3, 'sfs'),
(350, 'ZS3503020', 26, '2', 'Kim', 'Enemark', 'kim@acta-it.dk', 'Fredericia', '', 'Prinsessegade 18', '75942434', '562.9000', '112.5800', '200.0000', 'Placed', 'directpay', 0, 0, '2016-01-24', 2, '2016-01-24', 2, '7000'),
(351, 'ZS3515521', 26, '56a392229e4cc', 'Sharaz', 'gsdg', 'sharazkhanz@gmail.com', 'fsdgsdgsdgdsg', '', 'sdgsd', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'quickpay', 0, 0, '2016-01-26', 0, '2016-01-26', 0, 'gsdfg'),
(352, 'ZS3529068', 26, '56a392229e4cc', 'Sharaz', 'gsdg', 'sharazkhanz@gmail.com', 'fsdgsdgsdgdsg', '', 'sdgsd', '7777777777', '34.1600', '0.4000', '2.0000', 'Placed', 'epay', 0, 0, '2016-01-26', 0, '2016-01-26', 0, 'gsdfg'),
(353, 'ZS3536208', 26, '56a392229e4cc', 'Sharaz', 'gsdg', 'sharazkhanz@gmail.com', 'fsdgsdgsdgdsg', '', 'sdgsd', '7777777777', '32.1600', '0.4000', '2.0000', 'Pending', 'paypal', 1, 0, '2016-01-26', 0, '2016-01-26', 0, 'gsdfg'),
(354, 'ZS3549007', 26, '56a392229e4cc', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'terterter', '', 'etet', '7777777777', '300.0000', '60.0000', '200.0000', 'Placed', 'quickpay', 1, 0, '2016-01-26', 0, '2016-01-26', 0, 'erter'),
(355, 'ZS3551084', 26, '56a392229e4cc', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'terterter', '', 'etet', '7777777777', '450.0000', '90.0000', '200.0000', 'Placed', 'paypal', 1, 0, '2016-01-27', 0, '2016-01-27', 0, 'erter'),
(356, 'ZS356803', 26, '56a392229e4cc', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'terterter', '', 'etet', '7777777777', '650.0000', '130.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2016-01-27', 0, '2016-01-27', 0, 'erter'),
(357, 'ZS3575893', 26, '56a392229e4cc', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'terterter', '', 'etet', '7777777777', '650.0000', '130.0000', '200.0000', 'Cancelled', 'netaxept', 0, 0, '2016-01-27', 0, '2016-01-27', 0, 'erter'),
(358, 'ZS3583816', 26, '56a392229e4cc', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'terterter', '', 'etet', '7777777777', '650.0000', '130.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2016-01-27', 0, '2016-01-27', 0, 'erter'),
(359, 'ZS3598362', 26, '56a392229e4cc', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'terterter', '', 'etet', '7777777777', '650.0000', '130.0000', '200.0000', 'Placed', 'quickpay', 0, 0, '2016-01-27', 0, '2016-01-27', 0, 'erter'),
(360, 'ZS360720', 26, '56a392229e4cc', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'terterter', '', 'etet', '7777777777', '650.0000', '130.0000', '200.0000', 'Cancelled', 'epay', 0, 0, '2016-01-27', 0, '2016-01-27', 0, 'erter'),
(361, 'ZS3612583', 26, '56a392229e4cc', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'terterter', '', 'etet', '7777777777', '650.0000', '130.0000', '200.0000', 'Placed', 'paypal', 0, 0, '2016-01-27', 0, '2016-01-27', 0, 'erter'),
(362, 'ZS3624375', 26, '56ae347457852', 'sdfsfs', 'dfsdfsdfsdf', 'sharazkhanz@gmail.com', 'sdfsf', '', 'fsfsfsf', '7777777777', '34.1600', '0.4000', '2.0000', 'Success', 'epay', 0, 0, '2016-01-31', 0, '2016-01-31', 0, 'sdfs'),
(363, 'ZS3632080', 26, '56ae347457852', 'sdfsfs', 'dfsdfsdfsdf', 'sharazkhanz@gmail.com', 'sdfsf', '', 'fsfsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Placed', 'epay', 0, 0, '2016-01-31', 0, '2016-01-31', 0, 'sdfs'),
(364, 'ZS3643425', 26, '56ae347457852', 'sdfsfs', 'dfsdfsdfsdf', 'sharazkhanz@gmail.com', 'sdfsf', '', 'fsfsfsf', '7777777777', '350.0000', '70.0000', '200.0000', 'Placed', 'epay', 0, 0, '2016-01-31', 0, '2016-01-31', 0, 'sdfs'),
(365, 'ZS3651658', 26, '56c215718934c', 'Sharaz', 'dffgdg', 'sharazkhanz@gmail.com', 'dgdgdgdg', '', 'dfgdgdgd', '7025760973', '350.0000', '70.0000', '200.0000', 'Success', 'netaxept', 0, 0, '2016-02-15', 0, '2016-02-15', 0, 'gdg'),
(366, 'ZS3669417', 26, '56c24c44e5552', 'sharaz', 'sfsdf', 'sharazkhanz@gmail.com', 'fsfsf', '', 'dsfdsf', '7777777777', '32.1600', '0.4000', '2.0000', 'Cancelled', 'paypal', 0, 0, '2016-02-15', 0, '2016-02-15', 0, 'dsfs'),
(367, 'ZS3678252', 26, '56c24c44e5552', 'sharaz', 'sfsdf', 'sharazkhanz@gmail.com', 'fsfsf', '', 'dsfdsf', '7777777777', '32.1600', '0.4000', '2.0000', 'Cancelled', 'paypal', 0, 0, '2016-02-15', 0, '2016-02-15', 0, 'dsfs'),
(368, 'ZS3685227', 26, '56c24c44e5552', 'sharaz', 'sfsdf', 'sharazkhanz@gmail.com', 'fsfsf', '', 'dsfdsf', '7777777777', '32.1600', '0.4000', '2.0000', 'Cancelled', 'paypal', 0, 0, '2016-02-15', 0, '2016-02-15', 0, 'dsfs'),
(369, 'ZS3696549', 26, '56c24c44e5552', 'sharaz', 'sfsdf', 'sharazkhanz@gmail.com', 'fsfsf', '', 'dsfdsf', '7777777777', '32.1600', '0.4000', '2.0000', 'Placed', 'paypal', 0, 0, '2016-02-15', 0, '2016-02-15', 0, 'dsfs'),
(370, 'ZS3707868', 26, '56c24c44e5552', 'sharaz', 'sfsdf', 'sharazkhanz@gmail.com', 'fsfsf', '', 'dsfdsf', '7777777777', '32.1600', '0.4000', '2.0000', 'Cancelled', 'paypal', 0, 0, '2016-02-15', 0, '2016-02-15', 0, 'dsfs'),
(371, 'ZS3719098', 26, '5770044609099', 'Sharaz', 'dsgdgsdfg', 'sharazkhanz@gmail.com', 'dfg', '', 'dgdfg', '7025760973', '32.1600', '0.4000', '2.0000', 'directbuy', 'quickpay', 0, 0, '2016-06-26', 0, '2016-06-26', 0, 'dgdf'),
(372, 'ZS3727183', 26, '5770044609099', 'Sharaz', 'dsgdgsdfg', 'sharazkhanz@gmail.com', 'dfg', '', 'dgdfg', '7025760973', '32.1600', '0.4000', '2.0000', 'directbuy', 'directpay', 0, 0, '2016-06-26', 0, '2016-06-26', 0, 'dgdf'),
(373, 'ZS3731195', 26, '3', 'gsdgdgfggdg', 'fsfsfsfsfd', 'sharazkhanz@gmail.com', 'dfsfsd', '', 'sdfsdfsdf', '7025760973', '562.9000', '112.5800', '200.0000', 'directbuy', 'directpay', 0, 0, '2016-06-26', 3, '2016-06-26', 3, 'sdfsdfs'),
(374, 'ZS3748660', 61, '3', 'gsdgdgfggdg', 'fsfsfsfsfd', 'sharazkhanz@gmail.com', 'dfsfsd', '', 'sdfsdfsdf', '7025760973', '111.0000', '0.0000', '0.0000', 'directbuy', 'paypal', 0, 0, '2016-06-26', 3, '2016-06-26', 3, 'sdfsdfs'),
(375, 'ZS3753530', 61, '3', 'gsdgdgfggdg', 'fsfsfsfsfd', 'sharazkhanz@gmail.com', 'dfsfsd', '', 'sdfsdfsdf', '7025760973', '222.0000', '44.4000', '0.0000', 'directbuy', 'paypal', 0, 0, '2016-06-26', 3, '2016-06-26', 3, 'sdfsdfs'),
(376, 'ZS3768653', 61, '576b1bc922708', 'Sharaz', 'Khan', 'sharazkhanz@gmail.com', 'Ernakulam', '', 'Bcg golden orchid , ruby lane, old phase , 2nd floor , door no:2D, thamanam-682032, Cochin, Kerala', '7025760973', '111.0000', '0.0000', '0.0000', 'directbuy', 'paypal', 1, 0, '2016-06-27', 0, '2016-06-27', 0, '682032'),
(377, 'ZS377548', 26, '576b1bc922708', 'Sharaz', 'Khan', 'sharazkhanz@gmail.com', 'Ernakulam', '', 'Bcg golden orchid , ruby lane, old phase , 2nd floor , door no:2D, thamanam-682032, Cochin, Kerala', '7025760973', '500.0000', '100.0000', '200.0000', 'Pending', 'paypal', 0, 0, '2016-06-27', 0, '2016-06-27', 0, '682032'),
(378, 'ZS378863', 26, '5772ed9f3f53f', 'Sharaz', 'Khan', 'sharazkhanz@gmail.com', 'Bangalore', '', '24 F Cross', '7760916387', '350.0000', '70.0000', '200.0000', 'Pending', 'paypal', 0, 0, '2016-06-28', 0, '2016-06-28', 0, '560047'),
(379, 'ZS3796762', 26, '5775712fc95c8', 'Sharaz', 'Guest', 'sharazkhanz@gmail.com', 'sdfds', '', 'fsdfdsfsdf', '+91-7025760973', '921.8000', '184.3600', '200.0000', 'directbuy', 'paypal', 0, 0, '2016-07-02', 0, '2016-07-02', 0, 'sdfds'),
(380, 'ZS3804262', 26, '57758f11ac4f0', 'Sharaz ', 'Khan\\\'s ', 'aaa@aaa.com', 'Bbb', '', 'Bbbb', '7777777777', '560.9000', '40.0000', '200.0000', 'Cancelled', 'paypal', 0, 0, '2016-07-03', 0, '2016-07-03', 0, 'Hhh'),
(381, 'ZS3813633', 26, '3', 'sharaz', 'khan', 'sharaz@india.com', 'dfgfdgdf', '', 'ddfgdg', '7777777777', '254.0000', '50.8000', '200.0000', 'Pending', 'paypal', 0, 1, '2016-08-25', 3, '2016-08-25', 3, 'dfg'),
(382, 'ZS3822269', 26, '3', 'gfdsag', 'fasfsfd', 'sharazkhanz@gmail.com', 'sadf', '', 'sdf', '7777777777', '227.0000', '45.4000', '200.0000', 'Pending', 'paypal', 0, 1, '2016-08-25', 3, '2016-08-25', 3, 'safads'),
(383, 'ZS383327', 26, '3', 'sfgdgfd', 'dfgdsfg', 'sharazkhanz@gmail.com', 'dfgfdgdf', '', 'dfgdgdf', '7777777777', '560.9000', '40.0000', '200.0000', 'directbuy', 'paypal', 0, 0, '2016-08-25', 3, '2016-08-25', 3, 'dfg'),
(384, 'ZS3849731', 26, '57bf38a0b92ed', 'sdfa', 'sfsdf', 'sharazkhanz@gmail.com', 'asfsdf', '', 'asfasf', '7777777777', '587.9000', '117.5800', '200.0000', 'directbuy', 'paypal', 0, 0, '2016-08-26', 0, '2016-08-26', 0, 'asf'),
(385, 'ZS3858213', 26, '57bf38a0b92ed', 'sdfa', 'sfsdf', 'sharazkhanz@gmail.com', 'asfsdf', '', 'asfasf', '7777777777', '587.9000', '117.5800', '200.0000', 'directbuy', 'paypal', 0, 0, '2016-08-26', 0, '2016-08-26', 0, 'asf'),
(386, 'ZS3867918', 26, '57bf38a0b92ed', 'sdfa', 'sfsdf', 'sharazkhanz@gmail.com', 'asfsdf', '', 'asfasf', '7777777777', '587.9000', '117.5800', '200.0000', 'directbuy', 'paypal', 0, 0, '2016-08-26', 0, '2016-08-26', 0, 'asf'),
(387, 'ZS3873945', 26, '57bf38a0b92ed', 'sdfa', 'sfsdf', 'sharazkhanz@gmail.com', 'asfsdf', '', 'asfasf', '7777777777', '587.9000', '117.5800', '200.0000', 'directbuy', 'paypal', 0, 0, '2016-08-26', 0, '2016-08-26', 0, 'asf'),
(388, 'ZS3884795', 26, '57bf38a0b92ed', 'sdfa', 'sfsdf', 'sharazkhanz@gmail.com', 'asfsdf', '', 'asfasf', '7777777777', '975.8000', '195.1600', '200.0000', 'Pending', 'paypal', 0, 1, '2016-08-26', 0, '2016-08-26', 0, 'asf'),
(389, 'ZS3899379', 26, '3', 'sdfsd', 'fsdfsd', 'sharazkhanz@gmail.com', 'fsfs', '', 'fs', '7777777777', '587.9000', '117.5800', '200.0000', 'Cancelled', 'paypal', 0, 0, '2016-09-05', 3, '2016-09-05', 3, 'fsfs'),
(390, 'ZS3906979', 26, '3', 'sdfsd', 'fsdfsd', 'sharazkhanz@gmail.com', 'fsfs', '', 'fs', '7777777777', '587.9000', '117.5800', '200.0000', 'Pending', 'paypal', 0, 1, '2016-09-05', 3, '2016-09-05', 3, 'fsfs'),
(391, 'ZS3914139', 26, '3', 'sharaz', 'fdgh', 'sharazkhanz@gmail.com', 'fdghdhfg', '', 'dfghdfgh', '7777777777', '238.0000', '47.6000', '200.0000', 'Pending', 'paypal', 0, 1, '2016-09-05', 3, '2016-09-05', 3, 'dfghd'),
(392, 'ZS3929180', 26, '3', 'dgsdgs', 'dfgsdsdg', 'sharazkhanz@gmail.com', 'gfdsgdf', '', 'dsgsdg', '7777777777', '240.0000', '48.0000', '200.0000', 'Pending', 'paypal', 0, 1, '2016-09-05', 3, '2016-09-05', 3, 'sdgsdf'),
(393, 'ZS3939560', 26, '3', 'errr', 'erer', 'sharazkhanz@gmail.com', 'sss', '', 'fff', '9999999999', '41.1600', '2.6000', '2.0000', 'Authorized', 'paypal', 0, 1, '2017-10-29', 3, '2017-10-29', 3, 'sss');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_orderitems`
--

CREATE TABLE `zselex_orderitems` (
  `item_id` int(11) NOT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `product_options` longtext,
  `price` decimal(15,4) DEFAULT NULL,
  `options_price` decimal(15,4) DEFAULT NULL,
  `total` decimal(15,4) DEFAULT NULL,
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `prd_answer` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_orderitems`
--

INSERT INTO `zselex_orderitems` (`item_id`, `product_id`, `shop_id`, `order_id`, `quantity`, `product_options`, `price`, `options_price`, `total`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `prd_answer`) VALUES
(217, 126, 26, 'ZS1439539', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(216, 127, 26, 'ZS1429479', 1, '', '12.0000', '0.0000', '12.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(215, 126, 26, 'ZS1429479', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(214, 127, 26, 'ZS1415314', 1, '', '12.0000', '0.0000', '12.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(213, 126, 26, 'ZS140654', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(212, 127, 26, 'ZS1397629', 1, '', '12.0000', '0.0000', '12.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(211, 126, 26, 'ZS1383063', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(210, 126, 26, 'ZS1378298', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(209, 126, 26, 'ZS1365841', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(208, 127, 26, 'ZS1365841', 1, '', '12.0000', '0.0000', '12.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(207, 126, 26, 'ZS1356355', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(206, 127, 26, 'ZS1356355', 1, '', '12.0000', '0.0000', '12.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(205, 127, 26, 'ZS1343735', 1, '', '12.0000', '0.0000', '12.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(204, 127, 26, 'ZS1335025', 1, '', '12.0000', '0.0000', '12.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(203, 126, 26, 'ZS1335025', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(202, 120, 26, 'ZS1327982', 1, '', '120.0000', '0.0000', '120.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(201, 122, 26, 'ZS1327982', 1, '', '145.0000', '0.0000', '145.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(200, 123, 26, 'ZS1314208', 1, '', '233.0000', '0.0000', '233.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(199, 122, 26, 'ZS1305145', 1, '', '145.0000', '0.0000', '145.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(198, 123, 26, 'ZS1299980', 1, '', '233.0000', '0.0000', '233.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(197, 122, 26, 'ZS1285641', 1, '', '145.0000', '0.0000', '145.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(196, 120, 26, 'ZS1275941', 1, '', '120.0000', '0.0000', '120.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(195, 123, 26, 'ZS1275941', 1, '', '233.0000', '0.0000', '233.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(194, 122, 26, 'ZS1263939', 1, '', '145.0000', '0.0000', '145.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(193, 120, 26, 'ZS1252622', 1, '', '120.0000', '0.0000', '120.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(192, 120, 26, 'ZS1247104', 1, '', '120.0000', '0.0000', '120.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(191, 120, 26, 'ZS1234790', 1, '', '120.0000', '0.0000', '120.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(190, 122, 26, 'ZS1225994', 1, '', '145.0000', '0.0000', '145.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(189, 120, 26, 'ZS1212141', 1, '', '120.0000', '0.0000', '120.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(218, 126, 26, 'ZS1446168', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(219, 126, 26, 'ZS1451161', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(220, 126, 26, 'ZS1465674', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(221, 126, 26, 'ZS1471701', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(222, 126, 26, 'ZS1488149', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(223, 126, 26, 'ZS1498443', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(224, 126, 26, 'ZS1509300', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(225, 126, 26, 'ZS1519625', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(226, 126, 26, 'ZS1524649', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(227, 126, 26, 'ZS1539149', 1, '', '34.0000', '0.0000', '34.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(228, 127, 26, 'ZS1541454', 1, '', '12.0000', '0.0000', '12.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(229, 146, 26, 'ZS1556128', 1, '[{\"prdToOptionID\":\"1\",\"valueID\":\"1\"},{\"prdToOptionID\":\"2\",\"valueID\":\"4\"}]', '22.0000', '0.0000', '24.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(230, 146, 26, 'ZS1569699', 1, '[{\"prdToOptionID\":\"1\",\"valueID\":\"1\"},{\"prdToOptionID\":\"2\",\"valueID\":\"4\"}]', '22.0000', '0.0000', '24.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(231, 146, 26, 'ZS1573451', 1, '[{\"prdToOptionID\":\"1\",\"valueID\":\"3\"},{\"prdToOptionID\":\"2\",\"valueID\":\"6\"}]', '22.7700', '0.0000', '32.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(232, 146, 26, 'ZS1584054', 1, '[{\"prdToOptionID\":\"1\",\"valueID\":\"3\"},{\"prdToOptionID\":\"2\",\"valueID\":\"6\"}]', '22.7700', '0.0000', '32.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(233, 152, 26, 'ZS1592078', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"12\"}]', '22.7700', '0.0000', '29.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(234, 146, 26, 'ZS1606639', 2, '[{\"prdToOptionID\":\"1\",\"valueID\":\"3\"},{\"prdToOptionID\":\"2\",\"valueID\":\"6\"}]', '22.7700', '0.0000', '65.5400', '0000-00-00', 0, '0000-00-00', 0, NULL),
(235, 146, 26, 'ZS1614944', 2, '[{\"prdToOptionID\":\"1\",\"valueID\":\"3\"},{\"prdToOptionID\":\"2\",\"valueID\":\"6\"}]', '22.7700', '0.0000', '65.5400', '0000-00-00', 0, '0000-00-00', 0, NULL),
(236, 146, 26, 'ZS1628541', 2, '[{\"prdToOptionID\":\"1\",\"valueID\":\"3\"},{\"prdToOptionID\":\"2\",\"valueID\":\"6\"}]', '22.7700', '0.0000', '65.5400', '0000-00-00', 0, '0000-00-00', 0, NULL),
(237, 146, 26, 'ZS1634062', 2, '[{\"prdToOptionID\":\"1\",\"valueID\":\"3\"},{\"prdToOptionID\":\"2\",\"valueID\":\"6\"}]', '22.7700', '0.0000', '65.5400', '0000-00-00', 0, '0000-00-00', 0, NULL),
(238, 146, 26, 'ZS1641379', 1, '[{\"prdToOptionID\":\"1\",\"valueID\":\"1\"},{\"prdToOptionID\":\"2\",\"valueID\":\"5\"}]', '22.7700', '0.0000', '26.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(239, 146, 26, 'ZS1656397', 2, '[{\"prdToOptionID\":\"1\",\"valueID\":\"2\"},{\"prdToOptionID\":\"2\",\"valueID\":\"6\"}]', '22.7700', '0.0000', '59.5400', '0000-00-00', 0, '0000-00-00', 0, NULL),
(240, 146, 26, 'ZS166813', 2, '[{\"prdToOptionID\":\"1\",\"valueID\":\"2\"},{\"prdToOptionID\":\"2\",\"valueID\":\"5\"},{\"prdToOptionID\":\"10\",\"valueID\":\"28\"}]', '22.7700', '6.7000', '58.9400', '0000-00-00', 0, '0000-00-00', 0, NULL),
(241, 134, 26, 'ZS1673492', 2, '[{\"prdToOptionID\":\"7\",\"valueID\":\"21\"},{\"prdToOptionID\":\"8\",\"valueID\":\"22\"},{\"prdToOptionID\":\"9\",\"valueID\":\"24\"}]', '96.0000', '0.0000', '192.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(242, 152, 26, 'ZS1689424', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(243, 152, 26, 'ZS1695675', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(244, 152, 26, 'ZS1702778', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(245, 152, 26, 'ZS1713155', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(246, 152, 26, 'ZS1721979', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(247, 152, 26, 'ZS1735132', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"11\"}]', '22.7700', '2.0000', '24.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(248, 152, 26, 'ZS1741886', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(249, 152, 26, 'ZS1755376', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"8\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(250, 152, 26, 'ZS1765442', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"7\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(251, 152, 26, 'ZS1773622', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"7\"},{\"prdToOptionID\":\"4\",\"valueID\":\"10\"}]', '22.7700', '0.0000', '22.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(252, 152, 26, 'ZS1788028', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"7\"},{\"prdToOptionID\":\"4\",\"valueID\":\"12\"}]', '22.7700', '3.0000', '25.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(253, 152, 26, 'ZS1792954', 1, '[{\"prdToOptionID\":\"3\",\"valueID\":\"7\"},{\"prdToOptionID\":\"4\",\"valueID\":\"12\"}]', '22.7700', '3.0000', '25.7700', '0000-00-00', 0, '0000-00-00', 0, NULL),
(254, 163, 26, 'ZS1804950', 1, '[{\"prdToOptionID\":\"13\",\"valueID\":\"34\"},{\"prdToOptionID\":\"14\",\"valueID\":\"37\"}]', '567.0000', '42.0000', '609.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(255, 133, 26, 'ZS1804950', 1, '', '117.6000', '0.0000', '117.6000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(256, 163, 26, 'ZS1818982', 2, '[{\"prdToOptionID\":\"20\",\"valueID\":\"86\"}]', '567.0000', '8.0000', '1150.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(257, 163, 26, 'ZS1818982', 1, '[{\"prdToOptionID\":\"20\",\"valueID\":\"84\"}]', '567.0000', '3.0000', '570.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(258, 163, 26, 'ZS1818982', 1, '[{\"prdToOptionID\":\"20\",\"valueID\":\"81\"}]', '567.0000', '2.0000', '569.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(259, 163, 26, 'ZS1821989', 1, '[{\"prdToOptionID\":\"20\",\"valueID\":\"81\"}]', '567.0000', '2.0000', '569.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(260, 163, 26, 'ZS1835485', 1, '[{\"prdToOptionID\":\"20\",\"valueID\":\"89\"}]', '567.0000', '-2.0000', '565.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(261, 163, 26, 'ZS1835485', 1, '[{\"prdToOptionID\":\"20\",\"valueID\":\"90\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(262, 163, 26, 'ZS1847900', 1, '[{\"prdToOptionID\":\"20\",\"valueID\":\"92\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(263, 163, 26, 'ZS1847900', 1, '[{\"prdToOptionID\":\"20\",\"valueID\":\"91\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(264, 163, 26, 'ZS1847900', 1, '[{\"prdToOptionID\":\"20\",\"valueID\":\"84\"}]', '567.0000', '3.0000', '570.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(265, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"98\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(266, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"96\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(267, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"97\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(268, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"99\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(269, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"100\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(270, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"101\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(271, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"102\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(272, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"103\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(273, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"104\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(274, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"95\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(275, 163, 26, 'ZS185908', 1, '[{\"prdToOptionID\":\"21\",\"valueID\":\"94\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(276, 163, 26, 'ZS186174', 1, '[{\"prdToOptionID\":\"23\",\"valueID\":\"112\"},{\"prdToOptionID\":\"22\",\"valueID\":\"106\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(277, 163, 26, 'ZS186174', 2, '[{\"prdToOptionID\":\"23\",\"valueID\":\"113\"},{\"prdToOptionID\":\"22\",\"valueID\":\"106\"},{\"prdToOptionID\":\"22\",\"valueID\":\"107\"}]', '567.0000', '0.0000', '1134.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(278, 163, 26, 'ZS186174', 2, '[{\"prdToOptionID\":\"23\",\"valueID\":\"108\"},{\"prdToOptionID\":\"22\",\"valueID\":\"105\"},{\"prdToOptionID\":\"22\",\"valueID\":\"106\"}]', '567.0000', '0.0000', '1134.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(279, 163, 26, 'ZS186174', 1, '[{\"prdToOptionID\":\"23\",\"valueID\":\"108\"},{\"prdToOptionID\":\"22\",\"valueID\":\"106\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(280, 163, 26, 'ZS187481', 1, '[{\"prdToOptionID\":\"23\",\"valueID\":\"109\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(281, 163, 26, 'ZS1888080', 1, '[{\"prdToOptionID\":\"23\",\"valueID\":\"111\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(282, 163, 26, 'ZS189344', 1, '[{\"prdToOptionID\":\"23\",\"valueID\":\"111\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(283, 163, 26, 'ZS1901022', 1, '[{\"prdToOptionID\":\"23\",\"valueID\":\"109\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(284, 163, 26, 'ZS1901022', 1, '[{\"prdToOptionID\":\"23\",\"valueID\":\"108\"}]', '567.0000', '0.0000', '567.0000', '0000-00-00', 0, '0000-00-00', 0, NULL),
(285, 163, 26, 'ZS1916685', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '567.0000', '0.0000', '567.0000', '2014-09-24', 3, '2014-09-24', 3, NULL),
(286, 163, 26, 'ZS1916685', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '567.0000', '0.0000', '567.0000', '2014-09-24', 3, '2014-09-24', 3, NULL),
(287, 163, 26, 'ZS1927491', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"109\";}}', '567.0000', '0.0000', '567.0000', '2014-10-29', 3, '2014-10-29', 3, NULL),
(288, 163, 26, 'ZS1931053', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"108\";}}', '567.0000', '0.0000', '567.0000', '2014-10-29', 3, '2014-10-29', 3, NULL),
(289, 163, 26, 'ZS1943759', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '567.0000', '0.0000', '567.0000', '2014-10-30', 3, '2014-10-30', 3, NULL),
(290, 163, 26, 'ZS1956499', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '567.0000', '0.0000', '567.0000', '2014-10-30', 3, '2014-10-30', 3, NULL),
(291, 163, 26, 'ZS1967841', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"108\";}}', '567.0000', '0.0000', '567.0000', '2014-10-30', 3, '2014-10-30', 3, NULL),
(292, 163, 26, 'ZS1976386', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '567.0000', '0.0000', '567.0000', '2014-10-30', 3, '2014-10-30', 3, NULL),
(293, 163, 26, 'ZS198697', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '567.0000', '6.0000', '573.0000', '2014-10-30', 3, '2014-10-30', 3, NULL),
(294, 163, 26, 'ZS1999663', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '567.0000', '-1.0000', '-1.0000', '2014-11-04', 3, '2014-11-04', 3, NULL),
(295, 163, 26, 'ZS1999663', 2, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '567.0000', '300.0000', '600.0000', '2014-11-04', 3, '2014-11-04', 3, NULL),
(296, 163, 26, 'ZS2007376', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '567.0000', '6.0000', '573.0000', '2014-11-13', 3, '2014-11-13', 3, NULL),
(297, 163, 26, 'ZS2011769', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '567.0000', '300.0000', '300.0000', '2014-11-13', 3, '2014-11-13', 3, NULL),
(298, 163, 26, 'ZS2025254', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '567.0000', '6.0000', '573.0000', '2014-11-14', 3, '2014-11-14', 3, NULL),
(299, 163, 26, 'ZS2036122', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '567.0000', '6.0000', '573.0000', '2014-11-14', 3, '2014-11-14', 3, NULL),
(300, 163, 26, 'ZS2044703', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '567.0000', '6.0000', '573.0000', '2014-11-14', 3, '2014-11-14', 3, NULL),
(301, 163, 26, 'ZS2053075', 2, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '567.0000', '-1.0000', '1132.0000', '2014-11-17', 3, '2014-11-17', 3, NULL),
(302, 163, 26, 'ZS2068443', 2, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '567.0000', '-1.0000', '1132.0000', '2014-11-17', 3, '2014-11-17', 3, NULL),
(303, 163, 26, 'ZS2073031', 2, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '567.0000', '300.0000', '600.0000', '2014-11-17', 3, '2014-11-17', 3, NULL),
(304, 163, 26, 'ZS2085992', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '567.0000', '-1.0000', '566.0000', '2014-11-19', 3, '2014-11-19', 3, 'Test Answer... :)'),
(305, 146, 26, 'ZS2085992', 1, 'a:0:{}', '567.0000', '0.0000', '567.0000', '2014-11-19', 3, '2014-11-19', 3, 'Another Answer for testing... :-('),
(306, 163, 26, 'ZS209190', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '567.0000', '-1.0000', '566.0000', '2014-11-19', 3, '2014-11-19', 3, 'Test Answer... :)'),
(307, 146, 26, 'ZS209190', 1, 'a:0:{}', '567.0000', '0.0000', '567.0000', '2014-11-19', 3, '2014-11-19', 3, 'Another Answer for testing... :-('),
(308, 146, 26, 'ZS2104416', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"24\";s:7:\"valueID\";s:3:\"116\";}}', '2.0000', '2.0000', '2.0000', '2014-11-25', 3, '2014-11-25', 3, ''),
(309, 163, 26, 'ZS2112939', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '566.0000', '-1.0000', '566.0000', '2014-11-28', 3, '2014-11-28', 3, 'dddd'),
(310, 158, 57, 'ZS212210', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"15\";s:7:\"valueID\";s:2:\"40\";}}', '13.0000', '13.0000', '13.0000', '2014-11-28', 3, '2014-11-28', 3, ''),
(311, 163, 26, 'ZS2132175', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2014-11-28', 3, '2014-11-28', 3, 'fhfgh'),
(312, 332, 26, 'ZS2143807', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-22', 3, '2015-01-22', 3, 'hiiii'),
(313, 332, 26, 'ZS2156880', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(314, 163, 26, 'ZS2156880', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(315, 332, 26, 'ZS2163249', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(316, 163, 26, 'ZS2163249', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(317, 332, 26, 'ZS2174031', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(318, 163, 26, 'ZS2174031', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(319, 332, 26, 'ZS2183220', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(320, 163, 26, 'ZS2183220', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(321, 332, 26, 'ZS2194273', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(322, 163, 26, 'ZS2194273', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(323, 332, 26, 'ZS2208694', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(324, 163, 26, 'ZS2208694', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(325, 332, 26, 'ZS2216736', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(326, 163, 26, 'ZS2216736', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(327, 332, 26, 'ZS22279', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(328, 163, 26, 'ZS22279', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(329, 332, 26, 'ZS2231898', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(330, 163, 26, 'ZS2231898', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(331, 332, 26, 'ZS2242680', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(332, 163, 26, 'ZS2242680', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(333, 332, 26, 'ZS2252650', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(334, 163, 26, 'ZS2252650', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(335, 332, 26, 'ZS2268442', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(336, 163, 26, 'ZS2268442', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(337, 332, 26, 'ZS2279028', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(338, 163, 26, 'ZS2279028', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(339, 332, 26, 'ZS2283228', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(340, 163, 26, 'ZS2283228', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(341, 332, 26, 'ZS2292922', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(342, 163, 26, 'ZS2292922', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(343, 332, 26, 'ZS230192', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(344, 163, 26, 'ZS230192', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(345, 332, 26, 'ZS2319866', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-23', 3, '2015-01-23', 3, 'hiiii'),
(346, 163, 26, 'ZS2319866', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-01-23', 3, '2015-01-23', 3, 'xcvcxzv'),
(347, 332, 26, 'ZS2325827', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-24', 3, '2015-01-24', 3, 'hiiii'),
(348, 332, 26, 'ZS2338588', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-24', 3, '2015-01-24', 3, 'hiiii'),
(349, 332, 26, 'ZS2347309', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-24', 3, '2015-01-24', 3, 'hiiii'),
(350, 332, 26, 'ZS2359104', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-24', 3, '2015-01-24', 3, 'hiiii'),
(351, 332, 26, 'ZS2366335', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-24', 3, '2015-01-24', 3, 'jjhhj'),
(352, 332, 26, 'ZS2374837', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-24', 3, '2015-01-24', 3, 'jjhhj'),
(353, 332, 26, 'ZS2387392', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-24', 3, '2015-01-24', 3, 'jjhhj'),
(354, 332, 26, 'ZS2397405', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-28', 3, '2015-01-28', 3, 'jjhhj'),
(355, 330, 26, 'ZS2397405', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"128\";}}', '300.0000', '300.0000', '300.0000', '2015-01-28', 3, '2015-01-28', 3, ''),
(356, 332, 26, 'ZS2401708', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-28', 3, '2015-01-28', 3, 'jjhhj'),
(357, 330, 26, 'ZS2401708', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"128\";}}', '300.0000', '300.0000', '300.0000', '2015-01-28', 3, '2015-01-28', 3, ''),
(358, 332, 26, 'ZS2417652', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-28', 3, '2015-01-28', 3, 'jjhhj'),
(359, 330, 26, 'ZS2417652', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"128\";}}', '300.0000', '300.0000', '300.0000', '2015-01-28', 3, '2015-01-28', 3, ''),
(360, 163, 26, 'ZS2428460', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-28', 3, '2015-01-28', 3, 'dddd'),
(361, 330, 26, 'ZS2434220', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-29', 3, '2015-01-29', 3, 'jjj'),
(362, 330, 26, 'ZS2448601', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-29', 3, '2015-01-29', 3, 'jjj'),
(363, 330, 26, 'ZS2459164', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"125\";}}', '573.0000', '6.0000', '573.0000', '2015-01-29', 3, '2015-01-29', 3, 'dsfsf'),
(364, 330, 26, 'ZS2468386', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"125\";}}', '573.0000', '6.0000', '573.0000', '2015-01-29', 3, '2015-01-29', 3, 'dsfsf'),
(365, 332, 26, 'ZS2468386', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-29', 3, '2015-01-29', 3, 'fsdf'),
(366, 330, 26, 'ZS2471599', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"125\";}}', '573.0000', '6.0000', '573.0000', '2015-01-29', 3, '2015-01-29', 3, 'dsfsf'),
(367, 332, 26, 'ZS2471599', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"132\";}}', '121.0000', '0.0000', '121.0000', '2015-01-29', 3, '2015-01-29', 3, 'fsdf'),
(368, 332, 26, 'ZS2487738', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"131\";}}', '121.0000', '0.0000', '121.0000', '2015-01-29', 2, '2015-01-29', 2, ''),
(369, 330, 26, 'ZS2496918', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-30', 3, '2015-01-30', 3, 'sdfd'),
(370, 330, 26, 'ZS2504835', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-30', 3, '2015-01-30', 3, 'sdfd'),
(371, 330, 26, 'ZS2516483', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"125\";}}', '573.0000', '6.0000', '573.0000', '2015-01-30', 3, '2015-01-30', 3, 'dddd'),
(372, 330, 26, 'ZS2525830', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-30', 3, '2015-01-30', 3, 'jhkj'),
(373, 330, 26, 'ZS2537559', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"128\";}}', '300.0000', '300.0000', '300.0000', '2015-01-30', 3, '2015-01-30', 3, ''),
(374, 330, 26, 'ZS2544769', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-30', 3, '2015-01-30', 3, 'gfdsg'),
(375, 330, 26, 'ZS2558524', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-30', 3, '2015-01-30', 3, 'gfdsg'),
(376, 330, 26, 'ZS2563628', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-01-30', 3, '2015-01-30', 3, 'gfdsg'),
(377, 330, 26, 'ZS2575036', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(378, 328, 26, 'ZS2575036', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(379, 330, 26, 'ZS2585465', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(380, 328, 26, 'ZS2585465', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(381, 330, 26, 'ZS2593628', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(382, 328, 26, 'ZS2593628', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(383, 330, 26, 'ZS2605938', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(384, 328, 26, 'ZS2605938', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(385, 330, 26, 'ZS2617859', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(386, 328, 26, 'ZS2617859', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(387, 330, 26, 'ZS2622778', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(388, 328, 26, 'ZS2622778', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(389, 330, 26, 'ZS263295', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(390, 328, 26, 'ZS263295', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(391, 330, 26, 'ZS2647621', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(392, 328, 26, 'ZS2647621', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(393, 330, 26, 'ZS2654320', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(394, 328, 26, 'ZS2654320', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(395, 330, 26, 'ZS2668151', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(396, 328, 26, 'ZS2668151', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(397, 330, 26, 'ZS2675792', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(398, 328, 26, 'ZS2675792', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(399, 330, 26, 'ZS2689837', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(400, 328, 26, 'ZS2689837', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(401, 330, 26, 'ZS2693026', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(402, 328, 26, 'ZS2693026', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(403, 330, 26, 'ZS270528', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(404, 328, 26, 'ZS270528', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(405, 330, 26, 'ZS2713680', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'gfdsg'),
(406, 328, 26, 'ZS2713680', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-02-01', 3, '2015-02-01', 3, ''),
(407, 330, 26, 'ZS2727686', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"30\";s:7:\"valueID\";s:3:\"126\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-01', 3, '2015-02-01', 3, 'dsfsdf'),
(408, 146, 26, 'ZS2736619', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"24\";s:7:\"valueID\";s:3:\"116\";}}', '2.0000', '2.0000', '2.0000', '2015-02-02', 3, '2015-02-02', 3, ''),
(409, 146, 26, 'ZS2747149', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"24\";s:7:\"valueID\";s:3:\"115\";}}', '2.0000', '2.0000', '2.0000', '2015-02-02', 3, '2015-02-02', 3, 'dsffsdf'),
(410, 163, 26, 'ZS2758969', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-02', 3, '2015-02-02', 3, 'gdfgdg'),
(411, 328, 26, 'ZS2763931', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"118\";}}', '2.0000', '2.0000', '2.0000', '2015-02-03', 3, '2015-02-03', 3, ''),
(412, 328, 26, 'ZS2777741', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"118\";}}', '2.0000', '2.0000', '2.0000', '2015-02-03', 3, '2015-02-03', 3, ''),
(413, 328, 26, 'ZS2786600', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"118\";}}', '2.0000', '2.0000', '2.0000', '2015-02-03', 3, '2015-02-03', 3, ''),
(414, 332, 26, 'ZS2795784', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"134\";}}', '120.0000', '0.0000', '120.0000', '2015-02-08', 3, '2015-02-08', 3, ''),
(415, 328, 26, 'ZS2795784', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"118\";}}', '2.0000', '2.0000', '2.0000', '2015-02-08', 3, '2015-02-08', 3, ''),
(416, 332, 26, 'ZS2802919', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"134\";}}', '120.0000', '0.0000', '120.0000', '2015-02-08', 3, '2015-02-08', 3, ''),
(417, 332, 26, 'ZS2812997', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"133\";}}', '120.0000', '0.0000', '120.0000', '2015-02-08', 3, '2015-02-08', 3, ''),
(418, 332, 26, 'ZS2828147', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"133\";}}', '120.0000', '0.0000', '120.0000', '2015-02-14', 3, '2015-02-14', 3, ''),
(419, 332, 26, 'ZS2833819', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"133\";}}', '120.0000', '0.0000', '120.0000', '2015-02-14', 3, '2015-02-14', 3, ''),
(420, 332, 26, 'ZS2844659', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"133\";}}', '120.0000', '0.0000', '120.0000', '2015-02-15', 3, '2015-02-15', 3, ''),
(421, 332, 26, 'ZS2844659', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"131\";}}', '120.0000', '0.0000', '120.0000', '2015-02-15', 3, '2015-02-15', 3, ''),
(422, 332, 26, 'ZS2859675', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"133\";}}', '120.0000', '0.0000', '120.0000', '2015-02-15', 3, '2015-02-15', 3, ''),
(423, 332, 26, 'ZS2859675', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"131\";}}', '120.0000', '0.0000', '120.0000', '2015-02-15', 3, '2015-02-15', 3, ''),
(424, 332, 26, 'ZS2864693', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"133\";}}', '120.0000', '0.0000', '120.0000', '2015-02-15', 3, '2015-02-15', 3, ''),
(425, 332, 26, 'ZS2864693', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"131\";}}', '120.0000', '0.0000', '120.0000', '2015-02-15', 3, '2015-02-15', 3, ''),
(426, 332, 26, 'ZS2879482', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"32\";s:7:\"valueID\";s:3:\"131\";}}', '120.0000', '0.0000', '120.0000', '2015-02-15', 3, '2015-02-15', 3, ''),
(427, 146, 26, 'ZS288127', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"24\";s:7:\"valueID\";s:3:\"115\";}}', '2.0000', '2.0000', '2.0000', '2015-02-15', 3, '2015-02-15', 3, 'jkkkl'),
(428, 146, 26, 'ZS2899271', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"24\";s:7:\"valueID\";s:3:\"115\";}}', '2.0000', '2.0000', '2.0000', '2015-02-15', 3, '2015-02-15', 3, 'jkkkl'),
(429, 146, 26, 'ZS2908203', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"24\";s:7:\"valueID\";s:3:\"115\";}}', '2.0000', '2.0000', '2.0000', '2015-02-16', 3, '2015-02-16', 3, 'jkkkl'),
(430, 163, 26, 'ZS2908203', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-16', 3, '2015-02-16', 3, 'jjj'),
(431, 163, 26, 'ZS2919359', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"110\";}}', '566.0000', '-1.0000', '566.0000', '2015-02-16', 3, '2015-02-16', 3, 'lkiiii'),
(432, 163, 26, 'ZS2927670', 2, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '1146.0000', '2015-02-16', 3, '2015-02-16', 3, 'nhgh'),
(433, 163, 26, 'ZS2935692', 4, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '300.0000', '300.0000', '1200.0000', '2015-02-16', 3, '2015-02-16', 3, 'helloooo'),
(434, 163, 26, 'ZS2946749', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '300.0000', '300.0000', '300.0000', '2015-02-16', 3, '2015-02-16', 3, 'errrrrr'),
(435, 163, 26, 'ZS2959701', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '300.0000', '300.0000', '300.0000', '2015-02-16', 3, '2015-02-16', 3, 'errrrrr'),
(436, 163, 26, 'ZS2968313', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '300.0000', '300.0000', '300.0000', '2015-02-16', 3, '2015-02-16', 3, 'errrrrr'),
(437, 163, 26, 'ZS2972930', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '300.0000', '300.0000', '300.0000', '2015-02-16', 3, '2015-02-16', 3, 'errrrrr'),
(438, 163, 26, 'ZS2983815', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '300.0000', '300.0000', '300.0000', '2015-02-16', 3, '2015-02-16', 3, 'errrrrr'),
(439, 163, 26, 'ZS2998952', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"114\";}}', '300.0000', '300.0000', '300.0000', '2015-02-16', 3, '2015-02-16', 3, 'errrrrr'),
(440, 328, 26, 'ZS3004389', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"28\";s:7:\"valueID\";s:3:\"117\";}}', '2.0000', '2.0000', '2.0000', '2015-05-31', 3, '2015-05-31', 3, ''),
(441, 357, 26, 'ZS3004389', 1, 'a:0:{}', '128.0000', '0.0000', '128.0000', '2015-05-31', 3, '2015-05-31', 3, ''),
(442, 358, 26, 'ZS3016665', 1, 'a:0:{}', '324.0000', '0.0000', '324.0000', '2015-06-19', 3, '2015-06-19', 3, ''),
(443, 358, 26, 'ZS3026918', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-06-19', 3, '2015-06-19', 3, ''),
(444, 357, 26, 'ZS3036134', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"136\";}}', '31.1600', '3.0000', '31.1600', '2015-06-19', 3, '2015-06-19', 3, ''),
(445, 357, 26, 'ZS3049562', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"136\";}}', '31.1600', '3.0000', '31.1600', '2015-06-19', 3, '2015-06-19', 3, ''),
(446, 357, 26, 'ZS3057678', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"136\";}}', '31.1600', '3.0000', '31.1600', '2015-06-19', 3, '2015-06-19', 3, ''),
(447, 357, 26, 'ZS3062149', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"136\";}}', '31.1600', '3.0000', '31.1600', '2015-06-19', 3, '2015-06-19', 3, ''),
(448, 358, 26, 'ZS3062149', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-06-19', 3, '2015-06-19', 3, ''),
(449, 334, 26, 'ZS3076185', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-06-22', 3, '2015-06-22', 3, 'lll'),
(450, 334, 26, 'ZS3081173', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-07-14', 3, '2015-07-14', 3, 'dfgdgd'),
(451, 334, 26, 'ZS309609', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-07-14', 3, '2015-07-14', 3, 'dfgdgd'),
(452, 334, 26, 'ZS3109134', 2, 'a:0:{}', '70.0000', '0.0000', '140.0000', '2015-07-15', 3, '2015-07-15', 3, 'fdgdg'),
(453, 334, 26, 'ZS3111170', 3, 'a:0:{}', '70.0000', '0.0000', '210.0000', '2015-07-19', 3, '2015-07-19', 3, 'ttrr'),
(454, 334, 26, 'ZS3129972', 3, 'a:0:{}', '70.0000', '0.0000', '210.0000', '2015-07-19', 3, '2015-07-19', 3, 'ttrr'),
(455, 334, 26, 'ZS3135998', 3, 'a:0:{}', '70.0000', '0.0000', '210.0000', '2015-07-19', 3, '2015-07-19', 3, 'ttrr'),
(456, 358, 26, 'ZS3142920', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-08-07', 3, '2015-08-07', 3, ''),
(457, 163, 26, 'ZS3142920', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"23\";s:7:\"valueID\";s:3:\"112\";}}', '573.0000', '6.0000', '573.0000', '2015-08-07', 3, '2015-08-07', 3, 'sdfsdfs'),
(458, 334, 26, 'ZS3142920', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-08-07', 3, '2015-08-07', 3, 'ggdfgsfsdf'),
(459, 358, 26, 'ZS3159360', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-08-18', 3, '2015-08-18', 3, ''),
(460, 334, 26, 'ZS3159360', 2, 'a:0:{}', '70.0000', '0.0000', '140.0000', '2015-08-18', 3, '2015-08-18', 3, 'tytyuruyr'),
(461, 358, 26, 'ZS3162015', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-08-18', 3, '2015-08-18', 3, ''),
(462, 334, 26, 'ZS3162015', 2, 'a:0:{}', '70.0000', '0.0000', '140.0000', '2015-08-18', 3, '2015-08-18', 3, 'tytyuruyr'),
(463, 334, 26, 'ZS3173441', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-08-20', 3, '2015-08-20', 3, 'retre'),
(464, 334, 26, 'ZS3185034', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-08-20', 3, '2015-08-20', 3, 'retre'),
(465, 334, 26, 'ZS3192665', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-08-20', 3, '2015-08-20', 3, 'retre'),
(466, 334, 26, 'ZS3203470', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-08-20', 3, '2015-08-20', 3, 'retre'),
(467, 334, 26, 'ZS3216983', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-09-30', 3, '2015-09-30', 3, 'tetret'),
(468, 334, 26, 'ZS3224724', 1, 'a:0:{}', '70.0000', '0.0000', '70.0000', '2015-09-30', 3, '2015-09-30', 3, 'safasf'),
(469, 358, 26, 'ZS3236790', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-12-17', 3, '2015-12-17', 3, ''),
(470, 358, 26, 'ZS3248538', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-12-17', 3, '2015-12-17', 3, ''),
(471, 358, 26, 'ZS3254068', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-12-17', 3, '2015-12-17', 3, ''),
(472, 358, 26, 'ZS3269886', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-12-17', 3, '2015-12-17', 3, ''),
(473, 358, 26, 'ZS3279750', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-12-17', 3, '2015-12-17', 3, ''),
(474, 358, 26, 'ZS3283920', 1, 'a:0:{}', '360.0000', '0.0000', '360.0000', '2015-12-17', 3, '2015-12-17', 3, ''),
(475, 357, 26, 'ZS3297088', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '30.1600', '2.0000', '30.1600', '2016-01-22', 0, '2016-01-22', 0, ''),
(476, 357, 26, 'ZS3304049', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(477, 357, 26, 'ZS3312212', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(478, 357, 26, 'ZS3323956', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(479, 357, 26, 'ZS3336713', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(480, 357, 26, 'ZS3345967', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(481, 357, 26, 'ZS3357703', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(482, 357, 26, 'ZS3361448', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(483, 357, 26, 'ZS3372161', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(484, 358, 26, 'ZS3383190', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(485, 358, 26, 'ZS3392735', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, '');
INSERT INTO `zselex_orderitems` (`item_id`, `product_id`, `shop_id`, `order_id`, `quantity`, `product_options`, `price`, `options_price`, `total`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `prd_answer`) VALUES
(486, 358, 26, 'ZS3402780', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(487, 358, 26, 'ZS3417992', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(488, 357, 26, 'ZS3417992', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(489, 358, 26, 'ZS3423157', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(490, 357, 26, 'ZS3423157', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(491, 358, 26, 'ZS3431311', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(492, 357, 26, 'ZS3431311', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(493, 358, 26, 'ZS3445250', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(494, 358, 26, 'ZS3453692', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(495, 358, 26, 'ZS346884', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(496, 358, 26, 'ZS3479495', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(497, 358, 26, 'ZS3486786', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(498, 357, 26, 'ZS3486786', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(499, 358, 26, 'ZS349511', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-23', 3, '2016-01-23', 3, ''),
(500, 357, 26, 'ZS349511', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-23', 3, '2016-01-23', 3, ''),
(501, 358, 26, 'ZS3503020', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"153\";}}', '362.9000', '2.0000', '362.9000', '2016-01-24', 2, '2016-01-24', 2, ''),
(502, 357, 26, 'ZS3515521', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-26', 0, '2016-01-26', 0, ''),
(503, 357, 26, 'ZS3529068', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-26', 0, '2016-01-26', 0, ''),
(504, 357, 26, 'ZS3536208', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-26', 0, '2016-01-26', 0, ''),
(505, 358, 26, 'ZS3549007', 2, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '300.0000', '2016-01-26', 0, '2016-01-26', 0, ''),
(506, 358, 26, 'ZS3551084', 3, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '450.0000', '2016-01-27', 0, '2016-01-27', 0, ''),
(507, 358, 26, 'ZS356803', 3, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '450.0000', '2016-01-27', 0, '2016-01-27', 0, ''),
(508, 358, 26, 'ZS3575893', 3, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '450.0000', '2016-01-27', 0, '2016-01-27', 0, ''),
(509, 358, 26, 'ZS3583816', 3, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '450.0000', '2016-01-27', 0, '2016-01-27', 0, ''),
(510, 358, 26, 'ZS3598362', 3, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '450.0000', '2016-01-27', 0, '2016-01-27', 0, ''),
(511, 358, 26, 'ZS360720', 3, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '450.0000', '2016-01-27', 0, '2016-01-27', 0, ''),
(512, 358, 26, 'ZS3612583', 3, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '450.0000', '2016-01-27', 0, '2016-01-27', 0, ''),
(513, 357, 26, 'ZS3624375', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"137\";}}', '32.1600', '4.0000', '32.1600', '2016-01-31', 0, '2016-01-31', 0, ''),
(514, 358, 26, 'ZS3632080', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-31', 0, '2016-01-31', 0, ''),
(515, 358, 26, 'ZS3643425', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-01-31', 0, '2016-01-31', 0, ''),
(516, 358, 26, 'ZS3651658', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-02-15', 0, '2016-02-15', 0, ''),
(517, 357, 26, 'ZS3669417', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '30.1600', '2.0000', '30.1600', '2016-02-15', 0, '2016-02-15', 0, ''),
(518, 357, 26, 'ZS3678252', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '30.1600', '2.0000', '30.1600', '2016-02-15', 0, '2016-02-15', 0, ''),
(519, 357, 26, 'ZS3685227', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '30.1600', '2.0000', '30.1600', '2016-02-15', 0, '2016-02-15', 0, ''),
(520, 357, 26, 'ZS3696549', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '30.1600', '2.0000', '30.1600', '2016-02-15', 0, '2016-02-15', 0, ''),
(521, 357, 26, 'ZS3707868', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '30.1600', '2.0000', '30.1600', '2016-02-15', 0, '2016-02-15', 0, ''),
(522, 357, 26, 'ZS3719098', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '30.1600', '2.0000', '30.1600', '2016-06-26', 0, '2016-06-26', 0, ''),
(523, 357, 26, 'ZS3727183', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"33\";s:7:\"valueID\";s:3:\"135\";}}', '30.1600', '2.0000', '30.1600', '2016-06-26', 0, '2016-06-26', 0, ''),
(524, 367, 26, 'ZS3731195', 3, 'a:0:{}', '0.0000', '0.0000', '0.0000', '2016-06-26', 3, '2016-06-26', 3, ''),
(525, 358, 26, 'ZS3731195', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"153\";}}', '362.9000', '2.0000', '362.9000', '2016-06-26', 3, '2016-06-26', 3, ''),
(526, 369, 61, 'ZS3748660', 1, 'a:0:{}', '111.0000', '0.0000', '111.0000', '2016-06-26', 3, '2016-06-26', 3, ''),
(527, 369, 61, 'ZS3753530', 2, 'a:0:{}', '111.0000', '0.0000', '222.0000', '2016-06-26', 3, '2016-06-26', 3, ''),
(528, 369, 61, 'ZS3768653', 1, 'a:0:{}', '111.0000', '0.0000', '111.0000', '2016-06-27', 0, '2016-06-27', 0, ''),
(529, 358, 26, 'ZS377548', 2, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '300.0000', '2016-06-27', 0, '2016-06-27', 0, ''),
(530, 367, 26, 'ZS377548', 2, 'a:0:{}', '0.0000', '0.0000', '0.0000', '2016-06-27', 0, '2016-06-27', 0, ''),
(531, 358, 26, 'ZS378863', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"36\";s:7:\"valueID\";s:3:\"154\";}}', '150.0000', '150.0000', '150.0000', '2016-06-28', 0, '2016-06-28', 0, ''),
(532, 358, 26, 'ZS3796762', 2, 'a:0:{}', '360.9000', '0.0000', '721.8000', '2016-07-02', 0, '2016-07-02', 0, ''),
(533, 358, 26, 'ZS3804262', 1, 'a:0:{}', '360.9000', '0.0000', '360.9000', '2016-07-03', 0, '2016-07-03', 0, ''),
(534, 367, 26, 'ZS3813633', 2, 'a:0:{}', '27.0000', '0.0000', '54.0000', '2016-08-25', 3, '2016-08-25', 3, ''),
(535, 367, 26, 'ZS3822269', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-08-25', 3, '2016-08-25', 3, ''),
(536, 358, 26, 'ZS383327', 1, 'a:0:{}', '360.9000', '0.0000', '360.9000', '2016-08-25', 3, '2016-08-25', 3, ''),
(537, 367, 26, 'ZS3849731', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-08-26', 0, '2016-08-26', 0, ''),
(538, 358, 26, 'ZS3849731', 1, 'a:0:{}', '360.9000', '0.0000', '360.9000', '2016-08-26', 0, '2016-08-26', 0, ''),
(539, 367, 26, 'ZS3858213', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-08-26', 0, '2016-08-26', 0, ''),
(540, 358, 26, 'ZS3858213', 1, 'a:0:{}', '360.9000', '0.0000', '360.9000', '2016-08-26', 0, '2016-08-26', 0, ''),
(541, 367, 26, 'ZS3867918', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-08-26', 0, '2016-08-26', 0, ''),
(542, 358, 26, 'ZS3867918', 1, 'a:0:{}', '360.9000', '0.0000', '360.9000', '2016-08-26', 0, '2016-08-26', 0, ''),
(543, 367, 26, 'ZS3873945', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-08-26', 0, '2016-08-26', 0, ''),
(544, 358, 26, 'ZS3873945', 1, 'a:0:{}', '360.9000', '0.0000', '360.9000', '2016-08-26', 0, '2016-08-26', 0, ''),
(545, 367, 26, 'ZS3884795', 2, 'a:0:{}', '27.0000', '0.0000', '54.0000', '2016-08-26', 0, '2016-08-26', 0, ''),
(546, 358, 26, 'ZS3884795', 2, 'a:0:{}', '360.9000', '0.0000', '721.8000', '2016-08-26', 0, '2016-08-26', 0, ''),
(547, 358, 26, 'ZS3899379', 1, 'a:0:{}', '360.9000', '0.0000', '360.9000', '2016-09-05', 3, '2016-09-05', 3, ''),
(548, 367, 26, 'ZS3899379', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-09-05', 3, '2016-09-05', 3, ''),
(549, 358, 26, 'ZS3906979', 1, 'a:0:{}', '360.9000', '0.0000', '360.9000', '2016-09-05', 3, '2016-09-05', 3, ''),
(550, 367, 26, 'ZS3906979', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-09-05', 3, '2016-09-05', 3, ''),
(551, 367, 26, 'ZS3914139', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-09-05', 3, '2016-09-05', 3, ''),
(552, 358, 26, 'ZS3914139', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"37\";s:7:\"valueID\";s:3:\"155\";}}', '11.0000', '11.0000', '11.0000', '2016-09-05', 3, '2016-09-05', 3, ''),
(553, 367, 26, 'ZS3929180', 1, 'a:0:{}', '27.0000', '0.0000', '27.0000', '2016-09-05', 3, '2016-09-05', 3, ''),
(554, 358, 26, 'ZS3929180', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"37\";s:7:\"valueID\";s:3:\"157\";}}', '13.0000', '13.0000', '13.0000', '2016-09-05', 3, '2016-09-05', 3, ''),
(555, 358, 26, 'ZS3939560', 1, 'a:1:{i:0;a:2:{s:13:\"prdToOptionID\";s:2:\"37\";s:7:\"valueID\";s:3:\"155\";}}', '11.0000', '11.0000', '11.0000', '2017-10-29', 3, '2017-10-29', 3, ''),
(556, 357, 26, 'ZS3939560', 1, 'a:0:{}', '28.1600', '0.0000', '28.1600', '2017-10-29', 3, '2017-10-29', 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_parent`
--

CREATE TABLE `zselex_parent` (
  `tableId` int(11) NOT NULL,
  `childType` varchar(150) NOT NULL,
  `childId` int(11) NOT NULL,
  `parentId` int(11) NOT NULL,
  `parentType` varchar(150) NOT NULL,
  `status` int(11) NOT NULL,
  `obj_status` varchar(10) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_parent`
--

INSERT INTO `zselex_parent` (`tableId`, `childType`, `childId`, `parentId`, `parentType`, `status`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(375, 'CITY', 28, 0, 'CITY', 0, '', '2012-11-29 09:32:39', 3, '2012-11-29 09:32:39', 3),
(82, 'CITY', 27, 9, 'REGION', 0, '', '2012-03-07 18:47:31', 2, '2012-03-07 18:47:31', 2),
(81, 'CITY', 26, 11, 'REGION', 0, '', '2012-03-07 18:46:29', 2, '2012-03-07 18:46:29', 2),
(80, 'CITY', 25, 8, 'REGION', 0, '', '2012-03-07 18:46:11', 2, '2012-03-07 18:46:11', 2),
(79, 'CITY', 24, 7, 'REGION', 0, '', '2012-03-07 18:45:43', 2, '2012-03-07 18:45:43', 2),
(78, 'CITY', 23, 7, 'REGION', 0, '', '2012-03-07 18:45:24', 2, '2012-03-07 18:45:24', 2),
(272, 'REGION', 11, 61, 'COUNTRY', 0, '', '2012-11-12 08:40:44', 3, '2012-11-12 08:40:44', 3),
(274, 'REGION', 10, 61, 'COUNTRY', 0, '', '2012-11-12 08:41:09', 3, '2012-11-12 08:41:09', 3),
(278, 'REGION', 8, 61, 'COUNTRY', 0, '', '2012-11-12 08:41:35', 3, '2012-11-12 08:41:35', 3),
(276, 'REGION', 9, 61, 'COUNTRY', 0, '', '2012-11-12 08:41:20', 3, '2012-11-12 08:41:20', 3),
(280, 'REGION', 7, 61, 'COUNTRY', 0, '', '2012-11-12 08:41:58', 3, '2012-11-12 08:41:58', 3),
(72, 'COUNTRY', 7, 0, '', 0, '', '2012-03-07 18:41:05', 2, '2012-03-07 18:41:05', 2),
(99, 'SHOP', 19, 26, 'CITY', 0, '', '2012-03-08 09:59:40', 2, '2012-03-08 09:59:40', 2),
(103, 'SHOP', 20, 23, 'CITY', 0, '', '2012-03-08 10:01:49', 3, '2012-03-08 10:01:49', 3),
(107, 'SHOP', 22, 27, 'CITY', 0, '', '2012-03-08 10:21:36', 3, '2012-03-08 10:21:36', 3),
(137, 'REGION', 12, 7, 'COUNTRY', 0, '', '2012-03-27 09:23:45', 3, '2012-03-27 09:23:45', 3),
(138, 'REGION', 12, 7, 'REGION', 0, '', '2012-03-27 09:23:45', 3, '2012-03-27 09:23:45', 3),
(397, 'SHOP', 26, 3, 'CATEGORY', 0, '', '2012-12-04 17:29:28', 3, '2012-12-04 17:29:28', 3),
(365, 'SHOP', 23, 7, 'REGION', 0, '', '2012-11-23 07:12:01', 2, '2012-11-23 07:12:01', 2),
(364, 'SHOP', 23, 61, 'COUNTRY', 0, '', '2012-11-23 07:12:01', 2, '2012-11-23 07:12:01', 2),
(363, 'SHOP', 23, 23, 'CITY', 0, '', '2012-11-23 07:12:01', 2, '2012-11-23 07:12:01', 2),
(353, 'SHOP', 16, 7, 'REGION', 0, '', '2012-11-23 07:10:55', 2, '2012-11-23 07:10:55', 2),
(387, 'SHOP', 15, 7, 'AREA', 0, '', '2012-12-04 15:44:50', 3, '2012-12-04 15:44:50', 3),
(247, 'SHOP', 0, 0, 'SHOP', 0, '', '2012-10-10 15:01:38', 3, '2012-10-10 15:01:38', 3),
(260, 'COUNTRY', 1, 0, 'COUNTRY', 0, '', '2012-11-07 16:52:03', 3, '2012-11-07 16:52:03', 3),
(386, 'SHOP', 15, 7, 'REGION', 0, '', '2012-12-04 15:44:50', 3, '2012-12-04 15:44:50', 3),
(385, 'SHOP', 15, 61, 'COUNTRY', 0, '', '2012-12-04 15:44:50', 3, '2012-12-04 15:44:50', 3),
(354, 'SHOP', 16, 4, 'CATEGORY', 0, '', '2012-11-23 07:10:55', 2, '2012-11-23 07:10:55', 2),
(380, 'SHOP', 17, 7, 'REGION', 0, '', '2012-11-29 16:46:38', 2, '2012-11-29 16:46:38', 2),
(360, 'SHOP', 18, 12, 'REGION', 0, '', '2012-11-23 07:11:25', 2, '2012-11-23 07:11:25', 2),
(273, 'REGION', 11, 0, 'REGION', 0, '', '2012-11-12 08:40:44', 3, '2012-11-12 08:40:44', 3),
(275, 'REGION', 10, 0, 'REGION', 0, '', '2012-11-12 08:41:09', 3, '2012-11-12 08:41:09', 3),
(277, 'REGION', 9, 0, 'REGION', 0, '', '2012-11-12 08:41:20', 3, '2012-11-12 08:41:20', 3),
(279, 'REGION', 8, 0, 'REGION', 0, '', '2012-11-12 08:41:35', 3, '2012-11-12 08:41:35', 3),
(281, 'REGION', 7, 0, 'REGION', 0, '', '2012-11-12 08:41:58', 3, '2012-11-12 08:41:58', 3),
(379, 'SHOP', 17, 61, 'COUNTRY', 0, '', '2012-11-29 16:46:38', 2, '2012-11-29 16:46:38', 2),
(514, 'SHOP', 14, 2, 'CATEGORY', 0, '', '2013-01-22 12:27:38', 3, '2013-01-22 12:27:38', 3),
(352, 'SHOP', 16, 61, 'COUNTRY', 0, '', '2012-11-23 07:10:55', 2, '2012-11-23 07:10:55', 2),
(359, 'SHOP', 18, 103, 'COUNTRY', 0, '', '2012-11-23 07:11:25', 2, '2012-11-23 07:11:25', 2),
(384, 'SHOP', 15, 23, 'CITY', 0, '', '2012-12-04 15:44:50', 3, '2012-12-04 15:44:50', 3),
(351, 'SHOP', 16, 24, 'CITY', 0, '', '2012-11-23 07:10:55', 2, '2012-11-23 07:10:55', 2),
(513, 'SHOP', 14, 7, 'REGION', 0, '', '2013-01-22 12:27:38', 3, '2013-01-22 12:27:38', 3),
(378, 'SHOP', 17, 23, 'CITY', 0, '', '2012-11-29 16:46:38', 2, '2012-11-29 16:46:38', 2),
(361, 'SHOP', 18, 5, 'CATEGORY', 0, '', '2012-11-23 07:11:25', 2, '2012-11-23 07:11:25', 2),
(362, 'SHOP', 21, 4, 'CATEGORY', 0, '', '2012-11-23 07:11:46', 2, '2012-11-23 07:11:46', 2),
(366, 'SHOP', 23, 4, 'CATEGORY', 0, '', '2012-11-23 07:12:01', 2, '2012-11-23 07:12:01', 2),
(395, 'SHOP', 26, 18, 'COUNTRY', 0, '', '2012-12-04 17:29:28', 3, '2012-12-04 17:29:28', 3),
(396, 'SHOP', 26, 12, 'REGION', 0, '', '2012-12-04 17:29:28', 3, '2012-12-04 17:29:28', 3),
(371, 'AREA', 6, 103, 'COUNTRY', 0, '', '2012-11-29 09:27:27', 3, '2012-11-29 09:27:27', 3),
(372, 'AREA', 7, 28, 'CITY', 0, '', '2012-11-29 09:31:12', 3, '2012-11-29 09:31:12', 3),
(534, 'AREA', 8, 61, 'COUNTRY', 0, '', '2013-09-24 15:29:31', 3, '2013-09-24 15:29:31', 3),
(374, 'AREA', 9, 28, 'CITY', 0, '', '2012-11-29 09:31:40', 3, '2012-11-29 09:31:40', 3),
(376, 'CITY', 28, 61, 'COUNTRY', 0, '', '2012-11-29 09:32:39', 3, '2012-11-29 09:32:39', 3),
(377, 'CITY', 28, 8, 'REGION', 0, '', '2012-11-29 09:32:39', 3, '2012-11-29 09:32:39', 3),
(381, 'SHOP', 17, 5, 'CATEGORY', 0, '', '2012-11-29 16:46:38', 2, '2012-11-29 16:46:38', 2),
(382, 'SHOP', 17, 3, 'BRANCH', 0, '', '2012-11-29 16:46:38', 2, '2012-11-29 16:46:38', 2),
(432, 'SHOP', 32, 13, 'REGION', 0, '', '2012-12-12 13:01:46', 3, '2012-12-12 13:01:46', 3),
(388, 'SHOP', 15, 2, 'CATEGORY', 0, '', '2012-12-04 15:44:50', 3, '2012-12-04 15:44:50', 3),
(512, 'SHOP', 14, 61, 'COUNTRY', 0, '', '2013-01-22 12:27:38', 3, '2013-01-22 12:27:38', 3),
(480, 'SHOP', 33, 3, 'CATEGORY', 0, '', '2012-12-20 10:18:37', 3, '2012-12-20 10:18:37', 3),
(479, 'SHOP', 33, 7, 'AREA', 0, '', '2012-12-20 10:18:37', 3, '2012-12-20 10:18:37', 3),
(478, 'SHOP', 33, 13, 'REGION', 0, '', '2012-12-20 10:18:37', 3, '2012-12-20 10:18:37', 3),
(477, 'SHOP', 33, 103, 'COUNTRY', 0, '', '2012-12-20 10:18:37', 3, '2012-12-20 10:18:37', 3),
(476, 'SHOP', 33, 29, 'CITY', 0, '', '2012-12-20 10:18:37', 3, '2012-12-20 10:18:37', 3),
(419, 'REGION', 13, 103, 'COUNTRY', 0, '', '2012-12-12 10:57:42', 3, '2012-12-12 10:57:42', 3),
(420, 'REGION', 13, 0, 'REGION', 0, '', '2012-12-12 10:57:42', 3, '2012-12-12 10:57:42', 3),
(421, 'CITY', 29, 0, 'CITY', 0, '', '2012-12-12 10:58:18', 3, '2012-12-12 10:58:18', 3),
(422, 'CITY', 29, 103, 'COUNTRY', 0, '', '2012-12-12 10:58:18', 3, '2012-12-12 10:58:18', 3),
(423, 'CITY', 29, 13, 'REGION', 0, '', '2012-12-12 10:58:18', 3, '2012-12-12 10:58:18', 3),
(431, 'SHOP', 32, 103, 'COUNTRY', 0, '', '2012-12-12 13:01:46', 3, '2012-12-12 13:01:46', 3),
(430, 'SHOP', 32, 29, 'CITY', 0, '', '2012-12-12 13:01:46', 3, '2012-12-12 13:01:46', 3),
(511, 'SHOP', 14, 24, 'CITY', 0, '', '2013-01-22 12:27:38', 3, '2013-01-22 12:27:38', 3),
(481, 'SHOP', 33, 3, 'BRANCH', 0, '', '2012-12-20 10:18:37', 3, '2012-12-20 10:18:37', 3),
(510, 'SHOP', 37, 5, 'CATEGORY', 0, '', '2013-01-17 10:41:06', 2, '2013-01-17 10:41:06', 2),
(509, 'SHOP', 37, 7, 'REGION', 0, '', '2013-01-17 10:41:06', 2, '2013-01-17 10:41:06', 2),
(508, 'SHOP', 37, 61, 'COUNTRY', 0, '', '2013-01-17 10:41:06', 2, '2013-01-17 10:41:06', 2),
(507, 'SHOP', 37, 23, 'CITY', 0, '', '2013-01-17 10:41:06', 2, '2013-01-17 10:41:06', 2),
(495, 'SHOP', 35, 0, 'CITY', 0, '', '2013-01-17 08:44:23', 3, '2013-01-17 08:44:23', 3),
(496, 'SHOP', 35, 0, 'COUNTRY', 0, '', '2013-01-17 08:44:23', 3, '2013-01-17 08:44:23', 3),
(497, 'SHOP', 35, 0, 'REGION', 0, '', '2013-01-17 08:44:23', 3, '2013-01-17 08:44:23', 3),
(498, 'SHOP', 35, 0, 'AREA', 0, '', '2013-01-17 08:44:23', 3, '2013-01-17 08:44:23', 3),
(499, 'SHOP', 36, 28, 'CITY', 0, '', '2013-01-17 08:50:35', 3, '2013-01-17 08:50:35', 3),
(500, 'SHOP', 36, 61, 'COUNTRY', 0, '', '2013-01-17 08:50:35', 3, '2013-01-17 08:50:35', 3),
(501, 'SHOP', 36, 8, 'REGION', 0, '', '2013-01-17 08:50:35', 3, '2013-01-17 08:50:35', 3),
(502, 'SHOP', 36, 9, 'AREA', 0, '', '2013-01-17 08:50:35', 3, '2013-01-17 08:50:35', 3),
(515, 'REGION', 7, 0, 'REGION', 0, '', '2013-04-19 09:15:49', 3, '2013-04-19 09:15:49', 3),
(516, 'REGION', 7, 0, 'REGION', 0, '', '2013-04-19 09:16:03', 3, '2013-04-19 09:16:03', 3),
(517, 'REGION', 11, 0, 'REGION', 0, '', '2013-04-19 10:51:50', 2, '2013-04-19 10:51:50', 2),
(518, 'REGION', 10, 0, 'REGION', 0, '', '2013-04-19 10:52:07', 2, '2013-04-19 10:52:07', 2),
(519, 'REGION', 9, 0, 'REGION', 0, '', '2013-04-19 10:52:18', 2, '2013-04-19 10:52:18', 2),
(520, 'REGION', 8, 0, 'REGION', 0, '', '2013-04-19 10:52:28', 2, '2013-04-19 10:52:28', 2),
(521, 'CITY', 28, 0, 'CITY', 0, '', '2013-04-19 10:53:55', 2, '2013-04-19 10:53:55', 2),
(522, 'CITY', 28, 0, 'CITY', 0, '', '2013-04-19 10:54:06', 2, '2013-04-19 10:54:06', 2),
(523, 'CITY', 27, 0, 'CITY', 0, '', '2013-04-19 10:54:29', 2, '2013-04-19 10:54:29', 2),
(524, 'CITY', 26, 0, 'CITY', 0, '', '2013-04-19 10:54:57', 2, '2013-04-19 10:54:57', 2),
(525, 'CITY', 24, 0, 'CITY', 0, '', '2013-04-19 10:55:15', 2, '2013-04-19 10:55:15', 2),
(526, 'CITY', 23, 0, 'CITY', 0, '', '2013-04-19 10:55:37', 2, '2013-04-19 10:55:37', 2),
(527, 'REGION', 7, 0, 'REGION', 0, '', '2013-06-13 10:56:51', 2, '2013-06-13 10:56:51', 2),
(528, 'REGION', 11, 0, 'REGION', 0, '', '2013-06-13 10:58:16', 2, '2013-06-13 10:58:16', 2),
(529, 'REGION', 14, 0, 'REGION', 0, '', '2013-06-13 10:58:50', 2, '2013-06-13 10:58:50', 2),
(530, 'CITY', 24, 0, 'CITY', 0, '', '2013-06-13 11:00:35', 2, '2013-06-13 11:00:35', 2),
(531, 'CITY', 30, 0, 'CITY', 0, '', '2013-09-11 17:11:21', 2, '2013-09-11 17:11:21', 2),
(532, 'CITY', 31, 0, 'CITY', 0, '', '2013-09-11 17:11:50', 2, '2013-09-11 17:11:50', 2),
(533, 'CITY', 32, 0, 'CITY', 0, '', '2013-09-11 17:12:22', 2, '2013-09-11 17:12:22', 2),
(535, 'REGION', 15, 0, 'REGION', 0, '', '2013-11-06 13:41:22', 2, '2013-11-06 13:41:22', 2),
(536, 'REGION', 16, 0, 'REGION', 0, '', '2014-07-14 11:25:03', 3, '2014-07-14 11:25:03', 3),
(537, 'CITY', 33, 0, 'CITY', 0, '', '2014-07-14 11:25:36', 3, '2014-07-14 11:25:36', 3),
(538, 'AREA', 10, 61, 'COUNTRY', 0, '', '2014-07-14 11:26:11', 3, '2014-07-14 11:26:11', 3),
(539, 'AREA', 10, 16, 'REGION', 0, '', '2014-07-14 11:26:11', 3, '2014-07-14 11:26:11', 3),
(540, 'AREA', 10, 33, 'CITY', 0, '', '2014-07-14 11:26:11', 3, '2014-07-14 11:26:11', 3),
(541, 'SHOP', 58, 125, 'SHOPADMIN', 0, '', '2014-08-04 09:25:28', 2, '2014-08-04 09:25:28', 2),
(542, 'SHOP', 26, 132, 'SHOPADMIN', 0, '', '2014-11-28 16:37:03', 3, '2014-11-28 16:37:03', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_paypal`
--

CREATE TABLE `zselex_paypal` (
  `id` int(11) NOT NULL,
  `paypal_email` varchar(250) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zselex_plugin`
--

CREATE TABLE `zselex_plugin` (
  `plugin_id` int(11) NOT NULL,
  `plugin_name` varchar(250) DEFAULT NULL,
  `identifier` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `qty_based` tinyint(1) DEFAULT NULL,
  `description` longtext,
  `content` longtext,
  `price` decimal(15,4) DEFAULT NULL,
  `bundle` tinyint(1) DEFAULT NULL,
  `bundle_id` int(11) DEFAULT NULL,
  `top_bundle` tinyint(1) DEFAULT NULL,
  `service_depended` tinyint(1) DEFAULT NULL,
  `depended_services` longtext,
  `shop_depended` tinyint(1) DEFAULT NULL,
  `depended_shoptypes` longtext,
  `is_editable` tinyint(1) DEFAULT NULL,
  `func_name` varchar(250) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `demo` tinyint(1) DEFAULT NULL,
  `demoperiod` int(11) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_plugin`
--

INSERT INTO `zselex_plugin` (`plugin_id`, `plugin_name`, `identifier`, `type`, `qty_based`, `description`, `content`, `price`, `bundle`, `bundle_id`, `top_bundle`, `service_depended`, `depended_services`, `shop_depended`, `depended_shoptypes`, `is_editable`, `func_name`, `status`, `demo`, `demoperiod`, `sort_order`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(2, 'Advertise', 'createad', 'createad', 1, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:13:\"Opret Reklame\";s:11:\"infomessage\";s:148:\"Servicen Opret Reklame er beregnet på produkter i din Mini Shop.\r\nMed denne service kan du så eksponeret udvalgte produkter udenfor din Mini Shop.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:9:\"Create AD\";s:11:\"infomessage\";s:77:\"The service Create AD is used to promote selected products in your Mini Shop.\";}}', '10.0000', 0, 0, 0, 1, 'a:3:{i:0;a:3:{s:9:\"plugin_id\";i:33;s:4:\"type\";s:9:\"diskquota\";s:4:\"name\";s:9:\"Diskquota\";}i:1;a:3:{s:9:\"plugin_id\";i:10;s:4:\"type\";s:8:\"minishop\";s:4:\"name\";s:8:\"Minishop\";}i:2;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:8:\"Minisite\";}}', 0, '', 1, 'viewadvertise', 1, 1, 8, 32, '2012-04-24 15:50:38', 3, '2014-06-06 16:26:31', 3),
(4, 'Minishop Products', 'addproducts', 'addproducts', 1, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:17:\"Tilføj produkter\";s:11:\"infomessage\";s:82:\"Tilføj produkter er nødvendig for at kunne tilføje produkter til din Mini Shop.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:12:\"Add Products\";s:11:\"infomessage\";s:71:\"Add Products is necessary to be able to add products to your Mini Shop.\";}}', '5.0000', 0, 0, 0, 1, 'a:3:{i:0;a:3:{s:9:\"plugin_id\";i:33;s:4:\"type\";s:9:\"diskquota\";s:4:\"name\";s:9:\"Diskquota\";}i:1;a:3:{s:9:\"plugin_id\";i:10;s:4:\"type\";s:8:\"minishop\";s:4:\"name\";s:8:\"Minishop\";}i:2;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:8:\"Minisite\";}}', 0, '', 1, 'viewproducts', 1, 1, 100, 31, '2012-05-10 16:06:55', 3, '2013-12-11 07:26:08', 3),
(24, 'Google Map', 'minisitegooglemap', 'minisitegooglemap', 0, '', 'a:3:{s:11:\"displayinfo\";s:3:\"yes\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:10:\"Google Map\";s:11:\"infomessage\";s:104:\"Google Map servicen placerer et kort på siden Find Os og viser hvor jeres adressen er placeret på det.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:10:\"Google Map\";s:11:\"infomessage\";s:101:\"The Google Map service places a map on the Find Us page and shows where your address is placed in it.\";}}', '1.0000', 0, 0, 0, 0, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:9:\"Mini Site\";}}', 0, '', 0, '', 1, 1, 100, 61, '2012-12-04 18:27:49', 3, '2013-10-10 07:01:21', 2),
(10, 'Minishop', 'minishop', 'minishop', 0, 'display all shop products in minishop', 'a:3:{s:11:\"displayinfo\";s:3:\"yes\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:8:\"Minishop\";s:11:\"infomessage\";s:192:\"Minishop servicen er en komplet webshop, som er integreret 100% på dit Mini Site.\r\nHvis du ejer flere butikker eller er del af en kæde kan man desuden med de rigtige tillægsservices vise...\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:8:\"Minishop\";s:11:\"infomessage\";s:168:\"The Minishop service is a complete webshop integrated 100% in your Mini Site.\r\nIf you own more than one shop or you are part of a chain of shops and you purchase the...\";}}', '250.0000', 0, 0, 0, 0, '', 0, '', 1, '', 1, 1, 100, 30, '2012-08-24 15:19:31', 3, '2014-06-18 11:04:03', 3),
(11, 'Minisite Product Block', 'minisiteproductblock', 'minisiteproductblock', 0, 'display products in mini site of shop', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:23:\"Mini Site Product Block\";s:11:\"infomessage\";s:105:\"Mini Site Product Block giver mulighed for at få vist tilfældige produkter i en blok på sit Mini Site.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:23:\"Mini Site Product Block\";s:11:\"infomessage\";s:95:\"Mini Site product Block makes it possible to show random products in a block in your Mini Site.\";}}', '25.0000', 0, 0, 0, 0, '', 0, '', 0, '', 1, 1, 5, 50, '2012-08-24 15:20:13', 3, '2013-10-10 07:01:21', 2),
(12, 'Deal Of The Day', 'dealoftheday', 'dealoftheday', 0, 'displays the deal of the day product', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:15:\"Deal Of The Day\";s:11:\"infomessage\";s:210:\"Dagens tilbud (også kaldet DOTD) benyttes til at få eksponeret et bestemt tilbud, som kun gælder 24 timer.\r\nMan kan kun booke sig ind på 1 dag af gangen. Når det aktuelle DOTD er ovre kan man booke et nyt.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:15:\"Deal Of The Day\";s:11:\"infomessage\";s:197:\"Deal of the day (or DOTD) is used to expose a certain special offer that only is valid for 24 hours.\r\nYou can only book 1 DOTD at any one time. When the current DOTD is over you can book a new one.\";}}', '25.0000', 0, 0, 0, 1, 'a:4:{i:0;a:3:{s:9:\"plugin_id\";i:4;s:4:\"type\";s:11:\"addproducts\";s:4:\"name\";s:12:\"Add Products\";}i:1;a:3:{s:9:\"plugin_id\";i:33;s:4:\"type\";s:9:\"diskquota\";s:4:\"name\";s:9:\"Diskquota\";}i:2;a:3:{s:9:\"plugin_id\";i:10;s:4:\"type\";s:8:\"minishop\";s:4:\"name\";s:9:\"Mini Shop\";}i:3;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:9:\"Mini Site\";}}', 0, '', 1, 'viewdotd', 0, 1, 5, 51, '2012-08-24 15:21:06', 3, '2013-10-10 07:01:21', 2),
(17, 'Minisite Gallery', 'minisitegallery', 'minisitegallery', 1, '', 'a:3:{s:11:\"displayinfo\";s:3:\"yes\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:16:\"Minisite Galleri\";s:11:\"infomessage\";s:154:\"Hvis du har brug for et billedgalleri er det denne service du skal vælge.\r\nDu bestemmer selv antallet af billeder og de bliver vist i en gallerifunktion.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:16:\"Minisite Gallery\";s:11:\"infomessage\";s:163:\"If you are looking for an image gallery this is the service to choose.\r\nYou decide how many images you want to upload and they will be shown in a gallery function.\";}}', '5.0000', 0, 0, 0, 1, 'a:2:{i:0;a:3:{s:9:\"plugin_id\";i:33;s:4:\"type\";s:9:\"diskquota\";s:4:\"name\";s:9:\"Diskquota\";}i:1;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:8:\"Minisite\";}}', 0, '', 1, 'viewshopgalleryimages', 0, 1, 3, 12, '2012-11-26 08:46:11', 3, '2013-10-10 07:01:21', 2),
(18, 'Minisite Images', 'minisiteimages', 'minisiteimages', 1, '', 'a:3:{s:11:\"displayinfo\";s:3:\"yes\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:18:\"Mini Site Billeder\";s:11:\"infomessage\";s:173:\"Mini Site Billeder giver mulighed for at uploade billeder til sit site. Billederne bliver bl.a. vist på forsiden og i en billedblok. Begrænset antal billeder kan uploades.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:16:\"Mini Site Images\";s:11:\"infomessage\";s:165:\"Mini Site Images makes it possible to upload images to your site. Images will be shown on front page and in an image block. Limited amount of images can be uploaded.\";}}', '1.0000', 0, 0, 0, 1, 'a:2:{i:0;a:3:{s:9:\"plugin_id\";i:33;s:4:\"type\";s:9:\"diskquota\";s:4:\"name\";s:9:\"Diskquota\";}i:1;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:8:\"Minisite\";}}', 0, NULL, 1, 'shopsettings', 1, 1, 20, 11, '2012-11-26 14:28:47', 3, '2015-02-24 19:24:58', 3),
(21, 'Link To Shop', 'linktoshop', 'linktoshop', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:14:\"Link til butik\";s:11:\"infomessage\";s:244:\"Link til butik gør at man får et link direkte fra søgelisterne over butikker (resultatlisten brugerne får vist ved søgninger) til sin egen Mini Shop sammen med standardlinket til Mini Site. Kun aktuel hvis man har købt Mini Shop servicen.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:12:\"Link To Shop\";s:11:\"infomessage\";s:237:\"Link To Shop gives you a link directly from shop search lists  (resulting list when users search in CityPilot) to your own Mini Shop together with the stadard link to your Mini Site. Only useful if you have purched the Mini Shop service.\";}}', '5.0000', 0, 0, 0, 0, '', 0, '', 0, '', 1, 1, 3, 52, '2012-11-27 13:42:05', 3, '2013-10-10 07:01:21', 2),
(25, 'Pay Button', 'paybutton', 'paybutton', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:13:\"Betalingsknap\";s:11:\"infomessage\";s:200:\"Denne service gør det muligt at konfigurere sit eget betalingssystem. Benyttes hvis man f.eks. selv har en PayPal konto eller en aftale med Nets, som skal anvendes i stedet for vores betalingssystem.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:10:\"Pay Button\";s:11:\"infomessage\";s:185:\"The Pay Button service makes it possible to have ones own payment gateway. Can be used if one has a PayPal account or an agreement with another company regarding payment (such as Nets).\";}}', '50.0000', 0, 0, 0, 0, '', 0, '', 0, '', 1, 1, 10, 53, '2013-01-09 16:57:48', 3, '2013-10-10 07:01:21', 2),
(26, 'Minisite', 'minisite', 'minisite', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:8:\"Minisite\";s:11:\"infomessage\";s:125:\"Minisite servicen giver mulighed for at kunne administrere sit eget site og er nødvendig for tilkøb af alle andre services.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:8:\"Minisite\";s:11:\"infomessage\";s:121:\"The Minisite service makes it possible to administrate ones own site and is necessary for purchase of all other services.\";}}', '10.0000', 0, 0, 0, 0, '', 0, '', 1, '', 1, 1, 20, 10, '2013-01-16 15:24:10', 3, '2014-04-28 15:13:18', 3),
(27, 'PDF', 'pdfupload', 'pdfupload', 1, '', 'a:3:{s:11:\"displayinfo\";s:3:\"yes\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:19:\"Upload af PDF filer\";s:11:\"infomessage\";s:249:\"Med denne service er det muligt at uploade PDF dokumenter til sit minisite.\r\nI forbindelse med upload vil der automatisk blive fremstillet et billede af den første side i PDF dokumentet.\r\nBilledet bliver brugt til at \"vise\" PDF dokumentet som ikon.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:19:\"Upload of PDF files\";s:11:\"infomessage\";s:239:\"With this service it\'s possible to upload PDF documents to your minisite.\r\nWhen uploading there will automaticly be generated a image of the first page of the PDF document.\r\nThe image will be used to \"show\" the PDF document as a Thumbnail.\";}}', '5.0000', 0, 0, 0, 0, '', 0, '', 1, 'viewshoppdf', 1, 1, 190, 40, '2013-01-16 15:25:31', 3, '2013-10-10 07:01:21', 2),
(28, 'Standard Theme', 'stdtheme', 'stdtheme', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:15:\"Standard Design\";s:11:\"infomessage\";s:66:\"Du kan frit vælge mellem alle vore standard designs til dit site.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:15:\"Standard Design\";s:11:\"infomessage\";s:70:\"You are free to choose between all our standard designs for your site.\";}}', '5.0000', 0, 0, 0, 0, '', 0, '', 0, '', 1, 1, 190, 100, '2013-01-16 15:25:54', 3, '2013-11-01 15:23:03', 2),
(29, 'Modified Theme', 'modtheme', 'modtheme', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:26:\"Modificeret standarddesign\";s:11:\"infomessage\";s:174:\"Vi har flere standarddesigns at vælge imellem, men du syntes måske ikke helt det rammer og ønsker en eller flere ændringer foretaget. Det kalder vi et modificeret design.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:24:\"Modified Standard Design\";s:11:\"infomessage\";s:189:\"We have several standard designs to choose from but perhaps it\'s not exactly what you are looking for and you wish to change a couple of thinks in it. That\'s what we call a modified design.\";}}', '50.0000', 0, 0, 0, 0, 'a:2:{i:0;a:3:{s:9:\"plugin_id\";i:4;s:4:\"type\";s:11:\"addproducts\";s:4:\"name\";s:12:\"Add Products\";}i:1;a:3:{s:9:\"plugin_id\";i:2;s:4:\"type\";s:8:\"createad\";s:4:\"name\";s:9:\"Create AD\";}}', 0, 'iSHOP,zSHOP', 0, '', 0, 0, 0, 101, '2013-01-16 15:26:10', 3, '2013-10-10 07:01:21', 2),
(30, 'My own Theme', 'mytheme', 'mytheme', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:11:\"Eget design\";s:11:\"infomessage\";s:78:\"Få dit eget design lagt på dit site og send et signal om din individualitet.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:10:\"Own design\";s:11:\"infomessage\";s:76:\"Get your own design on your site and send a signal about your individuality.\";}}', '1000.0000', 0, 0, 0, 0, '', 0, '', 0, '', 0, 0, 0, 102, '2013-01-16 15:26:29', 3, '2013-10-10 07:01:21', 2),
(31, 'Create Articles', 'createarticle', 'createarticle', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:14:\"Opret Artikler\";s:11:\"infomessage\";s:153:\"Opret en eller flere artikler på dit site. Overvej også at tilkøbe artikel reklame servicen for at få eksponeret dine artikler udenfor dit eget site.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:14:\"Create Article\";s:11:\"infomessage\";s:132:\"Create one or more articles on your site. Consider to purchase Create Article AD service to get more exposure outside your own site.\";}}', '5.0000', 0, 0, 0, 0, '', 0, '', 0, '', 0, 1, 3, 41, '2013-01-16 15:28:02', 3, '2013-10-10 07:01:21', 2),
(32, 'Create Article AD', 'createarticlead', 'createarticlead', 1, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:25:\"Opret reklame for Artikel\";s:11:\"infomessage\";s:72:\"Få mulighed for at eksponere en eller flere artikler i reklameblokkene.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:21:\"Create AD for article\";s:11:\"infomessage\";s:67:\"Get opportunity to expose one or more articles in advertise blocks.\";}}', '5.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:9:\"Mini Site\";}}', 0, '', 1, 'viewarticleads', 0, 1, 3, 42, '2013-01-25 08:30:49', 3, '2013-10-10 07:01:21', 2),
(33, 'Diskquota', 'diskquota', 'diskquota', 1, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:9:\"Diskquota\";s:11:\"infomessage\";s:211:\"Diskquota eller diskplads servicen udvider den diskplads der er til rådighed for billeder (Galleri, Billeder, Artikler og Produkter) og dokumenter samt andre services der anvender diskplads til lagring af data.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:9:\"Diskquota\";s:11:\"infomessage\";s:191:\"The Diskquota service expands the diskspace available to your site for images (Gallery, Pictures, Articles, Products) and documents and other services that require diskspace for storing data.\";}}', '1.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:9:\"Mini Site\";}}', 0, '', 0, '', 1, 1, 30, 62, '2013-04-12 09:54:18', 26, '2013-10-10 07:01:21', 2),
(34, 'Minisite Events', 'eventservice', 'eventservice', 1, '', 'a:3:{s:11:\"displayinfo\";s:3:\"yes\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:15:\"Minisite Events\";s:11:\"infomessage\";s:203:\"Minisite Events giver mulighed for at oprette Events på dit site.\r\nTil events kan man knytte billeder (fra galleri eller billedmappe), produkter (fra minishop), artikler, dokumenter eller blot en tekst.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:15:\"Minisite Events\";s:11:\"infomessage\";s:207:\"Minisite Events makes it possible to create Events on your site.\r\nYou can attach other services to events. Images (from Gallery or Pictures), Products (from Minishop), Articles, Documents or just plain text.\";}}', '10.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:33;s:4:\"type\";s:9:\"diskquota\";s:4:\"name\";s:9:\"Diskquota\";}}', 0, '', 1, 'events', 1, 1, 30, 13, '2013-04-24 09:14:11', 3, '2013-11-04 09:37:26', 2),
(35, 'Facebook Like', 'fblike', 'fblike', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:21:\"Facebook Like service\";s:11:\"infomessage\";s:95:\"Facebook Like servicen placerer en knap på dit site hvormed dine brugere kan give dig \"Likes\".\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:21:\"Facebook Like service\";s:11:\"infomessage\";s:99:\"The Facebook Like service places a button on your site that your users can use to give you \"Likes\".\";}}', '5.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:8:\"Minisite\";}}', 0, NULL, 0, '', 1, 1, 5, 63, '2013-04-26 14:37:56', 3, '2014-11-18 14:15:18', 3),
(43, 'Minisite Banner', 'minisitebanner', 'minisitebanner', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}', '100.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:8:\"Minisite\";}}', 0, NULL, 1, 'shopsettings', 1, 1, 100, 14, '2013-08-23 18:51:32', 3, '2015-02-24 19:26:33', 3),
(44, 'Minisite Announcement', 'minisiteannouncement', 'minisiteannouncement', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}', '100.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:43;s:4:\"type\";s:14:\"minisitebanner\";s:4:\"name\";s:15:\"Minisite Banner\";}}', 0, '', 1, 'announcement', 1, 1, 100, 15, '2013-08-29 18:57:38', 3, '2013-10-10 07:01:21', 2),
(45, 'Facebook Comment', 'fbcomment', 'fbcomment', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:26:\"Facebook Kommentar service\";s:11:\"infomessage\";s:97:\"Facebook kommentar servicen giver dig mulighed for at vise facebook kommentarer på dit minisite.\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:24:\"Facebook Comment service\";s:11:\"infomessage\";s:98:\"The Facebook Comment service gives you the opportunity to show facebook comments on your minisite.\";}}', '10.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:9:\"Mini Site\";}}', 0, '', 0, '', 0, 1, 20, 64, '2013-09-16 08:55:55', 2, '2013-10-10 07:01:21', 2),
(46, 'Content Reminder', 'remindercontent', 'remindercontent', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:16:\"Indholdsreminder\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:16:\"Content Reminder\";s:11:\"infomessage\";s:0:\"\";}}', '0.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:9:\"Mini Site\";}}', 0, '', 0, '', 0, 1, 100, 65, '2013-09-16 12:47:02', 2, '2013-10-10 07:01:21', 2),
(47, 'Youtube Link', 'youtubelink', 'youtubelink', 1, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:11:\"Youtubelink\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:11:\"Youtubelink\";s:11:\"infomessage\";s:0:\"\";}}', '1.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:9:\"Mini Site\";}}', 0, '', 0, '', 0, 1, 10, 66, '2013-09-16 12:48:43', 2, '2013-10-10 07:01:21', 2),
(48, 'Shop Linker', 'shoplinker', 'shoplinker', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:12:\"Butikssamler\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:10:\"Shoplinker\";s:11:\"infomessage\";s:0:\"\";}}', '100.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:10;s:4:\"type\";s:8:\"minishop\";s:4:\"name\";s:9:\"Mini Shop\";}}', 0, '', 0, '', 0, 1, 20, 54, '2013-09-16 12:51:11', 2, '2013-10-10 07:01:21', 2),
(49, 'Product Linker', 'productlinker', 'productlinker', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:13:\"Produktsamler\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:13:\"Productlinker\";s:11:\"infomessage\";s:0:\"\";}}', '100.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:10;s:4:\"type\";s:8:\"minishop\";s:4:\"name\";s:9:\"Mini Shop\";}}', 0, '', 0, '', 0, 1, 20, 55, '2013-09-16 12:52:36', 2, '2013-10-10 07:01:21', 2),
(50, 'Employees', 'employees', 'employees', 1, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}', '5.0000', 0, 0, 0, 0, '', 0, '', 0, 'viewemployees', 1, 1, 100, 16, '2013-10-02 11:06:00', 3, '2013-10-23 16:34:56', 3),
(55, 'FB wall post', 'fbwallpost', 'fbwallpost', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}', '1.0000', 0, 0, 0, 0, '', 0, '', 0, '', 1, 1, 100, 0, '2014-01-16 10:11:35', 3, '2014-05-12 09:43:58', 3),
(58, 'Exclusive Event', 'exclusiveevent', 'exclusiveevent', 1, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}', '10.0000', 0, 0, 0, 1, 'a:1:{i:0;a:3:{s:9:\"plugin_id\";i:34;s:4:\"type\";s:12:\"eventservice\";s:4:\"name\";s:15:\"Minisite Events\";}}', 0, NULL, 1, 'events', 1, 1, 100, 0, '2014-05-07 09:34:06', 3, '2015-02-24 19:25:50', 3),
(59, 'Pages', 'pages', 'pages', 1, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}', '12.0000', NULL, NULL, NULL, 1, 'a:2:{i:0;a:3:{s:9:\"plugin_id\";i:26;s:4:\"type\";s:8:\"minisite\";s:4:\"name\";s:8:\"Minisite\";}i:1;a:3:{s:9:\"plugin_id\";i:18;s:4:\"type\";s:14:\"minisiteimages\";s:4:\"name\";s:15:\"Minisite Images\";}}', 0, NULL, 0, '', 1, 1, 0, NULL, '2015-04-28 20:59:29', 3, '2015-04-28 20:59:29', 3),
(60, 'Social Links', 'sociallinks', 'sociallinks', 0, '', 'a:3:{s:11:\"displayinfo\";s:2:\"no\";s:2:\"da\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:2:{s:9:\"infotitle\";s:0:\"\";s:11:\"infomessage\";s:0:\"\";}}', '0.0000', NULL, NULL, NULL, 0, '', 0, NULL, 1, '', 1, 1, 0, NULL, '2015-06-17 21:36:04', 3, '2015-06-17 21:36:04', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_product_categories`
--

CREATE TABLE `zselex_product_categories` (
  `prd_cat_id` int(11) NOT NULL,
  `prd_cat_name` varchar(250) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_product_categories`
--

INSERT INTO `zselex_product_categories` (`prd_cat_id`, `prd_cat_name`, `shop_id`, `user_id`, `status`) VALUES
(15, 'Livingroom', 42, 0, 1),
(14, 'Kitchen', 42, 0, 1),
(26, 'Sports', 26, 0, 1),
(16, 'Bath', 42, 0, 1),
(27, 'Food', 26, 0, 1),
(21, 'Boots High Heal', 46, 0, 1),
(22, 'Boots', 46, 0, 1),
(25, 'Phones', 26, 0, 1),
(24, 'test23', 32, 0, 1),
(28, 'Grossery', 26, 0, 1),
(33, 'Animals', 26, 0, 1),
(34, 'cat1', 57, 0, 1),
(35, 'hello', 26, 0, 1),
(36, 'Test', 26, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_product_options`
--

CREATE TABLE `zselex_product_options` (
  `option_id` bigint(20) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `option_name` varchar(250) DEFAULT NULL,
  `option_type` varchar(250) DEFAULT NULL,
  `option_value` longtext,
  `parent_option_id` bigint(20) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_product_options`
--

INSERT INTO `zselex_product_options` (`option_id`, `shop_id`, `option_name`, `option_type`, `option_value`, `parent_option_id`, `sort_order`) VALUES
(1, 26, 'Color', 'dropdown', 'a:3:{i:0;s:3:\"Red\";i:1;s:4:\"Blue\";i:2;s:5:\"Green\";}', 2, 2),
(2, 26, 'Size', 'dropdown', '', 1, 1),
(3, 26, 'Options', 'checkbox', '', 0, 3),
(5, 14, 'color', 'dropdown', '', 0, NULL),
(6, 14, 'size', 'radio', '', 0, NULL),
(7, 57, 'Color', 'dropdown', '', 0, NULL),
(9, 57, 'Test1', 'dropdown', '', NULL, NULL),
(10, 26, 'Test', 'dropdown', '', NULL, NULL),
(11, 26, 'myTest', 'checkbox', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_product_options_values`
--

CREATE TABLE `zselex_product_options_values` (
  `option_value_id` bigint(20) NOT NULL,
  `option_id` bigint(20) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `option_value` varchar(250) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_product_options_values`
--

INSERT INTO `zselex_product_options_values` (`option_value_id`, `option_id`, `shop_id`, `option_value`, `sort_order`) VALUES
(1, 1, 26, 'Blue', 0),
(2, 1, 26, 'Green', 0),
(3, 1, 26, 'Black', 0),
(5, 2, 26, '8', 3),
(6, 2, 26, '10', 5),
(7, 2, 26, '7', 2),
(8, 3, 26, 'small', 1),
(9, 3, 26, 'medium', 2),
(10, 3, 26, 'large', 3),
(11, 6, 14, '8', 0),
(12, 6, 14, '9', 0),
(13, 6, 14, '10', 0),
(14, 6, 14, '11', 0),
(15, 6, 14, '12', 0),
(16, 5, 14, 'blue', 0),
(17, 5, 14, 'red', 0),
(18, 5, 14, 'yellow', 0),
(19, 2, 26, '9', 4),
(24, 7, 57, 'Red', 1),
(25, 7, 57, 'Green', 2),
(26, 7, 57, 'Black', 3),
(27, 9, 57, 'saf', 0),
(28, 9, 57, 'sadf', 0),
(29, 10, 26, '1', NULL),
(30, 10, 26, '2', NULL),
(31, 10, 26, '3', NULL),
(32, 11, 26, 'test1', NULL),
(33, 11, 26, 'test2', NULL),
(34, 11, 26, 'test3', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_product_quantity_discount`
--

CREATE TABLE `zselex_product_quantity_discount` (
  `discount_id` int(11) NOT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `discount` varchar(100) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_product_quantity_discount`
--

INSERT INTO `zselex_product_quantity_discount` (`discount_id`, `product_id`, `quantity`, `discount`, `start_date`, `end_date`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(22, 334, 2, '2%', '2015-03-02', '2015-03-31', '2015-10-11 19:15:38', 3, '2015-10-11 19:15:38', 3),
(21, 334, 3, '30%', '2015-03-13', '2015-03-31', '2015-10-11 19:15:38', 3, '2015-10-11 19:15:38', 3),
(25, 357, 0, '78%', NULL, NULL, '2016-08-25 21:48:23', 3, '2016-08-25 21:48:23', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_product_to_category`
--

CREATE TABLE `zselex_product_to_category` (
  `product_id` bigint(20) NOT NULL,
  `prd_cat_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zselex_product_to_options`
--

CREATE TABLE `zselex_product_to_options` (
  `product_to_options_id` bigint(20) NOT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `option_id` bigint(20) DEFAULT NULL,
  `parent_option_id` int(11) DEFAULT NULL,
  `option_values` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_product_to_options`
--

INSERT INTO `zselex_product_to_options` (`product_to_options_id`, `product_id`, `option_id`, `parent_option_id`, `option_values`) VALUES
(11, 159, 6, NULL, ''),
(12, 159, 5, NULL, ''),
(15, 158, 7, NULL, ''),
(25, 155, 7, 0, ''),
(37, 358, 2, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_product_to_options_values`
--

CREATE TABLE `zselex_product_to_options_values` (
  `product_to_options_value_id` bigint(20) NOT NULL,
  `product_to_options_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `option_id` bigint(20) DEFAULT NULL,
  `option_value_id` int(11) DEFAULT NULL,
  `parent_option_value_id` int(11) DEFAULT NULL,
  `parent_option_id` int(11) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price_prefix` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_product_to_options_values`
--

INSERT INTO `zselex_product_to_options_values` (`product_to_options_value_id`, `product_to_options_id`, `product_id`, `option_id`, `option_value_id`, `parent_option_value_id`, `parent_option_id`, `price`, `qty`, `price_prefix`) VALUES
(29, 11, 159, 6, 12, 0, NULL, '0.00', 1, '0'),
(30, 11, 159, 6, 14, 0, NULL, '0.00', 2, '0'),
(31, 11, 159, 6, 15, 0, NULL, '0.00', 3, '0'),
(32, 12, 159, 5, 16, 0, NULL, '0.00', 3, '0'),
(33, 12, 159, 5, 17, 0, NULL, '0.00', 3, '0'),
(39, 15, 158, 7, 24, 0, NULL, '12.00', 3, NULL),
(40, 15, 158, 7, 25, 0, NULL, '13.00', 3, NULL),
(41, 15, 158, 7, 26, 0, NULL, '14.00', 5, NULL),
(157, 37, 358, 2, 19, 1, 1, '13', 1, '1'),
(155, 37, 358, 2, 7, 1, 1, '11', 0, '1'),
(156, 37, 358, 2, 5, 1, 1, '12', 2, '1'),
(158, 37, 358, 2, 6, 1, 1, '14', 2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_products`
--

CREATE TABLE `zselex_products` (
  `product_id` bigint(20) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `urltitle` varchar(255) DEFAULT NULL,
  `prd_description` longtext,
  `manufacturer_id` bigint(20) DEFAULT NULL,
  `keywords` longtext,
  `original_price` decimal(15,4) DEFAULT NULL,
  `prd_price` decimal(15,4) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `prd_quantity` int(11) DEFAULT NULL,
  `prd_image` varchar(255) DEFAULT NULL,
  `image_height` varchar(100) DEFAULT NULL,
  `image_width` varchar(100) DEFAULT NULL,
  `prd_status` tinyint(1) DEFAULT NULL,
  `advertise` tinyint(1) DEFAULT '0',
  `shipping_price` decimal(15,4) DEFAULT NULL,
  `enable_question` tinyint(1) DEFAULT NULL,
  `validate_question` tinyint(1) DEFAULT NULL,
  `prd_question` varchar(255) DEFAULT NULL,
  `no_vat` tinyint(1) DEFAULT '0',
  `max_discount` char(10) DEFAULT NULL,
  `no_delivery` smallint(1) DEFAULT '0',
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_products`
--

INSERT INTO `zselex_products` (`product_id`, `shop_id`, `product_name`, `urltitle`, `prd_description`, `manufacturer_id`, `keywords`, `original_price`, `prd_price`, `discount`, `prd_quantity`, `prd_image`, `image_height`, `image_width`, `prd_status`, `advertise`, `shipping_price`, `enable_question`, `validate_question`, `prd_question`, `no_vat`, `max_discount`, `no_delivery`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(124, 57, 'images', 'images27', '', 0, '', '12.0000', '12.0000', '0.0000', 0, 'images_1402065072.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2014-06-06 00:00:00', 3, '2014-06-06 00:00:00', 3),
(125, 57, 'meal2012-940x340', 'meal2012-940x340', '', 0, '', '12.0000', '12.0000', '0.0000', 0, 'meal2012-940x340_1402065072.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2014-06-06 00:00:00', 3, '2014-06-06 00:00:00', 3),
(158, 57, 'vacancies banner 940 x 342 ver3', 'vacancies-banner-940-x-342-ver3', '', 0, '', '200.0000', '200.0000', '', 0, 'vacanciesbanner940x342ver3.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2014-07-14 00:00:00', 3, '2014-07-14 00:00:00', 3),
(155, 57, 'vacancies banner 940 x 342 ver3', 'vacancies-banner-940-x-342-ver31', '', NULL, '', '200.0000', '200.0000', '', 0, 'e04-services.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2014-07-08 00:00:00', 3, '2014-07-08 00:00:00', 3),
(159, 14, 'IMG-20140729-WA0009', 'img-20140729-wa0009', '', 0, '', '567.0000', '567.0000', '', NULL, 'IMG-20140729-WA0009.jpg', NULL, NULL, 1, 0, '0.0000', 0, 0, '', 0, NULL, 0, '2014-08-12 00:00:00', 2, '2014-08-12 00:00:00', 2),
(160, 14, 'IMG-20140729-WA0006', 'img-20140729-wa0006', NULL, NULL, NULL, '0.0000', '0.0000', '', 0, 'IMG-20140729-WA0006.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2014-08-12 00:00:00', 2, '2014-08-12 00:00:00', 2),
(161, 14, 'IMG-20140729-WA0004', 'img-20140729-wa0004', NULL, NULL, NULL, '0.0000', '0.0000', '', 0, 'IMG-20140729-WA0004.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2014-08-12 00:00:00', 2, '2014-08-12 00:00:00', 2),
(162, 14, '20140718_143123', '20140718-143123', '', 0, '', '2000000.0000', '2000000.0000', '', 1, '20140718_143123.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2014-08-12 00:00:00', 2, '2014-08-12 00:00:00', 2),
(370, 61, 'social_icons', 'social-icons', '', 0, '', '234.0000', '234.0000', '0', 10, 'social_icons_09b2e6b4046810198a0e088aaab7043a.png', NULL, NULL, 1, 1, '0.0000', 0, 0, '', 0, NULL, 0, '2016-06-24 19:34:01', 3, '2016-06-24 19:34:01', 3),
(369, 61, 'vadakan', 'vadakan', '', 0, '', '111.0000', '111.0000', '0', 30, 'vadakan_81536905253f255596129bfc587dab9a.jpg', NULL, NULL, 1, 1, '0.0000', 0, 0, '', 0, NULL, 0, '2016-06-24 19:34:00', 3, '2016-06-24 19:34:00', 3),
(326, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2014-10-28 14:34:03', 3, '2014-10-28 14:34:03', 3),
(346, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-05-24 13:50:11', 3, '2015-05-24 13:50:11', 3),
(357, 26, 'test007', 'test007', '', 0, '', '128.0000', '128.0000', '0', 59, 'Penguins1.jpg', NULL, NULL, 1, 1, '2.0000', 0, 0, '', 1, NULL, 0, '2015-05-24 13:53:02', 3, '2015-05-24 13:53:02', 3),
(358, 26, 'Nokia Lumia 724', 'nokia-lumia-724', 'this is Lumia product sold for 400 RS', 0, '', '401.0000', '401.0000', '10%', NULL, 'lumia-720-1434048078.jpg', NULL, NULL, 1, 1, '0.0000', 0, 0, '', 0, NULL, 0, '2015-06-11 20:41:19', 3, '2015-06-11 20:41:19', 3),
(359, 198, 'Hydrangeas', 'hydrangeas2', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'Hydrangeas_a5d67ed52fb9f5859154a2375aff2cda.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-10-22 09:49:32', 3, '2015-10-22 09:49:32', 3),
(360, 198, 'Chrysanthemum', 'chrysanthemum2', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'Chrysanthemum_51e3220c10a3c24a3885d9b2850ff6b2.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-10-22 09:50:09', 3, '2015-10-22 09:50:09', 3),
(361, 198, 'Desert', 'desert2', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'Desert_19e842d11f7f24a9e10fb8df7a1e0d82.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-10-22 09:51:22', 3, '2015-10-22 09:51:22', 3),
(362, 198, 'Lighthouse', 'lighthouse2', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'Lighthouse_ebf9ed2d66fda34c9085666a432adf19.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-10-22 09:51:30', 3, '2015-10-22 09:51:30', 3),
(363, 198, 'Jellyfish', 'jellyfish2', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'Jellyfish_287796462cd3085da02a5bfaf765681d.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-10-22 09:52:30', 3, '2015-10-22 09:52:30', 3),
(364, 198, 'Penguins', 'penguins1', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'Penguins_a7a3fdac402373f83abc66ef7b84f7dc.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-10-22 09:52:42', 3, '2015-10-22 09:52:42', 3),
(365, 198, 'Tulips', 'tulips2', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'Tulips_3af082ae2f7b4ae28af6b0e70fb95b30.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-10-22 09:52:47', 3, '2015-10-22 09:52:47', 3),
(366, 198, 'Koala', 'koala2', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'Koala_0861fe9e1b65ab6f426962ebbc2145ac.jpg', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 0, NULL, 0, '2015-10-22 09:52:53', 3, '2015-10-22 09:52:53', 3),
(367, 26, 'preview_medium', 'preview-medium', '', 0, '', '30.0000', '30.0000', '3', 17, 'preview_medium_cd3507fe6f9b9706cf366aba23b74e98.png', NULL, NULL, 1, 1, '0.0000', 0, 0, '', 0, NULL, 0, '2016-01-19 20:36:20', 3, '2016-01-19 20:36:20', 3),
(368, 26, 'XEvent-KlausServants_17e06999710685bf523c904bde57ed3d', 'xevent-klausservants-17e06999710685bf523c904bde57ed3d', '', 0, '', '0.0000', '0.0000', '0', 0, 'XEvent-KlausServants_17e06999710685bf523c904bde57ed3d_f4202541ea37e926dbb6d80d762268e8.jpg', NULL, NULL, 1, 1, '0.0000', 0, 0, '', 0, NULL, 0, '2016-06-14 19:40:15', 3, '2016-06-14 19:40:15', 3),
(371, 61, 'story_83_8c7XnDJwMRK7b4rMased_800X800', 'story-83-8c7xndjwmrk7b4rmased-800x800', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'story_83_8c7XnDJwMRK7b4rMased_800X800_9f236fc864497dd618820efcfa1f9e8c.jpg', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, '2016-09-19 20:09:07', 3, '2016-09-19 20:09:07', 3),
(372, 61, 'story_77_w69lzsMHbEoTTnZdeTsW_800X800', 'story-77-w69lzsmhbeottnzdetsw-800x800', NULL, NULL, NULL, '0.0000', '0.0000', '0', 0, 'story_77_w69lzsMHbEoTTnZdeTsW_800X800_2f1a8c5036aad43325e4013f67c67029.jpg', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, '2016-09-19 20:09:08', 3, '2016-09-19 20:09:08', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_region`
--

CREATE TABLE `zselex_region` (
  `region_id` int(11) NOT NULL,
  `region_name` varchar(255) NOT NULL,
  `country_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `status` smallint(6) NOT NULL,
  `cr_date` date NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` date NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_region`
--

INSERT INTO `zselex_region` (`region_id`, `region_name`, `country_id`, `description`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(8, 'MIDTJYLLAND', 61, '', 1, '2012-03-07', 2, '2013-04-19', 2),
(9, 'NORDJYLLAND', 61, '', 1, '2012-03-07', 2, '2013-04-19', 2),
(7, 'SYDJYLLAND', 61, '', 1, '2012-03-07', 2, '2013-06-13', 2),
(10, 'SJÆLLAND', 61, '', 1, '2012-03-07', 2, '2013-04-19', 2),
(11, 'HOVEDSTADSOMRÅDET', 61, '', 1, '2012-03-07', 2, '2013-06-13', 2),
(12, 'TEST', 0, 'fdsdd', 0, '2012-03-27', 3, '2012-03-27', 3),
(16, 'Karnataka', 61, '', 1, '2014-07-14', 3, '2014-07-14', 3),
(14, 'FYN', 61, '', 1, '2013-06-13', 2, '2013-06-13', 2),
(15, 'BORNHOLM', 61, '', 1, '2013-11-06', 2, '2013-11-06', 2);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_service_bundle_items`
--

CREATE TABLE `zselex_service_bundle_items` (
  `id` int(11) NOT NULL,
  `bundle_id` int(11) DEFAULT NULL,
  `servicetype` varchar(255) DEFAULT NULL,
  `plugin_id` int(11) DEFAULT NULL,
  `service_name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `qty_based` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_service_bundle_items`
--

INSERT INTO `zselex_service_bundle_items` (`id`, `bundle_id`, `servicetype`, `plugin_id`, `service_name`, `price`, `qty`, `qty_based`) VALUES
(576, 16, 'eventservice', 34, 'Minisite Events', '10.00', 10, 1),
(575, 16, 'minisitebanner', 43, 'Minisite Banner', '100.00', 1, 0),
(574, 16, 'minisiteannouncement', 44, 'Minisite Announcement', '100.00', 1, 0),
(573, 16, 'minisite', 26, 'Minisite', '10.00', 1, 0),
(648, 17, 'pages', 59, 'Pages', '12.00', 10, 1),
(572, 16, 'addproducts', 4, 'Minishop Products', '5.00', 10, 1),
(600, 19, 'employees', 50, 'Employees', '5.00', 5, 1),
(598, 18, 'diskquota', 33, 'Diskquota', '1.00', 10, 1),
(571, 16, 'minishop', 10, 'Minishop', '250.00', 1, 0),
(570, 16, 'linktoshop', 21, 'Link To Shop', '5.00', 1, 0),
(647, 17, 'minisiteproductblock', 11, 'Minisite Product Block', '25.00', 1, 0),
(646, 17, 'minisiteimages', 18, 'Minisite Images', '1.00', 20, 1),
(564, 14, 'eventservice', 34, 'Minisite Events', '10.00', 5, 1),
(563, 14, 'minisite', 26, 'Minisite', '10.00', 1, 0),
(562, 14, 'minisitegooglemap', 24, 'Google Map', '1.00', 1, 0),
(561, 14, 'employees', 50, 'Employees', '5.00', 2, 1),
(569, 16, 'minisitegooglemap', 24, 'Google Map', '1.00', 1, 0),
(568, 16, 'fblike', 35, 'Facebook Like', '5.00', 1, 0),
(567, 16, 'employees', 50, 'Employees', '5.00', 5, 1),
(645, 17, 'eventservice', 34, 'Minisite Events', '10.00', 20, 1),
(644, 17, 'minisitebanner', 43, 'Minisite Banner', '100.00', 1, 0),
(643, 17, 'minisiteannouncement', 44, 'Minisite Announcement', '100.00', 1, 0),
(642, 17, 'minisite', 26, 'Minisite', '10.00', 1, 0),
(566, 16, 'diskquota', 33, 'Diskquota', '1.00', 10, 1),
(641, 17, 'addproducts', 4, 'Minishop Products', '5.00', 50, 1),
(640, 17, 'minishop', 10, 'Minishop', '250.00', 1, 0),
(639, 17, 'linktoshop', 21, 'Link To Shop', '5.00', 1, 0),
(637, 17, 'fblike', 35, 'Facebook Like', '5.00', 1, 0),
(638, 17, 'minisitegooglemap', 24, 'Google Map', '1.00', 1, 0),
(636, 17, 'fbcomment', 45, 'Facebook Comment', '10.00', 1, 0),
(560, 14, 'diskquota', 33, 'Diskquota', '1.00', 1, 1),
(565, 14, 'minisiteimages', 18, 'Minisite Images', '1.00', 5, 1),
(577, 16, 'minisiteimages', 18, 'Minisite Images', '1.00', 10, 1),
(578, 16, 'minisiteproductblock', 11, 'Minisite Product Block', '25.00', 1, 0),
(579, 16, 'paybutton', 25, 'Pay Button', '50.00', 1, 0),
(580, 16, 'stdtheme', 28, 'Standard Theme', '5.00', 1, 0),
(635, 17, 'employees', 50, 'Employees', '5.00', 5, 1),
(602, 20, 'createad', 2, 'Advertise', '10.00', 5, 1),
(609, 22, 'fbwallpost', 55, 'FB wall post', '1.00', 1, 0),
(608, 22, 'fblike', 35, 'Facebook Like', '5.00', 1, 0),
(613, 23, 'pdfupload', 27, 'PDF', '5.00', 10, 1),
(612, 21, 'exclusiveevent', 58, 'Exclusive Event', '10.00', 1, 1),
(614, 24, 'pages', 59, 'Pages', '12.00', 4, 1),
(634, 17, 'diskquota', 33, 'Diskquota', '1.00', 100, 1),
(633, 17, 'createad', 2, 'Advertise', '10.00', 10, 1),
(649, 17, 'paybutton', 25, 'Pay Button', '50.00', 1, 0),
(650, 17, 'stdtheme', 28, 'Standard Theme', '5.00', 1, 0),
(651, 25, 'sociallinks', 60, 'Social Links', '0.00', 1, 0),
(661, 26, 'fbwallpost', 55, 'FB wall post', '1.00', 1, 0),
(660, 26, 'fblike', 35, 'Facebook Like', '5.00', 1, 0),
(659, 26, 'diskquota', 33, 'Diskquota', '1.00', 1, 1),
(662, 26, 'minisitegooglemap', 24, 'Google Map', '1.00', 1, 0),
(663, 26, 'minishop', 10, 'Minishop', '250.00', 1, 0),
(664, 26, 'addproducts', 4, 'Minishop Products', '5.00', 5, 1),
(665, 26, 'minisite', 26, 'Minisite', '10.00', 1, 0),
(666, 26, 'eventservice', 34, 'Minisite Events', '10.00', 1, 1),
(667, 26, 'minisiteimages', 18, 'Minisite Images', '1.00', 1, 1),
(668, 26, 'sociallinks', 60, 'Social Links', '0.00', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_service_bundles`
--

CREATE TABLE `zselex_service_bundles` (
  `bundle_id` int(11) NOT NULL,
  `bundle_name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `bundle_price` decimal(15,4) DEFAULT NULL,
  `calculated_price` decimal(15,4) DEFAULT NULL,
  `bundle_description` longtext,
  `content` longtext,
  `bundle_type` varchar(255) DEFAULT NULL,
  `demo` smallint(6) DEFAULT NULL,
  `demoperiod` int(11) DEFAULT NULL,
  `is_free` tinyint(4) DEFAULT '0',
  `sort_order` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `cr_date` datetime DEFAULT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime DEFAULT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_service_bundles`
--

INSERT INTO `zselex_service_bundles` (`bundle_id`, `bundle_name`, `type`, `bundle_price`, `calculated_price`, `bundle_description`, `content`, `bundle_type`, `demo`, `demoperiod`, `is_free`, `sort_order`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(14, 'Basic', 'bundle1', '199.0000', '77.0000', 'Minimum pakke', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:180:\"I vores Basic pakke har du alt den funktionalitet til at blive synlig i CityPilot. Vis billeder, dine medarbejdere og events online.\r\n\r\nBasic - Når du vil være synlig på nettet.\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:192:\"In the Basic bundle you will get all the functionality for visibility in CityPilot. Show Images, your employees and events online.\r\n<br />\r\nBasic - When you want to be visible on the internet.\";}}', 'main', 1, 90, 0, 1, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(16, 'Basic Shop', 'test-bundle', '359.0000', '746.0000', 'Minimum and shop', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:176:\"I Basic Shop får du samme gode funktionaliter som i Basis, men her kan du sælge dine produkter på nettet, gennem dit site.\r\n<br />\r\nBasic Shop - Sælg dine varer på nettet.\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:193:\"In Basic Shop you have the same functionality as in Basic, but with this bundle you can sell products on the internetthrough your site.\r\n<br />\r\nBasic Shop - Sell your products on the internet.\";}}', 'main', 1, 90, 0, 2, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(17, 'Premium', 'butik-med-lidt-større-behov', '499.0000', '1376.0000', 'Premium', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:170:\"I Premium får du alt hvad du skal bruge af funktionalitet og synlighed - pakket ind i en let og overskuelig administrations.\r\n<br />\r\nPremium - Alt hvad du har brug for.\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:173:\"In Premium you will get all what you need in functionality and visibility - packed in an easy and managable administration.\r\n<br />\r\nPremium - Everything you will ever need.\";}}', 'main', 1, 90, 0, 3, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(18, 'Diskspace', 'tillæg1', '49.0000', '10.0000', 'Tillægspakke diskplads', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:14:\"Mere diskplads\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:14:\"More diskspace\";}}', 'additional', 1, 30, 0, 10, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(19, 'Employees', 'tillæg2', '10.0000', '25.0000', '', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:18:\"Flere medarbejdere\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:14:\"More employees\";}}', 'additional', 1, 30, 0, 11, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(20, 'Advertice', 'tillæg3', '29.0000', '50.0000', '', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:14:\"Flere annoncer\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:8:\"More Ads\";}}', 'additional', 1, 30, 0, 12, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(21, 'Exclusive events', 'exclusive-events', '0.0000', '10.0000', '', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:0:\"\";}}', 'additional', 1, 90, 0, 13, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(22, 'FB services', 'fb-services', '0.0000', '6.0000', '', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:0:\"\";}}', 'additional', 1, 90, 0, 14, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(23, 'pdf uploads', 'pdf-uploads', '34.0000', '50.0000', '', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:0:\"\";}}', 'additional', 1, 100, 0, 15, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(24, 'Pages', 'pages', '0.0000', '48.0000', '', NULL, 'additional', 1, 20, 0, 16, 1, '2015-04-28 21:00:54', 3, '2015-04-28 21:00:54', 3),
(25, 'Social Links', 'social-links', '12.0000', '23.0000', '', '', 'additional', 1, 21, 0, 17, 1, '2015-06-17 21:36:58', 3, '2015-06-17 21:36:58', 3),
(26, 'Free Bundle', 'free-bundle', '0.0000', '304.0000', '', 'a:2:{s:2:\"da\";a:1:{s:11:\"infomessage\";s:0:\"\";}s:2:\"en\";a:1:{s:11:\"infomessage\";s:0:\"\";}}', 'main', 1, 0, NULL, 0, 1, '2016-03-24 15:38:14', 3, '2016-03-24 15:38:14', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_service_config`
--

CREATE TABLE `zselex_service_config` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `plugin_id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `service_status` int(11) NOT NULL,
  `qty_based` int(11) NOT NULL,
  `bundle` int(11) NOT NULL,
  `bundle_id` int(11) NOT NULL,
  `top_bundle` int(11) NOT NULL,
  `start_date` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_service_config`
--

INSERT INTO `zselex_service_config` (`id`, `shop_id`, `plugin_id`, `type`, `user_id`, `owner_id`, `service_status`, `qty_based`, `bundle`, `bundle_id`, `top_bundle`, `start_date`) VALUES
(81, 14, 35, 'fblike', 2, 23, 1, 0, 0, 0, 0, '2013-09-10'),
(75, 14, 10, 'minishop', 2, 23, 1, 0, 0, 0, 0, '2013-09-10'),
(76, 14, 33, 'diskquota', 2, 23, 1, 1, 0, 0, 0, '2013-09-10'),
(77, 14, 18, 'minisiteimages', 2, 23, 1, 1, 0, 0, 0, '2013-09-10'),
(29, 26, 18, 'minisiteimages', 3, 20, 1, 1, 0, 0, 0, '2013-06-28'),
(87, 26, 34, 'eventservice', 3, 20, 1, 1, 0, 0, 0, '2013-09-12'),
(27, 26, 28, 'stdtheme', 3, 20, 1, 0, 0, 0, 0, '2013-06-28'),
(26, 26, 11, 'minisiteproductblock', 3, 20, 1, 0, 0, 0, 0, '2013-06-28'),
(25, 26, 24, 'minisitegooglemap', 3, 20, 1, 0, 0, 0, 0, '2013-06-28'),
(24, 26, 33, 'diskquota', 3, 20, 1, 1, 0, 0, 0, '2013-06-28'),
(23, 26, 10, 'minishop', 3, 20, 1, 0, 0, 0, 0, '2013-06-28'),
(22, 26, 26, 'minisite', 3, 20, 1, 0, 0, 0, 0, '2013-06-28'),
(21, 26, 4, 'addproducts', 3, 20, 1, 1, 0, 0, 0, '2013-06-28'),
(79, 14, 11, 'minisiteproductblock', 2, 23, 1, 0, 0, 0, 0, '2013-09-10'),
(78, 14, 2, 'createad', 2, 23, 1, 1, 0, 0, 0, '2013-09-10'),
(37, 37, 24, 'minisitegooglemap', 3, 21, 1, 0, 0, 0, 0, '2013-07-05'),
(38, 37, 26, 'minisite', 3, 21, 1, 0, 0, 0, 0, '2013-07-05'),
(39, 37, 10, 'minishop', 3, 21, 1, 0, 0, 0, 0, '2013-07-05'),
(40, 37, 33, 'diskquota', 3, 21, 1, 1, 0, 0, 0, '2013-07-05'),
(41, 37, 28, 'stdtheme', 21, 21, 1, 0, 0, 0, 0, '2013-07-22'),
(80, 14, 28, 'stdtheme', 2, 23, 1, 0, 0, 0, 0, '2013-09-10'),
(43, 26, 32, 'createarticlead', 3, 20, 1, 1, 0, 0, 0, '2013-07-23'),
(44, 26, 27, 'pdfupload', 3, 20, 1, 1, 0, 0, 0, '2013-07-26'),
(51, 15, 40, 'test-bundle', 22, 22, 1, 0, 1, 16, 1, '2013-08-07'),
(50, 15, 38, 'bundle1', 22, 22, 1, 0, 1, 14, 1, '2013-08-07'),
(52, 15, 10, 'minishop', 22, 22, 1, 0, 0, 0, 0, '2013-08-13'),
(53, 15, 10, 'minishop', 22, 22, 1, 0, 0, 0, 0, '2013-08-13'),
(54, 26, 38, '', 3, 20, 1, 0, 1, 14, 0, '2013-08-13'),
(55, 37, 33, 'diskquota', 21, 21, 1, 1, 0, 0, 0, '2013-08-14'),
(56, 37, 33, 'diskquota', 21, 21, 1, 1, 0, 0, 0, '2013-08-14'),
(58, 15, 38, '', 22, 22, 1, 0, 1, 14, 1, '2013-08-14'),
(59, 15, 10, 'minishop', 22, 22, 1, 0, 0, 0, 0, '2013-08-14'),
(60, 15, 21, 'linktoshop', 22, 22, 1, 0, 0, 0, 0, '2013-08-16'),
(61, 38, 41, 'butik-med-lidt-større-behov', 55, 55, 1, 0, 1, 17, 1, '2013-08-19'),
(62, 37, 38, 'bundle1', 21, 21, 1, 0, 1, 14, 1, '2013-08-19'),
(63, 39, 41, 'butik-med-lidt-større-behov', 56, 56, 1, 0, 1, 17, 1, '2013-08-20'),
(74, 14, 26, 'minisite', 2, 23, 1, 0, 0, 0, 0, '2013-09-10'),
(65, 26, 43, 'minisitebanner', 3, 20, 1, 0, 0, 0, 0, '2013-08-23'),
(66, 40, 41, 'butik-med-lidt-større-behov', 57, 57, 1, 0, 1, 17, 1, '2013-08-26'),
(67, 38, 43, 'minisitebanner', 2, 55, 1, 0, 0, 0, 0, '2013-08-27'),
(68, 26, 18, 'minisiteimages', 3, 20, 2, 1, 0, 0, 0, '2013-08-27'),
(69, 26, 44, 'minisiteannouncement', 3, 20, 1, 0, 0, 0, 0, '2013-08-29'),
(70, 38, 44, 'minisiteannouncement', 2, 55, 1, 0, 0, 0, 0, '2013-08-30'),
(71, 26, 24, 'minisitegooglemap', 3, 20, 1, 0, 0, 0, 0, '2013-08-30'),
(72, 38, 25, 'paybutton', 2, 55, 1, 0, 0, 0, 0, '2013-09-04'),
(84, 18, 41, '', 2, 20, 1, 0, 1, 17, 1, '2013-09-11'),
(94, 32, 41, 'butik-med-lidt-større-behov', 3, 24, 1, 0, 1, 17, 1, '2013-09-19'),
(86, 26, 2, 'createad', 3, 20, 1, 1, 0, 0, 0, '2013-09-12'),
(88, 26, 12, 'dealoftheday', 3, 20, 1, 0, 0, 0, 0, '2013-09-13'),
(89, 42, 41, 'butik-med-lidt-større-behov', 2, 60, 1, 0, 1, 17, 1, '2013-09-16'),
(90, 16, 41, 'butik-med-lidt-større-behov', 2, 55, 1, 0, 1, 17, 1, '2013-09-16'),
(91, 46, 41, 'butik-med-lidt-større-behov', 61, 61, 1, 0, 1, 17, 1, '2013-09-16'),
(92, 47, 41, 'butik-med-lidt-større-behov', 62, 62, 1, 0, 1, 17, 1, '2013-09-17'),
(93, 41, 41, 'butik-med-lidt-større-behov', 59, 59, 1, 0, 1, 17, 1, '2013-09-17'),
(95, 39, 41, 'butik-med-lidt-større-behov', 2, 56, 1, 0, 1, 17, 1, '2013-09-20'),
(96, 39, 40, 'test-bundle', 2, 56, 1, 0, 1, 16, 1, '2013-09-20'),
(97, 39, 26, 'minisite', 2, 56, 1, 0, 0, 0, 0, '2013-09-20'),
(98, 38, 41, 'butik-med-lidt-større-behov', 55, 55, 2, 0, 1, 17, 1, '2013-09-23'),
(99, 38, 34, 'eventservice', 55, 55, 2, 1, 1, 17, 0, '2013-09-23'),
(100, 26, 28, 'stdtheme', 3, 20, 1, 0, 0, 0, 0, '2013-09-30'),
(101, 26, 28, 'stdtheme', 3, 20, 1, 0, 0, 0, 0, '2013-09-30'),
(102, 26, 28, 'stdtheme', 3, 20, 1, 0, 0, 0, 0, '2013-09-30'),
(103, 26, 50, 'employees', 3, 20, 1, 1, 0, 0, 0, '2013-10-02'),
(104, 38, 34, 'eventservice', 2, 55, 1, 1, 0, 0, 0, '2013-10-09'),
(105, 49, 41, 'butik-med-lidt-større-behov', 64, 64, 1, 0, 1, 17, 1, '2013-10-10'),
(106, 48, 41, 'butik-med-lidt-større-behov', 63, 63, 1, 0, 1, 17, 1, '2013-10-10'),
(107, 26, 26, 'minisite', 3, 20, 1, 0, 0, 0, 0, '2013-10-14'),
(108, 26, 33, 'diskquota', 3, 20, 1, 1, 0, 0, 0, '2013-10-14'),
(109, 26, 43, 'minisitebanner', 3, 20, 1, 0, 0, 0, 0, '2013-10-14'),
(110, 26, 44, 'minisiteannouncement', 3, 20, 1, 0, 0, 0, 0, '2013-10-14'),
(111, 26, 50, 'employees', 3, 20, 1, 1, 0, 0, 0, '2013-10-16'),
(112, 26, 34, 'eventservice', 3, 20, 1, 1, 0, 0, 0, '2013-10-16'),
(113, 26, 18, 'minisiteimages', 3, 20, 1, 1, 0, 0, 0, '2013-10-21'),
(114, 26, 27, 'pdfupload', 3, 20, 1, 1, 0, 0, 0, '2013-10-21'),
(115, 21, 26, 'minisite', 3, 0, 1, 0, 0, 0, 0, '2013-10-29'),
(116, 21, 43, 'minisitebanner', 3, 0, 1, 0, 0, 0, 0, '2013-10-29'),
(117, 21, 44, 'minisiteannouncement', 3, 0, 1, 0, 0, 0, 0, '2013-10-29'),
(118, 26, 10, 'minishop', 3, 20, 1, 0, 0, 0, 0, '2013-11-04'),
(119, 26, 4, 'addproducts', 3, 20, 1, 1, 0, 0, 0, '2013-11-04'),
(120, 26, 28, 'stdtheme', 3, 20, 1, 0, 0, 0, 0, '2013-11-11'),
(121, 26, 24, 'minisitegooglemap', 3, 20, 1, 0, 0, 0, 0, '2013-11-11'),
(122, 26, 11, 'minisiteproductblock', 3, 20, 1, 0, 0, 0, 0, '2013-11-12'),
(123, 35, 41, 'butik-med-lidt-større-behov', 2, 69, 1, 0, 1, 17, 1, '2013-11-18'),
(124, 26, 35, 'fblike', 3, 20, 1, 0, 0, 0, 0, '2013-11-25'),
(125, 33, 41, 'butik-med-lidt-større-behov', 3, 0, 1, 0, 1, 17, 1, '2013-11-28'),
(126, 33, 38, 'bundle1', 3, 0, 1, 0, 1, 14, 1, '2013-11-28'),
(128, 17, 41, 'butik-med-lidt-større-behov', 2, 58, 1, 0, 1, 17, 1, '2013-11-28'),
(133, 26, 42, 'tillæg1', 3, 20, 1, 0, 1, 18, 1, '2013-11-29'),
(132, 45, 42, 'tillæg1', 2, 60, 1, 0, 1, 18, 1, '2013-11-29'),
(137, 50, 38, 'bundle1', 2, 0, 1, 0, 1, 14, 1, '2013-12-03'),
(139, 26, 53, 'exclusiveevent', 3, 20, 1, 1, 0, 0, 0, '2014-01-03'),
(140, 26, 2, 'createad', 3, 20, 1, 1, 0, 0, 0, '2014-01-08'),
(141, 26, 53, 'exclusiveevent', 3, 20, 1, 1, 0, 0, 0, '2014-01-16');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_service_demo`
--

CREATE TABLE `zselex_service_demo` (
  `demo_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `plugin_id` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `availed` int(11) DEFAULT NULL,
  `qty_based` tinyint(1) NOT NULL,
  `bundle_id` int(11) DEFAULT NULL,
  `top_bundle` tinyint(1) NOT NULL,
  `bundle_type` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `start_date` date NOT NULL,
  `timer_days` int(11) NOT NULL,
  `is_bundle` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_service_demo`
--

INSERT INTO `zselex_service_demo` (`demo_id`, `shop_id`, `plugin_id`, `type`, `user_id`, `owner_id`, `quantity`, `availed`, `qty_based`, `bundle_id`, `top_bundle`, `bundle_type`, `status`, `start_date`, `timer_days`, `is_bundle`) VALUES
(1, 63, NULL, NULL, 3, 99, 1, 0, 1, 16, 1, 'main', 1, '2010-10-16', 90, NULL),
(4, 57, NULL, NULL, 3, 22, 1, 0, 1, 14, 1, 'main', 1, '2014-10-22', 1, NULL),
(5, 14, NULL, NULL, 3, 56, 1, 0, 1, 16, 1, 'main', 1, '2014-11-10', 90, NULL),
(6, 58, NULL, NULL, 2, NULL, 1, 0, 1, 17, 1, 'main', 1, '2017-12-10', 200, NULL),
(7, 14, NULL, NULL, 3, 56, 1, 0, 1, 17, 1, 'main', 1, '2016-03-23', 100, NULL),
(10, 61, NULL, NULL, 3, 3, 1, 0, 1, 17, 1, 'main', 1, '2017-12-10', 200, NULL),
(12, 23, NULL, NULL, 2, NULL, 1, 0, 1, 17, 1, 'main', 1, '2017-12-10', 200, NULL),
(13, 23, NULL, NULL, 2, NULL, 1, 0, 1, 18, 1, 'additional', 1, '2017-12-10', 200, NULL),
(16, 26, NULL, NULL, 3, 3, 1, 0, 1, 17, 1, 'main', 1, '2017-12-10', 200, NULL),
(15, 198, NULL, NULL, 3, NULL, 1, 0, 1, 17, 1, 'main', 1, '2016-06-12', 100, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_service_identifiers`
--

CREATE TABLE `zselex_service_identifiers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `identifier` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_service_identifiers`
--

INSERT INTO `zselex_service_identifiers` (`id`, `name`, `identifier`, `description`, `status`) VALUES
(1, 'Minisite Images', 'minisiteimages', '', 1),
(2, 'Minisite Gallery', 'minisitegallery', '', 1),
(3, 'Minisite Google Map', 'minisitegooglemap', '', 1),
(4, 'Reminder Content', 'remindercontent', '', 1),
(5, 'Pay Button', 'paybutton', '', 1),
(6, 'Create Ad', 'createad', '', 1),
(7, 'Minishop Products', 'addproducts', '', 1),
(8, 'Minishop', 'minishop', '', 1),
(9, 'Minisite Product Block', 'minisiteproductblock', '', 1),
(10, 'Deal Of The Day', 'dealoftheday', '', 1),
(11, 'Link To Minishop', 'linktoshop', '', 1),
(12, 'Minisite', 'minisite', '', 1),
(13, 'Create Articles', 'createarticle', '', 1),
(14, 'Shop Linker', 'shoplinker', '', 1),
(15, 'Product Linker', 'productlinker', '', 1),
(16, 'Create Article Ad', 'createarticlead', '', 1),
(17, 'Pdf Upload', 'pdfupload', '', 1),
(18, 'Youtube Link', 'youtubelink', '', 1),
(19, 'Youtube Films', 'youtubefilms', '', 1),
(20, 'Movie Upload', 'movieupload', '', 1),
(21, 'Standard Theme', 'stdtheme', '', 1),
(22, 'Modified Theme', 'modtheme', '', 1),
(23, 'My Theme', 'mytheme', '', 1),
(24, 'Diskquota', 'diskquota', '', 1),
(25, 'Event Service', 'eventservice', '', 1),
(26, 'Facebook Like', 'fblike', '', 1),
(27, 'Facebook Comment', 'fbcomment', '', 1),
(28, 'Minisite Banner', 'minisitebanner', '', 1),
(29, 'Minisite Announcement', 'minisiteannouncement', '', 1),
(30, 'employees', 'employees', '', 1),
(31, 'exclusiveevent', 'exclusiveevent', '', 1),
(32, 'FB post on wall', 'fbwallpost', '', 1),
(33, 'Pages', 'pages', '', 1),
(34, 'sociallinks', 'sociallinks', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_service_order`
--

CREATE TABLE `zselex_service_order` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `grand_total` decimal(15,4) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_service_order`
--

INSERT INTO `zselex_service_order` (`id`, `order_id`, `user_id`, `grand_total`, `status`, `payment_method`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `transaction_id`) VALUES
(51, 'CP51248505', 3, '35.0000', 'Success', 'quickpay', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, NULL),
(50, 'CP50596441', 3, '359.0000', 'Success', 'quickpay', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, NULL),
(49, 'CP49348644', 3, '258.0000', 'Success', 'netaxept', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, NULL),
(48, 'CP48199146', 3, '359.0000', 'Success', 'quickpay', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, NULL),
(47, 'CP47415759', 3, '258.0000', 'Success', 'quickpay', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, NULL),
(52, 'CP52332384', 3, '139.7200', 'Success', 'netaxept', '2014-10-16 16:49:27', 3, '2014-10-16 16:49:27', 3, NULL),
(53, 'CP53232045', 3, '9.5200', 'Success', 'quickpay', '2014-10-16 16:56:31', 3, '2014-10-16 16:56:31', 3, NULL),
(54, 'CP54208888', 3, '114.8800', 'Placed', 'epay', '2015-02-15 18:40:02', 3, '2015-02-15 18:40:02', 3, NULL),
(55, 'CP55496221', 3, '114.8800', 'Placed', 'quickpay', '2015-02-15 19:05:05', 3, '2015-02-15 19:05:05', 3, NULL),
(56, 'CP56680282', 3, '114.8800', 'Cancelled', 'netaxept', '2015-02-15 19:05:56', 3, '2015-02-15 19:05:56', 3, NULL),
(57, 'CP5774859', 3, '114.8800', 'Cancelled', 'paypal', '2015-02-15 19:07:57', 3, '2015-02-15 19:07:57', 3, NULL),
(58, 'CP58130425', 3, '114.8800', 'Success', 'epay', '2015-02-15 19:29:22', 3, '2015-02-15 19:29:22', 3, '41100333');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_service_orderitems`
--

CREATE TABLE `zselex_service_orderitems` (
  `order_item_id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `plugin_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(15,4) DEFAULT NULL,
  `status` smallint(6) NOT NULL,
  `service_status` smallint(6) NOT NULL,
  `timer_days` int(11) NOT NULL,
  `qty_based` smallint(6) NOT NULL,
  `bundle_id` int(11) NOT NULL,
  `subtotal` decimal(15,4) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `is_bundle` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_service_orderitems`
--

INSERT INTO `zselex_service_orderitems` (`order_item_id`, `order_id`, `plugin_id`, `type`, `shop_id`, `user_id`, `owner_id`, `quantity`, `price`, `status`, `service_status`, `timer_days`, `qty_based`, `bundle_id`, `subtotal`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `is_bundle`) VALUES
(1, 'CP47415759', 0, 'test-bundle', 14, 3, 0, 1, '258.0000', 0, 2, 18, 0, 16, '258.0000', '2014-06-05 15:43:41', 3, '2014-06-05 15:43:41', 3, 0),
(2, 'CP48199146', 0, 'butik-med-lidt-større-behov', 14, 3, 0, 1, '359.0000', 0, 2, 18, 0, 17, '359.0000', '2014-06-05 15:44:52', 3, '2014-06-05 15:44:52', 3, 0),
(3, 'CP49348644', 0, 'test-bundle', 26, 3, 99, 1, '258.0000', 0, 2, 18, 0, 16, '258.0000', '2014-06-05 16:00:59', 3, '2014-06-05 16:00:59', 3, 0),
(4, 'CP50596441', 0, 'butik-med-lidt-større-behov', 26, 3, 99, 1, '359.0000', 0, 2, 18, 0, 17, '359.0000', '2014-06-05 16:02:40', 3, '2014-06-05 16:02:40', 3, 0),
(5, 'CP51248505', 0, 'tillæg1', 26, 3, 99, 1, '35.0000', 0, 2, 18, 0, 18, '35.0000', '2014-06-05 16:03:56', 3, '2014-06-05 16:03:56', 3, 0),
(6, 'CP52332384', 0, '', 63, 3, 0, 1, '139.7200', 0, 2, 7, 0, 17, '139.0000', '2014-10-16 16:49:27', 3, '2014-10-16 16:49:27', 3, 0),
(7, 'CP53232045', 0, '', 63, 3, 0, 1, '0.0000', 0, 2, 7, 0, 21, '0.0000', '2014-10-16 16:56:31', 3, '2014-10-16 16:56:31', 3, 0),
(8, 'CP53232045', 0, '', 63, 3, 0, 1, '9.5200', 0, 2, 7, 0, 23, '9.0000', '2014-10-16 16:56:31', 3, '2014-10-16 16:56:31', 3, 0),
(9, 'CP54208888', 0, '', 57, 3, 0, 1, '114.8800', 0, 2, 8, 0, 16, '114.0000', '2015-02-15 18:40:02', 3, '2015-02-15 18:40:02', 3, 0),
(10, 'CP55496221', 0, '', 57, 3, 0, 1, '114.8800', 0, 2, 8, 0, 16, '114.0000', '2015-02-15 19:05:05', 3, '2015-02-15 19:05:05', 3, 0),
(11, 'CP56680282', 0, '', 57, 3, 0, 1, '114.8800', 0, 2, 8, 0, 16, '114.0000', '2015-02-15 19:05:56', 3, '2015-02-15 19:05:56', 3, 0),
(12, 'CP5774859', 0, '', 57, 3, 0, 1, '114.8800', 0, 2, 8, 0, 16, '114.0000', '2015-02-15 19:07:57', 3, '2015-02-15 19:07:57', 3, 0),
(13, 'CP58130425', 0, '', 57, 3, 0, 1, '114.8800', 0, 2, 8, 0, 16, '114.0000', '2015-02-15 19:29:22', 3, '2015-02-15 19:29:22', 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_serviceapproval`
--

CREATE TABLE `zselex_serviceapproval` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `plugin_id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `service_status` int(11) NOT NULL,
  `qty_based` int(11) NOT NULL,
  `timer_days` int(11) NOT NULL,
  `bundle` int(11) NOT NULL,
  `bundle_id` int(11) NOT NULL,
  `top_bundle` int(11) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_serviceapproval`
--

INSERT INTO `zselex_serviceapproval` (`id`, `shop_id`, `user_id`, `owner_id`, `plugin_id`, `type`, `quantity`, `status`, `service_status`, `qty_based`, `timer_days`, `bundle`, `bundle_id`, `top_bundle`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(4, 23, 5, 0, 2, 'createad', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(3, 23, 5, 0, 3, 'createimage', 2, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(5, 23, 5, 0, 1, 'googlemap', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(8, 23, 5, 0, 2, 'createad', 2, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(11, 23, 5, 0, 3, 'createimage', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(13, 25, 5, 0, 4, 'addproducts', 3, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(14, 26, 5, 0, 2, 'createad', 3, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(15, 26, 5, 0, 1, 'googlemap', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(16, 26, 5, 0, 4, 'addproducts', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(17, 25, 5, 0, 3, 'createimage', 3, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(18, 23, 5, 0, 9, 'linktoshop', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(19, 23, 5, 0, 11, 'minisiteproductblock', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(20, 23, 5, 0, 10, 'minishop', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(21, 26, 5, 0, 3, 'createimage', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(22, 25, 5, 0, 4, 'addproducts', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(23, 26, 22, 0, 11, 'minisiteproductblock', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(27, 14, 3, 0, 17, 'gallery', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(26, 16, 2, 0, 5, 'andreas08', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(28, 14, 3, 0, 11, 'minisiteproductblock', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(29, 14, 3, 0, 18, 'minisiteimages', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(30, 15, 2, 0, 17, 'gallery', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(31, 26, 22, 0, 20, 'linktoshop', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(32, 14, 3, 0, 10, 'minishop', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(33, 26, 3, 0, 10, 'minishop', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(34, 33, 3, 0, 17, 'gallery', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(35, 33, 3, 0, 18, 'minisiteimages', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(36, 33, 3, 0, 17, 'gallery', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(37, 33, 3, 0, 11, 'minisiteproductblock', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(38, 33, 3, 0, 24, 'googlemap', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(39, 14, 2, 0, 24, 'googlemap', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(43, 37, 21, 0, 26, 'minisite', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(44, 37, 21, 0, 18, 'minisiteimages', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(45, 37, 21, 0, 18, 'minisiteimages', 2, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(46, 37, 21, 0, 17, 'minisitegallery', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(47, 37, 21, 0, 17, 'minisitegallery', 3, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(48, 37, 21, 0, 10, 'minishop', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(49, 37, 21, 0, 31, 'createarticle', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(50, 37, 21, 0, 27, 'pdfupload', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(51, 37, 21, 0, 24, 'minisitegooglemap', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(52, 37, 21, 0, 21, 'linktoshop', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(53, 37, 21, 0, 10, 'minishop', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(54, 37, 21, 0, 4, 'addproducts', 2, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(56, 37, 21, 0, 12, 'dealoftheday', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(61, 14, 3, 23, 28, 'stdtheme', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(62, 37, 21, 21, 27, 'pdfupload', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(65, 37, 21, 21, 27, 'pdfupload', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(89, 26, 3, 0, 12, 'dealoftheday', 15, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(88, 26, 3, 0, 2, 'createad', 13, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(90, 37, 21, 0, 27, 'pdfupload', 1, 1, 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(91, 26, 3, 20, 2, 'createad', 1, 1, 1, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(94, 26, 26, 20, 18, 'minisiteimages', 20, 1, 2, 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(96, 26, 3, 20, 2, 'createad', 1, 1, 2, 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(97, 26, 3, 20, 38, 'bundle1', 1, 1, 2, 0, 0, 1, 14, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(98, 26, 3, 20, 38, '', 1, 1, 1, 0, 0, 1, 14, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(99, 26, 3, 20, 18, 'minisiteimages', 10, 1, 2, 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(100, 26, 3, 20, 26, 'minisite', 1, 1, 2, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(101, 26, 3, 20, 33, 'diskquota', 1, 1, 2, 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(102, 38, 55, 55, 41, 'butik-med-lidt-større-behov', 1, 1, 2, 0, 0, 1, 17, 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(103, 26, 2, 20, 11, 'minisiteproductblock', 1, 1, 2, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(104, 26, 2, 20, 18, 'minisiteimages', 10, 1, 2, 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(105, 26, 2, 20, 44, 'minisiteannouncement', 1, 1, 2, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(106, 26, 2, 20, 2, 'createad', 10, 1, 2, 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(107, 26, 3, 20, 26, 'minisite', 1, 1, 0, 0, 27, 0, 0, 0, '2013-10-04 00:00:00', 0, '0000-00-00 00:00:00', 0),
(108, 26, 3, 20, 11, 'minisiteproductblock', 1, 1, 0, 0, 24, 0, 0, 0, '2013-10-07 00:00:00', 0, '0000-00-00 00:00:00', 0),
(109, 38, 2, 55, 26, 'minisite', 1, 1, 0, 0, 22, 0, 0, 0, '2013-10-09 00:00:00', 0, '0000-00-00 00:00:00', 0),
(110, 38, 2, 55, 44, 'minisiteannouncement', 1, 1, 0, 0, 22, 0, 0, 0, '2013-10-09 00:00:00', 0, '0000-00-00 00:00:00', 0),
(111, 38, 2, 55, 34, 'eventservice', 1, 1, 0, 1, 22, 0, 0, 0, '2013-10-09 00:00:00', 0, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_serviceshop`
--

CREATE TABLE `zselex_serviceshop` (
  `id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `owner_id` int(11) DEFAULT NULL,
  `plugin_id` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `original_quantity` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `availed` int(11) NOT NULL,
  `extra` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `service_status` smallint(6) NOT NULL,
  `qty_based` tinyint(1) NOT NULL,
  `is_bundle` tinyint(1) NOT NULL,
  `bundle_id` int(11) DEFAULT NULL,
  `top_bundle` tinyint(1) NOT NULL,
  `bundle_type` varchar(255) NOT NULL,
  `timer_date` date NOT NULL,
  `timer_days` int(11) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_serviceshop`
--

INSERT INTO `zselex_serviceshop` (`id`, `shop_id`, `user_id`, `owner_id`, `plugin_id`, `type`, `original_quantity`, `quantity`, `availed`, `extra`, `status`, `service_status`, `qty_based`, `is_bundle`, `bundle_id`, `top_bundle`, `bundle_type`, `timer_date`, `timer_days`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(4876, 61, NULL, 3, 25, 'paybutton', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4824, 26, NULL, 3, 2, 'createad', 10, 10, 2, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4845, 58, NULL, NULL, 45, 'fbcomment', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4846, 58, NULL, NULL, 35, 'fblike', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4847, 58, NULL, NULL, 24, 'minisitegooglemap', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4848, 58, NULL, NULL, 21, 'linktoshop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4849, 58, NULL, NULL, 10, 'minishop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4850, 58, NULL, NULL, 4, 'addproducts', 50, 50, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4851, 58, NULL, NULL, 26, 'minisite', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4852, 58, NULL, NULL, 44, 'minisiteannouncement', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4853, 58, NULL, NULL, 43, 'minisitebanner', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4854, 58, NULL, NULL, 34, 'eventservice', 20, 20, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4855, 58, NULL, NULL, 18, 'minisiteimages', 20, 20, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4856, 58, NULL, NULL, 11, 'minisiteproductblock', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4875, 61, NULL, 3, 59, 'pages', 10, 10, 4, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4874, 61, NULL, 3, 11, 'minisiteproductblock', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4873, 61, NULL, 3, 18, 'minisiteimages', 20, 20, 2, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4871, 61, NULL, 3, 43, 'minisitebanner', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4872, 61, NULL, 3, 34, 'eventservice', 20, 20, 1, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4791, 23, NULL, NULL, 45, 'fbcomment', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4792, 23, NULL, NULL, 35, 'fblike', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4793, 23, NULL, NULL, 24, 'minisitegooglemap', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4794, 23, NULL, NULL, 21, 'linktoshop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4795, 23, NULL, NULL, 10, 'minishop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4796, 23, NULL, NULL, 4, 'addproducts', 50, 50, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4797, 23, NULL, NULL, 26, 'minisite', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4798, 23, NULL, NULL, 44, 'minisiteannouncement', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4826, 26, NULL, 3, 50, 'employees', 5, 5, 3, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4825, 26, NULL, 3, 33, 'diskquota', 100, 100, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4827, 26, NULL, 3, 45, 'fbcomment', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4828, 26, NULL, 3, 35, 'fblike', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4799, 23, NULL, NULL, 43, 'minisitebanner', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4800, 23, NULL, NULL, 34, 'eventservice', 20, 20, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4801, 23, NULL, NULL, 18, 'minisiteimages', 20, 20, 4, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4870, 61, NULL, 3, 44, 'minisiteannouncement', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4869, 61, NULL, 3, 26, 'minisite', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4868, 61, NULL, 3, 4, 'addproducts', 50, 50, 4, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4867, 61, NULL, 3, 10, 'minishop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4866, 61, NULL, 3, 21, 'linktoshop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4865, 61, NULL, 3, 24, 'minisitegooglemap', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4881, 63, NULL, 99, 45, 'fbcomment', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4882, 63, NULL, 99, 35, 'fblike', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4883, 63, NULL, 99, 24, 'minisitegooglemap', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4884, 63, NULL, 99, 21, 'linktoshop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4885, 63, NULL, 99, 10, 'minishop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4886, 63, NULL, 99, 4, 'addproducts', 50, 50, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4887, 63, NULL, 99, 26, 'minisite', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4888, 63, NULL, 99, 44, 'minisiteannouncement', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4889, 63, NULL, 99, 43, 'minisitebanner', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4890, 63, NULL, 99, 34, 'eventservice', 20, 20, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4891, 63, NULL, 99, 18, 'minisiteimages', 20, 20, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4892, 63, NULL, 99, 11, 'minisiteproductblock', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4893, 63, NULL, 99, 59, 'pages', 10, 10, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4894, 63, NULL, 99, 25, 'paybutton', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4895, 63, NULL, 99, 28, 'stdtheme', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:07', 0, '2017-12-10 15:14:07', 0),
(4864, 61, NULL, 3, 35, 'fblike', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4291, 198, NULL, 24, 59, 'pages', 10, 10, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4290, 198, NULL, 24, 11, 'minisiteproductblock', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4289, 198, NULL, 24, 18, 'minisiteimages', 20, 20, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4288, 198, NULL, 24, 34, 'eventservice', 20, 20, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4287, 198, NULL, 24, 43, 'minisitebanner', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4286, 198, NULL, 24, 44, 'minisiteannouncement', 1, 1, 0, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4285, 198, NULL, 24, 26, 'minisite', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4284, 198, NULL, 24, 4, 'addproducts', 50, 50, 8, '', 1, 1, 1, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4283, 198, NULL, 24, 10, 'minishop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4282, 198, NULL, 24, 21, 'linktoshop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4281, 198, NULL, 24, 24, 'minisitegooglemap', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4280, 198, NULL, 24, 35, 'fblike', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4279, 198, NULL, 24, 45, 'fbcomment', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4278, 198, NULL, 24, 50, 'employees', 5, 5, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4277, 198, NULL, 24, 33, 'diskquota', 100, 100, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4276, 198, NULL, 24, 2, 'createad', 10, 10, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4802, 23, NULL, NULL, 11, 'minisiteproductblock', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4803, 23, NULL, NULL, 59, 'pages', 10, 10, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4804, 23, NULL, NULL, 25, 'paybutton', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4857, 58, NULL, NULL, 59, 'pages', 10, 10, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4858, 58, NULL, NULL, 25, 'paybutton', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4859, 58, NULL, NULL, 28, 'stdtheme', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4863, 61, NULL, 3, 45, 'fbcomment', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4897, 63, NULL, 99, 27, 'pdfupload', 10, 10, 1, '', 1, 1, 1, 1, 23, 0, 'additional', '2017-12-10', 200, '2017-12-10 15:14:07', 0, '2017-12-10 15:14:07', 0),
(4896, 63, NULL, 99, 58, 'exclusiveevent', 1, 1, 0, '', 1, 1, 1, 1, 21, 0, 'additional', '2017-12-10', 200, '2017-12-10 15:14:07', 0, '2017-12-10 15:14:07', 0),
(4292, 198, NULL, 24, 25, 'paybutton', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4293, 198, NULL, 24, 28, 'stdtheme', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2016-06-12', 100, '2016-06-12 13:04:41', 0, '2016-06-12 13:04:41', 0),
(4829, 26, NULL, 3, 24, 'minisitegooglemap', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4830, 26, NULL, 3, 21, 'linktoshop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4831, 26, NULL, 3, 10, 'minishop', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4862, 61, NULL, 3, 50, 'employees', 5, 5, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4837, 26, NULL, 3, 18, 'minisiteimages', 20, 20, 3, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4790, 23, NULL, NULL, 50, 'employees', 5, 5, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4789, 23, NULL, NULL, 33, 'diskquota', 130, 130, 0, '', 1, 1, 1, 1, 18, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4788, 23, NULL, NULL, 2, 'createad', 10, 10, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:04', 0, '2017-12-10 15:14:04', 0),
(4844, 58, NULL, NULL, 50, 'employees', 5, 5, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4843, 58, NULL, NULL, 33, 'diskquota', 100, 100, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4842, 58, NULL, NULL, 2, 'createad', 10, 10, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4861, 61, NULL, 3, 33, 'diskquota', 100, 100, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4860, 61, NULL, 3, 2, 'createad', 10, 10, 2, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4880, 63, NULL, 99, 50, 'employees', 5, 5, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4879, 63, NULL, 99, 33, 'diskquota', 100, 100, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4878, 63, NULL, 99, 2, 'createad', 10, 10, 0, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0),
(4838, 26, NULL, 3, 11, 'minisiteproductblock', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4839, 26, NULL, 3, 59, 'pages', 10, 10, 7, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4840, 26, NULL, 3, 25, 'paybutton', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4841, 26, NULL, 3, 28, 'stdtheme', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4832, 26, NULL, 3, 4, 'addproducts', 50, 50, 4, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4833, 26, NULL, 3, 26, 'minisite', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4834, 26, NULL, 3, 44, 'minisiteannouncement', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4835, 26, NULL, 3, 43, 'minisitebanner', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4836, 26, NULL, 3, 34, 'eventservice', 20, 20, 1, '', 1, 1, 1, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4805, 23, NULL, NULL, 28, 'stdtheme', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:05', 0, '2017-12-10 15:14:05', 0),
(4877, 61, NULL, 3, 28, 'stdtheme', 1, 1, 1, '', 1, 1, 0, 1, 17, 0, 'main', '2017-12-10', 200, '2017-12-10 15:14:06', 0, '2017-12-10 15:14:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_serviceshop_bundles`
--

CREATE TABLE `zselex_serviceshop_bundles` (
  `service_bundle_id` int(11) NOT NULL,
  `bundle_name` varchar(255) DEFAULT NULL,
  `bundle_id` int(11) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `original_quantity` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `service_status` int(11) NOT NULL,
  `bundle_type` varchar(255) NOT NULL,
  `timer_date` date NOT NULL,
  `timer_days` int(11) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_serviceshop_bundles`
--

INSERT INTO `zselex_serviceshop_bundles` (`service_bundle_id`, `bundle_name`, `bundle_id`, `shop_id`, `original_quantity`, `quantity`, `service_status`, `bundle_type`, `timer_date`, `timer_days`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(2, 'Premium', 17, 63, 1, 1, 1, 'main', '2017-12-10', 200, '2014-10-16 16:50:28', 3, '2014-10-16 16:50:28', 3),
(3, 'Exclusive events', 21, 63, 1, 1, 1, 'additional', '2017-12-10', 200, '2014-10-16 16:57:05', 3, '2014-10-16 16:57:05', 3),
(4, 'pdf uploads', 23, 63, 1, 1, 1, 'additional', '2017-12-10', 200, '2014-10-16 16:57:05', 3, '2014-10-16 16:57:05', 3),
(21, 'Premium', 17, 198, 1, 1, 1, 'main', '2016-06-12', 100, '2015-10-22 09:51:58', 3, '2015-10-22 09:51:58', 3),
(9, 'Premium', 17, 58, 1, 1, 1, 'main', '2017-12-10', 200, '2014-12-15 16:01:26', 2, '2014-12-15 16:01:26', 2),
(14, 'Premium', 17, 61, 1, 1, 1, 'main', '2017-12-10', 200, '2015-05-28 22:26:55', 3, '2015-05-28 22:26:55', 3),
(16, 'Premium', 17, 23, 1, 1, 1, 'main', '2017-12-10', 200, '2015-10-05 00:33:01', 2, '2015-10-05 00:33:01', 2),
(17, 'Diskspace', 18, 23, 3, 3, 1, 'additional', '2017-12-10', 200, '2015-10-05 00:35:05', 2, '2015-10-05 00:35:05', 2),
(46, 'Premium', 17, 26, 1, 1, 1, 'main', '2017-12-10', 200, '2017-09-30 14:28:24', 3, '2017-09-30 14:28:24', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop`
--

CREATE TABLE `zselex_shop` (
  `shop_id` bigint(20) NOT NULL,
  `shop_name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `urltitle` varchar(500) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `description` longtext,
  `shop_info` longtext,
  `address` longtext,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `opening_hours` longtext,
  `pictures` varchar(255) DEFAULT NULL,
  `default_img_frm` varchar(100) DEFAULT NULL,
  `main` smallint(6) DEFAULT NULL,
  `meta_tag` longtext,
  `meta_description` longtext,
  `shoptype_id` smallint(6) DEFAULT NULL,
  `link_to_homepage` longtext,
  `link_to_mailinglist` longtext,
  `status` smallint(6) DEFAULT NULL,
  `aff_id` int(11) DEFAULT NULL,
  `vat_number` varchar(300) DEFAULT NULL,
  `advertise_sel_prods` tinyint(1) DEFAULT '0',
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `terms_conditions` longtext,
  `delivery_time` varchar(300) DEFAULT NULL,
  `purchase_collect_stat` tinyint(4) DEFAULT NULL,
  `email_purchase_tries` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop`
--

INSERT INTO `zselex_shop` (`shop_id`, `shop_name`, `title`, `urltitle`, `user_id`, `country_id`, `region_id`, `city_id`, `area_id`, `branch_id`, `theme`, `description`, `shop_info`, `address`, `telephone`, `fax`, `email`, `opening_hours`, `pictures`, `default_img_frm`, `main`, `meta_tag`, `meta_description`, `shoptype_id`, `link_to_homepage`, `link_to_mailinglist`, `status`, `aff_id`, `vat_number`, `advertise_sel_prods`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `terms_conditions`, `delivery_time`, `purchase_collect_stat`, `email_purchase_tries`) VALUES
(14, 'KeepRunning', 'KeepRunning', 'keeprunning', 23, 61, 7, 28, 0, 3, 'CityPilot', '', '', 'Vestergade 15\r\n8000 Aarhus\r\nDenmark', '0', '0', 'rasmus@keeprunning.dk', 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sun\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:7:\"comment\";s:0:\"\";}', 'BotImg3.jpg', 'fromshop', 0, '', '', 0, '', NULL, 1, 2, '', 0, '2012-03-07 00:00:00', 2, '2014-08-12 00:00:00', 3, '', NULL, NULL, NULL),
(23, 'DemoShop', 'DemoShop', 'demoshop', 21, 61, 7, 23, 0, 0, '', '', '', 'Kobbelgårdsvej 10\r\n7000 Fredericia', '34324234', '0', 'adasdasdasd', '', 'shop_newyork_pic.jpg', 'fromshop', 0, '', '', 0, '', NULL, 1, 2, '', 0, '2012-03-08 00:00:00', 2, '2014-08-04 00:00:00', 3, '', NULL, NULL, NULL),
(26, 'newIshop', '', 'newishop', 99, 61, 7, 31, 0, 0, 'CityPilotShop', '', 'my shop info tesing......\r\ntesting.. checking.....!', 'krishna reddy layout ,\r\n domlur , bangalore-560071', '+91-7025760973', '+444-7760-90', 'sharazkhanz@gmail.com', 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:3:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";s:6:\"closed\";s:1:\"1\";}s:3:\"sun\";a:3:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";s:6:\"closed\";s:1:\"1\";}s:7:\"comment\";s:65:\"zxdfdsfdsfsdaf sdfd  fnksfkskjadfkjsdkfksfkskladflkslkadflksalflk\";}', 'Jellyfish.jpg', 'fromshop', 1, '', '', 0, 'http://www.mytest.com', NULL, 1, 2, '4872346782648127648', 1, '2012-05-15 00:00:00', 3, '2014-06-25 00:00:00', 3, '', '4-90 days', 1, 1),
(57, 'ishop2', 'ishop2', 'ishop2', 0, 61, 16, 33, 10, 0, '', '', '', 'krishna reddy layout, domlur\r\nbangalore, karnataka 560071\r\n', '0', '0', '', 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sun\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:7:\"comment\";s:0:\"\";}', '', 'fromshop', 0, '', '', 0, '', NULL, 1, 2, '', 0, '2014-06-06 00:00:00', 3, '2014-07-14 00:00:00', 3, '', NULL, NULL, NULL),
(58, 'Spar Nord Fredericia', 'spar-nord-fredericia', 'spar-nord-fredericia', 0, 61, 7, 23, 0, 0, '', '', 'Er du på udkig efter en bank, der er med dig i hverdagen? Har du lyst til at få en rådgiver, der har tid til at hjælpe og som er til at få fat på? Kan du se ideen i, at din bank engagerer sig i dit lokalområde på samme måde, som du selv gør? Så er Spar Nord i Fredericia garanteret noget for dig.', 'Sjællandsgade 33\r\n7000 Fredericia', '76206400', '0', 'kim@acta-it.dk', 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sun\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:7:\"comment\";s:0:\"\";}', NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, '', 0, '2014-08-04 00:00:00', 2, '2014-08-04 00:00:00', 2, '', NULL, NULL, NULL),
(59, 'trstshopFredrica', '', 'trstshopfredrica', 0, 61, 7, 23, 9, 3, '', '', NULL, NULL, '0', '0', NULL, NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, '', 0, '2014-08-04 00:00:00', 3, '2014-08-04 00:00:00', 3, '', NULL, NULL, NULL),
(60, 'Meldahls Rådhus', 'meldahls-radhus', 'meldahls-radhus', 0, 61, 8, 23, 0, 0, '', '', 'Fredericia Råd-, Ting- og Arresthus er opført i 1860 efter tegning af arkitekt Ferdinand Meldahl, og har i perioden frem til 2003 fungeret som ting/arresthus, dog i de senere år alene som retsbygning for kriminalretten.', 'Vendersgade 30\r\n7000 Fredericia', '0', '0', 'kim@acta-it.dk', 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:3:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";s:6:\"closed\";s:1:\"1\";}s:3:\"sun\";a:3:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";s:6:\"closed\";s:1:\"1\";}s:7:\"comment\";s:0:\"\";}', NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, '', 0, '2014-08-06 00:00:00', 2, '2014-08-06 00:00:00', 2, '', NULL, NULL, NULL),
(61, 'MondayShop', '', 'mondayshop', 0, 61, 9, 27, 0, 0, '', '', NULL, NULL, '0', '0', NULL, NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, '', 0, '2014-09-29 00:00:00', 3, '2014-09-29 00:00:00', 3, '', '', NULL, NULL),
(63, 'HEllooo2', '', 'hellooo2', 0, 61, 0, 0, 0, 0, '', '', NULL, NULL, '0', '0', NULL, NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, '', 0, '2014-10-16 16:42:06', 3, '2014-10-16 16:42:06', 3, '', NULL, NULL, NULL),
(64, '6. juli garden', '6.-juli-garden', '6.-juli-garden', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Mønstedsvænget 11\r\n7000 Fredericia', '40172207', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(65, 'Amoc', 'amoc', 'amoc', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 21\r\n7000 Fredericia', '75926033', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(66, 'Anne Vibeke Rossing', 'anne-vibeke-rossing', 'anne-vibeke-rossing', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 43\r\n7000 Fredericia', '75921658', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(67, 'Arbejdernes Landsbank', 'arbejdernes-landsbank', 'arbejdernes-landsbank', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 6\r\n7000 Fredericia', '38483052', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(68, 'Axeltorvs Apotek', 'axeltorvs-apotek', 'axeltorvs-apotek', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 24\r\n7000 Fredericia', '75923800', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(69, 'B H Magasinet', 'b-h-magasinet', 'b-h-magasinet', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 43\r\n7000 Fredericia', '75923532', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(70, 'Bianco', 'bianco', 'bianco', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 1\r\n7000 Fredericia', '75914555', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(71, 'Billunds Boghandel', 'billunds-boghandel', 'billunds-boghandel', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 24\r\n7000 Fredericia', '75920162', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(72, 'Bison Lædervarer ApS', 'bison-lædervarer-aps', 'bison-lædervarer-aps', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 15\r\n7000 Fredericia', '75920376', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(73, 'Bjerggeden og Byrotten', 'bjerggeden-og-byrotten', 'bjerggeden-og-byrotten', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 1\r\n7000 Fredericia', '75932447', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(74, 'Booking Huset', 'booking-huset', 'booking-huset', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Nørrebrogade 7\r\n7000 Fredericia', '75910086', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(75, 'BT Centralen', 'bt-centralen', 'bt-centralen', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 4\r\n7000 Fredericia', '75920586', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(76, 'BT Gulve og Gardiner A/S', 'bt-gulve-og-gardiner-a/s', 'bt-gulve-og-gardiner-a/s', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Søndermarksvej 210\r\n7000 Fredericia', '20208255', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(77, 'Budstikken', 'budstikken', 'budstikken', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Riddergade 17\r\n7000 Fredericia', '76200400', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(78, 'Café den 7 himmel', 'café-den-7-himmel', 'café-den-7-himmel', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 7\r\n7000 Fredericia', '75910405', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(79, 'Café nr. 47', 'café-nr.-47', 'café-nr.-47', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 47\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(80, 'Rustik Cafe & Restaurant', 'rustik-cafe-&-restaurant', 'rustik-cafe-&-restaurant', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 59\r\n7000 Fredericia', '20721351', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(81, 'Chilli', 'chilli', 'chilli', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade  39\r\n7000 Fredericia', '75928481', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(82, 'Cykelservice', 'cykelservice', 'cykelservice', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Venusvej 4\r\n7000 Fredericia', '75921409', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(83, 'DanmarkC TV', 'danmarkc-tv', 'danmarkc-tv', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Finsensvej 18\r\n7000 Fredericia', '42742740', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(84, 'Davidsen Tømmerhandel', 'davidsen-tømmerhandel', 'davidsen-tømmerhandel', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Røde Banke 1\r\n7000 Fredericia', '75943611', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(85, 'Deluxe', 'deluxe', 'deluxe', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 45\r\n7000 Fredericia', '75928406', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(86, 'Danske bank', 'danske-bank', 'danske-bank', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 18\r\n7000 Fredericia', '45125400', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(87, 'Den Engelske', 'den-engelske', 'den-engelske', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 39\r\n7000 Fredericia', '75932636', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(88, 'Det Bruunske Pakhus', 'det-bruunske-pakhus', 'det-bruunske-pakhus', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Kirkestræde 3\r\n7000 Fredericia', '72106710', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(89, 'Ecco', 'ecco', 'ecco', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 22\r\n7000 Fredericia', '75940152', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(90, 'Elbo Bladet', 'elbo-bladet', 'elbo-bladet', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Nørrebrogade 5\r\n7000 Fredericia', '75921244', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(91, 'Event C', 'event-c', 'event-c', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Lyøvænget 7\r\n7000 Fredericia', '70225085', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(92, 'Festmesteren', 'festmesteren', 'festmesteren', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Calvinsvej 17\r\n7000 Fredericia', '75924411', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(93, 'Flair', 'flair', 'flair', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 21\r\n7000 Fredericia', '75920202', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(94, 'Flashlight gruppen', 'flashlight-gruppen', 'flashlight-gruppen', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Titanvænget 10\r\n7000 Fredericia', '75920132', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(95, 'Fleur', 'fleur', 'fleur', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 43\r\n7000 Fredericia', '75923532', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(96, 'Flügger Farve', 'flügger-farve', 'flügger-farve', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Norgesgade 14\r\n7000 Fredericia', '75934866', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(97, 'Fona', 'fona', 'fona', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 12\r\n7000 Fredericia', '75922955', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(98, 'Fotograf Helle S. Andersen', 'fotograf-helle-s.-andersen', 'fotograf-helle-s.-andersen', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vesterbrogade 21\r\n7000 Fredericia', '75926888', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(99, 'Fredericia Bibliotek', 'fredericia-bibliotek', 'fredericia-bibliotek', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade  27\r\n7000 Fredericia', '72106800', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(100, 'Fredericia Dagblad', 'fredericia-dagblad', 'fredericia-dagblad', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Nørrebrogade 7\r\n7000 Fredericia', '75922600', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(101, 'Fredericia Skiltefabrik', 'fredericia-skiltefabrik', 'fredericia-skiltefabrik', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Strevelinsvej 20\r\n7000 Fredericia', '75912800', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(102, 'Fredericia Teater', 'fredericia-teater', 'fredericia-teater', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 29\r\n7000 Fredericia', '75922500', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(103, 'Fredericia Vinhandel', 'fredericia-vinhandel', 'fredericia-vinhandel', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 49\r\n7000 Fredericia', '75922767', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(104, 'Føtex city', 'føtex-city', 'føtex-city', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 49\r\n7000 Fredericia', '76222000', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(105, 'Føtex Vest', 'føtex-vest', 'føtex-vest', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Venusvej 8\r\n7000 Fredericia', '79234000', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(106, 'Geist & Gnist', 'geist-&-gnist', 'geist-&-gnist', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 22\r\n7000 Fredericia', '75931955', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(107, 'Guldbageren', 'guldbageren', 'guldbageren', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 10\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(108, 'Guldperlen', 'guldperlen', 'guldperlen', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 9\r\n7000 Fredericia', '75921202', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(109, 'Handelsbanken', 'handelsbanken', 'handelsbanken', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 82\r\n7000 Fredericia', '44564950', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(110, 'Hauge', 'hauge', 'hauge', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 12\r\n7000 Fredericia', '75932710', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(111, 'Havanna sko', 'havanna-sko', 'havanna-sko', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 4\r\n7000 Fredericia', '75928753', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(112, 'Helsekosten', 'helsekosten', 'helsekosten', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 37\r\n7000 Fredericia', '75934311', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(113, 'Hennes & Mauritz', 'hennes-&-mauritz', 'hennes-&-mauritz', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 22\r\n7000 Fredericia', '75935156', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(114, 'High end sport', 'high-end-sport', 'high-end-sport', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 18\r\n7000 Fredericia', '75920345', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(115, 'HK Midt', 'hk-midt', 'hk-midt', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vesterballevej 3a\r\n7000 Fredericia', '70114545', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(116, 'Holst sko', 'holst-sko', 'holst-sko', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 22\r\n7000 Fredericia', '32219259', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(117, 'Home Fredericia', 'home-fredericia', 'home-fredericia', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Købmagergade 14\r\n7000 Fredericia', '61304520', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(118, 'Imerco', 'imerco', 'imerco', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 7\r\n7000 Fredericia', '26331613', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(119, 'Jyske Bank', 'jyske-bank', 'jyske-bank', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksstræde 22\r\n7000 Fredericia', '89898560', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(120, 'Klokken', 'klokken', 'klokken', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 24 21\r\n7000 Fredericia', '75920375', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(121, 'Kop og Kande', 'kop-og-kande', 'kop-og-kande', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 1a\r\n7000 Fredericia', '75933939', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(122, 'LB Dans', 'lb-dans', 'lb-dans', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Hans Egedes vej 6\r\n7000 Fredericia', '75915096', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(123, 'Le noir', 'le-noir', 'le-noir', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 19\r\n7000 Fredericia', '75560472', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(124, 'Lucullus Smørebrød', 'lucullus-smørebrød', 'lucullus-smørebrød', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Luthersvej 14\r\n7000 Fredericia', '75922564', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(125, 'Løve Apoteket Vestcentretret', 'løveapoteket', 'loeve-apoteket', 0, 61, 7, 23, 0, 0, '', '', '', 'Danmarksgade 19\r\n7000 Fredericia', '75923544', '', 'kim@acta-it.dk', 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sun\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:7:\"comment\";s:0:\"\";}', NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, '', 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(126, 'Matas Gothersgade', 'matas-gothersgade', 'matas-gothersgade', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 20b\r\n7000 Fredericia', '75920066', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(127, 'Matas Vendersgade', 'matas-vendersgade', 'matas-vendersgade', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 25\r\n7000 Fredericia', '75920180', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(128, 'Miami', 'miami', 'miami', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 2b\r\n7000 Fredericia', '75921095', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(129, 'Middelfart Sparekasse', 'middelfart-sparekasse', 'middelfart-sparekasse', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 95\r\n7000 Fredericia', '75930800', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(130, 'Mr. Højer', 'mr.-højer', 'mr.-højer', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 20\r\n7000 Fredericia', '75920354', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(131, 'Nordea', 'nordea', 'nordea', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 5\r\n7000 Fredericia', '70333333', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(132, 'Nü by Staff', 'nü-by-staff', 'nü-by-staff', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 22\r\n7000 Fredericia', '75945050', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(133, 'Nykredit', 'nykredit', 'nykredit', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 17\r\n7000 Fredericia', '44556720', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(134, 'Optik Hallmann', 'optik-hallmann', 'optik-hallmann', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 1a\r\n7000 Fredericia', '75925950', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(135, 'Ostejyden', 'ostejyden', 'ostejyden', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 39\r\n7000 Fredericia', '75920731', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(136, 'Panorama', 'panorama', 'panorama', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 29\r\n7000 Fredericia', '75910024', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(137, 'Photo care', 'photo-care', 'photo-care', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 28a\r\n7000 Fredericia', '75922454', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(138, 'Pigernes Verden', 'pigernes-verden', 'pigernes-verden', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 23\r\n7000 Fredericia', '75927848', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(139, 'Pro Print', 'pro-print', 'pro-print', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Glarmestervej 1\r\n7000 Fredericia', '75934950', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(140, 'Profil Optik', 'profil-optik', 'profil-optik', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 13\r\n7000 Fredericia', '75924522', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(141, 'Radio Fredericia', 'radio-fredericia', 'radio-fredericia', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Bugattivej 8\r\n7100 Vejle', '76400400', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(142, 'Ranch Svendsen', 'ranch-svendsen', 'ranch-svendsen', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 1\r\n7000 Fredericia', '22580227', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(143, 'Restaurant Generalen', 'restaurant-generalen', 'restaurant-generalen', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 61\r\n7000 Fredericia', '26160176', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(144, 'Restaurant Oven Vande', 'restaurant-oven-vande', 'restaurant-oven-vande', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Sønder Voldgade 10\r\n7000 Fredericia', '76200226', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(145, 'Sadolin Farvehandel', 'sadolin-farvehandel', 'sadolin-farvehandel', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vejlevej 29\r\n7000 Fredericia', '75927611', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(146, 'Sejersen - Din tøjmand', 'sejersen---din-tøjmand', 'sejersen---din-tøjmand', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 23\r\n7000 Fredericia', '75921111', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(147, 'Simone', 'simone', 'simone', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 41\r\n7000 Fredericia', '75920565', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(148, 'Skoringen', 'skoringen', 'skoringen', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 17\r\n7000 Fredericia', '62265105', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(149, 'Nyt Syn', 'nyt-syn', 'nyt-syn', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 2\r\n7000 Fredericia', '75920062', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(150, 'Sport24', 'sport24', 'sport24', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 9\r\n7000 Fredericia', '30213300', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(151, 'Sportmaster', 'sportmaster', 'sportmaster', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 10\r\n7000 Fredericia', '75923700', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(152, 'Standard', 'standard', 'standard', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 2\r\n7000 Fredericia', '75920051', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(153, 'Stark Fredericia', 'stark-fredericia', 'stark-fredericia', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Nordre Ringvej 7\r\n7000 Fredericia', '75924333', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(154, 'Støvsugereksperten', 'støvsugereksperten', 'støvsugereksperten', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksstræde 1\r\n7000 Fredericia', '75933787', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(155, 'Superbrugsen Erritsø', 'superbrugsen-erritsø', 'superbrugsen-erritsø', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Erritsø Bygade 109\r\n7000 Fredericia', '76203800', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(156, 'Sydbank', 'sydbank', 'sydbank', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 33\r\n7000 Fredericia', '74375930', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(157, 'Synoptik', 'synoptik', 'synoptik', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 11\r\n7000 Fredericia', '75931361', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(158, 'Tantes Have', 'tantes-have', 'tantes-have', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Skærbækvej 3\r\n7000 Fredericia', '75954141', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(159, 'Telenor', 'telenor', 'telenor', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 15\r\n7000 Fredericia', '25264061', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(160, 'The og ide', 'the-og-ide', 'the-og-ide', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 10\r\n7000 Fredericia', '75910456', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(161, 'Thiele Briller', 'thiele-briller', 'thiele-briller', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 10a\r\n7000 Fredericia', '75927778', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(162, 'Tre-for', 'tre-for', 'tre-for', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Kokbjerg 30\r\n7000 Fredericia', '79333435', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(163, 'Tøjeksperten', 'tøjeksperten', 'tøjeksperten', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 25\r\n7000 Fredericia', '72349043', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(164, 'USO ', 'uso-', 'uso-', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 20b\r\n7000 Fredericia', '75514849', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(165, 'Vestbyens Herretøj', 'vestbyens-herretøj', 'vestbyens-herretøj', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Venusvej 10\r\n7000 Fredericia', '75927345', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(166, 'Vestfyns Bank', 'vestfyns-bank', 'vestfyns-bank', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 1a\r\n7000 Fredericia', '76203950', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(167, 'Vinoble', 'vinoble', 'vinoble', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 28b\r\n7000 Fredericia', '76203844', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(168, 'Willox', 'willox', 'willox', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 4\r\n7000 Fredericia', '75923550', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(169, 'Zederkof', 'zederkof', 'zederkof', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prins Christians Kvartér 28\r\n7000 Fredericia', '89121200', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(170, 'Zizzi', 'zizzi', 'zizzi', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 1\r\n7000 Fredericia', '75923600', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(171, 'Zoffman Optik', 'zoffman-optik', 'zoffman-optik', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 35\r\n7000 Fredericia', '75913133', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(172, 'Spaabæk Clinic', 'spaabæk-clinic', 'spaabæk-clinic', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Sjællandsgade 25\r\n7000 Fredericia', '24964689', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(173, 'Frk Nipz', 'frk-nipz', 'frk-nipz', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 1a\r\n7000 Fredericia', '75934505', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(174, 'Tegllund', 'tegllund', 'tegllund', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vejlevej 52\r\n7000 Fredericia', '27537533', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(175, 'CompuConsult Data', 'compuconsult-data', 'compuconsult-data', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Købmagergade 20\r\n7000 Fredericia', '40911491', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(176, 'Coach til salg', 'coach-til-salg', 'coach-til-salg', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsensgade 31.1 tv\r\n7000 Fredericia', '61317777', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(177, 'Skjold Burne', 'skjold-burne', 'skjold-burne', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 29\r\n7000 Fredericia', '72407000', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(178, 'Garn klip og styling', 'garn-klip-og-styling', 'garn-klip-og-styling', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 32a\r\n7000 Fredericia', '75914477', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(179, 'Cykelsmeden', 'cykelsmeden', 'cykelsmeden', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Kaltoftevej 1\r\n7000 Fredericia', '21609844', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(180, 'Butik Smagløs', 'butik-smagløs', 'butik-smagløs', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 36\r\n7000 Fredericia', '23280333', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(181, 'Lydbureauet', 'lydbureauet', 'lydbureauet', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Højrupvej 119\r\n7000 Fredericia', '60180099', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(182, 'Marcus', 'marcus', 'marcus', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 10\r\n7000 Fredericia', '75781100', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(183, 'Cafe Mair', 'cafe-mair', 'cafe-mair', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Gothersgade 55\r\n7000 Fredericia', '42729493', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(184, 'Hårværk', 'hårværk', 'hårværk', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 35\r\n7000 Fredericia', '88371135', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(185, 'Botique Unique', 'botique-unique', 'botique-unique', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 26\r\n7000 Fredericia', '23555185', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(186, 'Calle & Co', 'calle-&-co', 'calle-&-co', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 3\r\n7000 Fredericia', '40282738', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(187, 'Dueholm Begravelsesforretning', 'dueholm-begravelsesforretning', 'dueholm-begravelsesforretning', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 1\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(188, 'Frelsens Chokolade', 'frelsens-chokolade', 'frelsens-chokolade', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 24\r\n7000 Fredericia', '75925989', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(189, 'DE Eletronink/Skilte Værkstedet', 'de-eletronink/skilte-værkstedet', 'de-eletronink/skilte-værkstedet', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Købmagergade 23\r\n7000 Fredericia', '759423010', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(190, 'Garnkælderen', 'garnkælderen', 'garnkælderen', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 56 A\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(191, 'Isabellas Reataurant og Steakhaouse', 'isabellas-reataurant-og-steakhaouse', 'isabellas-reataurant-og-steakhaouse', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Vendersgade 20\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(192, 'fieV Photo & Design', 'fiev-photo-&-design', 'fiev-photo-design', 0, 61, 7, 23, 0, 0, '', '', NULL, 'Thygesminde Allé 137\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(193, 'Domisil', 'domisil', 'domisil', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Jyllandsgade 45\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(194, 'House of melfar', 'house-of-melfar', 'house-of-melfar', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 1\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(195, 'Nybolig', 'nybolig', 'nybolig', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Danmarksgade 31\r\n7000 Fredericia', '0', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(196, 'Vinspecialisten Fredericia', 'vinspecialisten-fredericia', 'vinspecialisten-fredericia', 0, 61, 7, 23, 0, 0, NULL, NULL, NULL, 'Prinsessegade 32B\r\n7000 Fredericia', '75527744', NULL, 'kim@acta-it.dk', NULL, NULL, 'fromshop', 0, NULL, NULL, 0, '', NULL, 1, 2, NULL, 0, '2014-11-02 20:28:53', 2, '0000-00-00 00:00:00', 0, '', NULL, NULL, NULL),
(197, 'Løve Apoteket Vestcentret', NULL, 'lve-apoteket-vestcentret', 0, 61, NULL, NULL, NULL, NULL, '', '', '', '', '0', '', '', '', '', 'fromshop', 0, '', '', 0, '', NULL, 1, 2, '', 0, '2015-09-17 19:22:15', 3, '2015-09-17 19:22:15', 3, '', '', NULL, NULL),
(199, 'hello 007', NULL, 'hello-007', 136, 61, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', 'fromshop', 0, '', '', 0, '', NULL, 1, 2, '', 0, '2016-02-10 17:49:08', 3, '2016-02-10 17:51:39', 3, '', '', 0, 0),
(198, 'Sharaz\\\'s Shop', NULL, 'sharazs-shop', 0, 61, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', 'fromshop', 0, '', '', 0, '', NULL, 1, 2, '', 0, '2015-10-22 09:43:59', 3, '2015-10-22 09:43:59', 3, '', '', 0, 0),
(200, 'Tijo\\\'s Shop', NULL, 'tijos-shop', 0, 61, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', 'fromshop', 0, '', '', 0, '', NULL, 1, NULL, '', 0, '2016-03-21 18:45:16', 3, '2016-03-21 18:45:16', 3, '', '', 0, 0),
(201, 'New Sharaz Shop', NULL, 'new-sharaz-shop', 0, 61, NULL, NULL, NULL, NULL, '', '', '', '', '', '', '', '', '', 'fromshop', 0, '', '', 0, '', NULL, 1, NULL, '', 0, '2016-03-21 18:49:09', 3, '2016-03-21 18:49:09', 3, '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_a_settings`
--

CREATE TABLE `zselex_shop_a_settings` (
  `id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `default_img_frm` varchar(100) DEFAULT NULL,
  `main` tinyint(1) DEFAULT NULL,
  `theme` varchar(250) DEFAULT NULL,
  `opening_hours` longtext,
  `no_payment` tinyint(1) DEFAULT NULL,
  `link_to_homepage` longtext,
  `terms_conditions` longtext
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_a_settings`
--

INSERT INTO `zselex_shop_a_settings` (`id`, `shop_id`, `default_img_frm`, `main`, `theme`, `opening_hours`, `no_payment`, `link_to_homepage`, `terms_conditions`) VALUES
(3, 14, 'fromshop', 0, NULL, 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sun\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:7:\"comment\";s:0:\"\";}', 0, '', ''),
(5, 23, NULL, 0, NULL, '', 0, '', ''),
(6, 26, 'fromshop', 1, NULL, 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:3:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";s:6:\"closed\";s:1:\"1\";}s:3:\"sun\";a:3:{s:4:\"open\";s:5:\" 9:00\";s:5:\"close\";s:5:\"16:00\";s:6:\"closed\";s:1:\"1\";}s:7:\"comment\";s:65:\"zxdfdsfdsfsdaf sdfd  fnksfkskjadfkjsdkfksfkskladflkslkadflksalflk\";}', 0, 'http://www.mytest.com', 'a:2:{s:2:\"da\";a:7:{s:4:\"info\";s:4:\"test\";s:3:\"rma\";s:1:\"m\";s:14:\"deliveryprices\";s:1:\"m\";s:12:\"deliverytime\";s:1:\"m\";s:12:\"termsoftrade\";s:1:\"m\";s:7:\"privacy\";s:1:\"m\";s:13:\"securepayment\";s:1:\"m\";}s:2:\"en\";a:7:{s:4:\"info\";s:1:\"m\";s:3:\"rma\";s:1:\"m\";s:14:\"deliveryprices\";s:1:\"m\";s:12:\"deliverytime\";s:1:\"m\";s:12:\"termsoftrade\";s:1:\"m\";s:7:\"privacy\";s:1:\"m\";s:13:\"securepayment\";s:1:\"m\";}}'),
(21, 57, 'fromshop', 0, NULL, 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sun\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:7:\"comment\";s:0:\"\";}', 0, '', NULL),
(22, 58, NULL, 0, NULL, 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sun\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:7:\"comment\";s:0:\"\";}', 0, '', NULL),
(23, 59, NULL, 0, NULL, NULL, 0, NULL, NULL),
(24, 60, NULL, 0, NULL, 'a:8:{s:3:\"mon\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"tue\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"wed\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"thu\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"fri\";a:2:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";}s:3:\"sat\";a:3:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";s:6:\"closed\";s:1:\"1\";}s:3:\"sun\";a:3:{s:4:\"open\";s:5:\" 8:00\";s:5:\"close\";s:5:\"16:00\";s:6:\"closed\";s:1:\"1\";}s:7:\"comment\";s:0:\"\";}', 1, '', NULL),
(25, 61, NULL, 0, NULL, NULL, 0, NULL, NULL),
(27, 63, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(28, 197, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(29, 198, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(30, 199, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(31, 200, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(32, 201, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_admins`
--

CREATE TABLE `zselex_shop_admins` (
  `admin_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_admins`
--

INSERT INTO `zselex_shop_admins` (`admin_id`, `shop_id`, `user_id`, `owner_id`) VALUES
(16, 14, 17, 3),
(17, 14, 18, 3),
(18, 14, 9, 2),
(19, 14, 37, 2),
(22, 58, 125, 2),
(25, 26, 9, 3),
(26, 26, 3, 3),
(27, 199, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_affiliation`
--

CREATE TABLE `zselex_shop_affiliation` (
  `aff_id` int(11) NOT NULL,
  `aff_name` varchar(255) NOT NULL,
  `aff_image` varchar(255) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_affiliation`
--

INSERT INTO `zselex_shop_affiliation` (`aff_id`, `aff_name`, `aff_image`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `sort_order`) VALUES
(2, 'Member', 'member.png', '2013-12-18 00:00:00', 2, '2013-12-18 00:00:00', 2, 0),
(3, 'Union', 'member.png', '2013-12-18 00:00:00', 2, '2013-12-18 00:00:00', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_announcement`
--

CREATE TABLE `zselex_shop_announcement` (
  `ann_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `text` longtext,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_announcement`
--

INSERT INTO `zselex_shop_announcement` (`ann_id`, `shop_id`, `text`, `start_date`, `end_date`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(2, 38, 'BY NIGHT\r\nFREDAG 10.00-22.00', '2013-09-15', '2013-09-21', 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(3, 42, 'BY NIGHT\r\nFREDAG 10.00-22.00', '2013-09-16', '2013-09-21', 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(4, 46, 'BY NIGHT\r\nFREDAG 10.00-22.00', '2013-09-16', '2013-09-21', 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(5, 16, 'BY NIGHT\r\nFREDAG 12.00-24.00', '2013-09-16', '2013-09-21', 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(6, 47, 'BY NIGHT\r\nFREDAG 10.00-22.00', '2013-09-17', '2013-09-21', 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(7, 41, 'BY NIGHT\r\nFREDAG 10.00-22.00', '2013-09-17', '2013-10-12', 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(8, 49, '10-22\r\nFREDAG\r\nOPEN BY NIGHT', '2013-10-07', '2013-10-12', 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(9, 48, 'OPEN BY NIGHT\r\nFREDAG 10.00-22.00', '2013-10-07', '2013-10-12', 1, '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(10, 26, 'Hello World. This is a test the cross line text on banner', '2016-01-23', '2017-04-14', 1, '2016-01-23 17:06:53', 3, '2016-01-23 17:06:53', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_banner`
--

CREATE TABLE `zselex_shop_banner` (
  `shop_banner_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `banner_image` varchar(250) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL,
  `height` varchar(250) DEFAULT NULL,
  `width` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_banner`
--

INSERT INTO `zselex_shop_banner` (`shop_banner_id`, `shop_id`, `banner_image`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`, `height`, `width`) VALUES
(93, 57, 'Tulips.jpg', NULL, '2015-05-28 21:18:42', 3, '2015-05-28 21:18:42', 3, NULL, NULL),
(144, 26, 'event-demo11_eaab58428d6b2a7c4a1dd684b1db0f69.jpg', NULL, '2016-06-12 13:03:14', 0, '2016-06-12 13:03:14', 0, '320', '960'),
(147, 61, 'banner_346f6fcefdb846087a30c855de946034.jpg', NULL, '2016-09-19 21:15:23', 3, '2016-09-19 21:15:23', 3, '320', '2048');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_banner_settings`
--

CREATE TABLE `zselex_shop_banner_settings` (
  `ban_set_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `image_mode` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_banner_settings`
--

INSERT INTO `zselex_shop_banner_settings` (`ban_set_id`, `shop_id`, `image_mode`) VALUES
(1, 26, 1);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_config`
--

CREATE TABLE `zselex_shop_config` (
  `shopconfigId` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `shoptype_id` int(11) NOT NULL,
  `domain` varchar(30) NOT NULL,
  `hostname` varchar(250) NOT NULL,
  `dbname` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `table_prefix` varchar(35) NOT NULL,
  `status` int(15) NOT NULL,
  `obj_status` varchar(10) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_config`
--

INSERT INTO `zselex_shop_config` (`shopconfigId`, `shop_id`, `shoptype_id`, `domain`, `hostname`, `dbname`, `username`, `password`, `table_prefix`, `status`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(6, 14, 1, 'shop.keeprunning.dk', 'shop.keeprunning.dk', 'c6shopkeep', 'c6shopkeep', 'th140651', 'zen_', 0, '', '2012-03-07 18:59:00', 2, '2012-03-07 18:59:00', 2),
(7, 15, 1, 'shop.keeprunning.dk', 'shop.keeprunning.dk', 'c6shopkeep', 'c6shopkeep', 'th140651', 'zen_', 0, '', '2012-03-07 19:02:14', 2, '2012-03-07 19:02:14', 2),
(8, 16, 0, '', '', '', '', '', '', 0, '', '2012-03-07 19:08:38', 2, '2012-03-07 19:08:38', 2),
(9, 17, 0, '', '', '', '', '', '', 0, '', '2012-03-07 19:10:37', 2, '2012-03-07 19:10:37', 2),
(10, 18, 1, 'mydomain', 'shop.keeprunning.dk 	', 'mydbbb', 'sdfsfsf', 'sdfsdfsdf', 'sdfsdf', 0, '', '2012-03-08 08:20:09', 3, '2012-03-08 08:20:09', 3),
(11, 19, 1, 'demo.keeprunning.dk', '', 'c6demokeep', 'c6demokeep', 'th140651', 'zen_', 0, '', '2012-03-08 09:59:40', 2, '2012-03-08 09:59:40', 2),
(12, 20, 1, 'domain.coamin.asas', 'test.host', 'asda', 'asdad', 'sdasdasd', 'asdad', 0, '', '2012-03-08 10:01:49', 3, '2012-03-08 10:01:49', 3),
(13, 21, 1, '', 'host.com/test.dk', 'asdasdad', 'asdasdsa', 'asdsad', 'asdsadsad', 0, '', '2012-03-08 10:20:16', 3, '2012-03-08 10:20:16', 3),
(14, 22, 1, 'doamain.comsdsadsa', 'hosttttttttttttttt', 'dfdsfsf', 'sdfsdfdf', 'sdf', 'sdfsd', 0, '', '2012-03-08 10:21:36', 3, '2012-03-08 10:21:36', 3),
(15, 23, 1, 'demo.keeprunning.dk', 'demo.keeprunning.dk', 'c6demokeep', 'c6demokeep', 'th140651', 'zen_', 0, '', '2012-03-08 11:44:44', 2, '2012-03-08 11:44:44', 2);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_details`
--

CREATE TABLE `zselex_shop_details` (
  `shop_id` int(11) NOT NULL,
  `terms_conditions` longtext NOT NULL,
  `no_payment` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_details`
--

INSERT INTO `zselex_shop_details` (`shop_id`, `terms_conditions`, `no_payment`) VALUES
(26, 'a:2:{s:2:\"da\";a:7:{s:4:\"info\";s:4:\"test\";s:3:\"rma\";s:1:\"m\";s:14:\"deliveryprices\";s:1:\"m\";s:12:\"deliverytime\";s:1:\"m\";s:12:\"termsoftrade\";s:1:\"m\";s:7:\"privacy\";s:1:\"m\";s:13:\"securepayment\";s:1:\"m\";}s:2:\"en\";a:7:{s:4:\"info\";s:1:\"m\";s:3:\"rma\";s:1:\"m\";s:14:\"deliveryprices\";s:1:\"m\";s:12:\"deliverytime\";s:1:\"m\";s:12:\"termsoftrade\";s:1:\"m\";s:7:\"privacy\";s:1:\"m\";s:13:\"securepayment\";s:1:\"m\";}}', 0),
(14, '', 0),
(21, '', 0),
(23, '', 0),
(32, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_employees`
--

CREATE TABLE `zselex_shop_employees` (
  `emp_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `cell` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  `emp_image` varchar(255) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_employees`
--

INSERT INTO `zselex_shop_employees` (`emp_id`, `shop_id`, `name`, `phone`, `cell`, `email`, `job`, `emp_image`, `status`, `sort_order`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(27, 26, 'DSC_0029', NULL, NULL, NULL, NULL, 'DSC_0029.jpg', 1, NULL, '2014-10-22 09:37:33', 3, '2014-10-22 09:37:33', 3),
(30, 26, 'Chrysanthemum', NULL, NULL, NULL, NULL, 'Chrysanthemum-bd287590cc524f6c54841f6cd62f3c9c.jpg', 1, 0, '2015-09-09 21:29:13', 3, '2015-09-09 21:29:13', 3),
(32, 26, 'logo2', NULL, NULL, NULL, NULL, 'logo2-735f8c3c6397ff5b8d1a8ebf6d190715.jpg', 1, 0, '2015-09-12 22:22:11', 3, '2015-09-12 22:22:11', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_event_temp`
--

CREATE TABLE `zselex_shop_event_temp` (
  `id` bigint(20) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `event_date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_event_temp`
--

INSERT INTO `zselex_shop_event_temp` (`id`, `event_id`, `shop_id`, `event_date`) VALUES
(132, 97, 26, '2017-10-11'),
(131, 97, 26, '2017-10-10'),
(130, 97, 26, '2017-10-09'),
(129, 97, 26, '2017-10-08'),
(128, 97, 26, '2017-10-07'),
(127, 97, 26, '2017-10-06'),
(126, 97, 26, '2017-10-05'),
(125, 97, 26, '2017-10-04'),
(124, 97, 26, '2017-10-03'),
(123, 97, 26, '2017-10-02'),
(61, 81, 61, '2016-09-19'),
(62, 81, 61, '2016-09-20'),
(63, 81, 61, '2016-09-21'),
(64, 81, 61, '2016-09-22'),
(65, 81, 61, '2016-09-23'),
(66, 81, 61, '2016-09-24'),
(67, 81, 61, '2016-09-25'),
(68, 81, 61, '2016-09-26'),
(69, 81, 61, '2016-09-27'),
(70, 81, 61, '2016-09-28'),
(71, 81, 61, '2016-09-29'),
(72, 81, 61, '2016-09-30'),
(133, 97, 26, '2017-10-12'),
(134, 97, 26, '2017-10-13'),
(135, 97, 26, '2017-10-14'),
(136, 97, 26, '2017-10-15'),
(137, 97, 26, '2017-10-16'),
(138, 97, 26, '2017-10-17'),
(139, 97, 26, '2017-10-18'),
(140, 97, 26, '2017-10-19'),
(141, 97, 26, '2017-10-20'),
(142, 97, 26, '2017-10-21'),
(143, 97, 26, '2017-10-22'),
(144, 97, 26, '2017-10-23'),
(145, 97, 26, '2017-10-24'),
(146, 97, 26, '2017-10-25'),
(147, 97, 26, '2017-10-26'),
(148, 97, 26, '2017-10-27'),
(149, 97, 26, '2017-10-28'),
(150, 97, 26, '2017-10-29'),
(151, 97, 26, '2017-10-30'),
(152, 97, 26, '2017-10-31');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_events`
--

CREATE TABLE `zselex_shop_events` (
  `shop_event_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `shop_event_name` varchar(255) DEFAULT NULL,
  `event_urltitle` varchar(255) NOT NULL,
  `shop_event_shortdescription` longtext,
  `shop_event_description` longtext,
  `shop_event_keywords` longtext,
  `news_article_id` int(11) DEFAULT NULL,
  `shop_event_startdate` date DEFAULT NULL,
  `shop_event_starthour` varchar(255) DEFAULT NULL,
  `shop_event_startminute` varchar(255) DEFAULT NULL,
  `shop_event_enddate` date DEFAULT NULL,
  `shop_event_endhour` varchar(255) DEFAULT NULL,
  `shop_event_endminute` varchar(255) DEFAULT NULL,
  `activation_date` date DEFAULT NULL,
  `event_image` varchar(255) DEFAULT NULL,
  `image_height` varchar(255) DEFAULT NULL,
  `image_width` varchar(255) DEFAULT NULL,
  `event_doc` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `showfrom` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `contact_name` varchar(250) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `shop_event_venue` longtext,
  `exclusive` tinyint(1) DEFAULT NULL,
  `event_link` varchar(255) DEFAULT NULL,
  `open_new` tinyint(1) NOT NULL,
  `call_link_directly` smallint(6) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_events`
--

INSERT INTO `zselex_shop_events` (`shop_event_id`, `shop_id`, `shop_event_name`, `event_urltitle`, `shop_event_shortdescription`, `shop_event_description`, `shop_event_keywords`, `news_article_id`, `shop_event_startdate`, `shop_event_starthour`, `shop_event_startminute`, `shop_event_enddate`, `shop_event_endhour`, `shop_event_endminute`, `activation_date`, `event_image`, `image_height`, `image_width`, `event_doc`, `product_id`, `showfrom`, `price`, `contact_name`, `email`, `phone`, `shop_event_venue`, `exclusive`, `event_link`, `open_new`, `call_link_directly`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(6, 18, 'sample event', 'sample-event', 'event desc', 'event details', 'event , sharaz , r2', 6, '2013-02-19', '4', '35', '2013-04-05', '16', '35', '0000-00-00', '', '', '', '1371644767_doc.pdf', 0, 'doc', '0.0000', '', '', '0', '', 0, NULL, 0, 0, 1, '2013-02-19 18:00:38', 3, '2013-06-19 14:26:07', 3),
(92, 14, 'The Rock', '', '', '', '', 0, '2016-03-23', '', '', '2019-03-30', '', '', '2016-03-23', '', '', '', '', 0, '', '0', NULL, '', '', '', 0, '', 0, 0, 1, '2016-03-23 18:49:59', 3, '2016-03-23 18:49:59', 3),
(19, 51, 'Fest', 'fest', 'Fest', 'Fest', '', 0, '2013-10-31', '18', '0', '2013-11-01', '13', '0', '0000-00-00', '', '', '', '', 0, 'product', '200.0000', '', 'kgp@creativeunited.dk', '86760010', '', 0, NULL, 0, 0, 1, '2013-10-29 20:10:26', 68, '2013-10-29 20:10:26', 68),
(81, 61, 'CPRC', 'cprc', '', '', '', NULL, '2016-09-17', '', NULL, '2016-09-30', '', NULL, '0000-00-00', '', '', '', 'CPRC-1432846322.pdf', 0, 'doc', '0', '', '', '0', '', 0, '', 0, 0, 1, '2015-05-28 22:52:05', 3, '2015-05-28 22:52:05', 3),
(69, 57, 'vacancies banner 940 x 342 ver3', 'vacancies-banner-940-x-342-ver3', '', '', '', 0, '2014-06-11', '', '', '2014-12-31', '', '', '0000-00-00', 'vacanciesbanner940x342ver3.jpg', '342', '940', '', 0, 'image', '0.0000', '', '', '0', 'krishna reddy layout, domlur\r\nbangalore, karnataka 560071\r\n', 1, NULL, 0, 0, 1, '2014-06-11 16:24:53', 3, '2014-06-11 16:25:07', 3),
(97, 26, 'story_83_8c7XnDJwMRK7b4rMased_800X800', 'story-83-8c7xndjwmrk7b4rmased-800x800', '', '', '', NULL, '2017-09-30', '', NULL, '2017-10-31', '', NULL, '0000-00-00', 'Food_Money_bank_statement_c917e2ab9ec950488460252758cb9d1f.jpg', '575', '1024', '', 0, 'image', '0', '', 'sharazkhanz@gmail.com', '+91-7025760973', 'krishna reddy layout ,\r\n domlur , bangalore-560071', 0, '', 0, 0, 1, '2016-12-22 20:39:51', 3, '2016-12-22 20:39:51', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_gallery`
--

CREATE TABLE `zselex_shop_gallery` (
  `gallery_id` int(11) NOT NULL,
  `image_name` varchar(50) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `image_description` text NOT NULL,
  `keywords` text NOT NULL,
  `defaultImg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_gallery`
--

INSERT INTO `zselex_shop_gallery` (`gallery_id`, `image_name`, `shop_id`, `user_id`, `image_description`, `keywords`, `defaultImg`) VALUES
(1, '1351147004_img2.jpg', 23, 3, 'test...', '', 1),
(2, '1348664042_ContRightImg.jpg', 25, 3, 'sadasds', '', 1),
(4, '1359473857_Chrysanthemum.jpg', 14, 3, 'gfdsfg', 'dsgfsfdg', 1),
(5, '1349799268_ContRightImg.jpg', 14, 3, '', '', 0),
(6, '1351009538_shop_newyork_pic.jpg', 18, 20, 'sdfdsfdsfsfsd', '', 0),
(7, '1360688380_Penguins.jpg', 18, 20, 'test....\r\n', '', 1),
(13, '1359473838_Koala.jpg', 14, 3, 'dfg', 'dfgdsfg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_news`
--

CREATE TABLE `zselex_shop_news` (
  `shop_news_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `cr_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_news`
--

INSERT INTO `zselex_shop_news` (`shop_news_id`, `shop_id`, `news_id`, `cr_uid`) VALUES
(1, 26, 5, 5),
(2, 18, 6, 3),
(3, 17, 7, 3),
(4, 16, 8, 3),
(5, 25, 9, 3),
(6, 25, 10, 5),
(7, 15, 11, 3),
(8, 15, 12, 3),
(9, 15, 13, 3),
(10, 18, 14, 5),
(11, 18, 15, 3),
(12, 15, 16, 5),
(13, 17, 17, 5),
(14, 26, 18, 5),
(15, 15, 19, 5),
(16, 16, 20, 3),
(17, 15, 21, 5),
(18, 15, 22, 3),
(19, 15, 23, 3),
(20, 23, 24, 5),
(21, 23, 25, 5),
(22, 23, 26, 3),
(23, 14, 28, 3),
(24, 14, 29, 3),
(25, 32, 30, 3),
(26, 14, 31, 3),
(27, 14, 32, 3),
(28, 37, 33, 2),
(29, 14, 34, 3),
(30, 38, 35, 55);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_owners`
--

CREATE TABLE `zselex_shop_owners` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `main` smallint(6) NOT NULL,
  `co_owner` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_owners`
--

INSERT INTO `zselex_shop_owners` (`id`, `user_id`, `shop_id`, `main`, `co_owner`) VALUES
(36, 56, 14, 0, 0),
(37, 22, 57, 0, 0),
(39, 21, 60, 0, 0),
(40, 3, 61, 0, 0),
(42, 99, 63, 0, 0),
(46, 3, 26, 1, 0),
(47, 24, 198, 1, 0),
(48, 125, 26, 0, 1),
(49, 136, 199, 0, 0),
(50, 137, 200, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_owners_theme`
--

CREATE TABLE `zselex_shop_owners_theme` (
  `id` int(11) NOT NULL,
  `theme_id` int(11) NOT NULL,
  `theme_name` varchar(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_owners_theme`
--

INSERT INTO `zselex_shop_owners_theme` (`id`, `theme_id`, `theme_name`, `user_id`, `shop_id`) VALUES
(5, 4, 'RSS', 22, 0),
(6, 3, 'Printer', 24, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_pdf`
--

CREATE TABLE `zselex_shop_pdf` (
  `pdf_id` int(11) NOT NULL,
  `pdf_name` varchar(100) NOT NULL,
  `pdf_image` varchar(100) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pdf_description` text NOT NULL,
  `keywords` text NOT NULL,
  `defaultImg` varchar(100) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_ratings`
--

CREATE TABLE `zselex_shop_ratings` (
  `rating_id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `rating` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `dateposted` longtext,
  `timestamp` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_ratings`
--

INSERT INTO `zselex_shop_ratings` (`rating_id`, `shop_id`, `rating`, `user_id`, `dateposted`, `timestamp`) VALUES
(1, 26, 5, 3, 'Thursday, August 25, 2016 at 10:02:27 PM', 1472155347),
(2, 37, 3, 3, '0000-00-00', 1374236271),
(3, 37, 5, 21, '0000-00-00', 1374486847),
(4, 26, 2, 24, 'Saturday, July 2, 2016 at 07:29:01 PM', 1467480541),
(5, 18, 2, 20, '0000-00-00', 1374484153),
(6, 33, 3, 24, '0000-00-00', 1375991055),
(7, 38, 5, 55, '0000-00-00', 1376927479),
(8, 40, 2, 55, '0000-00-00', 1377599673),
(9, 38, 5, 3, '0000-00-00', 1397480135),
(10, 17, 1, 2, '0000-00-00', 1378377819),
(11, 46, 3, 61, '0000-00-00', 1379357823),
(12, 41, 3, 59, '0000-00-00', 1379403141),
(13, 42, 5, 55, '0000-00-00', 1379922028),
(14, 41, 5, 2, '0000-00-00', 1379922086),
(15, 41, 5, 55, '0000-00-00', 1379922105),
(16, 41, 5, 3, '0000-00-00', 1380026822),
(17, 40, 5, 3, '0000-00-00', 1383728344),
(18, 39, 3, 3, '0000-00-00', 1380217132),
(19, 42, 5, 3, '0000-00-00', 1380532115),
(20, 46, 5, 3, '0000-00-00', 1380900743),
(21, 47, 4, 3, '0000-00-00', 1381770562),
(22, 38, 5, 68, '0000-00-00', 1396339031),
(23, 57, 5, 3, '0000-00-00', 1408374863),
(24, 198, 3, 0, 'Friday, July 1, 2016 at 10:40:09 PM', 1467405609),
(25, 61, 5, 0, 'Friday, July 1, 2016 at 11:06:08 PM', 1467407168);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_settings`
--

CREATE TABLE `zselex_shop_settings` (
  `idSettings` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `defaultImgFrm` varchar(50) NOT NULL,
  `main` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_settings`
--

INSERT INTO `zselex_shop_settings` (`idSettings`, `shop_id`, `defaultImgFrm`, `main`) VALUES
(1, 32, 'fromshop', 0),
(2, 33, 'fromshop', 0),
(3, 34, 'fromshop', 0),
(4, 35, 'fromshop', 0),
(5, 36, 'fromshop', 0),
(6, 37, 'fromshop', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_to_branch`
--

CREATE TABLE `zselex_shop_to_branch` (
  `shop_id` bigint(20) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_to_category`
--

CREATE TABLE `zselex_shop_to_category` (
  `shop_id` bigint(20) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zselex_shop_types`
--

CREATE TABLE `zselex_shop_types` (
  `shoptype_id` int(11) NOT NULL,
  `shoptype` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(4) NOT NULL,
  `obj_status` varchar(10) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_shop_types`
--

INSERT INTO `zselex_shop_types` (`shoptype_id`, `shoptype`, `description`, `status`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'zSHOP', '0', 0, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(2, 'iSHOP', '0', 0, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0),
(3, 'xSHOP', '0', 0, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_social_links`
--

CREATE TABLE `zselex_social_links` (
  `socl_link_id` int(11) NOT NULL,
  `socl_link_name` varchar(255) NOT NULL,
  `socl_image` longtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_social_links`
--

INSERT INTO `zselex_social_links` (`socl_link_id`, `socl_link_name`, `socl_image`, `status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'FaceBook', 'facebook.jpg', 1, '2015-06-17 21:17:49', 3, '2015-06-17 21:17:49', 3),
(2, 'LinkedIn', 'linkedin.jpg', 1, '2015-06-17 21:18:06', 3, '2015-06-17 21:18:06', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_social_links_shop`
--

CREATE TABLE `zselex_social_links_shop` (
  `id` int(11) NOT NULL,
  `socl_link_id` int(11) DEFAULT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `link_url` longtext NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_social_links_shop`
--

INSERT INTO `zselex_social_links_shop` (`id`, `socl_link_id`, `shop_id`, `link_url`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 1, 26, 'http://www.test.com/ll', '2015-06-17 21:31:31', 3, '2015-06-17 21:31:31', 3),
(2, 2, 26, 'http://www.test.com', '2015-06-17 21:31:31', 3, '2015-06-17 21:31:31', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_social_links_shop_settings`
--

CREATE TABLE `zselex_social_links_shop_settings` (
  `id` int(11) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `icon_size` varchar(100) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_social_links_shop_settings`
--

INSERT INTO `zselex_social_links_shop_settings` (`id`, `shop_id`, `icon_size`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 26, 'small', '2015-06-17 21:31:31', 3, '2015-06-17 21:31:31', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_themes`
--

CREATE TABLE `zselex_themes` (
  `zt_id` int(11) NOT NULL,
  `theme_id` int(11) NOT NULL,
  `theme_name` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_themes`
--

INSERT INTO `zselex_themes` (`zt_id`, `theme_id`, `theme_name`) VALUES
(41, 25, 'ZLGBlue'),
(42, 23, 'ZOrangeJuice'),
(43, 22, 'ZWine'),
(44, 21, 'ZSunrise'),
(45, 20, 'ZNaturalGloom'),
(46, 19, 'ZFruitopia'),
(47, 18, 'ZGreenway'),
(48, 17, 'ZLightBiz'),
(49, 15, 'ZLimelight'),
(50, 10, 'ZSeaBreeze'),
(51, 9, 'ZAndreas08'),
(55, 28, 'CityPilot'),
(57, 31, 'CityPilotSkin3'),
(58, 30, 'CityPilotSkin2'),
(59, 29, 'CityPilotSkin1'),
(60, 33, 'CityPilotResponsive'),
(63, 41, 'CityPilotShop');

-- --------------------------------------------------------

--
-- Table structure for table `zselex_type`
--

CREATE TABLE `zselex_type` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `status` int(11) NOT NULL,
  `obj_status` varchar(25) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_type`
--

INSERT INTO `zselex_type` (`type_id`, `type_name`, `description`, `status`, `obj_status`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 'CITY', 'CITY', 1, 'A', '2012-02-24 13:58:49', 2, '2012-02-28 09:23:34', 2),
(2, 'SHOP', 'SHOP', 1, 'A', '2012-02-24 13:59:05', 2, '2012-02-24 13:59:05', 2),
(3, 'AD', 'AD', 1, 'A', '2012-02-24 13:59:18', 2, '2012-02-24 13:59:18', 2),
(4, 'PLUGIN', 'PLUGIN', 1, 'A', '2012-02-24 13:59:31', 2, '2012-02-24 13:59:31', 2),
(10, 'COUNTRY', 'dsfsdfsdf', 1, 'A', '2012-03-07 08:14:07', 2, '2012-03-07 08:14:07', 2),
(11, 'BRANCH', '', 1, 'A', '2012-03-07 08:14:23', 2, '2012-03-07 08:14:23', 2),
(12, 'REGION', '', 1, 'A', '2012-03-07 08:15:44', 2, '2012-03-07 08:15:44', 2);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_urls`
--

CREATE TABLE `zselex_urls` (
  `url_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `type` varchar(25) NOT NULL,
  `url` varchar(200) NOT NULL,
  `shop_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_urls`
--

INSERT INTO `zselex_urls` (`url_id`, `type_id`, `type`, `url`, `shop_id`) VALUES
(1, 334, 'product', 'jk', 26),
(2, 334, 'product', 'animation-image', 26),
(3, 26, 'shop', 'newishop', 0),
(4, 76, 'event', 'vacancies-banner-940-x-342-ver31', 26),
(5, 76, 'event', 'vacancies-banner', 26),
(6, 26, 'shop', 'newishopz', 0),
(7, 125, 'shop', 'løve-apoteket', 0),
(8, 26, 'shop', 'newishop89', 0),
(9, 125, 'shop', 'løveapoteket', 0),
(10, 358, 'product', 'lumia-720', 26),
(11, 358, 'product', 'nokia-lumia-720', 26),
(12, 358, 'product', 'nokia-lumia-720-phone', 26),
(13, 358, 'product', 'nokia-lumia', 26),
(14, 358, 'product', 'nokia-lumia-721', 26),
(15, 358, 'product', 'nokia-lumia-722', 26),
(16, 26, 'shop', 'indianshop', 0),
(17, 358, 'product', 'nokia-lumia-724', 26),
(18, 367, 'product', 'preview-medium', 26),
(19, 159, 'product', 'img-20140729-wa0009', 14),
(20, 88, 'event', '', 26),
(21, 5, 'event', 'event-with-doc', 14),
(22, 4, 'event', 'event-with-image', 14),
(23, 90, 'event', 'activestar', 26),
(24, 78, 'event', 'meal2012-940x340', 26),
(25, 370, 'product', 'social-icons', 61),
(26, 369, 'product', 'vadakan', 61),
(27, 357, 'product', 'test007', 26),
(28, 93, 'event', 'helloo', 26),
(29, 368, 'product', 'xevent-klausservants-17e06999710685bf523c904bde57ed3d', 26),
(30, 81, 'event', 'cprc', 61),
(31, 95, 'event', 'pdf-sample', 26),
(32, 96, 'event', 'story-77-w69lzsmhbeottnzdetsw-800x800', 26),
(33, 97, 'event', 'story-83-8c7xndjwmrk7b4rmased-800x800', 26);

-- --------------------------------------------------------

--
-- Table structure for table `zselex_zenshop`
--

CREATE TABLE `zselex_zenshop` (
  `zen_id` int(11) NOT NULL,
  `minishop_id` int(11) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `domain` varchar(100) NOT NULL,
  `hostname` varchar(100) NOT NULL,
  `dbname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `table_prefix` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zselex_zenshop`
--

INSERT INTO `zselex_zenshop` (`zen_id`, `minishop_id`, `shop_id`, `domain`, `hostname`, `dbname`, `username`, `password`, `table_prefix`) VALUES
(2, 0, 14, 'tes', '', '', '', '', ''),
(3, 0, 23, 'demo.keeprunning.dk', 'demo.keeprunning.dk', 'c6demokeep', 'c6demokeep', 'th140651', 'zen_');

-- --------------------------------------------------------

--
-- Table structure for table `zseleximport`
--

CREATE TABLE `zseleximport` (
  `ID` int(11) NOT NULL,
  `Butik` varchar(500) NOT NULL,
  `Kontakt` varchar(25) NOT NULL,
  `Telefon` varchar(25) NOT NULL,
  `Mobil` varchar(25) NOT NULL,
  `Adresse` text NOT NULL,
  `Email` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zseleximport`
--

INSERT INTO `zseleximport` (`ID`, `Butik`, `Kontakt`, `Telefon`, `Mobil`, `Adresse`, `Email`) VALUES
(1001, '6. juli garden', 'Sonja', '40172207', '', 'Mønstedsvænget 11\r\n7000 Fredericia', 'sonja@hojvangsalle10.dk'),
(1002, 'Amoc', 'Lone Ahrentoft', '75926033', '', 'Vendersgade 21\r\n7000 Fredericia', 'id2hmail@gmail.com'),
(1003, 'Anne Vibeke Rossing', 'Anne Vibeke Rossing', '75921658', '', 'Jyllandsgade 43\r\n7000 Fredericia', 'a.v.rossing@gmail.com'),
(1004, 'Arbejdernes Landsbank', 'Tommy Stricker', '38483052', '', 'Danmarksgade 6\r\n7000 Fredericia', 'TOMMY.STRICKER@AL-BANK.DK'),
(1005, 'Axeltorvs Apotek', 'Birgitte Rasmussen', '75923800', '', 'Jyllandsgade 24\r\n7000 Fredericia', 'axeltorv@apoteket.dk'),
(1006, 'B H Magasinet', 'Kirsten Heisel', '75923532', '', 'Prinsessegade 43\r\n7000 Fredericia', 'bhmagasinet@mail.tele.dk'),
(1007, 'Bianco', 'Keld Høll', '75914555', ' ', 'Gothersgade 1\r\n7000 Fredericia', '003@shop.bianco.com'),
(1008, 'Billunds Boghandel', 'Else Billund', '75920162', '', 'Gothersgade 24\r\n7000 Fredericia', 'billunds@bogpost.dk'),
(1009, 'Bison Lædervarer ApS', 'Arne Andersen', '75920376', '', 'Gothersgade 15\r\n7000 Fredericia', 'bison.laedervarer@firma.tele.dk'),
(1010, 'Bjerggeden og Byrotten', 'Arne Poulsen eller Lau Bi', '75932447', ' ', 'Vendersgade 1\r\n7000 Fredericia', 'arne@bjerggedenogbyrotten.dk'),
(1011, 'Booking Huset', 'Jan Midjord', '75910086', '', 'Nørrebrogade 7\r\n7000 Fredericia', 'jm@bookinghuset.dk'),
(1012, 'BT Centralen', 'Bent Nielsen', '75920586', ' ', 'Gothersgade 4\r\n7000 Fredericia', 'kob_salg@hotmail.com'),
(1013, 'BT Gulve og Gardiner A/S', 'Michael Kristensen', '20208255', '', 'Søndermarksvej 210\r\n7000 Fredericia', 'fredericia@btgulve.dk'),
(1014, 'Budstikken', 'Helle Buhl Uth', '76200400', '', 'Riddergade 17\r\n7000 Fredericia', 'charlotte.pour@lokalavisen.dk'),
(1015, 'Café den 7 himmel', 'Kristian ', '75910405', ' ', 'Gothersgade 7\r\n7000 Fredericia', 'visesi@cafeden7himmel.dk'),
(1016, 'Café nr. 47', '', '', '', 'Jyllandsgade 47\r\n7000 Fredericia', 'cafe.47@gmail.com'),
(1017, 'Rustik Cafe & Restaurant', 'Rene', '20721351', '', 'Jyllandsgade 59\r\n7000 Fredericia', 'bogholderi@caferustik.dk'),
(1018, 'Chilli', 'Betina Meilandt', '75928481', '', 'Jyllandsgade  39\r\n7000 Fredericia', 'batinadk@yahoo.dk'),
(1019, 'Cykelservice', 'Kai Jensen', '75921409', '', 'Venusvej 4\r\n7000 Fredericia', 'cykelservice@mail.tele.dk'),
(1020, 'DanmarkC TV', 'Theis Søndergaard', '42742740', '', 'Finsensvej 18\r\n7000 Fredericia', 'tv@danmarkc.tv'),
(1021, 'Davidsen Tømmerhandel', 'Morten Laursen', '75943611', '', 'Røde Banke 1\r\n7000 Fredericia', 'mail@davidsen.as'),
(1022, 'Deluxe', 'Betina Meilandt', '75928406', '', 'Jyllandsgade 45\r\n7000 Fredericia', 'batinadk@yahoo.dk'),
(1023, 'Danske bank', 'Søren ', '45125400', '', 'Gothersgade 18\r\n7000 Fredericia', 'srea@danskebank.dk'),
(1024, 'Den Engelske', 'Henrik', '75932636', '', 'Gothersgade 39\r\n7000 Fredericia', 'info@denengelske.dk'),
(1025, 'Det Bruunske Pakhus', 'Helle Lilletorp', '72106710', '', 'Kirkestræde 3\r\n7000 Fredericia', 'kontor@bruunskepakhus.dk'),
(1026, 'Ecco', 'Vathana', '75940152', ' ', 'Danmarksgade 22\r\n7000 Fredericia', 'eccofredericia@holstsko.dk'),
(1027, 'Elbo Bladet', 'Per Kristensen', '75921244', '', 'Nørrebrogade 5\r\n7000 Fredericia', 'pk@elbobladet.dk'),
(1028, 'Event C', 'Ulrich Nicolaisen', '70225085', '', 'Lyøvænget 7\r\n7000 Fredericia', 'ulrich@momenti.dk'),
(1029, 'Fakta', ' ', '76414300', ' ', 'Vendersgade 1\r\n7000 Fredericia', ' '),
(1030, 'Festmesteren', 'Birger Dyrby', '75924411', '', 'Calvinsvej 17\r\n7000 Fredericia', 'festmesteren@festmesteren.dk'),
(1031, 'Flair', 'Jette Lund', '75920202', ' ', 'Gothersgade 21\r\n7000 Fredericia', 'flair@lund.mail.dk'),
(1032, 'Flashlight gruppen', 'Jesper Brock', '75920132', '', 'Titanvænget 10\r\n7000 Fredericia', 'admin@flashlight-gruppen.dk'),
(1033, 'Fleur', 'Kirsten Heisel', '75923532', '', 'Prinsessegade 43\r\n7000 Fredericia', 'bhmagasinet@mail.tele.dk'),
(1034, 'Flügger Farve', 'Mogens Christiansen', '75934866', '', 'Norgesgade 14\r\n7000 Fredericia', 'norgesgade@fluggerfarver.dk'),
(1035, 'Fona', 'Kenneth Rasmussen', '75922955', ' ', 'Gothersgade 12\r\n7000 Fredericia', 'go168@fona.dk'),
(1036, 'Fotograf Helle S. Andersen', 'Helle S. Andersen', '75926888', '', 'Vesterbrogade 21\r\n7000 Fredericia', 'post@hellesandersen.dk'),
(1037, 'Fredericia Bibliotek', 'Jytte Bræmer', '72106800', ' ', 'Prinsessegade  27\r\n7000 Fredericia', 'jytte.bramer@fredericia.dk'),
(1038, 'Fredericia Dagblad', '', '75922600', '', 'Nørrebrogade 7\r\n7000 Fredericia', 'fd@fredericiadagblad.dk'),
(1039, 'Fredericia Skiltefabrik', 'Michael Bruun', '75912800', '', 'Strevelinsvej 20\r\n7000 Fredericia', 'post@fredericia-skilte.dk'),
(1040, 'Fredericia Teater', 'Søren Davidsen', '75922500', '', 'Prinsessegade 29\r\n7000 Fredericia', 'Soren@fredericiateater.dk'),
(1041, 'Fredericia Vinhandel', 'Kirsten Fahlen', '75922767', '', 'Danmarksgade 49\r\n7000 Fredericia', 'fredericiavinhandel@hotmail.com'),
(1042, 'Føtex city', '', '76222000', '', 'Prinsessegade 49\r\n7000 Fredericia', 'plt.fredericia@foetex.dk'),
(1043, 'Føtex Vest', 'Kristian Henriksen', '79234000', '', 'Venusvej 8\r\n7000 Fredericia', 'hm.venusvej@foetex.dk'),
(1044, 'Geist & Gnist', 'Jesper Gaarsvig', '75931955', '20636890', 'Vendersgade 22\r\n7000 Fredericia', 'hello@geistgnist.dk'),
(1045, 'Guldbageren', 'Carina Bergstedt', '', '', 'Jyllandsgade 10\r\n7000 Fredericia', 'kbceh@post.tele.dk'),
(1046, 'Guldperlen', 'Birte Larsen', '75921202', ' ', 'Gothersgade 9\r\n7000 Fredericia', 'guldperlen@gmail.com'),
(1047, 'Handelsbanken', '', '44564950', '', 'Prinsessegade 82\r\n7000 Fredericia', 'fredericia@handelsbanken.dk'),
(1048, 'Hauge', 'Kurt Hauge', '75932710', '', 'Danmarksgade 12\r\n7000 Fredericia', 'hauge@haugemiljoe.dk'),
(1049, 'Havanna sko', 'Vibe Møller', '75928753', ' ', 'Gothersgade 4\r\n7000 Fredericia', 'fredericia@havanna-shoes.dk'),
(1050, 'Helsekosten', 'Anni Liborius', '75934311', '', 'Prinsessegade 37\r\n7000 Fredericia', 'helsekosten@mail.tele.dk'),
(1051, 'Hennes & Mauritz', 'Anja Lindhardt', '75935156', '', 'Jyllandsgade 22\r\n7000 Fredericia', 'anjalindhardt1@gmail.com'),
(1052, 'High end sport', 'Torben Hansen', '75920345', '', 'Prinsessegade 18\r\n7000 Fredericia', 'torben@hesport.dk'),
(1053, 'HK Midt', 'Lone Tomhav', '70114545', ' ', 'Vesterballevej 3a\r\n7000 Fredericia', 'midt@hk.dk'),
(1054, 'Holst sko', 'Lis Hansen', '32219259', '', 'Danmarksgade 22\r\n7000 Fredericia', 'fredericia@holstsko.dk'),
(1055, 'Home Fredericia', 'Sandra Nielsen', '61304520', '', 'Købmagergade 14\r\n7000 Fredericia', 'slns@home.dk'),
(1056, 'Imerco', 'Martin Brobøl', '26331613', '', 'Danmarksgade 7\r\n7000 Fredericia', 'bc36090@imerco.dk'),
(1057, 'Jyske Bank', 'Torben Hansen', '89898560', '', 'Danmarksstræde 22\r\n7000 Fredericia', 'torben.hansen@jyskebank.dk'),
(1058, 'Klokken', 'Anette Lund Jensen', '75920375', '31701463', 'Jyllandsgade 24 21\r\n7000 Fredericia', 'klokken@nypost.dk'),
(1059, 'Kop og Kande', 'Lise og Helle', '75933939', ' ', 'Vendersgade 1a\r\n7000 Fredericia', 'lim@kop-kande.dk'),
(1060, 'LB Dans', 'Rikke Ommestrup Bekker', '75915096', '40721096', 'Hans Egedes vej 6\r\n7000 Fredericia', 'lb-dans@youmail.dk'),
(1061, 'Le noir', 'Helle Østergaard', '75560472', '24976738', 'Vendersgade 19\r\n7000 Fredericia', 'helle@l-oestergaard.dk'),
(1062, 'Lucullus Smørebrød', 'Kirsten Nylander', '75922564', '', 'Luthersvej 14\r\n7000 Fredericia', 'lucullus-fredericia@mail.dk'),
(1063, 'Løve Apoteket', 'Lene Landsgrav', '75923544', '', 'Danmarksgade 19\r\n7000 Fredericia', '015fl@apoteket.dk'),
(1064, 'Matas Gothersgade', 'Jette Iversen', '75920066', '', 'Gothersgade 20b\r\n7000 Fredericia', 'post@11487.matas.dk'),
(1065, 'Matas Vendersgade', 'Maria', '75920180', '', 'Vendersgade 25\r\n7000 Fredericia', 'post@11517.matas.dk'),
(1066, 'Miami', 'Ole Mortensen', '75921095', ' ', 'Gothersgade 2b\r\n7000 Fredericia', 'ole@miami.dk'),
(1067, 'Middelfart Sparekasse', 'Palle Mogensen', '75930800', '', 'Prinsessegade 95\r\n7000 Fredericia', 'ht@midspar.dk'),
(1068, 'Mr. Højer', 'Preben Højer', '75920354', '', 'Danmarksgade 20\r\n7000 Fredericia', 'mrhoejer@hotmail.com'),
(1069, 'Nordea', 'Lars Bukdal', '70333333', ' ', 'Gothersgade 5\r\n7000 Fredericia', 'lars.bukdal@nordea.dk'),
(1070, 'Nü by Staff', 'Erling Nørgaard', '75945050', '', 'Gothersgade 22\r\n7000 Fredericia', 'info@uso-fredericia.dk'),
(1071, 'Nykredit', 'Lilian Bech Ladefoged', '44556720', ' ', 'Gothersgade 17\r\n7000 Fredericia', 'servicecenter@nykredit.dk'),
(1072, 'Optik Hallmann', ' ', '75925950', ' ', 'Vendersgade 1a\r\n7000 Fredericia', 'fredericia@optik-halmann.dk'),
(1073, 'Ostejyden', 'Bente Mechlenborg', '75920731', '', 'Jyllandsgade 39\r\n7000 Fredericia', 'bente@ostejyden.dk'),
(1074, 'Panorama', 'Lars Broen', '75910024', '', 'Prinsessegade 29\r\n7000 Fredericia', 'post@panorama-fredericia.dk'),
(1075, 'Photo care', 'Thomas', '75922454', '', 'Danmarksgade 28a\r\n7000 Fredericia', 'fredericia@photocare.dk'),
(1076, 'Pigernes Verden', 'Sanne', '75927848', '', 'Gothersgade 23\r\n7000 Fredericia', 'fredericia@pigernesverden.dk'),
(1077, 'Pro Print', 'Ole Nicolaisen', '75934950', '', 'Glarmestervej 1\r\n7000 Fredericia', 'ole@pro-print.dk'),
(1078, 'Profil Optik', 'Carina Lauritzen', '75924522', ' ', 'Gothersgade 13\r\n7000 Fredericia', 'fredericia@profiloptik.dk'),
(1079, 'Radio Fredericia', '', '76400400', '', 'Bugattivej 8\r\n7100 Vejle', 'vlr@vlr.dk'),
(1080, 'Ranch Svendsen', 'Jane Torp', '22580227', ' ', 'Gothersgade 1\r\n7000 Fredericia', 'rsfredericia@gmail.com'),
(1081, 'Restaurant Generalen', 'Michael Buch', '26160176', '', 'Prinsessegade 61\r\n7000 Fredericia', 'generalrye@gmail.com'),
(1082, 'Restaurant Oven Vande', 'Henrik Lyager', '76200226', '20106834', 'Sønder Voldgade 10\r\n7000 Fredericia', 'ovenvande@ovenvande.com'),
(1083, 'Sadolin Farvehandel', '', '75927611', '', 'Vejlevej 29\r\n7000 Fredericia', 'fredericia@sadolinfarveland.dk'),
(1084, 'Sejersen - Din tøjmand', 'Henriette Sejersen', '75921111', '', 'Vendersgade 23\r\n7000 Fredericia', 'fredericia@dintojmand.dk'),
(1085, 'Simone', 'Dagmar Egsgaard', '75920565', '', 'Jyllandsgade 41\r\n7000 Fredericia', 'simone@business.tele.dk'),
(1086, 'Skoringen', 'Jeanette Rasmussen', '62265105', '', 'Danmarksgade 17\r\n7000 Fredericia', 'fr@sander-sko.dk'),
(1087, 'Spar nord', 'Christian Jungmark', '76206400', '', 'Sjællandsgade  33\r\n7000 Fredericia', 'cjm@sparnord.dk'),
(1088, 'Nyt Syn', 'Jørgen Spetzler', '75920062', ' ', 'Gothersgade 2\r\n7000 Fredericia', 'nytsyn.fredericia@nytsyn.dk'),
(1089, 'Sport24', 'René Fly Elbæk', '30213300', '', 'Danmarksgade 9\r\n7000 Fredericia', 'rfe@sport24.dk'),
(1090, 'Sportmaster', 'Lars Landry Lynge', '75923700', ' ', 'Gothersgade 10\r\n7000 Fredericia', 'fredericia.butikschef@sportmaster.dk'),
(1091, 'Standard', 'Annette Larsen', '75920051', ' ', 'Gothersgade 2\r\n7000 Fredericia', 'annettelarsen@live.dk'),
(1092, 'Stark Fredericia', 'Jens Jørgen Jensen', '75924333', '', 'Nordre Ringvej 7\r\n7000 Fredericia', 'info.fredericia@stark.dk'),
(1093, 'Støvsugereksperten', 'Claus Lindegaard', '75933787', '', 'Danmarksstræde 1\r\n7000 Fredericia', 'salg@cleaning.dk'),
(1094, 'Superbrugsen Erritsø', 'Karl', '76203800', '', 'Erritsø Bygade 109\r\n7000 Fredericia', '03135a@superbrugsen.dk'),
(1095, 'Sydbank', 'Kirsten Povlsen', '74375930', '', 'Gothersgade 33\r\n7000 Fredericia', 'kirsten.povlsen@sydbank.dk'),
(1096, 'Synoptik', 'David Drejø Carlsen', '75931361', ' ', 'Gothersgade 11\r\n7000 Fredericia', '158@synoptik.dk'),
(1097, 'Tantes Have', 'Michael Rasmussen', '75954141', '', 'Skærbækvej 3\r\n7000 Fredericia', 'mr@tanteshave.dk'),
(1098, 'Telenor', 'Thomas Meyer', '25264061', ' ', 'Gothersgade 15\r\n7000 Fredericia', 'dsc@telenor.dk'),
(1099, 'The og ide', 'Marianne Lyngs Eghoff Reb', '75910456', '', 'Jyllandsgade 10\r\n7000 Fredericia', 'fredericia@theogide.dk'),
(1100, 'Thiele Briller', 'Steen Krogsager', '75927778', '', 'Jyllandsgade 10a\r\n7000 Fredericia', 'fredericia@thiele.dk'),
(1101, 'Tre-for', 'Claus Linnemann', '79333435', '', 'Kokbjerg 30\r\n7000 Fredericia', 'claus.linnemann@tre-for.dk'),
(1102, 'Tøjeksperten', 'Martin Bossel', '72349043', '', 'Gothersgade 25\r\n7000 Fredericia', 'fredericia@tojeksperten.dk'),
(1103, 'USO ', 'Erling Nørgaard', '75514849', '', 'Gothersgade 20b\r\n7000 Fredericia', 'info@uso-fredericia.dk'),
(1104, 'Vestbyens Herretøj', '', '75927345', '', 'Venusvej 10\r\n7000 Fredericia', 'vcht@mail.dk'),
(1105, 'Vestfyns Bank', 'Palle Dahl Sørensen', '76203950', ' ', 'Vendersgade 1a\r\n7000 Fredericia', 'pds@vb.dk '),
(1106, 'Vinoble', 'Dennis Kappel ', '76203844', '', 'Danmarksgade 28b\r\n7000 Fredericia', 'fredericia@vinoble.dk'),
(1107, 'Willox', 'Danny Pedersen', '75923550', '', 'Danmarksgade 4\r\n7000 Fredericia', 'info@willox.dk'),
(1108, 'Zederkof', 'Jan Zederkof', '89121200', '', 'Prins Christians Kvartér 28\r\n7000 Fredericia', 'info@zederkof.dk'),
(1109, 'Zizzi', 'Marianne Koed Enemark', '75923600', ' ', 'Vendersgade 1\r\n7000 Fredericia', 'marianne-e-jensen@hotmail.com'),
(1110, 'Zoffman Optik', 'Lars Zoffmann', '75913133', '', 'Gothersgade 35\r\n7000 Fredericia', 'info@zoffmann-optik.dk'),
(1111, 'Spaabæk Clinic', 'Karin Spaabæk', '24964689', '', 'Sjællandsgade 25\r\n7000 Fredericia', 'ks@spaabaekc.dk'),
(1112, 'Frk Nipz', 'finn', '75934505', '', 'Vendersgade 1a\r\n7000 Fredericia', 'frk.nipz@c.dk'),
(1113, 'Tegllund', 'Frank Schroder', '27537533', '', 'Vejlevej 52\r\n7000 Fredericia', 'ragna.mikkelsen@tegllund.dk'),
(1114, 'CompuConsult Data', 'Per Lykkegaard', '40911491', '', 'Købmagergade 20\r\n7000 Fredericia', 'mail@ccpip.dk'),
(1115, 'Coach til salg', 'Nete Sørensen', '61317777', '', 'Prinsensgade 31.1 tv\r\n7000 Fredericia', 'ns@coachtilsalg.nu'),
(1116, 'Skjold Burne', 'Henrik Eriksen', '72407000 ', '', 'Jyllandsgade 29\r\n7000 Fredericia', 'fredericia@skjold-burne.dk'),
(1117, 'Garn klip og styling', 'Camilla', '75914477', '', 'Prinsessegade 32a\r\n7000 Fredericia', 'mail@garn7000.dk'),
(1118, 'Cykelsmeden', 'Jette Lundsgaard', '21609844', '', 'Kaltoftevej 1\r\n7000 Fredericia', 'lundsgaardcykler2@live.dk'),
(1119, 'Butik Smagløs', 'Hanne Krogh', '23280333', '', 'Gothersgade 36\r\n7000 Fredericia', 'butik@smaglos.com'),
(1120, 'Lydbureauet', 'Henning Lodberg', '60180099', '', 'Højrupvej 119\r\n7000 Fredericia', 'kontakt@lydbureauet.dk'),
(1121, 'Marcus', 'Kim Duus', '75781100', '', 'Danmarksgade 10\r\n7000 Fredericia', 'fredericia@marcus.dk'),
(1122, 'Cafe Mair', 'Eva Mair', '42729493', '', 'Gothersgade 55\r\n7000 Fredericia', 'eva@mairs.dk'),
(1123, 'Hårværk', 'Nicole M Christensen', '88371135', '', 'Danmarksgade 35\r\n7000 Fredericia', 'haarvaerk@haarvaerk.dk'),
(1124, 'Botique Unique', 'Dorte Bruun', '23555185', '', 'Danmarksgade 26\r\n7000 Fredericia', 'dortebruun2@gmail.com'),
(1125, 'Calle & Co', 'Carsten', '40282738', '', 'Danmarksgade 3\r\n7000 Fredericia', 'calleogco@yahoo.dk'),
(1126, 'Dueholm Begravelsesforretning', 'Hanne', '', '', 'Danmarksgade 1\r\n7000 Fredericia', 'info@tommydueholm.dk'),
(1127, 'Frelsens Chokolade', 'Elisabeth Petersen', '75925989', '', 'Danmarksgade 24\r\n7000 Fredericia', 'frellsenfredericia@gmail.com'),
(1128, 'DE Eletronink/Skilte Værkstedet', 'Dennis Egholm', '759423010', '', 'Købmagergade 23\r\n7000 Fredericia', 'info@skilte-vaerkstedet.dk'),
(1129, 'Garnkælderen', 'Winnie Kristensen', '', '', 'Prinsessegade 56 A\r\n7000 Fredericia', 'wik@youmail.dk'),
(1130, 'Isabellas Reataurant og Steakhaouse', 'Soner Incik', '', '', 'Vendersgade 20\r\n7000 Fredericia', 'sonerincik@live.dk'),
(1131, 'fieV Photo & Design', 'Fie Vandborg', '', '', 'Thygesminde Allé 137\r\n7000 Fredericia', 'fotograf@fiev.dk'),
(1132, 'Domisil', 'Niels Henry Andersen', '', '', 'Jyllandsgade 45\r\n7000 Fredericia', 'nha@domisil.dk'),
(1133, 'House of melfar', 'Jan Sørensen', '', '', 'Danmarksgade 1\r\n7000 Fredericia', 'christiansenag@yahoo.dk'),
(1134, 'Nybolig', 'M. Nielsen', '', '', 'Danmarksgade 31\r\n7000 Fredericia', 'mn@nybolig.dk'),
(1135, 'Vinspecialisten Fredericia', 'Helle Svaneborg Pedersen', '75527744', '27899714', 'Prinsessegade 32B\r\n7000 Fredericia', 'fredericia@vinspecialisten.dk');

-- --------------------------------------------------------

--
-- Table structure for table `ztext_pages`
--

CREATE TABLE `ztext_pages` (
  `text_id` bigint(20) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `headertext` varchar(250) DEFAULT NULL,
  `urltitle` varchar(250) DEFAULT NULL,
  `bodytext` longtext,
  `active` tinyint(1) DEFAULT NULL,
  `displayonfront` tinyint(1) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `extension` varchar(250) DEFAULT NULL,
  `doc` varchar(250) DEFAULT NULL,
  `link` varchar(250) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ztext_pages`
--

INSERT INTO `ztext_pages` (`text_id`, `shop_id`, `headertext`, `urltitle`, `bodytext`, `active`, `displayonfront`, `image`, `extension`, `doc`, `link`, `sort_order`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(35, 61, 'ameena_new', 'ameena-new', NULL, 1, 0, 'ameena_new-1432846153.jpg', 'jpg', '', NULL, NULL, '2015-05-28 22:49:14', 3, '2015-05-28 22:49:14', 3),
(36, 61, 'CPRC', 'cprc2', NULL, 1, 0, 'CPRC-1432846638.jpg', 'pdf', 'CPRC-1432846638.pdf', NULL, NULL, '2015-05-28 22:49:39', 3, '2015-05-28 22:49:39', 3),
(37, 61, 'CPRC', 'cprc3', NULL, 1, 0, 'sign-1432846582.jpg', 'jpg', '', NULL, NULL, '2015-05-28 22:50:06', 3, '2015-05-28 22:50:06', 3),
(32, 26, 'CPRC', 'cprc', NULL, 1, 0, 'CPRC-1432842315.jpg', 'pdf', 'CPRC-1432842315.pdf', NULL, NULL, '2015-05-28 21:45:18', 3, '2015-05-28 21:45:18', 3),
(34, 61, 'CPRC', 'cprc1', NULL, 1, 0, 'CPRC-1432845195.jpg', 'pdf', 'CPRC-1432845195.pdf', NULL, NULL, '2015-05-28 22:33:19', 3, '2015-05-28 22:33:19', 3),
(38, 26, 'CPRC', 'cprc4', NULL, 1, 0, 'sign-1433362018.jpg', 'jpg', '', NULL, NULL, '2015-06-01 18:16:48', 3, '2015-06-01 18:16:48', 3),
(39, 26, 'Jellyfish', 'jellyfish', '<p>hii this is a baody texttt for testing</p>\r\n<p></p>', 1, 0, 'Jellyfish-1433362043.jpg', 'jpg', '', '', 0, '2015-06-03 22:07:24', 3, '2015-06-03 22:07:24', 3),
(40, 26, 'CPRC', 'cprc5', NULL, 1, 0, 'CPRC-88e351f7838b7f30fa80f7b6b6e7b7b8.jpg', 'pdf', 'CPRC-88e351f7838b7f30fa80f7b6b6e7b7b8.pdf', NULL, NULL, '2015-09-16 20:25:31', 3, '2015-09-16 20:25:31', 3),
(41, 26, 'Sommerm', 'sommerm', NULL, 1, 0, 'Sommerm-49c900ac5df7cb3ca80fa5db99865c82.jpg', 'pdf', 'Sommerm-49c900ac5df7cb3ca80fa5db99865c82.pdf', NULL, NULL, '2015-09-16 20:35:54', 3, '2015-09-16 20:35:54', 3),
(42, 26, 'ITR_Conf', 'itr-conf', '<p>Drag and Drop Page image to<br /> this box or just click anywhere inside the box</p>', 1, 0, 'ITR_Conf-fc58ace023b9ec0142ea052a001f746d.jpg', 'jpg', '', '', 0, '2015-11-25 19:48:36', 3, '2015-11-25 19:48:36', 3),
(43, 26, 'a-guide-to-the-project-management-body-of-knowledge-pmbok-guide-5th-edition', 'a-guide-to-the-project-management-body-of-knowledge-pmbok-guide-5th-edition', NULL, 1, 0, 'a-guide-to-the-project-management-body-of-knowledge-pmbok-guide-5th-edition-becd66f5dc88e8ee36a0391834ebf777.jpg', 'pdf', 'a-guide-to-the-project-management-body-of-knowledge-pmbok-guide-5th-edition-becd66f5dc88e8ee36a0391834ebf777.pdf', NULL, NULL, '2016-06-01 18:20:37', 3, '2016-06-01 18:20:37', 3);

-- --------------------------------------------------------

--
-- Table structure for table `ztext_settings`
--

CREATE TABLE `ztext_settings` (
  `id` bigint(20) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `disable_page_index` tinyint(1) DEFAULT NULL,
  `disable_frontend_image` tinyint(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ztext_settings`
--

INSERT INTO `ztext_settings` (`id`, `shop_id`, `disable_page_index`, `disable_frontend_image`) VALUES
(1, 26, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zvelo_bicycle`
--

CREATE TABLE `zvelo_bicycle` (
  `bicycle_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `nos` varchar(255) NOT NULL,
  `iconname` varchar(255) NOT NULL,
  `imagename` varchar(255) NOT NULL,
  `imagename2` varchar(250) DEFAULT NULL,
  `description` longtext NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zvelo_customer`
--

CREATE TABLE `zvelo_customer` (
  `customer_id` int(11) NOT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `address` longtext,
  `address2` longtext,
  `zipcode` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `comments` longtext,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zvelo_customer`
--

INSERT INTO `zvelo_customer` (`customer_id`, `gender`, `first_name`, `last_name`, `address`, `address2`, `zipcode`, `city`, `phone`, `email`, `comments`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(2, '', 'sharaz', 'khan', '', '', '', '', '', '', '', '2014-08-07 09:03:03', 0, '2014-08-07 09:03:03', 0),
(3, 'male', 'Jesper', 'Johannesen', 'Brennerpasset 68', '', '6000', 'Kolding', '30303030', 'kim@acta-it.dk', 'God til at cykle', '2014-08-07 09:45:24', 0, '2014-08-07 09:45:24', 0),
(4, 'female', 'shafna', '', '', '', '', '', '', '', '', '2014-08-11 09:33:50', 3, '2014-08-11 09:33:50', 3),
(5, 'male', 'Laiju', 'Cohin', '', '', '', '', '', '', '', '2014-09-19 16:55:06', 3, '2014-09-19 16:55:06', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zvelo_customer_ergonomic_value`
--

CREATE TABLE `zvelo_customer_ergonomic_value` (
  `ergonomic_value_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `bicycle_id` int(11) DEFAULT NULL,
  `value1` varchar(255) NOT NULL,
  `value2` varchar(255) NOT NULL,
  `value3` varchar(255) NOT NULL,
  `value4` varchar(255) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zvelo_customer_ergonomic_value`
--

INSERT INTO `zvelo_customer_ergonomic_value` (`ergonomic_value_id`, `customer_id`, `bicycle_id`, `value1`, `value2`, `value3`, `value4`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(1, 3, NULL, '', '', '', '', '2014-08-07 09:55:07', 0, '2014-08-07 09:55:07', 0),
(2, 2, NULL, 'test1', 'test2', 'test3', 'test4', '2014-08-07 10:00:06', 0, '2014-08-07 10:00:06', 0),
(3, 5, NULL, 'sdfg', 'dsfg', 'dsfg', 'dfgds', '2014-09-19 16:55:49', 3, '2014-09-19 16:55:49', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zvelo_customer_measurement`
--

CREATE TABLE `zvelo_customer_measurement` (
  `measurement_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `functionalheight` varchar(255) NOT NULL,
  `shoulderheight` varchar(255) NOT NULL,
  `shoulderwidth` varchar(255) NOT NULL,
  `fistheight` varchar(255) NOT NULL,
  `pelvicboneheight` varchar(255) NOT NULL,
  `weight` varchar(255) NOT NULL,
  `comments` longtext,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zvelo_customer_measurement`
--

INSERT INTO `zvelo_customer_measurement` (`measurement_id`, `customer_id`, `functionalheight`, `shoulderheight`, `shoulderwidth`, `fistheight`, `pelvicboneheight`, `weight`, `comments`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(2, 2, '5.9', '2', '3', '5', '4', '80', NULL, '2014-08-07 09:03:03', 0, '2014-08-07 09:03:03', 0),
(3, 3, '181', '150,5', '14', '84', '108,5', '76', NULL, '2014-08-07 09:45:25', 0, '2014-08-07 09:45:25', 0),
(4, 4, '', '', '', '', '', '', NULL, '2014-08-11 09:33:50', 3, '2014-08-11 09:33:50', 3),
(5, 5, '', '', '', '', '', '', NULL, '2014-09-19 16:55:06', 3, '2014-09-19 16:55:06', 3);

-- --------------------------------------------------------

--
-- Table structure for table `zvelo_customer_wish`
--

CREATE TABLE `zvelo_customer_wish` (
  `wish_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `bicycle_id` int(11) DEFAULT NULL,
  `seatposition` int(11) DEFAULT NULL,
  `usages` varchar(255) DEFAULT NULL,
  `ageclass` varchar(255) DEFAULT NULL,
  `kmmonthly` varchar(255) DEFAULT NULL,
  `framematerial` varchar(255) DEFAULT NULL,
  `frametype` varchar(255) DEFAULT NULL,
  `suspension` varchar(255) DEFAULT NULL,
  `gears` varchar(255) DEFAULT NULL,
  `brakes` varchar(255) DEFAULT NULL,
  `accessories` varchar(255) DEFAULT NULL,
  `comments` longtext,
  `cr_date` datetime NOT NULL,
  `cr_uid` int(11) NOT NULL,
  `lu_date` datetime NOT NULL,
  `lu_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zvelo_customer_wish`
--

INSERT INTO `zvelo_customer_wish` (`wish_id`, `customer_id`, `bicycle_id`, `seatposition`, `usages`, `ageclass`, `kmmonthly`, `framematerial`, `frametype`, `suspension`, `gears`, `brakes`, `accessories`, `comments`, `cr_date`, `cr_uid`, `lu_date`, `lu_uid`) VALUES
(2, 3, NULL, 2, 'a:2:{i:0;s:9:\"Commuting\";i:1;s:10:\"Recreation\";}', '31 - 45', '< 201 - 500', 'a:3:{i:0;s:5:\"Steel\";i:1;s:5:\"Alloy\";i:2;s:9:\"Composite\";}', 'a:1:{i:0;s:7:\"Diamond\";}', 'a:3:{i:0;s:5:\"Front\";i:1;s:5:\"Frame\";i:2;s:7:\"Seatpos\";}', 'a:2:{i:0;s:10:\"Derailleur\";i:1;s:11:\"Internalhub\";}', 'a:2:{i:0;s:7:\"V-brake\";i:1;s:9:\"Discbrake\";}', 'a:4:{i:0;s:8:\"Clothing\";i:1;s:6:\"Helmet\";i:2;s:4:\"Pump\";i:3;s:5:\"Shoes\";}', NULL, '2014-08-07 09:52:22', 0, '2014-08-07 09:52:22', 0),
(3, 2, NULL, 2, 'a:3:{i:0;s:9:\"Commuting\";i:1;s:10:\"Recreation\";i:2;s:7:\"Fitness\";}', '31 - 45', '< 201 - 500', 'a:3:{i:0;s:5:\"Steel\";i:1;s:5:\"Alloy\";i:2;s:9:\"Composite\";}', 'a:2:{i:0;s:5:\"Women\";i:1;s:6:\"Unisex\";}', 'a:3:{i:0;s:5:\"Front\";i:1;s:5:\"Frame\";i:2;s:7:\"Seatpos\";}', 'a:2:{i:0;s:10:\"Derailleur\";i:1;s:11:\"Internalhub\";}', 'a:3:{i:0;s:7:\"V-brake\";i:1;s:9:\"Discbrake\";i:2;s:9:\"Hydraulic\";}', 'a:4:{i:0;s:8:\"Clothing\";i:1;s:6:\"Helmet\";i:2;s:4:\"Pump\";i:3;s:5:\"Shoes\";}', NULL, '2014-08-07 09:54:46', 0, '2014-08-07 09:54:46', 0),
(4, 5, NULL, 3, 'N;', NULL, NULL, 'N;', 'N;', 'N;', 'N;', 'a:4:{i:0;s:7:\"V-brake\";i:1;s:9:\"Discbrake\";i:2;s:9:\"Hydraulic\";i:3;s:5:\"Other\";}', 'N;', NULL, '2014-09-19 16:55:34', 3, '2014-09-19 16:55:34', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_category`
--
ALTER TABLE `admin_category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `admin_module`
--
ALTER TABLE `admin_module`
  ADD PRIMARY KEY (`amid`),
  ADD KEY `mid_cid` (`mid`,`cid`);

--
-- Indexes for table `block_placements`
--
ALTER TABLE `block_placements`
  ADD KEY `bid_pid_idx` (`bid`,`pid`);

--
-- Indexes for table `block_positions`
--
ALTER TABLE `block_positions`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `name_idx` (`name`);

--
-- Indexes for table `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `active_idx` (`active`);

--
-- Indexes for table `categories_category`
--
ALTER TABLE `categories_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_categories_parent` (`parent_id`),
  ADD KEY `idx_categories_is_leaf` (`is_leaf`),
  ADD KEY `idx_categories_name` (`name`),
  ADD KEY `idx_categories_ipath` (`ipath`,`is_leaf`,`status`),
  ADD KEY `idx_categories_status` (`status`),
  ADD KEY `idx_categories_ipath_status` (`ipath`,`status`);

--
-- Indexes for table `categories_mapmeta`
--
ALTER TABLE `categories_mapmeta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_categories_mapmeta` (`meta_id`);

--
-- Indexes for table `categories_mapobj`
--
ALTER TABLE `categories_mapobj`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_categories_mapobj` (`modname`,`tablename`,`obj_id`,`obj_idcolumn`);

--
-- Indexes for table `categories_registry`
--
ALTER TABLE `categories_registry`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_categories_registry` (`modname`,`tablename`,`property`);

--
-- Indexes for table `clip_grouptypes`
--
ALTER TABLE `clip_grouptypes`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `clip_pubdata1`
--
ALTER TABLE `clip_pubdata1`
  ADD PRIMARY KEY (`id`),
  ADD KEY `urltitle_index` (`urltitle`);

--
-- Indexes for table `clip_pubdata2`
--
ALTER TABLE `clip_pubdata2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `urltitle_index` (`urltitle`);

--
-- Indexes for table `clip_pubdata3`
--
ALTER TABLE `clip_pubdata3`
  ADD PRIMARY KEY (`id`),
  ADD KEY `urltitle_index` (`urltitle`);

--
-- Indexes for table `clip_pubfields`
--
ALTER TABLE `clip_pubfields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clip_pubtypes`
--
ALTER TABLE `clip_pubtypes`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `clip_relations`
--
ALTER TABLE `clip_relations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clip_workflowvars`
--
ALTER TABLE `clip_workflowvars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content_content`
--
ALTER TABLE `content_content`
  ADD PRIMARY KEY (`con_id`),
  ADD KEY `pageActive` (`con_pageid`,`con_active`),
  ADD KEY `pagePosition` (`con_pageid`,`con_areaindex`,`con_position`);

--
-- Indexes for table `content_history`
--
ALTER TABLE `content_history`
  ADD PRIMARY KEY (`ch_id`),
  ADD KEY `entry` (`ch_pageid`,`ch_revisionno`),
  ADD KEY `action` (`ch_action`);

--
-- Indexes for table `content_page`
--
ALTER TABLE `content_page`
  ADD PRIMARY KEY (`page_id`),
  ADD KEY `parentPageId` (`page_ppid`,`page_pos`),
  ADD KEY `leftright` (`page_setleft`,`page_setright`),
  ADD KEY `categoryId` (`page_categoryid`),
  ADD KEY `urlname` (`page_urlname`,`page_ppid`);

--
-- Indexes for table `content_pagecategory`
--
ALTER TABLE `content_pagecategory`
  ADD KEY `pageId` (`con_pageid`);

--
-- Indexes for table `content_searchable`
--
ALTER TABLE `content_searchable`
  ADD PRIMARY KEY (`search_cid`);

--
-- Indexes for table `content_translatedcontent`
--
ALTER TABLE `content_translatedcontent`
  ADD KEY `entry` (`transc_cid`,`transc_lang`);

--
-- Indexes for table `content_translatedpage`
--
ALTER TABLE `content_translatedpage`
  ADD KEY `entry` (`transp_pid`,`transp_lang`);

--
-- Indexes for table `faqanswer`
--
ALTER TABLE `faqanswer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fconnect`
--
ALTER TABLE `fconnect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `google`
--
ALTER TABLE `google`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `group_applications`
--
ALTER TABLE `group_applications`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `group_membership`
--
ALTER TABLE `group_membership`
  ADD KEY `gid_uid` (`uid`,`gid`);

--
-- Indexes for table `group_perms`
--
ALTER TABLE `group_perms`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `hook_area`
--
ALTER TABLE `hook_area`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `areaidx` (`areaname`);

--
-- Indexes for table `hook_binding`
--
ALTER TABLE `hook_binding`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sortidx` (`sareaid`);

--
-- Indexes for table `hook_provider`
--
ALTER TABLE `hook_provider`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nameidx` (`pareaid`,`hooktype`);

--
-- Indexes for table `hook_runtime`
--
ALTER TABLE `hook_runtime`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hook_subscriber`
--
ALTER TABLE `hook_subscriber`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `myindex` (`eventname`);

--
-- Indexes for table `hooks`
--
ALTER TABLE `hooks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `smodule` (`smodule`),
  ADD KEY `smodule_tmodule` (`smodule`,`tmodule`);

--
-- Indexes for table `markers`
--
ALTER TABLE `markers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `module_deps`
--
ALTER TABLE `module_deps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `module_vars`
--
ALTER TABLE `module_vars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mod_var` (`modname`,`name`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `state` (`state`),
  ADD KEY `mod_state` (`name`,`state`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `objectdata_attributes`
--
ALTER TABLE `objectdata_attributes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `object_type` (`object_type`),
  ADD KEY `object_id` (`object_id`);

--
-- Indexes for table `objectdata_log`
--
ALTER TABLE `objectdata_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `objectdata_meta`
--
ALTER TABLE `objectdata_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sc_intrusion`
--
ALTER TABLE `sc_intrusion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scribite`
--
ALTER TABLE `scribite`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `search_result`
--
ALTER TABLE `search_result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`),
  ADD KEY `module` (`module`);

--
-- Indexes for table `search_stat`
--
ALTER TABLE `search_stat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session_info`
--
ALTER TABLE `session_info`
  ADD PRIMARY KEY (`sessid`);

--
-- Indexes for table `shoppr_city`
--
ALTER TABLE `shoppr_city`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoppr_cityshops`
--
ALTER TABLE `shoppr_cityshops`
  ADD PRIMARY KEY (`shopproducts_entity_city_id`,`shopproducts_entity_shop_id`),
  ADD KEY `IDX_461C0BDC8DE19613` (`shopproducts_entity_city_id`),
  ADD KEY `IDX_461C0BDC4B5B3061` (`shopproducts_entity_shop_id`);

--
-- Indexes for table `shoppr_product`
--
ALTER TABLE `shoppr_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoppr_shop`
--
ALTER TABLE `shoppr_shop`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shoppr_shopproducts`
--
ALTER TABLE `shoppr_shopproducts`
  ADD PRIMARY KEY (`shopproducts_entity_shop_id`,`shopproducts_entity_product_id`),
  ADD KEY `IDX_7B82D0C4B5B3061` (`shopproducts_entity_shop_id`),
  ADD KEY `IDX_7B82D0CF17D78BC` (`shopproducts_entity_product_id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `twitter_login`
--
ALTER TABLE `twitter_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_property`
--
ALTER TABLE `user_property`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prop_label` (`label`),
  ADD KEY `prop_attr` (`attributename`);

--
-- Indexes for table `userblocks`
--
ALTER TABLE `userblocks`
  ADD KEY `bid_uid_idx` (`uid`,`bid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `uname` (`uname`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `users_verifychg`
--
ALTER TABLE `users_verifychg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workflows`
--
ALTER TABLE `workflows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `obj_table` (`obj_table`),
  ADD KEY `obj_idcolumn` (`obj_idcolumn`),
  ADD KEY `obj_id` (`obj_id`);

--
-- Indexes for table `zmap`
--
ALTER TABLE `zmap`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `zmap_projects`
--
ALTER TABLE `zmap_projects`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `zmap_roadmap`
--
ALTER TABLE `zmap_roadmap`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `zpayment_cards_accepted`
--
ALTER TABLE `zpayment_cards_accepted`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_directpay_settings`
--
ALTER TABLE `zpayment_directpay_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_epay`
--
ALTER TABLE `zpayment_epay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_epay_settings`
--
ALTER TABLE `zpayment_epay_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_freight_settings`
--
ALTER TABLE `zpayment_freight_settings`
  ADD PRIMARY KEY (`freight_id`);

--
-- Indexes for table `zpayment_netaxept`
--
ALTER TABLE `zpayment_netaxept`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_netaxept_settings`
--
ALTER TABLE `zpayment_netaxept_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_paypal`
--
ALTER TABLE `zpayment_paypal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_paypal_settings`
--
ALTER TABLE `zpayment_paypal_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_quickpay`
--
ALTER TABLE `zpayment_quickpay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zpayment_quickpay_settings`
--
ALTER TABLE `zpayment_quickpay_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zselex`
--
ALTER TABLE `zselex`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `zselex_advertise`
--
ALTER TABLE `zselex_advertise`
  ADD PRIMARY KEY (`advertise_id`),
  ADD KEY `shop_id` (`shop_id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `region_id` (`region_id`),
  ADD KEY `city_id` (`city_id`),
  ADD KEY `area_id` (`area_id`),
  ADD KEY `IDX_21CC8E486F16CF1E` (`adprice_id`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `zselex_advertise_price`
--
ALTER TABLE `zselex_advertise_price`
  ADD PRIMARY KEY (`adprice_id`),
  ADD KEY `identifier` (`identifier`);

--
-- Indexes for table `zselex_area`
--
ALTER TABLE `zselex_area`
  ADD PRIMARY KEY (`area_id`),
  ADD KEY `IDX_89A8A29F8BAC62AF` (`city_id`),
  ADD KEY `IDX_89A8A29F98260155` (`region_id`),
  ADD KEY `IDX_89A8A29FF92F3E70` (`country_id`);
ALTER TABLE `zselex_area` ADD FULLTEXT KEY `area_name` (`area_name`);

--
-- Indexes for table `zselex_article_ads`
--
ALTER TABLE `zselex_article_ads`
  ADD PRIMARY KEY (`articlead_id`);

--
-- Indexes for table `zselex_basket`
--
ALTER TABLE `zselex_basket`
  ADD PRIMARY KEY (`basket_id`),
  ADD KEY `IDX_190BF7E8EC942BCF` (`plugin_id`),
  ADD KEY `IDX_190BF7E84D16C4DD` (`shop_id`),
  ADD KEY `IDX_190BF7E8F1FAD9D3` (`bundle_id`);

--
-- Indexes for table `zselex_branch`
--
ALTER TABLE `zselex_branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `zselex_cart`
--
ALTER TABLE `zselex_cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `IDX_559F17404584665A` (`product_id`),
  ADD KEY `IDX_559F17404D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_category`
--
ALTER TABLE `zselex_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `zselex_city`
--
ALTER TABLE `zselex_city`
  ADD PRIMARY KEY (`city_id`),
  ADD KEY `region_id` (`region_id`),
  ADD KEY `country_id` (`country_id`);
ALTER TABLE `zselex_city` ADD FULLTEXT KEY `city_name` (`city_name`);

--
-- Indexes for table `zselex_country`
--
ALTER TABLE `zselex_country`
  ADD PRIMARY KEY (`country_id`);
ALTER TABLE `zselex_country` ADD FULLTEXT KEY `country_name` (`country_name`);
ALTER TABLE `zselex_country` ADD FULLTEXT KEY `country_name_2` (`country_name`);
ALTER TABLE `zselex_country` ADD FULLTEXT KEY `country_name_3` (`country_name`);
ALTER TABLE `zselex_country` ADD FULLTEXT KEY `country_name_4` (`country_name`);
ALTER TABLE `zselex_country` ADD FULLTEXT KEY `country_name_5` (`country_name`);
ALTER TABLE `zselex_country` ADD FULLTEXT KEY `country_name_6` (`country_name`);
ALTER TABLE `zselex_country` ADD FULLTEXT KEY `country_name_7` (`country_name`);

--
-- Indexes for table `zselex_discounts`
--
ALTER TABLE `zselex_discounts`
  ADD PRIMARY KEY (`discount_id`),
  ADD KEY `IDX_EA2913294D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_dotd`
--
ALTER TABLE `zselex_dotd`
  ADD PRIMARY KEY (`dotdId`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_files`
--
ALTER TABLE `zselex_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_keywords`
--
ALTER TABLE `zselex_keywords`
  ADD PRIMARY KEY (`keyword_id`),
  ADD KEY `shop_id` (`shop_id`);
ALTER TABLE `zselex_keywords` ADD FULLTEXT KEY `keyword` (`keyword`);

--
-- Indexes for table `zselex_manufacturer`
--
ALTER TABLE `zselex_manufacturer`
  ADD PRIMARY KEY (`manufacturer_id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_minishop`
--
ALTER TABLE `zselex_minishop`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_ministe_updates`
--
ALTER TABLE `zselex_ministe_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zselex_newsletter`
--
ALTER TABLE `zselex_newsletter`
  ADD PRIMARY KEY (`nl_id`);

--
-- Indexes for table `zselex_order`
--
ALTER TABLE `zselex_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D6AEC8B84D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_orderitems`
--
ALTER TABLE `zselex_orderitems`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `shop_id` (`shop_id`),
  ADD KEY `IDX_76D47E824584665A` (`product_id`);

--
-- Indexes for table `zselex_parent`
--
ALTER TABLE `zselex_parent`
  ADD PRIMARY KEY (`tableId`);

--
-- Indexes for table `zselex_paypal`
--
ALTER TABLE `zselex_paypal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zselex_plugin`
--
ALTER TABLE `zselex_plugin`
  ADD PRIMARY KEY (`plugin_id`);

--
-- Indexes for table `zselex_product_categories`
--
ALTER TABLE `zselex_product_categories`
  ADD PRIMARY KEY (`prd_cat_id`),
  ADD KEY `IDX_ADB3347B4D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_product_options`
--
ALTER TABLE `zselex_product_options`
  ADD PRIMARY KEY (`option_id`),
  ADD KEY `IDX_191D928E4D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_product_options_values`
--
ALTER TABLE `zselex_product_options_values`
  ADD PRIMARY KEY (`option_value_id`),
  ADD KEY `IDX_FE72C6A4A7C41D6F` (`option_id`),
  ADD KEY `IDX_FE72C6A44D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_product_quantity_discount`
--
ALTER TABLE `zselex_product_quantity_discount`
  ADD PRIMARY KEY (`discount_id`),
  ADD KEY `IDX_F9C15F854584665A` (`product_id`);

--
-- Indexes for table `zselex_product_to_category`
--
ALTER TABLE `zselex_product_to_category`
  ADD PRIMARY KEY (`product_id`,`prd_cat_id`),
  ADD KEY `IDX_4F3C86C34584665A` (`product_id`),
  ADD KEY `IDX_4F3C86C31DC53942` (`prd_cat_id`);

--
-- Indexes for table `zselex_product_to_options`
--
ALTER TABLE `zselex_product_to_options`
  ADD PRIMARY KEY (`product_to_options_id`),
  ADD KEY `IDX_C9EDB5614584665A` (`product_id`),
  ADD KEY `IDX_C9EDB561A7C41D6F` (`option_id`);

--
-- Indexes for table `zselex_product_to_options_values`
--
ALTER TABLE `zselex_product_to_options_values`
  ADD PRIMARY KEY (`product_to_options_value_id`),
  ADD KEY `IDX_7F53CC10C705FB7E` (`product_to_options_id`),
  ADD KEY `IDX_7F53CC104584665A` (`product_id`),
  ADD KEY `IDX_7F53CC10A7C41D6F` (`option_id`);

--
-- Indexes for table `zselex_products`
--
ALTER TABLE `zselex_products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `shop_id` (`shop_id`),
  ADD KEY `IDX_A1648E85A23B42D` (`manufacturer_id`),
  ADD KEY `urltitle` (`urltitle`),
  ADD KEY `prd_status` (`prd_status`,`shop_id`,`advertise`);

--
-- Indexes for table `zselex_region`
--
ALTER TABLE `zselex_region`
  ADD PRIMARY KEY (`region_id`),
  ADD KEY `country_id` (`country_id`);
ALTER TABLE `zselex_region` ADD FULLTEXT KEY `region_name` (`region_name`);

--
-- Indexes for table `zselex_service_bundle_items`
--
ALTER TABLE `zselex_service_bundle_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_F7AACDAAF1FAD9D3` (`bundle_id`),
  ADD KEY `IDX_F7AACDAAEC942BCF` (`plugin_id`);

--
-- Indexes for table `zselex_service_bundles`
--
ALTER TABLE `zselex_service_bundles`
  ADD PRIMARY KEY (`bundle_id`);

--
-- Indexes for table `zselex_service_config`
--
ALTER TABLE `zselex_service_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zselex_service_demo`
--
ALTER TABLE `zselex_service_demo`
  ADD PRIMARY KEY (`demo_id`),
  ADD KEY `IDX_B4C6B64D16C4DD` (`shop_id`),
  ADD KEY `IDX_B4C6B6F1FAD9D3` (`bundle_id`),
  ADD KEY `search` (`shop_id`,`bundle_id`);

--
-- Indexes for table `zselex_service_identifiers`
--
ALTER TABLE `zselex_service_identifiers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `zselex_service_order`
--
ALTER TABLE `zselex_service_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zselex_service_orderitems`
--
ALTER TABLE `zselex_service_orderitems`
  ADD PRIMARY KEY (`order_item_id`);

--
-- Indexes for table `zselex_serviceapproval`
--
ALTER TABLE `zselex_serviceapproval`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zselex_serviceshop`
--
ALTER TABLE `zselex_serviceshop`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shop_id` (`shop_id`),
  ADD KEY `IDX_C1BBABF8EC942BCF` (`plugin_id`),
  ADD KEY `search` (`shop_id`,`type`),
  ADD KEY `IDX_C1BBABF8F1FAD9D3` (`bundle_id`);

--
-- Indexes for table `zselex_serviceshop_bundles`
--
ALTER TABLE `zselex_serviceshop_bundles`
  ADD PRIMARY KEY (`service_bundle_id`),
  ADD KEY `IDX_61B57153F1FAD9D3` (`bundle_id`),
  ADD KEY `IDX_61B571534D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_shop`
--
ALTER TABLE `zselex_shop`
  ADD PRIMARY KEY (`shop_id`),
  ADD KEY `country_id` (`country_id`),
  ADD KEY `region_id` (`region_id`),
  ADD KEY `city_id` (`city_id`),
  ADD KEY `area_id` (`area_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `search` (`country_id`,`region_id`,`city_id`,`area_id`),
  ADD KEY `urltitle` (`urltitle`(333)),
  ADD KEY `IDX_F256D355E3554B4C` (`aff_id`);
ALTER TABLE `zselex_shop` ADD FULLTEXT KEY `shop_name` (`shop_name`);
ALTER TABLE `zselex_shop` ADD FULLTEXT KEY `address` (`address`);

--
-- Indexes for table `zselex_shop_a_settings`
--
ALTER TABLE `zselex_shop_a_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zselex_shop_admins`
--
ALTER TABLE `zselex_shop_admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_shop_affiliation`
--
ALTER TABLE `zselex_shop_affiliation`
  ADD PRIMARY KEY (`aff_id`);

--
-- Indexes for table `zselex_shop_announcement`
--
ALTER TABLE `zselex_shop_announcement`
  ADD PRIMARY KEY (`ann_id`),
  ADD KEY `IDX_ACD793084D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_shop_banner`
--
ALTER TABLE `zselex_shop_banner`
  ADD PRIMARY KEY (`shop_banner_id`),
  ADD KEY `IDX_E8D513B24D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_shop_banner_settings`
--
ALTER TABLE `zselex_shop_banner_settings`
  ADD PRIMARY KEY (`ban_set_id`),
  ADD KEY `IDX_5CCF8E7B4D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_shop_config`
--
ALTER TABLE `zselex_shop_config`
  ADD PRIMARY KEY (`shopconfigId`);

--
-- Indexes for table `zselex_shop_details`
--
ALTER TABLE `zselex_shop_details`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `zselex_shop_employees`
--
ALTER TABLE `zselex_shop_employees`
  ADD PRIMARY KEY (`emp_id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_shop_event_temp`
--
ALTER TABLE `zselex_shop_event_temp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_761A57FE71F7E88B` (`event_id`),
  ADD KEY `IDX_761A57FE4D16C4DD` (`shop_id`),
  ADD KEY `event_date` (`event_date`);

--
-- Indexes for table `zselex_shop_events`
--
ALTER TABLE `zselex_shop_events`
  ADD PRIMARY KEY (`shop_event_id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_shop_gallery`
--
ALTER TABLE `zselex_shop_gallery`
  ADD PRIMARY KEY (`gallery_id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_shop_news`
--
ALTER TABLE `zselex_shop_news`
  ADD PRIMARY KEY (`shop_news_id`);

--
-- Indexes for table `zselex_shop_owners`
--
ALTER TABLE `zselex_shop_owners`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_shop_owners_theme`
--
ALTER TABLE `zselex_shop_owners_theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zselex_shop_pdf`
--
ALTER TABLE `zselex_shop_pdf`
  ADD PRIMARY KEY (`pdf_id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_shop_ratings`
--
ALTER TABLE `zselex_shop_ratings`
  ADD PRIMARY KEY (`rating_id`),
  ADD KEY `shop_id` (`shop_id`);

--
-- Indexes for table `zselex_shop_settings`
--
ALTER TABLE `zselex_shop_settings`
  ADD PRIMARY KEY (`idSettings`);

--
-- Indexes for table `zselex_shop_to_branch`
--
ALTER TABLE `zselex_shop_to_branch`
  ADD PRIMARY KEY (`shop_id`,`branch_id`),
  ADD KEY `IDX_C2D757DE4D16C4DD` (`shop_id`),
  ADD KEY `IDX_C2D757DEDCD6CC49` (`branch_id`);

--
-- Indexes for table `zselex_shop_to_category`
--
ALTER TABLE `zselex_shop_to_category`
  ADD PRIMARY KEY (`shop_id`,`category_id`),
  ADD KEY `IDX_ABC78B244D16C4DD` (`shop_id`),
  ADD KEY `IDX_ABC78B2412469DE2` (`category_id`);

--
-- Indexes for table `zselex_shop_types`
--
ALTER TABLE `zselex_shop_types`
  ADD PRIMARY KEY (`shoptype_id`);

--
-- Indexes for table `zselex_social_links`
--
ALTER TABLE `zselex_social_links`
  ADD PRIMARY KEY (`socl_link_id`);

--
-- Indexes for table `zselex_social_links_shop`
--
ALTER TABLE `zselex_social_links_shop`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_1CC23A6ED7640633` (`socl_link_id`),
  ADD KEY `IDX_1CC23A6E4D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_social_links_shop_settings`
--
ALTER TABLE `zselex_social_links_shop_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_64BFBC644D16C4DD` (`shop_id`);

--
-- Indexes for table `zselex_themes`
--
ALTER TABLE `zselex_themes`
  ADD PRIMARY KEY (`zt_id`);

--
-- Indexes for table `zselex_type`
--
ALTER TABLE `zselex_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `zselex_urls`
--
ALTER TABLE `zselex_urls`
  ADD PRIMARY KEY (`url_id`),
  ADD KEY `search_url` (`type`,`url`);

--
-- Indexes for table `zselex_zenshop`
--
ALTER TABLE `zselex_zenshop`
  ADD PRIMARY KEY (`zen_id`);

--
-- Indexes for table `zseleximport`
--
ALTER TABLE `zseleximport`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ztext_pages`
--
ALTER TABLE `ztext_pages`
  ADD PRIMARY KEY (`text_id`),
  ADD KEY `IDX_E2408CC54D16C4DD` (`shop_id`);

--
-- Indexes for table `ztext_settings`
--
ALTER TABLE `ztext_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_B5907A4C4D16C4DD` (`shop_id`);

--
-- Indexes for table `zvelo_bicycle`
--
ALTER TABLE `zvelo_bicycle`
  ADD PRIMARY KEY (`bicycle_id`);

--
-- Indexes for table `zvelo_customer`
--
ALTER TABLE `zvelo_customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `zvelo_customer_ergonomic_value`
--
ALTER TABLE `zvelo_customer_ergonomic_value`
  ADD PRIMARY KEY (`ergonomic_value_id`),
  ADD KEY `IDX_D8C084E39395C3F3` (`customer_id`),
  ADD KEY `IDX_D8C084E3A69645CF` (`bicycle_id`);

--
-- Indexes for table `zvelo_customer_measurement`
--
ALTER TABLE `zvelo_customer_measurement`
  ADD PRIMARY KEY (`measurement_id`),
  ADD KEY `IDX_4CDBD3AF9395C3F3` (`customer_id`);

--
-- Indexes for table `zvelo_customer_wish`
--
ALTER TABLE `zvelo_customer_wish`
  ADD PRIMARY KEY (`wish_id`),
  ADD KEY `IDX_EAF2D1049395C3F3` (`customer_id`),
  ADD KEY `IDX_EAF2D104A69645CF` (`bicycle_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_category`
--
ALTER TABLE `admin_category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `admin_module`
--
ALTER TABLE `admin_module`
  MODIFY `amid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `block_positions`
--
ALTER TABLE `block_positions`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
--
-- AUTO_INCREMENT for table `blocks`
--
ALTER TABLE `blocks`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;
--
-- AUTO_INCREMENT for table `categories_category`
--
ALTER TABLE `categories_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10014;
--
-- AUTO_INCREMENT for table `categories_mapmeta`
--
ALTER TABLE `categories_mapmeta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories_mapobj`
--
ALTER TABLE `categories_mapobj`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `categories_registry`
--
ALTER TABLE `categories_registry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `clip_grouptypes`
--
ALTER TABLE `clip_grouptypes`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `clip_pubdata1`
--
ALTER TABLE `clip_pubdata1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `clip_pubdata2`
--
ALTER TABLE `clip_pubdata2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `clip_pubdata3`
--
ALTER TABLE `clip_pubdata3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `clip_pubfields`
--
ALTER TABLE `clip_pubfields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `clip_pubtypes`
--
ALTER TABLE `clip_pubtypes`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `clip_relations`
--
ALTER TABLE `clip_relations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `clip_workflowvars`
--
ALTER TABLE `clip_workflowvars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `content_content`
--
ALTER TABLE `content_content`
  MODIFY `con_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `content_history`
--
ALTER TABLE `content_history`
  MODIFY `ch_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `content_page`
--
ALTER TABLE `content_page`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `content_searchable`
--
ALTER TABLE `content_searchable`
  MODIFY `search_cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `faqanswer`
--
ALTER TABLE `faqanswer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fconnect`
--
ALTER TABLE `fconnect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `google`
--
ALTER TABLE `google`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `group_applications`
--
ALTER TABLE `group_applications`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `group_perms`
--
ALTER TABLE `group_perms`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `hook_area`
--
ALTER TABLE `hook_area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `hook_binding`
--
ALTER TABLE `hook_binding`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `hook_provider`
--
ALTER TABLE `hook_provider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `hook_runtime`
--
ALTER TABLE `hook_runtime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `hook_subscriber`
--
ALTER TABLE `hook_subscriber`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `hooks`
--
ALTER TABLE `hooks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `markers`
--
ALTER TABLE `markers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `module_deps`
--
ALTER TABLE `module_deps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2707;
--
-- AUTO_INCREMENT for table `module_vars`
--
ALTER TABLE `module_vars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=489;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `objectdata_attributes`
--
ALTER TABLE `objectdata_attributes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=940;
--
-- AUTO_INCREMENT for table `objectdata_log`
--
ALTER TABLE `objectdata_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `objectdata_meta`
--
ALTER TABLE `objectdata_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sc_intrusion`
--
ALTER TABLE `sc_intrusion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `scribite`
--
ALTER TABLE `scribite`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `search_result`
--
ALTER TABLE `search_result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1783;
--
-- AUTO_INCREMENT for table `search_stat`
--
ALTER TABLE `search_stat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT for table `shoppr_city`
--
ALTER TABLE `shoppr_city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `shoppr_product`
--
ALTER TABLE `shoppr_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `shoppr_shop`
--
ALTER TABLE `shoppr_shop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `twitter_login`
--
ALTER TABLE `twitter_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `user_property`
--
ALTER TABLE `user_property`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;
--
-- AUTO_INCREMENT for table `users_verifychg`
--
ALTER TABLE `users_verifychg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `workflows`
--
ALTER TABLE `workflows`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zmap`
--
ALTER TABLE `zmap`
  MODIFY `bid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zmap_projects`
--
ALTER TABLE `zmap_projects`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `zmap_roadmap`
--
ALTER TABLE `zmap_roadmap`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=192;
--
-- AUTO_INCREMENT for table `zpayment_cards_accepted`
--
ALTER TABLE `zpayment_cards_accepted`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zpayment_directpay_settings`
--
ALTER TABLE `zpayment_directpay_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zpayment_epay`
--
ALTER TABLE `zpayment_epay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `zpayment_epay_settings`
--
ALTER TABLE `zpayment_epay_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zpayment_freight_settings`
--
ALTER TABLE `zpayment_freight_settings`
  MODIFY `freight_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zpayment_netaxept`
--
ALTER TABLE `zpayment_netaxept`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
--
-- AUTO_INCREMENT for table `zpayment_netaxept_settings`
--
ALTER TABLE `zpayment_netaxept_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zpayment_paypal`
--
ALTER TABLE `zpayment_paypal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `zpayment_paypal_settings`
--
ALTER TABLE `zpayment_paypal_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zpayment_quickpay`
--
ALTER TABLE `zpayment_quickpay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `zpayment_quickpay_settings`
--
ALTER TABLE `zpayment_quickpay_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zselex`
--
ALTER TABLE `zselex`
  MODIFY `bid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zselex_advertise`
--
ALTER TABLE `zselex_advertise`
  MODIFY `advertise_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `zselex_advertise_price`
--
ALTER TABLE `zselex_advertise_price`
  MODIFY `adprice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zselex_area`
--
ALTER TABLE `zselex_area`
  MODIFY `area_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zselex_article_ads`
--
ALTER TABLE `zselex_article_ads`
  MODIFY `articlead_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zselex_basket`
--
ALTER TABLE `zselex_basket`
  MODIFY `basket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;
--
-- AUTO_INCREMENT for table `zselex_branch`
--
ALTER TABLE `zselex_branch`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zselex_cart`
--
ALTER TABLE `zselex_cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `zselex_category`
--
ALTER TABLE `zselex_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zselex_city`
--
ALTER TABLE `zselex_city`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `zselex_country`
--
ALTER TABLE `zselex_country`
  MODIFY `country_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=249;
--
-- AUTO_INCREMENT for table `zselex_discounts`
--
ALTER TABLE `zselex_discounts`
  MODIFY `discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zselex_dotd`
--
ALTER TABLE `zselex_dotd`
  MODIFY `dotdId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `zselex_files`
--
ALTER TABLE `zselex_files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=275;
--
-- AUTO_INCREMENT for table `zselex_keywords`
--
ALTER TABLE `zselex_keywords`
  MODIFY `keyword_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=263;
--
-- AUTO_INCREMENT for table `zselex_manufacturer`
--
ALTER TABLE `zselex_manufacturer`
  MODIFY `manufacturer_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `zselex_minishop`
--
ALTER TABLE `zselex_minishop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `zselex_ministe_updates`
--
ALTER TABLE `zselex_ministe_updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `zselex_newsletter`
--
ALTER TABLE `zselex_newsletter`
  MODIFY `nl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `zselex_order`
--
ALTER TABLE `zselex_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=394;
--
-- AUTO_INCREMENT for table `zselex_orderitems`
--
ALTER TABLE `zselex_orderitems`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=557;
--
-- AUTO_INCREMENT for table `zselex_parent`
--
ALTER TABLE `zselex_parent`
  MODIFY `tableId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=543;
--
-- AUTO_INCREMENT for table `zselex_paypal`
--
ALTER TABLE `zselex_paypal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zselex_plugin`
--
ALTER TABLE `zselex_plugin`
  MODIFY `plugin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `zselex_product_categories`
--
ALTER TABLE `zselex_product_categories`
  MODIFY `prd_cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `zselex_product_options`
--
ALTER TABLE `zselex_product_options`
  MODIFY `option_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `zselex_product_options_values`
--
ALTER TABLE `zselex_product_options_values`
  MODIFY `option_value_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `zselex_product_quantity_discount`
--
ALTER TABLE `zselex_product_quantity_discount`
  MODIFY `discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `zselex_product_to_options`
--
ALTER TABLE `zselex_product_to_options`
  MODIFY `product_to_options_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `zselex_product_to_options_values`
--
ALTER TABLE `zselex_product_to_options_values`
  MODIFY `product_to_options_value_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;
--
-- AUTO_INCREMENT for table `zselex_products`
--
ALTER TABLE `zselex_products`
  MODIFY `product_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=373;
--
-- AUTO_INCREMENT for table `zselex_region`
--
ALTER TABLE `zselex_region`
  MODIFY `region_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `zselex_service_bundle_items`
--
ALTER TABLE `zselex_service_bundle_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=669;
--
-- AUTO_INCREMENT for table `zselex_service_bundles`
--
ALTER TABLE `zselex_service_bundles`
  MODIFY `bundle_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `zselex_service_config`
--
ALTER TABLE `zselex_service_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;
--
-- AUTO_INCREMENT for table `zselex_service_demo`
--
ALTER TABLE `zselex_service_demo`
  MODIFY `demo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `zselex_service_identifiers`
--
ALTER TABLE `zselex_service_identifiers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `zselex_service_order`
--
ALTER TABLE `zselex_service_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `zselex_service_orderitems`
--
ALTER TABLE `zselex_service_orderitems`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `zselex_serviceapproval`
--
ALTER TABLE `zselex_serviceapproval`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;
--
-- AUTO_INCREMENT for table `zselex_serviceshop`
--
ALTER TABLE `zselex_serviceshop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4898;
--
-- AUTO_INCREMENT for table `zselex_serviceshop_bundles`
--
ALTER TABLE `zselex_serviceshop_bundles`
  MODIFY `service_bundle_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `zselex_shop`
--
ALTER TABLE `zselex_shop`
  MODIFY `shop_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;
--
-- AUTO_INCREMENT for table `zselex_shop_a_settings`
--
ALTER TABLE `zselex_shop_a_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `zselex_shop_admins`
--
ALTER TABLE `zselex_shop_admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `zselex_shop_affiliation`
--
ALTER TABLE `zselex_shop_affiliation`
  MODIFY `aff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zselex_shop_announcement`
--
ALTER TABLE `zselex_shop_announcement`
  MODIFY `ann_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `zselex_shop_banner`
--
ALTER TABLE `zselex_shop_banner`
  MODIFY `shop_banner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;
--
-- AUTO_INCREMENT for table `zselex_shop_banner_settings`
--
ALTER TABLE `zselex_shop_banner_settings`
  MODIFY `ban_set_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zselex_shop_config`
--
ALTER TABLE `zselex_shop_config`
  MODIFY `shopconfigId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `zselex_shop_employees`
--
ALTER TABLE `zselex_shop_employees`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `zselex_shop_event_temp`
--
ALTER TABLE `zselex_shop_event_temp`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT for table `zselex_shop_events`
--
ALTER TABLE `zselex_shop_events`
  MODIFY `shop_event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
--
-- AUTO_INCREMENT for table `zselex_shop_gallery`
--
ALTER TABLE `zselex_shop_gallery`
  MODIFY `gallery_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `zselex_shop_news`
--
ALTER TABLE `zselex_shop_news`
  MODIFY `shop_news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `zselex_shop_owners`
--
ALTER TABLE `zselex_shop_owners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `zselex_shop_owners_theme`
--
ALTER TABLE `zselex_shop_owners_theme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `zselex_shop_pdf`
--
ALTER TABLE `zselex_shop_pdf`
  MODIFY `pdf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;
--
-- AUTO_INCREMENT for table `zselex_shop_ratings`
--
ALTER TABLE `zselex_shop_ratings`
  MODIFY `rating_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `zselex_shop_settings`
--
ALTER TABLE `zselex_shop_settings`
  MODIFY `idSettings` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `zselex_shop_types`
--
ALTER TABLE `zselex_shop_types`
  MODIFY `shoptype_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zselex_social_links`
--
ALTER TABLE `zselex_social_links`
  MODIFY `socl_link_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zselex_social_links_shop`
--
ALTER TABLE `zselex_social_links_shop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zselex_social_links_shop_settings`
--
ALTER TABLE `zselex_social_links_shop_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zselex_themes`
--
ALTER TABLE `zselex_themes`
  MODIFY `zt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `zselex_type`
--
ALTER TABLE `zselex_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `zselex_urls`
--
ALTER TABLE `zselex_urls`
  MODIFY `url_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `zselex_zenshop`
--
ALTER TABLE `zselex_zenshop`
  MODIFY `zen_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zseleximport`
--
ALTER TABLE `zseleximport`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1136;
--
-- AUTO_INCREMENT for table `ztext_pages`
--
ALTER TABLE `ztext_pages`
  MODIFY `text_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `ztext_settings`
--
ALTER TABLE `ztext_settings`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zvelo_bicycle`
--
ALTER TABLE `zvelo_bicycle`
  MODIFY `bicycle_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zvelo_customer`
--
ALTER TABLE `zvelo_customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zvelo_customer_ergonomic_value`
--
ALTER TABLE `zvelo_customer_ergonomic_value`
  MODIFY `ergonomic_value_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zvelo_customer_measurement`
--
ALTER TABLE `zvelo_customer_measurement`
  MODIFY `measurement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zvelo_customer_wish`
--
ALTER TABLE `zvelo_customer_wish`
  MODIFY `wish_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `zvelo_customer_ergonomic_value`
--
ALTER TABLE `zvelo_customer_ergonomic_value`
  ADD CONSTRAINT `FK_D8C084E39395C3F3` FOREIGN KEY (`customer_id`) REFERENCES `zvelo_customer` (`customer_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_D8C084E3A69645CF` FOREIGN KEY (`bicycle_id`) REFERENCES `zvelo_bicycle` (`bicycle_id`);

--
-- Constraints for table `zvelo_customer_measurement`
--
ALTER TABLE `zvelo_customer_measurement`
  ADD CONSTRAINT `FK_4CDBD3AF9395C3F3` FOREIGN KEY (`customer_id`) REFERENCES `zvelo_customer` (`customer_id`) ON DELETE CASCADE;

--
-- Constraints for table `zvelo_customer_wish`
--
ALTER TABLE `zvelo_customer_wish`
  ADD CONSTRAINT `FK_EAF2D1049395C3F3` FOREIGN KEY (`customer_id`) REFERENCES `zvelo_customer` (`customer_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_EAF2D104A69645CF` FOREIGN KEY (`bicycle_id`) REFERENCES `zvelo_bicycle` (`bicycle_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
